(function(sttc) {
    'use strict';
    var aa, ba = Object.defineProperty,
        ca = globalThis,
        da = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        ea = {},
        fa = {};

    function ha(a, b, c) {
        if (!c || a != null) {
            c = fa[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function ja(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in ea ? f = ea : f = ca;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = da && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? ba(ea, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (fa[d] === void 0 && (a = Math.random() * 1E9 >>> 0, fa[d] = da ? ca.Symbol(d) : "$jscp$" + a + "$" + d), ba(f, fa[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    var ka = Object.create,
        la = Object.setPrototypeOf;

    function oa(a, b) {
        a.prototype = ka(b.prototype);
        a.prototype.constructor = a;
        la(a, b);
        a.Sk = b.prototype
    }
    ja("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    ja("String.prototype.replaceAll", function(a) {
        return a ? a : function(b, c) {
            if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
            return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
        }
    }, "es_2021");
    ja("AggregateError", function(a) {
        function b(c, d) {
            d = Error(d);
            "stack" in d && (this.stack = d.stack);
            this.errors = c;
            this.message = d.message
        }
        if (a) return a;
        oa(b, Error);
        b.prototype.name = "AggregateError";
        return b
    }, "es_2021");
    ja("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : Array.from(b);
            return Promise.all(b.map(function(c) {
                return Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new ea.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var q = this || self;

    function pa(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function qa(a) {
        var b = pa(a);
        return b == "array" || b == "object" && typeof a.length == "number"
    }

    function ra(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function sa(a) {
        return Object.prototype.hasOwnProperty.call(a, ta) && a[ta] || (a[ta] = ++va)
    }
    var ta = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        va = 0;

    function wa(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function ya(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function za(a, b, c) {
        za = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? wa : ya;
        return za.apply(null, arguments)
    }

    function Aa(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function Ba(a, b, c) {
        a = a.split(".");
        c = c || q;
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function Ca(a) {
        return a
    }

    function Da(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.Sk = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.Mo = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    };
    var Fa = {
        Pn: 0,
        On: 1,
        Nn: 2
    };
    var Ga;

    function Ha(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Ia(a, b) {
        const c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Ja(a, b) {
        var c = a.length;
        const d = typeof a === "string" ? a.split("") : a;
        for (--c; c >= 0; --c) c in d && b.call(void 0, d[c], c, a)
    }

    function Ka(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function La(a, b) {
        const c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Ma(a, b) {
        let c = 1;
        Ia(a, function(d, e) {
            c = b.call(void 0, c, d, e, a)
        });
        return c
    }

    function Na(a, b) {
        const c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Pa(a, b) {
        return Ha(a, b) >= 0
    }

    function Qa(a, b) {
        b = Ha(a, b);
        let c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function Ra(a, b) {
        let c = 0;
        Ja(a, function(d, e) {
            b.call(void 0, d, e, a) && Array.prototype.splice.call(a, e, 1).length == 1 && c++
        })
    }

    function Sa(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function Ta(a) {
        const b = a.length;
        if (b > 0) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function Ua(a, b) {
        for (let c = 1; c < arguments.length; c++) {
            const d = arguments[c];
            if (qa(d)) {
                const e = a.length || 0,
                    f = d.length || 0;
                a.length = e + f;
                for (let g = 0; g < f; g++) a[e + g] = d[g]
            } else a.push(d)
        }
    }

    function Va(a, b, c) {
        return arguments.length <= 2 ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    }

    function Wa(a, b, c) {
        c = c || Xa;
        let d = 0,
            e = a.length,
            f;
        for (; d < e;) {
            const g = d + (e - d >>> 1);
            let h;
            h = c(b, a[g]);
            h > 0 ? d = g + 1 : (e = g, f = !h)
        }
        return f ? d : -d - 1
    }

    function Xa(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function Ya(a) {
        const b = [];
        for (let c = 0; c < arguments.length; c++) {
            const d = arguments[c];
            if (Array.isArray(d))
                for (let e = 0; e < d.length; e += 8192) {
                    const f = Ya.apply(null, Va(d, e, e + 8192));
                    for (let g = 0; g < f.length; g++) b.push(f[g])
                } else b.push(d)
        }
        return b
    }

    function Za(a, b) {
        b = b || Math.random;
        for (let c = a.length - 1; c > 0; c--) {
            const d = Math.floor(b() * (c + 1)),
                e = a[c];
            a[c] = a[d];
            a[d] = e
        }
    };
    var $a = {
        kl: "google_adtest",
        rl: "google_ad_client",
        Cl: "google_ad_intent_query",
        Bl: "google_ad_intent_qetid",
        Al: "google_ad_intent_eids",
        ul: "google_ad_format",
        wl: "google_ad_height",
        Ol: "google_ad_width",
        Dl: "google_ad_layout",
        El: "google_ad_layout_key",
        Gl: "google_ad_output",
        Hl: "google_ad_region",
        Kl: "google_ad_slot",
        Ml: "google_ad_type",
        Nl: "google_ad_url",
        vm: "google_gl",
        Dm: "google_enable_ose",
        Nm: "google_full_width_responsive",
        Sn: "google_rl_filtering",
        Rn: "google_rl_mode",
        Tn: "google_rt",
        Qn: "google_rl_dest_url",
        yn: "google_max_radlink_len",
        Dn: "google_num_radlinks",
        En: "google_num_radlinks_per_unit",
        ql: "google_ad_channel",
        xn: "google_max_num_ads",
        zn: "google_max_responsive_height",
        im: "google_color_border",
        Cm: "google_enable_content_recommendations",
        sm: "google_content_recommendation_ui_type",
        rm: "google_source_type",
        qm: "google_content_recommendation_rows_num",
        pm: "google_content_recommendation_columns_num",
        om: "google_content_recommendation_ad_positions",
        tm: "google_content_recommendation_use_square_imgs",
        km: "google_color_link",
        jm: "google_color_line",
        mm: "google_color_url",
        ll: "google_ad_block",
        Jl: "google_ad_section",
        ml: "google_ad_callback",
        fm: "google_captcha_token",
        lm: "google_color_text",
        am: "google_alternate_ad_url",
        zl: "google_ad_host_tier_id",
        gm: "google_city",
        xl: "google_ad_host",
        yl: "google_ad_host_channel",
        bm: "google_alternate_color",
        hm: "google_color_bg",
        Em: "google_encoding",
        Lm: "google_font_face",
        Pm: "google_hints",
        gn: "google_image_size",
        An: "google_mtl",
        so: "google_cpm",
        nm: "google_contents",
        Bn: "google_native_settings_key",
        um: "google_country",
        qo: "google_targeting",
        Mm: "google_font_size",
        Am: "google_disable_video_autoplay",
        Go: "google_video_product_type",
        Fo: "google_video_doc_id",
        Eo: "google_cust_gender",
        ko: "google_cust_lh",
        jo: "google_cust_l",
        ro: "google_tfs",
        on: "google_kw",
        no: "google_tag_for_child_directed_treatment",
        oo: "google_tag_for_under_age_of_consent",
        Vn: "google_region",
        xm: "google_cust_criteria",
        Il: "google_safe",
        wm: "google_ctr_threshold",
        Xn: "google_resizing_allowed",
        Zn: "google_resizing_width",
        Yn: "google_resizing_height",
        Do: "google_cust_age",
        sn: "google_language",
        qn: "google_kw_type",
        Kn: "google_pucrd",
        In: "google_page_url",
        po: "google_tag_partner",
        eo: "google_restrict_data_processing",
        fl: "google_adbreak_test",
        vl: "google_ad_frequency_hint",
        il: "google_admob_interstitial_slot",
        jl: "google_admob_rewarded_slot",
        gl: "google_admob_ads_only",
        Ll: "google_ad_start_delay_hint",
        wn: "google_max_ad_content_rating",
        Mn: "google_ad_public_floor",
        Ln: "google_ad_private_floor",
        Bo: "google_traffic_source",
        Gn: "google_overlays",
        Jn: "google_privacy_treatments",
        lo: "google_special_category_data",
        Ho: "google_wrap_fullscreen_ad",
        Fl: "google_ad_loaded_callback"
    };

    function ab() {
        return !1
    }

    function bb() {
        return !0
    }

    function cb(a) {
        const b = arguments,
            c = b.length;
        return function() {
            for (let d = 0; d < c; d++)
                if (!b[d].apply(this, arguments)) return !1;
            return !0
        }
    }

    function db(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function eb(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function fb(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    }

    function gb(a, b) {
        let c = 0;
        return function(d) {
            q.clearTimeout(c);
            const e = arguments;
            c = q.setTimeout(function() {
                a.apply(b, e)
            }, 63)
        }
    }

    function hb(a, b) {
        function c() {
            e = q.setTimeout(d, 63);
            let h = g;
            g = [];
            a.apply(b, h)
        }

        function d() {
            e = 0;
            f && (f = !1, c())
        }
        let e = 0,
            f = !1,
            g = [];
        return function(h) {
            g = arguments;
            e ? f = !0 : c()
        }
    };
    var ib = {
            passive: !0
        },
        jb = eb(function() {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
                q.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function kb(a) {
        return a ? a.passive && jb() ? a : a.capture || !1 : !1
    }

    function lb(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, kb(d)), !0) : !1
    }

    function mb(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, kb(d)), !0) : !1
    };
    var nb, ob;
    a: {
        for (var pb = ["CLOSURE_FLAGS"], qb = q, rb = 0; rb < pb.length; rb++)
            if (qb = qb[pb[rb]], qb == null) {
                ob = null;
                break a
            }
        ob = qb
    }
    var sb = ob && ob[610401301];
    nb = sb != null ? sb : !1;

    function tb(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function ub(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };

    function vb() {
        var a = q.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var wb;
    const xb = q.navigator;
    wb = xb ? xb.userAgentData || null : null;

    function yb(a) {
        return nb ? wb ? wb.brands.some(({
            brand: b
        }) => b && b.indexOf(a) != -1) : !1 : !1
    }

    function r(a) {
        return vb().indexOf(a) != -1
    };

    function zb() {
        return nb ? !!wb && wb.brands.length > 0 : !1
    }

    function Ab() {
        return zb() ? !1 : r("Opera")
    }

    function Bb() {
        return r("Firefox") || r("FxiOS")
    }

    function Db() {
        return r("Safari") && !(Eb() || (zb() ? 0 : r("Coast")) || Ab() || (zb() ? 0 : r("Edge")) || (zb() ? yb("Microsoft Edge") : r("Edg/")) || (zb() ? yb("Opera") : r("OPR")) || Bb() || r("Silk") || r("Android"))
    }

    function Eb() {
        return zb() ? yb("Chromium") : (r("Chrome") || r("CriOS")) && !(zb() ? 0 : r("Edge")) || r("Silk")
    }

    function Fb() {
        return r("Android") && !(Eb() || Bb() || Ab() || r("Silk"))
    };

    function Gb() {
        return nb && wb ? wb.mobile : !Hb() && (r("iPod") || r("iPhone") || r("Android") || r("IEMobile"))
    }

    function Hb() {
        return nb && wb ? !wb.mobile && (r("iPad") || r("Android") || r("Silk")) : r("iPad") || r("Android") && !r("Mobile") || r("Silk")
    };

    function Ib(a, b, c) {
        return Math.min(Math.max(a, b), c)
    }

    function Kb(a) {
        return Array.prototype.reduce.call(arguments, function(b, c) {
            return b + c
        }, 0)
    }

    function Lb(a) {
        return Kb.apply(null, arguments) / arguments.length
    };

    function Mb(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function Nb(a) {
        var b = Ob;
        a: {
            for (const c in b)
                if (b[c] == a) {
                    a = !0;
                    break a
                }
            a = !1
        }
        return a
    }

    function Pb(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function Qb(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    }
    const Rb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function Sb(a, b) {
        let c, d;
        for (let e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (let f = 0; f < Rb.length; f++) c = Rb[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };

    function Tb(a) {
        Tb[" "](a);
        return a
    }
    Tb[" "] = function() {};

    function Ub(a, b) {
        try {
            return Tb(a[b]), !0
        } catch (c) {}
        return !1
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    let Vb = globalThis.trustedTypes,
        Wb;

    function Xb() {
        let a = null;
        if (!Vb) return a;
        try {
            const b = c => c;
            a = Vb.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    }

    function Yb() {
        Wb === void 0 && (Wb = Xb());
        return Wb
    };
    var Zb = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function $b(a) {
        const b = Yb();
        return new Zb(b ? b.createScriptURL(a) : a)
    }

    function ac(a) {
        if (a instanceof Zb) return a.g;
        throw Error("");
    };
    var bc = class {
            constructor(a) {
                this.g = a
            }
            toString() {
                return this.g
            }
        },
        cc = new bc("about:invalid#zClosurez");

    function dc(a) {
        return a instanceof bc
    }

    function ec(a) {
        if (dc(a)) return a.g;
        throw Error("");
    };
    class fc {
        constructor(a) {
            this.bk = a
        }
    }

    function gc(a) {
        return new fc(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const hc = [gc("data"), gc("http"), gc("https"), gc("mailto"), gc("ftp"), new fc(a => /^[^:]*([/?#]|$)/.test(a))];

    function ic(a, b = hc) {
        if (dc(a)) return a;
        for (let c = 0; c < b.length; ++c) {
            const d = b[c];
            if (d instanceof fc && d.bk(a)) return new bc(a)
        }
    }
    var jc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function kc(a) {
        if (jc.test(a)) return a
    };

    function lc(a) {
        var b = kc("#");
        b !== void 0 && (a.href = b)
    };

    function mc(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    var nc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function oc(a) {
        const b = Yb();
        return new nc(b ? b.createHTML(a) : a)
    }

    function pc(a) {
        if (a instanceof nc) return a.g;
        throw Error("");
    };

    function qc(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function rc(a, b) {
        a.src = ac(b);
        (b = qc(a.ownerDocument)) && a.setAttribute("nonce", b)
    };
    var sc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function tc(a, b) {
        if (a.nodeType === 1 && /^(script|style)$/i.test(a.tagName)) throw Error("");
        a.innerHTML = pc(b)
    }

    function uc(a, b, c) {
        var d = [vc `width`, vc `height`];
        if (d.length === 0) throw Error("");
        d = d.map(f => {
            if (f instanceof sc) f = f.g;
            else throw Error("");
            return f
        });
        const e = b.toLowerCase();
        if (d.every(f => e.indexOf(f) !== 0)) throw Error(`Attribute "${b}" does not match any of the allowed prefixes.`);
        a.setAttribute(b, c)
    };
    var wc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function xc(a) {
        if (a instanceof wc) return a.g;
        throw Error("");
    };

    function yc(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };

    function zc(a, b) {
        const c = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        let d;
        d = b ? b.createElement("div") : q.document.createElement("div");
        return a.replace(Ac, function(e, f) {
            let g = c[e];
            if (g) return g;
            f.charAt(0) == "#" && (f = Number("0" + f.slice(1)), isNaN(f) || (g = String.fromCharCode(f)));
            g || (tc(d, oc(e + " ")), g = d.firstChild.nodeValue.slice(0, -1));
            return c[e] = g
        })
    }
    var Ac = /&([^;\s<&]+);?/g;

    function Bc(a) {
        let b = 0;
        for (let c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
        return b
    }

    function Cc(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function Dc(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var Ec = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    var Fc = zb() ? !1 : r("Trident") || r("MSIE"),
        Gc = r("Edge") || Fc,
        Hc = r("Gecko") && !(ub(vb(), "WebKit") && !r("Edge")) && !(r("Trident") || r("MSIE")) && !r("Edge"),
        Ic = ub(vb(), "WebKit") && !r("Edge");

    function vc(a) {
        return new sc(a[0].toLowerCase())
    };

    function Jc(a) {
        return new wc(a[0])
    };

    function Kc(a) {
        return a instanceof nc ? a : oc(Lc(String(a)))
    }

    function Lc(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    }

    function Mc(a) {
        const b = Kc("");
        return oc(a.map(c => pc(Kc(c))).join(pc(b).toString()))
    }
    const Nc = /^[a-z][a-z\d-]*$/i,
        Oc = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" ");
    var Pc = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" ");
    const Qc = ["action", "formaction", "href"];

    function Rc(a) {
        if (!Nc.test(a)) throw Error("");
        if (Oc.indexOf(a.toUpperCase()) !== -1) throw Error("");
    }

    function Sc(a, b, c) {
        Rc(a);
        let d = `<${a}`;
        b && (d += Tc(b));
        Array.isArray(c) || (c = c === void 0 ? [] : [c]);
        Pc.indexOf(a.toUpperCase()) !== -1 ? d += ">" : (b = Mc(c.map(e => e instanceof nc ? e : Kc(String(e)))), d += ">" + b.toString() + "</" + a + ">");
        return oc(d)
    }

    function Tc(a) {
        var b = "";
        const c = Object.keys(a);
        for (let f = 0; f < c.length; f++) {
            var d = c[f],
                e = a[d];
            if (!Nc.test(d)) throw Error("");
            if (e !== void 0 && e !== null) {
                if (/^on./i.test(d)) throw Error("");
                Qc.indexOf(d.toLowerCase()) !== -1 && (e = dc(e) ? e.toString() : kc(String(e)) || "about:invalid#zClosurez");
                e = `${d}="${Kc(String(e))}"`;
                b += " " + e
            }
        }
        return b
    };

    function Uc(a, ...b) {
        if (b.length === 0) return $b(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return $b(c)
    }

    function Vc(a, b) {
        a = ac(a).toString();
        const c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return Wc(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function Wc(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(k => e(k, h)) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        let f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(g => e(g[1], g[0])) : d.forEach(e);
        return $b(a + b + c)
    };

    function Xc(a) {
        try {
            return !!a && a.location.href != null && Ub(a, "foo")
        } catch {
            return !1
        }
    }

    function Yc(a, b = q) {
        b = Zc(b);
        let c = 0;
        for (; b && c++ < 40 && !a(b);) b = Zc(b)
    }

    function Zc(a) {
        try {
            const b = a.parent;
            if (b && b != a) return b
        } catch {}
        return null
    }

    function $c(a) {
        return Xc(a.top) ? a.top : null
    }

    function ad(a, b) {
        const c = bd("SCRIPT", a);
        rc(c, b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function cd(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function dd() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function ed(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function fd(a) {
        const b = [];
        ed(a, function(c) {
            b.push(c)
        });
        return b
    }

    function gd(a) {
        const b = a.length;
        if (b == 0) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    }
    var id = eb(() => Na(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], hd) || Math.random() < 1E-4);
    const hd = a => vb().indexOf(a) != -1;
    var jd = /^([0-9.]+)px$/,
        kd = /^(-?[0-9.]{1,30})$/;

    function ld(a) {
        if (!kd.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function md(a) {
        return (a = jd.exec(a)) ? +a[1] : null
    }
    var nd = {
        Pl: "allow-forms",
        Ql: "allow-modals",
        Rl: "allow-orientation-lock",
        Sl: "allow-pointer-lock",
        Tl: "allow-popups",
        Ul: "allow-popups-to-escape-sandbox",
        Vl: "allow-presentation",
        Wl: "allow-same-origin",
        Xl: "allow-scripts",
        Yl: "allow-top-navigation",
        Zl: "allow-top-navigation-by-user-activation"
    };
    const od = eb(() => fd(nd));

    function pd() {
        var a = ["allow-top-navigation", "allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"];
        const b = od();
        return a.length ? Ka(b, c => !Pa(a, c)) : b
    }

    function qd() {
        const a = bd("IFRAME"),
            b = {};
        Ia(od(), c => {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    }
    var rd = (a, b) => {
            try {
                return !(!a.frames || !a.frames[b])
            } catch {
                return !1
            }
        },
        sd = (a, b) => {
            for (let c = 0; c < 50; ++c) {
                if (rd(a, b)) return a;
                if (!(a = Zc(a))) break
            }
            return null
        },
        td = eb(() => Gb() ? 2 : Hb() ? 1 : 0),
        u = (a, b) => {
            ed(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        },
        vd = (a, b) => {
            if ("length" in a.style) {
                a = a.style;
                const c = a.length;
                for (let d = 0; d < c; d++) {
                    const e = a[d];
                    b(a[e], e, a)
                }
            } else a = ud(a.style.cssText), ed(a, b)
        },
        ud = a => {
            const b = {};
            if (a) {
                const c = /\s*:\s*/;
                Ia((a || "").split(/\s*;\s*/), d => {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d &&
                            e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        wd = a => {
            const b = /!\s*important/i;
            vd(a, (c, d) => {
                b.test(c) ? b.test(c) : a.style.setProperty(d, c, "important")
            })
        };
    const xd = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        yd = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        zd = /.*domain\.test$/,
        Ad = /\.prod\.google\.com(:\d+)?$/;
    var Bd = a => xd[a] || yd.test(a) || zd.test(a) || Ad.test(a);
    let Cd = [];
    const Dd = () => {
        const a = Cd;
        Cd = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var Ed = () => {
            var a = Math.random;
            return Math.floor(a() * 2 ** 52)
        },
        Fd = (a, b) => {
            if (typeof a.goog_pvsid !== "number") try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: Ed(),
                    configurable: !1
                })
            } catch (c) {
                b && b.ia(784, c)
            }
            a = Number(a.goog_pvsid);
            b && (!a || a <= 0) && b.ia(784, Error(`Invalid correlator, ${a}`));
            return a || -1
        },
        Gd = (a, b) => {
            a.document.readyState === "complete" ? (Cd.push(b), Cd.length == 1 && (window.Promise ? Promise.resolve().then(Dd) : window.setImmediate ? setImmediate(Dd) : setTimeout(Dd, 0))) : a.addEventListener("load", b)
        },
        Hd = (a,
            b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        });

    function bd(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    }
    var Id = a => {
            let b = a;
            for (; a && a != a.parent;) a = a.parent, Xc(a) && (b = a);
            return b
        },
        Kd = a => Eb() && Gb() ? Jd(a) : 1,
        Jd = a => {
            var b = $c(a);
            if (!b) return 1;
            a = td() === 0;
            const c = !!b.document.querySelector('meta[name=viewport][content*="width=device-width"]'),
                d = b.innerWidth;
            b = b.outerWidth;
            if (d === 0) return 1;
            const e = Math.round((b / d + Number.EPSILON) * 100) / 100;
            return e === 1 ? 1 : a || c ? e : Math.round((b / d / .4 + Number.EPSILON) * 100) / 100
        };
    let Ld;

    function Md(a) {
        return (Ld || (Ld = new TextEncoder)).encode(a)
    };

    function Nd(a) {
        q.setTimeout(() => {
            throw a;
        }, 0)
    };
    Fb();
    Eb();
    Db();
    var Od = {},
        Pd = null;

    function Qd(a) {
        var b = 3;
        b === void 0 && (b = 0);
        Rd();
        b = Od[b];
        const c = Array(Math.floor(a.length / 3)),
            d = b[64] || "";
        let e = 0,
            f = 0;
        for (; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function Sd(a) {
        const b = [];
        let c = 0;
        for (let d = 0; d < a.length; d++) {
            let e = a.charCodeAt(d);
            e > 255 && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        return Qd(b)
    }

    function Td(a) {
        const b = [];
        Ud(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Ud(a, b) {
        function c(e) {
            for (; d < a.length;) {
                const f = a.charAt(d++),
                    g = Pd[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        Rd();
        let d = 0;
        for (;;) {
            const e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Rd() {
        if (!Pd) {
            Pd = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                const d = a.concat(b[c].split(""));
                Od[c] = d;
                for (let e = 0; e < d.length; e++) {
                    const f = d[e];
                    Pd[f] === void 0 && (Pd[f] = e)
                }
            }
        }
    };

    function Vd(a) {
        let b = "",
            c = 0;
        const d = a.length - 10240;
        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    }
    const Wd = /[-_.]/g,
        Xd = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Yd(a) {
        return Xd[a] || ""
    }

    function Zd(a) {
        return a != null && a instanceof Uint8Array
    }
    var $d = {},
        ae = typeof structuredClone != "undefined";

    function be() {
        return ce || (ce = new de(null, $d))
    }

    function ee(a) {
        fe($d);
        var b = a.g;
        if (b != null && !Zd(b))
            if (typeof b === "string") {
                Wd.test(b) && (b = b.replace(Wd, Yd));
                b = atob(b);
                const c = new Uint8Array(b.length);
                for (let d = 0; d < b.length; d++) c[d] = b.charCodeAt(d);
                b = c
            } else b = null;
        return b == null ? b : a.g = b
    }
    var de = class {
        isEmpty() {
            return this.g == null
        }
        constructor(a, b) {
            fe(b);
            this.g = a;
            if (a != null && a.length === 0) throw Error("ByteString should be constructed with non-empty values");
        }
    };
    let ce;

    function fe(a) {
        if (a !== $d) throw Error("illegal external caller");
    };
    let ge = void 0,
        he;

    function ie(a) {
        if (he) throw Error("");
        he = b => {
            q.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function je(a) {
        if (he) try {
            he(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function ke() {
        const a = Error();
        yc(a, "incident");
        he ? je(a) : Nd(a)
    }

    function le(a) {
        a = Error(a);
        yc(a, "warning");
        je(a);
        return a
    };
    var me = new Set;

    function ne(a, b = !1, c = !1) {
        a = c && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol();
        b && me.add(a);
        return a
    }
    var oe = ne(),
        pe = ne(void 0, !0),
        qe = ne(),
        re = ne(void 0, !0),
        se = ne();
    const x = ne("jas", !0, !0);

    function te(a, b) {
        a[x] &= ~b
    }

    function ue(a) {
        if (4 & a) return 4096 & a ? 4096 : 8192 & a ? 8192 : 0
    }

    function xe(a) {
        a[x] |= 34;
        return a
    }

    function ye(a) {
        a[x] |= 32;
        return a
    }

    function ze(a, b) {
        b[x] = (a | 0) & -30975
    }

    function Ae(a, b) {
        b[x] = (a | 34) & -30941
    };

    function Be(a) {
        return Array.prototype.slice.call(a)
    };
    var Ce = {};

    function De(a) {
        return a !== null && typeof a === "object" && !Array.isArray(a) && a.constructor === Object
    }

    function Ee(a, b) {
        if (a != null)
            if (typeof a === "string") a = a ? new de(a, $d) : be();
            else if (a.constructor !== de)
            if (Zd(a)) a = a.length ? new de(new Uint8Array(a), $d) : be();
            else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    }
    var Fe;
    const Ge = [];
    Ge[x] = 55;
    Fe = Object.freeze(Ge);

    function He(a) {
        if (a & 2) throw Error();
    }
    class Ie {
        constructor(a, b, c) {
            this.j = 0;
            this.g = a;
            this.i = b;
            this.l = c
        }
        next() {
            if (this.j < this.g.length) {
                const a = this.g[this.j++];
                return {
                    done: !1,
                    value: this.i ? this.i.call(this.l, a) : a
                }
            }
            return {
                done: !0,
                value: void 0
            }
        }[Symbol.iterator]() {
            return new Ie(this.g, this.i, this.l)
        }
    }

    function Je(a) {
        const b = Ca(re);
        return b ? a[b] : void 0
    }
    var Ke = Object.freeze({});

    function Le(a, b) {
        const c = Me;
        if (!b(a)) throw b = (typeof c === "function" ? c() : c) ? .concat("\n") ? ? "", Error(b + String(a));
    }

    function Ne(a) {
        a.To = !0;
        return a
    }
    let Me = void 0;
    const Oe = Ne(a => a !== null && a !== void 0);
    var Pe = Ne(a => typeof a === "number"),
        Qe = Ne(a => typeof a === "string"),
        Re = Ne(a => a === void 0);

    function Se() {
        var a = Te;
        return Ne(b => {
            for (const c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        })
    }
    var Ue = Ne(a => !!a && (typeof a === "object" || typeof a === "function"));

    function Ve() {
        return We(Ne((a, b) => a === void 0 ? !0 : Qe(a, b)))
    }

    function We(a) {
        a.Yj = !0;
        return a
    }
    var Xe = Ne(a => Array.isArray(a));

    function Ye() {
        return Ne(a => Xe(a) ? a.every(b => Pe(b)) : !1)
    };

    function Ze(a) {
        if (Qe(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (Pe(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var bf = Ne(a => a >= $e && a <= af);
    const $e = BigInt(Number.MIN_SAFE_INTEGER),
        af = BigInt(Number.MAX_SAFE_INTEGER);
    let cf = 0,
        df = 0,
        ef;

    function ff(a) {
        const b = a >>> 0;
        cf = b;
        df = (a - b) / 4294967296 >>> 0
    }

    function gf(a) {
        if (a < 0) {
            ff(-a);
            a = cf;
            var b = df;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            const [c, d] = [a, b];
            cf = c >>> 0;
            df = d >>> 0
        } else ff(a)
    }

    function hf(a, b) {
        const c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : jf(a, b)
    }

    function jf(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function kf() {
        var a = cf,
            b = df,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = jf(a, b);
        return c
    }

    function lf(a) {
        a.length < 16 ? gf(Number(a)) : (a = BigInt(a), cf = Number(a & BigInt(4294967295)) >>> 0, df = Number(a >> BigInt(32) & BigInt(4294967295)))
    };
    const mf = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        nf = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        of = Number.isSafeInteger,
        pf = Number.isFinite,
        qf = Math.trunc;

    function rf(a) {
        if (a != null && typeof a !== "number") throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);
        return a
    }

    function sf(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function tf(a) {
        if (typeof a !== "boolean") throw Error(`Expected boolean but got ${pa(a)}: ${a}`);
        return a
    }

    function uf(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    const vf = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function wf(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return pf(a);
            case "string":
                return vf.test(a);
            default:
                return !1
        }
    }

    function xf(a) {
        if (!pf(a)) throw le("enum");
        return a | 0
    }

    function yf(a) {
        return a == null ? a : pf(a) ? a | 0 : void 0
    }

    function zf(a) {
        if (typeof a !== "number") throw le("int32");
        if (!pf(a)) throw le("int32");
        return a | 0
    }

    function Af(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return pf(a) ? a | 0 : void 0
    }

    function Bf(a) {
        if (typeof a !== "number") throw le("uint32");
        if (!pf(a)) throw le("uint32");
        return a >>> 0
    }

    function Cf(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return pf(a) ? a >>> 0 : void 0
    }

    function Df(a, b = 0) {
        if (!wf(a)) throw le("int64");
        const c = typeof a;
        switch (b) {
            case 4096:
                switch (c) {
                    case "string":
                        return Ef(a);
                    case "bigint":
                        return String(mf(64, a));
                    default:
                        return Ff(a)
                }
            case 8192:
                switch (c) {
                    case "string":
                        return Gf(a);
                    case "bigint":
                        return Ze(mf(64, a));
                    default:
                        return Hf(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return Ef(a);
                    case "bigint":
                        return Ze(mf(64, a));
                    default:
                        return If(a)
                }
            default:
                return mc(b, "Unknown format requested type for int64")
        }
    }

    function Jf(a) {
        return a == null ? a : Df(a, 0)
    }

    function Kf(a) {
        if (a[0] === "-") return !1;
        const b = a.length;
        return b < 20 ? !0 : b === 20 && Number(a.substring(0, 6)) < 184467
    }

    function Lf(a) {
        const b = a.length;
        return a[0] === "-" ? b < 20 ? !0 : b === 20 && Number(a.substring(0, 7)) > -922337 : b < 19 ? !0 : b === 19 && Number(a.substring(0, 6)) < 922337
    }

    function Mf(a) {
        if (a < 0) {
            gf(a);
            var b = jf(cf, df);
            a = Number(b);
            return of(a) ? a : b
        }
        b = String(a);
        if (Kf(b)) return b;
        gf(a);
        return hf(cf, df)
    }

    function If(a) {
        a = qf(a);
        if (! of (a)) {
            gf(a);
            var b = cf,
                c = df;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            b = hf(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function Nf(a) {
        a = qf(a);
        return a >= 0 && of (a) ? a : Mf(a)
    }

    function Ff(a) {
        a = qf(a);
        if ( of (a)) a = String(a);
        else {
            {
                const b = String(a);
                Lf(b) ? a = b : (gf(a), a = kf())
            }
        }
        return a
    }

    function Of(a) {
        a = qf(a);
        if (a >= 0 && of (a)) a = String(a);
        else {
            {
                const b = String(a);
                Kf(b) ? a = b : (gf(a), a = jf(cf, df))
            }
        }
        return a
    }

    function Ef(a) {
        var b = qf(Number(a));
        if ( of (b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        Lf(a) || (lf(a), a = kf());
        return a
    }

    function Gf(a) {
        var b = qf(Number(a));
        if ( of (b)) return Ze(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Ze(mf(64, BigInt(a)))
    }

    function Hf(a) {
        return of(a) ? Ze(If(a)) : Ze(Ff(a))
    }

    function Pf(a) {
        var b = qf(Number(a));
        if ( of (b) && b >= 0) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        Kf(a) || (lf(a), a = jf(cf, df));
        return a
    }

    function Qf(a) {
        if (a == null) return a;
        if (typeof a === "bigint") return bf(a) ? a = Number(a) : (a = mf(64, a), a = bf(a) ? Number(a) : String(a)), a;
        if (wf(a)) return typeof a === "number" ? If(a) : Ef(a)
    }

    function Rf(a) {
        const b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Ze(mf(64, a));
        if (wf(a)) return b === "string" ? Gf(a) : Hf(a)
    }

    function Sf(a, b = 0) {
        if (!wf(a)) throw le("uint64");
        const c = typeof a;
        switch (b) {
            case 4096:
                switch (c) {
                    case "string":
                        return Pf(a);
                    case "bigint":
                        return String(nf(64, a));
                    default:
                        return Of(a)
                }
            case 8192:
                switch (c) {
                    case "string":
                        return b = qf(Number(a)), of (b) && b >= 0 ? a = Ze(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = Ze(nf(64, BigInt(a)))), a;
                    case "bigint":
                        return Ze(nf(64, a));
                    default:
                        return of(a) ? Ze(Nf(a)) : Ze(Of(a))
                }
            case 0:
                switch (c) {
                    case "string":
                        return Pf(a);
                    case "bigint":
                        return Ze(nf(64, a));
                    default:
                        return Nf(a)
                }
            default:
                return mc(b,
                    "Unknown format requested type for int64")
        }
    }

    function Tf(a) {
        return a == null ? a : Sf(a, 0)
    }

    function Uf(a) {
        const b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return String(nf(64, a));
        if (wf(a)) return b === "string" ? Pf(a) : Of(a)
    }

    function Vf(a) {
        if (a == null) return a;
        const b = typeof a;
        if (b === "bigint") return String(mf(64, a));
        if (wf(a)) {
            if (b === "string") return Ef(a);
            if (b === "number") return If(a)
        }
    }

    function Wf(a) {
        if (a == null) return a;
        const b = typeof a;
        if (b === "bigint") return String(nf(64, a));
        if (wf(a)) {
            if (b === "string") return Pf(a);
            if (b === "number") return Nf(a)
        }
    }

    function Xf(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function Yf(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function Zf(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function $f(a, b, c, d) {
        if (a != null && typeof a === "object" && a.Of === Ce) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? ((a = b[oe]) || (a = new b, xe(a.R), a = b[oe] = a), b = a) : b = new b : b = void 0, b;
        let e = c = a[x] | 0;
        e === 0 && (e |= d & 32);
        e |= d & 2;
        e !== c && (a[x] = e);
        return new b(a)
    }

    function ag(a, b, c) {
        return b ? Xf(a) : Zf(a) ? ? (c ? "" : void 0)
    };

    function bg(a) {
        return a
    };
    const cg = {},
        dg = (() => class extends Map {
            constructor() {
                super()
            }
        })();

    function eg(a) {
        return a
    }

    function fg(a) {
        if (a.oc & 2) throw Error("Cannot mutate an immutable Map");
    }
    var kg = class extends dg {
        constructor(a, b, c = eg, d = eg) {
            super();
            let e = a[x] | 0;
            e |= 64;
            this.oc = a[x] = e;
            this.Be = b;
            this.Oc = c;
            this.yg = this.Be ? gg : d;
            for (let f = 0; f < a.length; f++) {
                const g = a[f],
                    h = c(g[0], !1, !0);
                let k = g[1];
                b ? k === void 0 && (k = null) : k = d(g[1], !1, !0, void 0, void 0, e);
                super.set(h, k)
            }
        }
        Wk() {
            var a = hg;
            if (this.size !== 0) return this.vg(a)
        }
        vg(a = ig) {
            const b = [],
                c = super.entries();
            for (var d; !(d = c.next()).done;) d = d.value, d[0] = a(d[0]), d[1] = a(d[1]), b.push(d);
            return b
        }
        clear() {
            fg(this);
            super.clear()
        }
        delete(a) {
            fg(this);
            return super.delete(this.Oc(a, !0, !1))
        }
        entries() {
            var a = this.zh();
            return new Ie(a, jg, this)
        }
        keys() {
            return this.ck()
        }
        values() {
            var a = this.zh();
            return new Ie(a, kg.prototype.get, this)
        }
        forEach(a, b) {
            super.forEach((c, d) => {
                a.call(b, this.get(d), d, this)
            })
        }
        set(a, b) {
            fg(this);
            a = this.Oc(a, !0, !1);
            return a == null ? this : b == null ? (super.delete(a), this) : super.set(a, this.yg(b, !0, !0, this.Be, !1, this.oc))
        }
        has(a) {
            return super.has(this.Oc(a, !1, !1))
        }
        get(a) {
            a = this.Oc(a, !1, !1);
            const b = super.get(a);
            if (b !== void 0) {
                var c = this.Be;
                return c ? (c = this.yg(b, !1, !0, c, this.Xi,
                    this.oc), c !== b && super.set(a, c), c) : b
            }
        }
        zh() {
            return Array.from(super.keys())
        }
        ck() {
            return super.keys()
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    kg.prototype.toJSON = void 0;

    function gg(a, b, c, d, e, f) {
        a = $f(a, d, c, f);
        e && (a = lg(a));
        return a
    }

    function ig(a) {
        return a
    }

    function jg(a) {
        return [a, this.get(a)]
    }
    let mg;

    function ng() {
        return mg || (mg = new kg(xe([]), void 0, void 0, void 0, cg))
    };

    function og(a, b, c) {
        const d = Be(a);
        var e = d.length;
        const f = b & 256 ? d[e - 1] : void 0;
        e += f ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < e; b++) d[b] = c(d[b]);
        if (f) {
            b = d[b] = {};
            for (const g in f) Object.prototype.hasOwnProperty.call(f, g) && (b[g] = c(f[g]))
        }(a = Je(a)) && (d[re] = Be(a));
        return d
    }

    function pg(a, b, c, d, e) {
        if (a != null) {
            if (Array.isArray(a)) {
                const f = a[x] | 0;
                return a.length === 0 && f & 1 ? void 0 : e && f & 2 ? a : qg(a, b, c, d !== void 0, e)
            }
            return b(a, d)
        }
    }

    function qg(a, b, c, d, e) {
        const f = d || c ? a[x] | 0 : 0,
            g = d ? !!(f & 32) : void 0;
        d = Be(a);
        let h = 0;
        const k = d.length;
        for (let v = 0; v < k; v++) {
            var l = d[v];
            if (v === k - 1 && De(l)) {
                var m = b,
                    n = c,
                    p = g,
                    t = e;
                let w = void 0;
                for (let B in l) {
                    if (!Object.prototype.hasOwnProperty.call(l, B)) continue;
                    const G = pg(l[B], m, n, p, t);
                    G != null && ((w ? ? (w = {}))[B] = G)
                }
                l = w
            } else l = pg(d[v], b, c, g, e);
            d[v] = l;
            l != null && (h = v + 1)
        }
        h < k && (d.length = h);
        c && ((a = Je(a)) && (d[re] = Be(a)), c(f, d));
        return d
    }

    function hg(a) {
        return pg(a, rg, void 0, void 0, !1)
    }

    function rg(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return bf(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Zd(a)) return Vd(a);
                if (a.Of === Ce) return sg(a);
                if (a instanceof de) {
                    const b = a.g;
                    return b == null ? "" : typeof b === "string" ? b : a.g = Vd(b)
                }
                if (a instanceof kg) return a.Wk();
                return
        }
        return a
    }
    var tg = ae ? structuredClone : a => qg(a, rg, void 0, void 0, !1);
    let ug;

    function vg(a) {
        try {
            return sg(a)
        } finally {
            ug = void 0
        }
    }

    function sg(a) {
        var b = a.R;
        a = qg(b, rg, void 0, void 0, !1);
        var c = b[x] | 0;
        if ((b = a.length) && !(c & 512)) {
            var d = a[b - 1],
                e = !1;
            De(d) ? (b--, e = !0) : d = void 0;
            c = c & 512 ? 0 : -1;
            var f = b - c,
                g = (ug ? ? bg)(f, c, a, d);
            d && (a[b] = void 0);
            if (f < g && d) {
                f = !0;
                for (var h in d) {
                    if (!Object.prototype.hasOwnProperty.call(d, h)) continue;
                    const k = +h;
                    if (k <= g) e = k + c, a[e] = d[h], b = Math.max(e + 1, b), e = !1, delete d[h];
                    else {
                        f = !1;
                        break
                    }
                }
                f && (d = void 0)
            }
            for (f = b - 1; b > 0; f = b - 1)
                if (h = a[f], h == null) b--, e = !0;
                else if (f -= c, f >= g)(d ? ? (d = {}))[f] = h, b--, e = !0;
            else break;
            e && (a.length = b);
            d && a.push(d)
        }
        return a
    };
    let wg, xg;

    function yg(a) {
        switch (typeof a) {
            case "boolean":
                return wg || (wg = [0, void 0, !0]);
            case "number":
                return a > 0 ? void 0 : a === 0 ? xg || (xg = [0, void 0]) : [-a, void 0];
            case "string":
                return [0, a];
            case "object":
                return a
        }
    }

    function zg(a, b, c) {
        a = Ag(a, b[0], b[1], c ? 1 : 2);
        b !== wg && c && (a[x] |= 16384);
        return a
    }

    function Ag(a, b, c, d) {
        if (a == null) {
            var e = 96;
            c ? (a = [c], e |= 512) : a = [];
            b && (e = e & -33521665 | (b & 1023) << 15)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[x] | 0;
            16384 & e || !(64 & e) || 2 & e || Bg();
            if (e & 2048) throw Error("farr");
            if (e & 64) return a;
            d === 1 || d === 2 || (e |= 64);
            if (c && (e |= 512, c !== a[0])) throw Error("mid");
            a: {
                c = a;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    d = c[g];
                    if (De(d)) {
                        e |= 256;
                        b = e & 512 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in d)
                            if (Object.prototype.hasOwnProperty.call(d, h))
                                if (f = +h, f < g) c[f + b] = d[h], delete d[h];
                                else break;
                        e = e & -33521665 | (g & 1023) << 15;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 512 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -33521665 | (h & 1023) << 15
                }
            }
        }
        a[x] = e;
        return a
    }

    function Bg() {
        if (se != null) {
            var a = ge ? ? (ge = {});
            var b = a[se] || 0;
            b >= 5 || (a[se] = b + 1, ke())
        }
    };

    function Cg(a, b, c = Ae) {
        if (a != null) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[x] | 0;
                if (d & 2) return a;
                b && (b = d === 0 || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[x] = d | 34, d & 4 && Object.freeze(a), a) : qg(a, Cg, d & 4 ? Ae : c, !0, !0)
            }
            a.Of === Ce ? (c = a.R, d = c[x] | 0, a = d & 2 ? a : new a.constructor(Dg(c, d, !0))) : a instanceof kg && !(a.oc & 2) && (c = xe(a.vg(Cg)), a = new kg(c, a.Be, a.Oc, a.yg));
            return a
        }
    }

    function Eg(a) {
        const b = a.R;
        return new a.constructor(Dg(b, b[x] | 0, !1))
    }

    function Dg(a, b, c) {
        const d = c || b & 2 ? Ae : ze,
            e = !!(b & 32);
        a = og(a, b, f => Cg(f, e, d));
        a[x] = a[x] | 32 | (c ? 2 : 0);
        return a
    }

    function lg(a) {
        const b = a.R,
            c = b[x] | 0;
        return c & 2 ? new a.constructor(Dg(b, c, !1)) : a
    };
    const Fg = Ze(0);

    function Gg(a, b) {
        a = a.R;
        return Hg(a, a[x] | 0, b)
    }

    function Hg(a, b, c) {
        if (c === -1) return null;
        const d = c + (b & 512 ? 0 : -1),
            e = a.length - 1;
        if (d >= e && b & 256) return a[e][c];
        if (d <= e) return a[d]
    }

    function Ig(a, b, c) {
        const d = a.R;
        let e = d[x] | 0;
        He(e);
        Jg(d, e, b, c);
        return a
    }

    function Jg(a, b, c, d) {
        const e = b & 512 ? 0 : -1,
            f = c + e;
        var g = a.length - 1;
        if (f >= g && b & 256) return a[g][c] = d, b;
        if (f <= g) return a[f] = d, b;
        d !== void 0 && (g = b >> 15 & 1023 || 536870912, c >= g ? d != null && (a[g + e] = {
            [c]: d
        }, b |= 256, a[x] = b) : a[f] = d);
        return b
    }

    function Kg(a, b, c) {
        return Lg(a, b, c) !== void 0
    }

    function Mg(a, b, c, d) {
        return Lg(a, b, Ng(a, d, c)) !== void 0
    }

    function Og(a, b) {
        a = a.R;
        let c = a[x] | 0;
        const d = Hg(a, c, b),
            e = sf(d);
        e != null && e !== d && Jg(a, c, b, e);
        return e
    }

    function Pg(a) {
        return a === Ke ? 2 : 4
    }

    function Qg(a, b, c, d, e, f) {
        const g = a.R;
        let h = g[x] | 0;
        const k = 2 & h ? 1 : d;
        e = !!e;
        d = Rg(g, h, b);
        var l = d[x] | 0;
        var m = l;
        4 & m ? f == null ? a = !1 : (!e && f === 0 && (4096 & m || 8192 & m) && (a.constructor[qe] = (a.constructor[qe] | 0) + 1) < 5 && ke(), a = f === 0 ? !1 : !(f & m)) : a = !0;
        if (a) {
            4 & l && (d = Be(d), l = Sg(l, h), h = Jg(g, h, b, d));
            for (m = a = 0; a < d.length; a++) {
                const n = c(d[a]);
                n != null && (d[m++] = n)
            }
            m < a && (d.length = m);
            l = Tg(l, h);
            l = (l | 20) & -4097;
            l &= -8193;
            f && (l |= f);
            d[x] = l;
            2 & l && Object.freeze(d)
        }
        k === 1 || k === 4 && 32 & l ? Ug(l) || (e = l, l |= 2, l !== e && (d[x] = l), Object.freeze(d)) : (k ===
            2 && Ug(l) && (d = Be(d), l = Sg(l, h), l = Vg(l, h, e), d[x] = l, h = Jg(g, h, b, d)), Ug(l) || (b = l, l = Vg(l, h, e), l !== b && (d[x] = l)));
        return d
    }

    function Rg(a, b, c) {
        a = Hg(a, b, c);
        return Array.isArray(a) ? a : Fe
    }

    function Tg(a, b) {
        a === 0 && (a = Sg(a, b));
        return a | 1
    }

    function Ug(a) {
        return !!(2 & a) && !!(4 & a) || !!(2048 & a)
    }

    function Wg(a) {
        var b = a.R;
        const c = b[x] | 0;
        a = Xg;
        const d = c & 2;
        a: {
            var e = Hg(b, c, 14),
                f = c & 2,
                g = !1;
            if (e == null) {
                if (f) {
                    b = ng();
                    break a
                }
                e = []
            } else if (e.constructor === kg) {
                if ((e.oc & 2) == 0 || f) {
                    b = e;
                    break a
                }
                e = e.vg()
            } else Array.isArray(e) ? g = !!((e[x] | 0) & 2) : e = [];
            if (f) {
                if (!e.length) {
                    b = ng();
                    break a
                }
                g || (g = !0, xe(e))
            } else if (g) {
                g = !1;
                f = Be(e);
                for (e = 0; e < f.length; e++) {
                    const h = f[e] = Be(f[e]);
                    Array.isArray(h[1]) && (h[1] = xe(h[1]))
                }
                e = f
            }
            g || ((e[x] | 0) & 64 ? te(e, 32) : 32 & c && ye(e));g = new kg(e, a, ag, void 0);Jg(b, c, 14, g);b = g
        }!d && a && (b.Xi = !0);
        return b
    }

    function Yg(a, b, c, d) {
        const e = a.R;
        let f = e[x] | 0;
        He(f);
        if (c == null) return Jg(e, f, b), a;
        let g = c[x] | 0,
            h = g;
        var k = Ug(g);
        let l = k || Object.isFrozen(c);
        k || (g = 0);
        l || (c = Be(c), h = 0, g = Sg(g, f), g = Vg(g, f, !0), l = !1);
        g |= 21;
        k = ue(g) ? ? 0;
        for (let m = 0; m < c.length; m++) {
            const n = c[m],
                p = d(n, k);
            Object.is(n, p) || (l && (c = Be(c), h = 0, g = Sg(g, f), g = Vg(g, f, !0), l = !1), c[m] = p)
        }
        g !== h && (l && (c = Be(c), g = Sg(g, f), g = Vg(g, f, !0)), c[x] = g);
        Jg(e, f, b, c);
        return a
    }

    function Zg(a, b, c, d) {
        const e = a.R;
        let f = e[x] | 0;
        He(f);
        Jg(e, f, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function $g(a, b, c, d) {
        const e = a.R;
        var f = e[x] | 0;
        He(f);
        if (d == null) {
            var g = ah(e);
            if (bh(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = ah(e);
            const h = bh(g, e, f, c);
            h !== b && (h && (f = Jg(e, f, h)), g.set(c, b))
        }
        Jg(e, f, b, d);
        return a
    }

    function Ng(a, b, c) {
        return ch(a, b) === c ? c : -1
    }

    function ch(a, b) {
        a = a.R;
        return bh(ah(a), a, a[x] | 0, b)
    }

    function ah(a) {
        return a[pe] ? ? (a[pe] = new Map)
    }

    function bh(a, b, c, d) {
        let e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            const g = d[f];
            Hg(b, c, g) != null && (e !== 0 && (c = Jg(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function dh(a) {
        var b = eh;
        a = a.R;
        let c = a[x] | 0;
        He(c);
        const d = Hg(a, c, 26);
        b = lg($f(d, b, !0, c));
        d !== b && Jg(a, c, 26, b);
        return b
    }

    function Lg(a, b, c) {
        a = a.R;
        let d = a[x] | 0;
        const e = Hg(a, d, c);
        b = $f(e, b, !1, d);
        b !== e && b != null && Jg(a, d, c, b);
        return b
    }

    function fh(a, b, c) {
        (a = Lg(a, b, c)) || (a = b[oe]) || (a = new b, xe(a.R), a = b[oe] = a);
        return a
    }

    function y(a, b, c) {
        b = Lg(a, b, c);
        if (b == null) return b;
        a = a.R;
        let d = a[x] | 0;
        if (!(d & 2)) {
            const e = lg(b);
            e !== b && (b = e, Jg(a, d, c, b))
        }
        return b
    }

    function gh(a, b, c, d, e, f, g) {
        a = a.R;
        var h = !!(2 & b);
        const k = h ? 1 : e;
        f = !!f;
        g && (g = !h);
        e = Rg(a, b, d);
        var l = e[x] | 0;
        h = !!(4 & l);
        if (!h) {
            l = Tg(l, b);
            var m = e,
                n = b;
            const p = !!(2 & l);
            p && (n |= 2);
            let t = !p,
                v = !0,
                w = 0,
                B = 0;
            for (; w < m.length; w++) {
                const G = $f(m[w], c, !1, n);
                if (G instanceof c) {
                    if (!p) {
                        const L = !!((G.R[x] | 0) & 2);
                        t && (t = !L);
                        v && (v = L)
                    }
                    m[B++] = G
                }
            }
            B < w && (m.length = B);
            l |= 4;
            l = v ? l | 16 : l & -17;
            l = t ? l | 8 : l & -9;
            m[x] = l;
            p && Object.freeze(m)
        }
        if (g && !(8 & l || !e.length && (k === 1 || k === 4 && 32 & l))) {
            Ug(l) && (e = Be(e), l = Sg(l, b), b = Jg(a, b, d, e));
            c = e;
            g = l;
            for (m = 0; m < c.length; m++) l =
                c[m], n = lg(l), l !== n && (c[m] = n);
            g |= 8;
            g = c.length ? g & -17 : g | 16;
            l = c[x] = g
        }
        k === 1 || k === 4 && 32 & l ? Ug(l) || (b = l, l |= !e.length || 16 & l && (!h || 32 & l) ? 2 : 2048, l !== b && (e[x] = l), Object.freeze(e)) : (k === 2 && Ug(l) && (e = Be(e), l = Sg(l, b), l = Vg(l, b, f), e[x] = l, b = Jg(a, b, d, e)), Ug(l) || (d = l, l = Vg(l, b, f), l !== d && (e[x] = l)));
        return e
    }

    function hh(a, b, c, d) {
        const e = a.R[x] | 0;
        return gh(a, e, b, c, d, !1, !(2 & e))
    }

    function z(a, b, c) {
        c == null && (c = void 0);
        return Ig(a, b, c)
    }

    function C(a, b, c, d) {
        d == null && (d = void 0);
        return $g(a, b, c, d)
    }

    function ih(a, b, c) {
        const d = a.R;
        let e = d[x] | 0;
        He(e);
        if (c == null) return Jg(d, e, b), a;
        let f = c[x] | 0,
            g = f;
        const h = Ug(f),
            k = h || Object.isFrozen(c);
        let l = !0,
            m = !0;
        for (let p = 0; p < c.length; p++) {
            var n = c[p];
            h || (n = !!((n.R[x] | 0) & 2), l && (l = !n), m && (m = n))
        }
        h || (f = l ? 13 : 5, f = m ? f | 16 : f & -17);
        k && f === g || (c = Be(c), g = 0, f = Sg(f, e), f = Vg(f, e, !0));
        f !== g && (c[x] = f);
        Jg(d, e, b, c);
        return a
    }

    function Sg(a, b) {
        a = (2 & b ? a | 2 : a & -3) | 32;
        return a &= -2049
    }

    function Vg(a, b, c) {
        32 & b && c || (a &= -33);
        return a
    }

    function jh(a, b, c, d, e, f, g) {
        He(a.R[x] | 0);
        b = Qg(a, b, e, 2, !0);
        e = ue(b[x] | 0) ? ? 0;
        if (g)
            if (Array.isArray(d))
                for (f = d.length, g = 0; g < f; g++) b.push(c(d[g], e));
            else
                for (const h of d) b.push(c(h, e));
        else {
            if (f) throw Error();
            b.push(c(d, e))
        }
        return a
    }

    function kh(a, b, c, d) {
        const e = a.R[x] | 0;
        He(e);
        b = gh(a, e, c, b, 2, !0);
        d = d != null ? d : new c;
        b.push(d);
        (d.R[x] | 0) & 2 ? te(b, 8) : te(b, 16);
        return a
    }

    function lh(a, b) {
        return uf(Gg(a, b))
    }

    function mh(a, b) {
        return Af(Gg(a, b))
    }

    function D(a, b) {
        return Zf(Gg(a, b))
    }

    function nh(a, b) {
        return yf(Gg(a, b))
    }

    function E(a, b) {
        return lh(a, b) ? ? !1
    }

    function oh(a, b) {
        return mh(a, b) ? ? 0
    }

    function ph(a, b) {
        return Qf(Gg(a, b)) ? ? 0
    }

    function qh(a, b, c = 0) {
        return Og(a, b) ? ? c
    }

    function F(a, b) {
        return D(a, b) ? ? ""
    }

    function I(a, b) {
        return nh(a, b) ? ? 0
    }

    function rh(a, b) {
        return Qg(a, b, Af, Pg())
    }

    function sh(a, b) {
        return Qg(a, b, Zf, Pg())
    }

    function th(a, b) {
        return Qg(a, b, yf, Pg())
    }

    function uh(a, b, c, d) {
        return y(a, b, Ng(a, d, c))
    }

    function vh(a, b) {
        return lh(a, b) ? ? void 0
    }

    function wh(a, b) {
        return mh(a, b) ? ? void 0
    }

    function xh(a, b) {
        return nh(a, b) ? ? void 0
    }

    function yh(a, b, c) {
        return Ig(a, b, c == null ? c : tf(c))
    }

    function J(a, b, c) {
        return Zg(a, b, c == null ? c : tf(c), !1)
    }

    function zh(a, b, c) {
        return Ig(a, b, c == null ? c : zf(c))
    }

    function Ah(a, b, c) {
        return Zg(a, b, c == null ? c : zf(c), 0)
    }

    function Bh(a, b, c) {
        return Ig(a, b, Jf(c))
    }

    function Ch(a, b, c) {
        return Zg(a, b, Jf(c), "0")
    }

    function Dh(a, b, c) {
        return Ig(a, b, Yf(c))
    }

    function Eh(a, b, c) {
        return Zg(a, b, Yf(c), "")
    }

    function Fh(a, b, c) {
        return Ig(a, b, c == null ? c : xf(c))
    }

    function M(a, b, c) {
        return Zg(a, b, c == null ? c : xf(c), 0)
    }

    function Gh(a, b) {
        return lh(a, b) != null
    };

    function Hh(a) {
        return JSON.stringify(vg(a))
    }
    var N = class {
        constructor(a) {
            this.R = Ag(a)
        }
        toJSON() {
            return vg(this)
        }
        g() {
            const a = this.R,
                b = a[x] | 0;
            return b & 2 ? this : new this.constructor(Dg(a, b, !0))
        }
    };
    N.prototype.Of = Ce;

    function Ih(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        b[x] |= 128;
        return new a(ye(b))
    };

    function Jh(a) {
        a = BigInt.asUintN(64, a);
        return new Kh(Number(a & BigInt(4294967295)), Number(a >> BigInt(32)))
    }

    function Lh(a) {
        if (!a) return Mh || (Mh = new Kh(0, 0));
        if (!/^\d+$/.test(a)) return null;
        lf(a);
        return new Kh(cf, df)
    }
    var Kh = class {
        constructor(a, b) {
            this.i = a >>> 0;
            this.g = b >>> 0
        }
    };
    let Mh;

    function Nh(a) {
        a = BigInt.asUintN(64, a);
        return new Oh(Number(a & BigInt(4294967295)), Number(a >> BigInt(32)))
    }

    function Ph(a) {
        if (!a) return Qh || (Qh = new Oh(0, 0));
        if (!/^-?\d+$/.test(a)) return null;
        lf(a);
        return new Oh(cf, df)
    }
    var Oh = class {
        constructor(a, b) {
            this.i = a >>> 0;
            this.g = b >>> 0
        }
    };
    let Qh;

    function Rh(a, b, c) {
        for (; c > 0 || b > 127;) a.g.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
        a.g.push(b)
    }

    function Sh(a, b) {
        for (; b > 127;) a.g.push(b & 127 | 128), b >>>= 7;
        a.g.push(b)
    }

    function Th(a, b) {
        if (b >= 0) Sh(a, b);
        else {
            for (let c = 0; c < 9; c++) a.g.push(b & 127 | 128), b >>= 7;
            a.g.push(1)
        }
    }

    function Uh(a, b) {
        a.g.push(b >>> 0 & 255);
        a.g.push(b >>> 8 & 255);
        a.g.push(b >>> 16 & 255);
        a.g.push(b >>> 24 & 255)
    }
    var Vh = class {
        constructor() {
            this.g = []
        }
        length() {
            return this.g.length
        }
        end() {
            const a = this.g;
            this.g = [];
            return a
        }
    };

    function Wh(a, b) {
        b.length !== 0 && (a.j.push(b), a.i += b.length)
    }

    function Xh(a, b) {
        Wh(a, a.g.end());
        Wh(a, b)
    }

    function Yh(a, b, c) {
        Sh(a.g, b * 8 + c)
    }

    function Zh(a, b) {
        Yh(a, b, 2);
        b = a.g.end();
        Wh(a, b);
        b.push(a.i);
        return b
    }

    function $h(a, b) {
        var c = b.pop();
        for (c = a.i + a.g.length() - c; c > 127;) b.push(c & 127 | 128), c >>>= 7, a.i++;
        b.push(c);
        a.i++
    }

    function ai(a) {
        Wh(a, a.g.end());
        const b = new Uint8Array(a.i),
            c = a.j,
            d = c.length;
        let e = 0;
        for (let f = 0; f < d; f++) {
            const g = c[f];
            b.set(g, e);
            e += g.length
        }
        a.j = [b];
        return b
    }

    function bi(a, b, c, d) {
        c != null && (b = Zh(a, b), d(c, a), $h(a, b))
    }

    function ci(a, b, c) {
        var d = di;
        if (c != null)
            for (let e = 0; e < c.length; e++) {
                const f = Zh(a, b);
                d(c[e], a);
                $h(a, f)
            }
    }
    var ei = class {
        constructor() {
            this.j = [];
            this.i = 0;
            this.g = new Vh
        }
    };

    function fi() {
        const a = class {
            constructor() {
                throw Error();
            }
        };
        Object.setPrototypeOf(a, a.prototype);
        return a
    }
    var gi = fi(),
        hi = fi(),
        ii = fi(),
        ji = fi(),
        ki = fi(),
        li = fi(),
        mi = fi(),
        ni = fi();
    var oi = class {
        constructor(a, b) {
            this.g = a;
            a = Ca(gi);
            this.i = !!a && b === a || !1
        }
    };

    function pi(a, b, c, d, e) {
        bi(a, c, qi(b, d), e)
    }
    const ri = new oi(pi, gi),
        si = new oi(pi, gi);
    var ti = Symbol(),
        ui = Symbol();
    let vi, wi;

    function xi(a) {
        var b = yi,
            c = zi,
            d = a[ti];
        if (d) return d;
        d = {};
        d.No = a;
        d.Eh = yg(a[0]);
        var e = a[1];
        let f = 1;
        e && e.constructor === Object && (d.yj = e, e = a[++f], typeof e === "function" && (d.Xj = !0, vi ? ? (vi = e), wi ? ? (wi = a[f + 1]), e = a[f += 2]));
        const g = {};
        for (; e && Array.isArray(e) && e.length && typeof e[0] === "number" && e[0] > 0;) {
            for (var h = 0; h < e.length; h++) g[e[h]] = e;
            e = a[++f]
        }
        for (h = 1; e !== void 0;) {
            typeof e === "number" && (h += e, e = a[++f]);
            let m;
            var k = void 0;
            e instanceof oi ? m = e : (m = ri, f--);
            if (m ? .i) {
                e = a[++f];
                k = a;
                var l = f;
                typeof e === "function" && (e =
                    e(), k[l] = e);
                k = e
            }
            e = a[++f];
            l = h + 1;
            typeof e === "number" && e < 0 && (l -= e, e = a[++f]);
            for (; h < l; h++) {
                const n = g[h];
                k ? c(d, h, m, k, n) : b(d, h, m, n)
            }
        }
        return a[ti] = d
    }

    function qi(a, b) {
        if (a instanceof N) return a.R;
        if (Array.isArray(a)) return zg(a, b, !1)
    };

    function yi(a, b, c) {
        a[b] = c.g
    }

    function zi(a, b, c, d) {
        let e, f;
        const g = c.g;
        a[b] = (h, k, l) => g(h, k, l, f || (f = xi(d).Eh), e || (e = Ai(d)))
    }

    function Ai(a) {
        let b = a[ui];
        if (!b) {
            const c = xi(a);
            b = (d, e) => Bi(d, e, c);
            a[ui] = b
        }
        return b
    }

    function Bi(a, b, c) {
        for (var d = a[x] | 0, e = d & 512 ? 0 : -1, f = a.length, g = d & 512 ? 1 : 0, h = f + (d & 256 ? -1 : 0); g < h; g++) {
            const k = a[g];
            if (k == null) continue;
            const l = g - e,
                m = Ci(c, l);
            m && m(b, k, l)
        }
        if (d & 256) {
            d = a[f - 1];
            for (const k in d) Object.prototype.hasOwnProperty.call(d, k) && (e = +k, Number.isNaN(e) || (f = d[e], f != null && (h = Ci(c, e)) && h(b, f, e)))
        }
        if (a = Je(a))
            for (Wh(b, b.g.end()), c = 0; c < a.length; c++) Wh(b, ee(a[c]) || new Uint8Array(0))
    }

    function Ci(a, b) {
        var c = a[b];
        if (c) return c;
        if (c = a.yj)
            if (c = c[b]) {
                c = Array.isArray(c) ? c[0] instanceof oi ? c : [si, c] : [c, void 0];
                var d = c[0].g;
                if (c = c[1]) {
                    const e = Ai(c),
                        f = xi(c).Eh;
                    c = a.Xj ? wi(f, e) : (g, h, k) => d(g, h, k, f, e)
                } else c = d;
                return a[b] = c
            }
    };

    function Di(a, b, c) {
        if (Array.isArray(b)) {
            var d = b[x] | 0;
            if (d & 4) return b;
            for (var e = 0, f = 0; e < b.length; e++) {
                const g = a(b[e]);
                g != null && (b[f++] = g)
            }
            f < e && (b.length = f);
            c && (b[x] = (d | 5) & -12289, d & 2 && Object.freeze(b));
            return b
        }
    }

    function Ei(a, b) {
        return new oi(a, b)
    }

    function Fi(a, b) {
        return new oi(a, b)
    }
    var Gi = new oi(function(a, b, c, d, e) {
        if (b instanceof kg) b.forEach((f, g) => {
            bi(a, c, zg([g, f], d, !1), e)
        });
        else if (Array.isArray(b))
            for (let f = 0; f < b.length; f++) {
                const g = b[f];
                Array.isArray(g) && bi(a, c, zg(g, d, !1), e)
            }
    }, gi);

    function Hi(a, b, c) {
        b = sf(b);
        b != null && (Yh(a, c, 1), a = a.g, c = ef || (ef = new DataView(new ArrayBuffer(8))), c.setFloat64(0, +b, !0), cf = c.getUint32(0, !0), df = c.getUint32(4, !0), Uh(a, cf), Uh(a, df))
    }

    function Ii(a, b, c) {
        b = Vf(b);
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Ph(b)
            }
            if (b != null) switch (Yh(a, c, 0), typeof b) {
                case "number":
                    a = a.g;
                    gf(b);
                    Rh(a, cf, df);
                    break;
                case "bigint":
                    c = Nh(b);
                    Rh(a.g, c.i, c.g);
                    break;
                default:
                    c = Ph(b), Rh(a.g, c.i, c.g)
            }
        }
    }

    function Ji(a, b, c) {
        b = Di(Vf, b, !1);
        if (b != null && b.length) {
            c = Zh(a, c);
            for (let e = 0; e < b.length; e++) {
                const f = b[e];
                switch (typeof f) {
                    case "number":
                        var d = a.g;
                        gf(f);
                        Rh(d, cf, df);
                        break;
                    case "bigint":
                        d = Nh(f);
                        Rh(a.g, d.i, d.g);
                        break;
                    default:
                        d = Ph(f), Rh(a.g, d.i, d.g)
                }
            }
            $h(a, c)
        }
    }

    function Ki(a, b, c) {
        b = Wf(b);
        if (b != null) {
            switch (typeof b) {
                case "string":
                    Lh(b)
            }
            if (b != null) switch (Yh(a, c, 0), typeof b) {
                case "number":
                    a = a.g;
                    gf(b);
                    Rh(a, cf, df);
                    break;
                case "bigint":
                    c = Jh(b);
                    Rh(a.g, c.i, c.g);
                    break;
                default:
                    c = Lh(b), Rh(a.g, c.i, c.g)
            }
        }
    }

    function Li(a, b, c) {
        b = Af(b);
        b != null && b != null && (Yh(a, c, 0), Th(a.g, b))
    }

    function Mi(a, b, c) {
        b = uf(b);
        b != null && (Yh(a, c, 0), a.g.g.push(b ? 1 : 0))
    }

    function Ni(a, b, c) {
        b = Zf(b);
        b != null && (b = Md(b), Yh(a, c, 2), Sh(a.g, b.length), Xh(a, b))
    }

    function Oi(a, b, c, d, e) {
        bi(a, c, qi(b, d), e)
    }

    function Pi(a, b, c) {
        b = Af(b);
        b != null && (b = parseInt(b, 10), Yh(a, c, 0), Th(a.g, b))
    }
    var Qi = Ei(Hi, mi),
        Ri = Ei(Hi, mi),
        Si = Ei(function(a, b, c) {
            b = sf(b);
            b != null && (Yh(a, c, 5), a = a.g, c = ef || (ef = new DataView(new ArrayBuffer(8))), c.setFloat32(0, +b, !0), df = 0, cf = c.getUint32(0, !0), Uh(a, cf))
        }, fi()),
        Ti = Fi(Ji, ki),
        Ui = Ei(Ii, ki),
        Vi = Fi(Ji, ki),
        Wi = Ei(Ii, ki),
        Xi = Ei(Ii, ki),
        Yi = Ei(Ki, li),
        Zi = Fi(function(a, b, c) {
            b = Di(Wf, b, !1);
            if (b != null && b.length) {
                c = Zh(a, c);
                for (let f = 0; f < b.length; f++) {
                    var d = b[f];
                    switch (typeof d) {
                        case "number":
                            var e = a.g;
                            gf(d);
                            Rh(e, cf, df);
                            break;
                        case "bigint":
                            e = Number(d);
                            Number.isSafeInteger(e) ? (d = a.g,
                                gf(e), Rh(d, cf, df)) : (d = Jh(d), Rh(a.g, d.i, d.g));
                            break;
                        default:
                            d = Lh(d), Rh(a.g, d.i, d.g)
                    }
                }
                $h(a, c)
            }
        }, li),
        $i = Ei(Ki, li),
        aj = Ei(Li, ji),
        bj = Fi(function(a, b, c) {
            b = Di(Af, b, !0);
            if (b != null && b.length) {
                c = Zh(a, c);
                for (let d = 0; d < b.length; d++) Th(a.g, b[d]);
                $h(a, c)
            }
        }, ji),
        cj = Ei(Li, ji),
        dj = Ei(function(a, b, c) {
            b = Cf(b);
            b != null && (Yh(a, c, 5), Uh(a.g, b))
        }, fi()),
        ej = Ei(Mi, hi),
        fj = Ei(Mi, hi),
        gj = Ei(Mi, hi),
        hj = Ei(Ni, ii),
        ij = Fi(function(a, b, c) {
            b = Di(Zf, b, !0);
            if (b != null)
                for (let g = 0; g < b.length; g++) {
                    var d = a,
                        e = c,
                        f = b[g];
                    f != null && (f = Md(f), Yh(d, e, 2),
                        Sh(d.g, f.length), Xh(d, f))
                }
        }, ii),
        jj = Ei(Ni, ii),
        kj = Ei(Ni, ii),
        lj = function(a, b, c = gi) {
            return new oi(b, c)
        }(function(a, b, c, d, e) {
            if (a.g() !== 2) return !1;
            var f = a.i;
            d = zg(void 0, d, !0);
            var g = b[x] | 0;
            He(g);
            let h = Rg(b, g, c);
            const k = h !== Fe;
            if (64 & g || !(16384 & g) || !k) {
                const l = k ? h[x] | 0 : 0;
                let m = l;
                if (!k || 2 & m || Ug(m) || 4 & m && !(32 & m)) h = Be(h), m = Sg(m, g), g = Jg(b, g, c, h);
                m = Tg(m, g) & -13;
                m = Vg(m & -17, g, !0);
                m !== l && (h[x] = m)
            }
            h.push(d);
            f.call(a, d, e);
            return !0
        }, function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (let f = 0; f < b.length; f++) Oi(a, b[f], c, d, e)
        }),
        O = new oi(Oi, gi),
        mj = Ei(function(a, b, c) {
            b = Cf(b);
            b != null && b != null && (Yh(a, c, 0), Sh(a.g, b))
        }, fi()),
        nj = Ei(Pi, ni),
        oj = Fi(function(a, b, c) {
            b = Di(Af, b, !0);
            if (b != null && b.length) {
                c = Zh(a, c);
                for (let d = 0; d < b.length; d++) Th(a.g, b[d]);
                $h(a, c)
            }
        }, ni),
        pj = Ei(Pi, ni);

    function qj(a) {
        return () => {
            var b;
            (b = a[oe]) || (b = new a, xe(b.R), b = a[oe] = b);
            return b
        }
    }

    function rj(a) {
        return b => {
            const c = new ei;
            Bi(b.R, c, xi(a));
            return ai(c)
        }
    }

    function sj(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(ye(b))
            }
            return b
        }
    };
    Uc `https://www.google.com/recaptcha/api2/aframe`;

    function tj(a) {
        var b = window;
        new Promise((c, d) => {
            function e() {
                f.onload = null;
                f.onerror = null;
                f.parentElement ? .removeChild(f)
            }
            const f = b.document.createElement("script");
            f.onload = () => {
                e();
                c()
            };
            f.onerror = () => {
                e();
                d(void 0)
            };
            f.type = "text/javascript";
            rc(f, a);
            b.document.readyState !== "complete" ? lb(b, "load", () => {
                b.document.body.appendChild(f)
            }) : b.document.body.appendChild(f)
        })
    };
    async function uj(a) {
        var b = `${a.Za?"https://ep1.adtrafficquality.google/getconfig/sodar":"https://pagead2.googlesyndication.com/getconfig/sodar"}?sv=${200}&tid=${a.g}` + `&tv=${a.i}&st=` + `${a.lc}`;
        let c = void 0;
        try {
            c = await vj(b)
        } catch (g) {}
        if (c) {
            b = a.Nc || c.sodar_query_id;
            var d = c.rc_enable !== void 0 && a.j ? c.rc_enable : "n",
                e = c.bg_snapshot_delay_ms === void 0 ? "0" : c.bg_snapshot_delay_ms,
                f = c.is_gen_204 === void 0 ? "1" : c.is_gen_204;
            if (b && c.bg_hash_basename && c.bg_binary) return {
                context: a.l,
                Si: c.bg_hash_basename,
                Ri: c.bg_binary,
                dk: a.g + "_" + a.i,
                Nc: b,
                lc: a.lc,
                Qd: d,
                xe: e,
                Od: f,
                Za: a.Za
            }
        }
    }
    let vj = a => new Promise((b, c) => {
        const d = new XMLHttpRequest;
        d.onreadystatechange = () => {
            d.readyState === d.DONE && (d.status >= 200 && d.status < 300 ? b(JSON.parse(d.responseText)) : c())
        };
        d.open("GET", a, !0);
        d.send()
    });
    async function wj(a) {
        if (a = await uj(a)) {
            var b = window,
                c = b.GoogleGcLKhOms;
            c && typeof c.push === "function" || (c = b.GoogleGcLKhOms = []);
            c.push({
                _ctx_: a.context,
                _bgv_: a.Si,
                _bgp_: a.Ri,
                _li_: a.dk,
                _jk_: a.Nc,
                _st_: a.lc,
                _rc_: a.Qd,
                _dl_: a.xe,
                _g2_: a.Od,
                _atqg_: a.Za === void 0 ? "0" : a.Za ? "1" : "0"
            });
            if (c = b.GoogleDX5YKUSk) b.GoogleDX5YKUSk = void 0, c[1]();
            a = a.Za ? Uc `https://ep2.adtrafficquality.google/sodar/${"sodar2"}.js` : Uc `https://tpc.googlesyndication.com/sodar/${"sodar2"}.js`;
            tj(a)
        }
    };

    function xj(a, b) {
        return Eh(a, 1, b)
    }
    var yj = class extends N {
        i() {
            return F(this, 1)
        }
    };

    function zj(a, b) {
        return z(a, 5, b)
    }

    function Aj(a, b) {
        return Eh(a, 3, b)
    }

    function Cj(a, b) {
        return J(a, 6, b)
    }
    var Dj = class extends N {};

    function Ej(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    }
    var Fj = class {
            constructor(a) {
                this.g = a.i;
                this.i = a.j;
                this.l = a.l;
                this.Nc = a.Nc;
                this.win = a.ca();
                this.lc = a.lc;
                this.Qd = a.Qd;
                this.xe = a.xe;
                this.Od = a.Od;
                this.j = a.g;
                this.Za = a.Za
            }
        },
        Gj = class {
            constructor(a, b, c) {
                this.i = a;
                this.j = b;
                this.l = c;
                this.win = window;
                this.lc = "env";
                this.Qd = "n";
                this.xe = "0";
                this.Od = "1";
                this.g = !0;
                this.Za = !1
            }
            ca() {
                return this.win
            }
            build() {
                return new Fj(this)
            }
        };

    function Hj(a) {
        var b = new Ij;
        return Dh(b, 1, a)
    }
    var Ij = class extends N {
        getValue() {
            return F(this, 1)
        }
        getVersion() {
            return I(this, 5)
        }
    };
    var Jj = class extends N {};
    var Kj = class extends N {};

    function Lj(a, b, c = null, d = !1, e = !1) {
        Mj(a, b, c, d, e)
    }

    function Mj(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = bd("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                d && Qa(a.google_image_requests, f);
                mb(f, "load", g);
                mb(f, "error", g)
            };
            lb(f, "load", g);
            lb(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var Oj = (a, b) => {
            let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
            ed(a, (d, e) => {
                if (d || d === 0) c += `&${e}=${encodeURIComponent(""+d)}`
            });
            Nj(c)
        },
        Nj = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : Lj(b, a, void 0, !1, !1)
        };
    let Pj = null;
    var Qj = window;
    var Rj = class extends N {};
    var Sj = class extends N {
        getCorrelator() {
            return Rf(Gg(this, 1)) ? ? Fg
        }
        setCorrelator(a) {
            return Ch(this, 1, a)
        }
    };
    var Tj = class extends N {};
    let Uj = null,
        Vj = null;

    function Wj() {
        if (Uj != null) return Uj;
        Uj = !1;
        try {
            const a = $c(q);
            a && a.location.hash.indexOf("google_logging") !== -1 && (Uj = !0)
        } catch (a) {}
        return Uj
    }

    function Xj() {
        if (Vj != null) return Vj;
        Vj = !1;
        try {
            const a = $c(q);
            a && a.location.hash.indexOf("auto_ads_logging") !== -1 && (Vj = !0)
        } catch (a) {}
        return Vj
    }
    var Yj = (a, b = []) => {
        let c = !1;
        q.google_logging_queue || (c = !0, q.google_logging_queue = []);
        q.google_logging_queue.push([a, b]);
        c && Wj() && ad(q.document, Uc `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function Zj(a, b) {
        this.x = a !== void 0 ? a : 0;
        this.y = b !== void 0 ? b : 0
    }
    Zj.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    Zj.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    Zj.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    Zj.prototype.scale = function(a, b) {
        this.x *= a;
        this.y *= typeof b === "number" ? b : a;
        return this
    };

    function ak(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    aa = ak.prototype;
    aa.getWidth = function() {
        return this.right - this.left
    };
    aa.getHeight = function() {
        return this.bottom - this.top
    };

    function bk(a) {
        return new ak(a.top, a.right, a.bottom, a.left)
    }
    aa.contains = function(a) {
        return this && a ? a instanceof ak ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };

    function ck(a, b) {
        return a.left <= b.right && b.left <= a.right && a.top <= b.bottom && b.top <= a.bottom
    }
    aa.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    aa.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    aa.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    aa.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.right *= a;
        this.top *= b;
        this.bottom *= b;
        return this
    };

    function dk(a, b) {
        this.width = a;
        this.height = b
    }

    function ek(a, b) {
        return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
    }
    aa = dk.prototype;
    aa.aspectRatio = function() {
        return this.width / this.height
    };
    aa.isEmpty = function() {
        return !(this.width * this.height)
    };
    aa.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    aa.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    aa.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    aa.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function fk(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    }

    function gk(a, b) {
        const c = Math.max(a.left, b.left),
            d = Math.min(a.left + a.width, b.left + b.width);
        if (c <= d) {
            const e = Math.max(a.top, b.top);
            a = Math.min(a.top + a.height, b.top + b.height);
            if (e <= a) return new fk(c, e, d - c, a - e)
        }
        return null
    }

    function hk(a, b) {
        var c = gk(a, b);
        if (!c || !c.height || !c.width) return [new fk(a.left, a.top, a.width, a.height)];
        c = [];
        let d = a.top,
            e = a.height;
        const f = a.left + a.width,
            g = a.top + a.height,
            h = b.left + b.width,
            k = b.top + b.height;
        b.top > a.top && (c.push(new fk(a.left, a.top, a.width, b.top - a.top)), d = b.top, e -= b.top - a.top);
        k < g && (c.push(new fk(a.left, k, a.width, g - k)), e = k - d);
        b.left > a.left && c.push(new fk(a.left, d, b.left - a.left, e));
        h < f && c.push(new fk(h, d, f - h, e));
        return c
    }
    aa = fk.prototype;
    aa.contains = function(a) {
        return a instanceof Zj ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    aa.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    aa.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    aa.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    aa.scale = function(a, b) {
        b = typeof b === "number" ? b : a;
        this.left *= a;
        this.width *= a;
        this.top *= b;
        this.height *= b;
        return this
    };
    const ik = {
        "AMP-CAROUSEL": "ac",
        "AMP-FX-FLYING-CARPET": "fc",
        "AMP-LIGHTBOX": "lb",
        "AMP-STICKY-AD": "sa"
    };

    function jk(a = q) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function kk(a = jk()) {
        return a && a.mode ? +a.mode.version || null : null
    }

    function lk(a = jk()) {
        if (a && a.container) {
            a = a.container.split(",");
            const b = [];
            for (let c = 0; c < a.length; c++) b.push(ik[a[c]] || "x");
            return b.join()
        }
        return null
    }

    function mk() {
        var a = jk();
        return a && a.initialIntersection
    }

    function nk() {
        const a = mk();
        return a && ra(a.rootBounds) ? new dk(a.rootBounds.width, a.rootBounds.height) : null
    }

    function ok(a = jk()) {
        return a ? Xc(a.master) ? a.master : null : null
    }

    function pk(a, b) {
        const c = a.ampInaboxIframes = a.ampInaboxIframes || [];
        let d = () => {},
            e = () => {};
        b && (c.push(b), e = () => {
            a.AMP && a.AMP.inaboxUnregisterIframe && a.AMP.inaboxUnregisterIframe(b);
            Qa(c, b);
            d()
        });
        if (a.ampInaboxInitialized) return e;
        a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
        const f = g => {
            if (a.ampInaboxInitialized) g = !0;
            else {
                var h, k = g.data === "amp-ini-load";
                a.ampInaboxPendingMessages && !k && (h = /^amp-(\d{15,20})?/.exec(g.data)) && (a.ampInaboxPendingMessages.push(g), g = h[1], a.ampInaboxInitialized ||
                    g && !/^\d{15,20}$/.test(g) || a.document.querySelector('script[src$="amp4ads-host-v0.js"]') || ad(a.document, g ? Uc `https://cdn.ampproject.org/rtv/${g}/amp4ads-host-v0.js` : Uc `https://cdn.ampproject.org/amp4ads-host-v0.js`));
                g = !1
            }
            g && d()
        };
        c.google_amp_listener_added || (c.google_amp_listener_added = !0, lb(a, "message", f), d = () => {
            mb(a, "message", f)
        });
        return e
    };

    function qk(a) {
        return a ? new rk(sk(a)) : Ga || (Ga = new rk)
    }

    function tk(a) {
        a = a.document;
        a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
        return new dk(a.clientWidth, a.clientHeight)
    }

    function uk(a) {
        const b = a.scrollingElement ? a.scrollingElement : Ic || a.compatMode != "CSS1Compat" ? a.body || a.documentElement : a.documentElement;
        a = a.defaultView;
        return new Zj(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
    }

    function vk(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function wk(a) {
        a && a.parentNode && a.parentNode.removeChild(a)
    }

    function sk(a) {
        return a.nodeType == 9 ? a : a.ownerDocument || a.document
    }
    var xk = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        },
        yk = {
            IMG: " ",
            BR: "\n"
        };

    function zk(a) {
        const b = [];
        Ak(a, b, !0);
        a = b.join("");
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g, "");
        a = a.replace(/ +/g, " ");
        a != " " && (a = a.replace(/^\s*/, ""));
        return a
    }

    function Ak(a, b, c) {
        if (!(a.nodeName in xk))
            if (a.nodeType == 3) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in yk) b.push(yk[a.nodeName]);
        else
            for (a = a.firstChild; a;) Ak(a, b, c), a = a.nextSibling
    }

    function Bk(a, b, c) {
        if (!b && !c) return null;
        const d = b ? String(b).toUpperCase() : null;
        return Ck(a, function(e) {
            return (!d || e.nodeName == d) && (!c || typeof e.className === "string" && Pa(e.className.split(/\s+/), c))
        })
    }

    function Ck(a, b) {
        let c = 0;
        for (; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function rk(a) {
        this.g = a || q.document || document
    }
    aa = rk.prototype;
    aa.si = function(a) {
        var b = this.g;
        return typeof a === "string" ? b.getElementById(a) : a
    };
    aa.el = rk.prototype.si;

    function Dk(a, b) {
        return vk(a.g, b)
    }

    function Ek(a, b) {
        var c = a.g;
        a = vk(c, "DIV");
        tc(a, b);
        if (a.childNodes.length == 1) b = a.removeChild(a.firstChild);
        else
            for (b = c.createDocumentFragment(); a.firstChild;) b.appendChild(a.firstChild);
        return b
    }
    aa.ca = function() {
        return this.g.defaultView
    };
    aa.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };
    aa.Aj = function(a) {
        let b;
        const c = arguments.length;
        if (!c) return null;
        if (c == 1) return arguments[0];
        const d = [];
        let e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (let h = 1; h < c; h++)
                if (g != d[h][b]) return f;
            f = g
        }
        return f
    };

    function Fk(a, b, c) {
        if (typeof b === "string")(b = Gk(a, b)) && (a.style[b] = c);
        else
            for (const e in b) {
                c = a;
                var d = b[e];
                const f = Gk(c, e);
                f && (c.style[f] = d)
            }
    }
    var Hk = {};

    function Gk(a, b) {
        let c = Hk[b];
        if (!c) {
            var d = Cc(b);
            c = d;
            a.style[d] === void 0 && (d = (Ic ? "Webkit" : Hc ? "Moz" : null) + Dc(d), a.style[d] !== void 0 && (c = d));
            Hk[b] = c
        }
        return c
    }

    function Ik(a, b) {
        const c = a.style[Cc(b)];
        return typeof c !== "undefined" ? c : a.style[Gk(a, b)] || ""
    }

    function Jk(a, b) {
        const c = sk(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    }

    function Kk(a, b) {
        return Jk(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function Lk(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function Mk(a) {
        var b = sk(a);
        const c = new Zj(0, 0);
        if (a == (b ? sk(b) : document).documentElement) return c;
        a = Lk(a);
        b = uk(qk(b).g);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function Nk(a) {
        var b = Ok;
        if (Kk(a, "display") != "none") return b(a);
        const c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function Ok(a) {
        const b = a.offsetWidth,
            c = a.offsetHeight,
            d = Ic && !b && !c;
        return (b === void 0 || d) && a.getBoundingClientRect ? (a = Lk(a), new dk(a.right - a.left, a.bottom - a.top)) : new dk(b, c)
    };
    var Pk = a => typeof a === "number" && a > 0,
        Rk = (a, b) => {
            a = Qk(a);
            if (!a) return b;
            const c = b.slice(-1);
            return b + (c === "?" || c === "#" ? "" : "&") + a
        },
        Qk = a => Object.entries(Sk(a)).map(([b, c]) => `${b}=${encodeURIComponent(String(c))}`).join("&"),
        Sk = a => {
            const b = {};
            ed(a, (c, d) => {
                if (c || c === 0 || c === !1) typeof c === "boolean" && (c = c ? 1 : 0), b[d] = c
            });
            return b
        },
        Tk = a => {
            a = ok(jk(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1
        },
        Uk = a => {
            a = a.google_unique_id;
            return typeof a === "number" ? a : 0
        },
        Vk = a => {
            let b;
            b = a.nodeType !== 9 && a.id;
            a: {
                if (a && a.nodeName &&
                    a.parentElement) {
                    var c = a.nodeName.toString().toLowerCase();
                    const d = a.parentElement.childNodes;
                    let e = 0;
                    for (let f = 0; f < d.length; ++f) {
                        const g = d[f];
                        if (g.nodeName && g.nodeName.toString().toLowerCase() === c) {
                            if (a === g) {
                                c = "." + e;
                                break a
                            }++e
                        }
                    }
                }
                c = ""
            }
            return (a.nodeName && a.nodeName.toString().toLowerCase()) + (b ? "/" + b : "") + c
        },
        Wk = a => (a = a.google_ad_format) ? a.indexOf("_0ads") > 0 : !1,
        Xk = a => {
            let b = Number(a.google_ad_width),
                c = Number(a.google_ad_height);
            if (!(b > 0 && c > 0)) {
                a: {
                    try {
                        const e = String(a.google_ad_format);
                        if (e && e.match) {
                            const f =
                                e.match(/(\d+)x(\d+)/i);
                            if (f) {
                                const g = parseInt(f[1], 10),
                                    h = parseInt(f[2], 10);
                                if (g > 0 && h > 0) {
                                    var d = {
                                        width: g,
                                        height: h
                                    };
                                    break a
                                }
                            }
                        }
                    } catch (e) {}
                    d = null
                }
                a = d;
                if (!a) return null;b = b > 0 ? b : a.width;c = c > 0 ? c : a.height
            }
            return {
                width: b,
                height: c
            }
        };
    var Yk = class {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };

    function Zk(a) {
        return new Yk(a, {
            message: $k(a)
        })
    }

    function $k(a) {
        let b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        a.stack && (b = al(a.stack, b));
        return b
    }

    function al(a, b) {
        try {
            a.indexOf(b) == -1 && (a = b + "\n" + a);
            let c;
            for (; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (c) {
            return b
        }
    };
    const bl = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var cl = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        dl = class {
            constructor(a, b, c) {
                this.url = a;
                this.win = b;
                this.wh = !!c;
                this.depth = null
            }
        };
    let el = null;

    function fl() {
        var a = window;
        if (el === null) {
            el = "";
            try {
                let b = "";
                try {
                    b = a.top.location.hash
                } catch (c) {
                    b = a.location.hash
                }
                if (b) {
                    const c = b.match(/\bdeid=([\d,]+)/);
                    el = c ? c[1] : ""
                }
            } catch (b) {}
        }
        return el
    };

    function gl() {
        const a = q.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function hl() {
        const a = q.performance;
        return a && a.now ? a.now() : null
    };
    var il = class {
        constructor(a, b) {
            var c = hl() || gl();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const jl = q.performance,
        kl = !!(jl && jl.mark && jl.measure && jl.clearMarks),
        ll = eb(() => {
            var a;
            if (a = kl) a = fl(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function ml(a) {
        a && jl && ll() && (jl.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), jl.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function nl(a) {
        a.g = !1;
        a.i !== a.j.google_js_reporting_queue && (ll() && Ia(a.i, ml), a.i.length = 0)
    }

    function ol(a, b) {
        if (!a.g) return b();
        const c = a.start("491", 3);
        let d;
        try {
            d = b()
        } catch (e) {
            throw ml(c), e;
        }
        a.end(c);
        return d
    }
    var pl = class {
        constructor(a) {
            this.i = [];
            this.j = a || q;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = ll() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new il(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            jl && ll() && jl.mark(b);
            return a
        }
        end(a) {
            if (this.g && typeof a.value === "number") {
                a.duration = (hl() || gl()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                jl && ll() && jl.mark(b);
                !this.g || this.i.length >
                    2048 || this.i.push(a)
            }
        }
    };

    function ql(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function rl(a, b, c, d, e) {
        const f = [];
        ed(a, (g, h) => {
            (g = sl(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function sl(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c === "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(sl(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(rl(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function tl(a) {
        let b = 1;
        for (const c in a.i) c.length > b && (b = c.length);
        return 3997 - b - a.j.length - 1
    }

    function ul(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = tl(a) - b.length;
        if (d < 0) return "";
        a.g.sort((f, g) => f - g);
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.i[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = b == null ? g : b;
                    break
                }
                let l = rl(h[k], a.j, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.j;
                        break
                    }
                    b = b == null ? g : b
                }
            }
        }
        a = "";
        b != null && (a = `${e}${"trn"}=${b}`);
        return c + a
    }
    var vl = class {
        constructor() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.g = []
        }
    };
    var xl = class {
        constructor(a, b, c = null) {
            this.H = a;
            this.B = b;
            this.i = c;
            this.g = null;
            this.l = !1;
            this.A = this.ia
        }
        lg(a) {
            this.g = a
        }
        j(a) {
            this.l = a
        }
        Wa(a, b, c) {
            let d, e;
            try {
                this.i && this.i.g ? (e = this.i.start(a.toString(), 3), d = b(), this.i.end(e)) : d = b()
            } catch (f) {
                b = this.B;
                try {
                    ml(e), b = this.A(a, Zk(f), void 0, c)
                } catch (g) {
                    this.ia(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        Xa(a, b, c, d) {
            return (...e) => this.Wa(a, () => b.apply(c, e), d)
        }
        ia(a, b, c, d, e) {
            e = e || "jserror";
            let f = void 0;
            try {
                const H = new vl;
                var g = H;
                g.g.push(1);
                g.i[1] =
                    ql("context", a);
                b.error && b.meta && b.id || (b = Zk(b));
                g = b;
                if (g.msg) {
                    b = H;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.i[2] = ql("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.g) try {
                    this.g(h)
                } catch (ma) {}
                if (d) try {
                    d(h)
                } catch (ma) {}
                d = H;
                k = [k];
                d.g.push(3);
                d.i[3] = k;
                d = q;
                k = [];
                h = null;
                do {
                    var l = d;
                    if (Xc(l)) {
                        var m = l.location.href;
                        h = l.document && l.document.referrer || null
                    } else m = h, h = null;
                    k.push(new dl(m || "", l));
                    try {
                        d = l.parent
                    } catch (ma) {
                        d = null
                    }
                } while (d && l != d);
                for (let ma = 0, na = k.length - 1; ma <= na; ++ma) k[ma].depth = na - ma;
                l = q;
                if (l.location &&
                    l.location.ancestorOrigins && l.location.ancestorOrigins.length == k.length - 1)
                    for (m = 1; m < k.length; ++m) {
                        var n = k[m];
                        n.url || (n.url = l.location.ancestorOrigins[m - 1] || "", n.wh = !0)
                    }
                var p = k;
                let K = new dl(q.location.href, q, !1);
                l = null;
                const ia = p.length - 1;
                for (n = ia; n >= 0; --n) {
                    var t = p[n];
                    !l && bl.test(t.url) && (l = t);
                    if (t.url && !t.wh) {
                        K = t;
                        break
                    }
                }
                t = null;
                const Jb = p.length && p[ia].url;
                K.depth != 0 && Jb && (t = p[ia]);
                f = new cl(K, t);
                if (f.i) {
                    p = H;
                    var v = f.i.url || "";
                    p.g.push(4);
                    p.i[4] = ql("top", v)
                }
                var w = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    const ma =
                        f.g.url.match(Ec);
                    var B = ma[1],
                        G = ma[3],
                        L = ma[4];
                    v = "";
                    B && (v += B + ":");
                    G && (v += "//", v += G, L && (v += ":" + L));
                    var A = v
                } else A = "";
                B = H;
                w = [w, {
                    url: A
                }];
                B.g.push(5);
                B.i[5] = w;
                wl(this.H, e, H, this.l, c)
            } catch (H) {
                try {
                    wl(this.H, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: $k(H),
                        url: f ? .g.url ? ? ""
                    }, this.l, c)
                } catch (K) {}
            }
            return this.B
        }
        Fa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.ia(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    var yl = class extends N {};
    var zl = rj([0, pj, jj]);

    function Al(a, b) {
        try {
            const c = d => [{
                [d.Ya]: d.be
            }];
            return JSON.stringify([a.filter(d => d.Ka).map(c), vg(b), a.filter(d => !d.Ka).map(c)])
        } catch (c) {
            return Bl(c, b), ""
        }
    }

    function Cl(a, b) {
        const c = new ei;
        try {
            const d = a.filter(f => f.Ka).map(Dl);
            ci(c, 1, d);
            bi(c, 2, zl(b), di);
            const e = a.filter(f => !f.Ka).map(Dl);
            ci(c, 3, e)
        } catch (d) {
            Bl(d, b)
        }
        return ai(c)
    }

    function Bl(a, b) {
        try {
            Oj({
                m: $k(a instanceof Error ? a : Error(String(a))),
                b: I(b, 1) || null,
                v: F(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }

    function Dl(a) {
        const b = new ei;
        bi(b, a.Ya, a.ve, di);
        return ai(b)
    }

    function di(a, b) {
        Xh(b, a.subarray(0, a.length))
    }
    var El = class {
        constructor(a, b) {
            var c = new yl;
            a = M(c, 1, a);
            this.i = Eh(a, 2, b).g()
        }
    };

    function Fl(a) {
        return Math.round(a)
    };

    function Gl(a, b) {
        return $g(a, 1, Hl, Yf(b))
    }

    function Il(a, b) {
        return $g(a, 2, Hl, Jf(b))
    }

    function Jl(a, b) {
        return $g(a, 3, Hl, b == null ? b : tf(b))
    }
    var P = class extends N {},
        Hl = [1, 2, 3];

    function Kl(a, b) {
        return $g(a, 2, Ll, Jf(b))
    }

    function Ml(a, b) {
        return $g(a, 4, Ll, rf(b))
    }
    var Nl = class extends N {},
        Ll = [2, 4];

    function Ol(a) {
        var b = new Pl;
        return Eh(b, 1, a)
    }

    function Ql(a, b) {
        return z(a, 3, b)
    }

    function Q(a, b) {
        return kh(a, 4, P, b)
    }
    var Pl = class extends N {};
    var Rl = rj([0, jj, 1, [0, Ll, 1, Xi, 1, Ri], lj, [0, Hl, kj, Xi, gj]]);
    var Sl = class extends N {
        j() {
            return F(this, 2)
        }
        getWidth() {
            return F(this, 3)
        }
        getHeight() {
            return F(this, 4)
        }
    };
    var Tl = class extends N {};
    var Ul = class extends N {};
    var Vl = class extends N {};
    var Wl = class extends N {},
        Xl = [5, 6];
    var Yl = [0, Ui, -1];
    var Zl = [0, lj, [0, oj, [0, aj, -3]], Yl, -1];
    var $l = class extends N {
        getValue() {
            return I(this, 1)
        }
    };

    function am(a) {
        var b = new bm;
        return Fh(b, 1, a)
    }
    var bm = class extends N {
        getValue() {
            return I(this, 1)
        }
    };
    var cm = class extends N {
        getValue() {
            return I(this, 1)
        }
    };

    function dm(a, b) {
        return Ch(a, 1, b)
    }

    function em(a, b) {
        return Ch(a, 2, b)
    }

    function fm(a, b) {
        return Ch(a, 3, b)
    }

    function gm(a, b) {
        return Ch(a, 4, b)
    }

    function hm(a, b) {
        return Ch(a, 5, b)
    }

    function im(a, b) {
        return Zg(a, 8, rf(b), 0)
    }

    function jm(a, b) {
        return Zg(a, 9, rf(b), 0)
    }
    var km = class extends N {};

    function lm(a, b) {
        return Ch(a, 1, b)
    }

    function mm(a, b) {
        return Ch(a, 2, b)
    }
    var nm = class extends N {};

    function om(a, b) {
        kh(a, 1, nm, b)
    }
    var Xg = class extends N {};
    var pm = class extends N {};

    function qm(a, b) {
        return Yg(a, 1, b, Xf)
    }

    function rm(a, b) {
        return Yg(a, 12, b, Sf)
    }

    function sm() {
        var a = new tm;
        return jh(a, 2, Xf, "irr", Zf)
    }

    function um(a, b) {
        return J(a, 3, b)
    }

    function vm(a, b) {
        return J(a, 4, b)
    }

    function wm(a, b) {
        return J(a, 5, b)
    }

    function xm(a, b) {
        return J(a, 7, b)
    }

    function ym(a, b) {
        return J(a, 8, b)
    }

    function zm(a, b) {
        return Ch(a, 9, b)
    }

    function Am(a, b) {
        return ih(a, 10, b)
    }

    function Bm(a, b) {
        return Yg(a, 11, b, Df)
    }
    var tm = class extends N {};

    function Cm(a) {
        var b = Dm();
        z(a, 1, b)
    }

    function Em(a, b) {
        return Ch(a, 2, b)
    }

    function Fm(a, b) {
        return ih(a, 3, b)
    }

    function Gm(a, b) {
        return ih(a, 4, b)
    }

    function Hm(a, b) {
        return kh(a, 4, bm, b)
    }

    function Im(a, b) {
        return ih(a, 5, b)
    }

    function Jm(a, b) {
        return Yg(a, 6, b, Xf)
    }

    function Km(a, b) {
        return Ch(a, 7, b)
    }

    function Lm(a, b) {
        return Ch(a, 8, b)
    }

    function Mm(a, b) {
        z(a, 9, b)
    }

    function Nm(a, b) {
        return J(a, 10, b)
    }

    function Om(a, b) {
        return J(a, 11, b)
    }

    function Pm(a, b) {
        return J(a, 12, b)
    }
    var Qm = class extends N {};
    var Rm = class extends N {};
    var Sm = class extends N {};

    function Tm(a) {
        var b = new Um;
        return M(b, 1, a)
    }
    var Um = class extends N {};
    var Vm = class extends N {};
    var Wm = class extends N {};
    var Xm = class extends N {};
    var Ym = class extends N {},
        Zm = [1, 2];
    var $m = class extends N {};
    var an = class extends N {},
        bn = [1];

    function cn(a) {
        var b = new dn;
        return M(b, 1, a)
    }
    var dn = class extends N {};
    var en = class extends N {};
    var fn = class extends N {};
    var gn = class extends N {};
    var hn = class extends N {};
    var jn = class extends N {};
    var kn = class extends N {
        getContentUrl() {
            return F(this, 1)
        }
    };
    var ln = class extends N {};

    function mn(a) {
        var b = new nn;
        return Yg(b, 1, a, xf)
    }
    var nn = class extends N {};
    var on = class extends N {};

    function pn() {
        var a = new qn,
            b = new on;
        return C(a, 1, rn, b)
    }

    function sn() {
        var a = new qn,
            b = new on;
        return C(a, 9, rn, b)
    }

    function tn() {
        var a = new qn,
            b = new on;
        return C(a, 13, rn, b)
    }

    function un(a, b) {
        return C(a, 14, rn, b)
    }
    var qn = class extends N {},
        rn = [1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
    var vn = class extends N {};
    var wn = class extends N {};
    var xn = class extends N {};
    var yn = class extends N {};

    function zn(a, b) {
        return Zg(a, 10, Tf(b), "0")
    }

    function An(a, b) {
        return M(a, 1, b)
    }
    var Bn = class extends N {};
    var Cn = class extends N {};
    var Dn = class extends N {};
    var Fn = class extends N {
            j() {
                return uh(this, Cn, 4, En)
            }
            i() {
                return Mg(this, Cn, 4, En)
            }
        },
        En = [4, 5];

    function Gn(a) {
        var b = new Hn;
        return Eh(b, 4, a)
    }

    function In(a, b) {
        return Ig(a, 6, Tf(b))
    }
    var Hn = class extends N {};
    var Jn = class extends N {};
    var Kn = class extends N {
        j() {
            return y(this, Cn, 1)
        }
        i() {
            return Kg(this, Cn, 1)
        }
    };
    var Ln = class extends N {};
    var Mn = class extends N {};
    var Nn = class extends N {};
    var On = class extends N {};
    var Pn = class extends N {},
        Qn = [2, 3];
    var Rn = class extends N {},
        Sn = [3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 16, 17];
    var Tn = class extends N {};

    function Un(a, b) {
        return Bh(a, 1, b)
    }

    function Vn(a, b) {
        return Bh(a, 2, b)
    }
    var Wn = class extends N {
        getWidth() {
            return Rf(Gg(this, 1)) ? ? Fg
        }
        getHeight() {
            return Rf(Gg(this, 2)) ? ? Fg
        }
    };
    var Xn = class extends N {
        getContentUrl() {
            return F(this, 4)
        }
    };

    function Yn(a, b) {
        return z(a, 1, b)
    }
    var Zn = class extends N {};
    var $n = class extends N {};
    var ao = class extends N {};

    function bo(a, b) {
        return C(a, 3, co, b)
    }
    var eo = class extends N {},
        co = [1, 2, 3, 4];

    function fo(a, b) {
        return Ch(a, 3, b)
    }
    var go = class extends N {},
        ho = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17];
    var io = [0];
    var jo = [0, fj, lj, [0, pj, jj, -2, cj, -2, [0, jj, 2, cj, -1, jj, [0, cj, -2, Si], -1], lj, [0, jj, ij], $i, hj, aj], Wi, [0, fj, Wi, fj, -2]];
    var ko = [0, Ui, -1];
    var lo = rj([0, ho, Wi, jj, Wi, O, [0, Yl, -1, [0, nj], jj, fj], O, [0, [0, ij, -1, fj, -5, Wi, lj, [0, jj, Wi, fj, -1], Vi, Zi, $i], Wi, lj, [0, nj], lj, [0, nj], lj, [0, nj], ij, Wi, -1, [0, Wi, -4, 2, Qi, -1], fj, -2, 1, Gi, [!0, hj, [0, lj, [0, Wi, -1]]], lj, [0, jj, -2]], O, [0, Sn, Wi, -1, O, [0, En, [0, jj, -1, fj, Ui],
            [0, ij, jj, -1], Wi, O, jo, O, [0, lj, [0, rn, O, io, -2, 1, O, io, -1, O, [0, Wi], O, io, -5, O, [0, oj]]],
            [0, aj, -1, mj, -2, aj]
        ], O, [0, Wi, $i], O, [0, Wi], O, [0, Ui, Yi, hj, jj, fj, aj], O, [0, Wi], O, [0, Ui, -2, jj, ej, Yi, Ui], O, [0, Qn, Wi, O, [0], O, [0]],
        [0, Wi, cj, Vi], O, [0, pj], O, [0, Wi, jj, $i], O, [0], O, [0,
            jo, Wi
        ], ej, O, [0, $i], O, [0, Wi]
    ], Wi, O, [0, jj, [0, cj, -1, [0, Qi, -5, fj]], Wi, Zl], O, [0, pj, bj], O, [0, pj, -1, jj, -1], O, [0, bn, O, [0, ej, -1]], O, [0, pj, fj, -9], O, [0, Zm, O, [0, [0, pj, jj, -1]], O, [0, cj, -1, jj, [0, cj, -1], -1, fj, oj, cj, -1]], O, [0, co, O, [0, [0, Ui, -1], ko, ej, hj], O, [0], O, [0, ko], O, [0]], O, [0, [3, 4, 5, 6, 7, 8], Ui, [0, Ti], O, [0], O, [0], O, [0], O, [0], O, [0], O, [0, [1, 2, 3, 4, 5], O, [0], -4]], O, [0, Xl, Ui, -2, [0, hj, -2, ej, [0, hj, -3]], O, [0], O, [0]], O, Zl]);

    function mo(a, b) {
        return Ch(a, 1, b)
    }

    function no(a, b) {
        return Ch(a, 2, b)
    }
    var oo = class extends N {
        getTagSessionCorrelator() {
            return Rf(Gg(this, 1)) ? ? Fg
        }
    };
    var po = rj([0, Wi, -1, pj]);
    var qo = class extends N {};

    function ro() {
        var a = lg(so());
        return Eh(a, 1, to())
    }
    var uo = class extends N {};
    var vo = [0, [0, Ui, dj, -1], jj];
    var wo = class extends N {};
    var xo = class extends N {
        getTagSessionCorrelator() {
            return Rf(Gg(this, 1)) ? ? Fg
        }
    };
    var yo = class extends N {},
        zo = [1, 7],
        Ao = [4, 6, 8];
    var Bo = rj([0, zo, Ao, O, [0, pj, jj, -1, ij, -1, vo],
        [0, Wi, bj, jj], 1, O, [0, jj, cj, ij], Wi, O, [0, jj, -1, hj, [0, bj], 1, pj, jj, -1], O, [0, jj, -1, ij, -1, vo], O, [0, [1], O, [0, [0, jj, -2, pj, jj]],
            [0, Wi, -1]
        ]
    ]);
    class Co {
        constructor(a) {
            this.H = a;
            this.ze = new Do(this.H)
        }
    }
    class Do {
        constructor(a) {
            this.H = a;
            this.ld = new Eo(this.H)
        }
    }
    class Eo {
        constructor(a) {
            this.H = a;
            this.g = new Fo(this.H);
            this.ai = new Go(this.H)
        }
    }
    class Fo {
        constructor(a) {
            this.H = a;
            this.i = new Ho(this.H);
            this.g = new Io(this.H)
        }
    }
    class Ho {
        constructor(a) {
            this.H = a
        }
        Xc(a) {
            this.H.g(Ql(Q(Ol("xR0Czf"), Gl(new P, a.status)), Ml(new Nl, a.cd)))
        }
    }
    class Io {
        constructor(a) {
            this.H = a
        }
        Xc(a) {
            this.H.g(Ql(Q(Ol("jM4CPd"), Il(new P, Fl(a.Vk))), Ml(new Nl, a.cd)))
        }
    }
    class Go {
        constructor(a) {
            this.H = a;
            this.Ai = new Jo(this.H);
            this.Bi = new Ko(this.H);
            this.Qe = new Lo(this.H);
            this.Ci = new Mo(this.H);
            this.Di = new No(this.H);
            this.Ei = new Oo(this.H);
            this.Fi = new Po(this.H);
            this.Se = new Qo(this.H);
            this.Zi = new Ro(this.H);
            this.lj = new So(this.H);
            this.mj = new To(this.H);
            this.Cj = new Uo(this.H);
            this.Dk = new Vo(this.H)
        }
    }
    class Jo {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Ol("VEDP7d"), Gl(new P, a.language)), Il(new P, a.ya)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Ko {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Ol("igjuhc"), Gl(new P, a.language)), Il(new P, a.ya)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Lo {
        constructor(a) {
            this.H = a
        }
        Xc(a) {
            this.H.g(Ql(Q(Q(Q(Q(Q(Ol("i3zJEd"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.outcome)), Jl(new P, a.Mc)), Jl(new P, a.xf)), Ml(new Nl, a.cd)))
        }
    }
    class Mo {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Q(Q(Ol("JN0hVd"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.outcome)), Jl(new P, a.Mc)), Jl(new P, a.xf)), Kl(new Nl, Fl(a.da))))
        }
    }
    class No {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Ol("rmHfOd"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.reason)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Oo {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Ol("VEyQic"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.format)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Po {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Ol("QFcNxc"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.format)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Qo {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Q(Ol("SIhp4"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.format)), Jl(new P, a.Mc)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Ro {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Ol("Eeiun"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.format)), Kl(new Nl, Fl(a.da))))
        }
    }
    class So {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Ol("zGH6sc"), Gl(new P, a.language)), Il(new P, a.ya)), Kl(new Nl, Fl(a.da))))
        }
    }
    class To {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Ol("SmbJl"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.type)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Uo {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Ol("qleBg"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.format)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Vo {
        constructor(a) {
            this.H = a
        }
        Ea(a) {
            this.H.g(Ql(Q(Q(Q(Ol("pYLGPe"), Gl(new P, a.language)), Il(new P, a.ya)), Il(new P, a.type)), Kl(new Nl, Fl(a.da))))
        }
    }
    class Wo extends El {
        constructor() {
            super(...arguments);
            this.ce = new Co(this)
        }
    }
    var Xo = class extends Wo {
            Yh(...a) {
                this.B(...a.map(b => ({
                    Ka: !0,
                    Ya: 3,
                    be: vg(b)
                })))
            }
            lb(...a) {
                this.B(...a.map(b => ({
                    Ka: !0,
                    Ya: 7,
                    be: vg(b)
                })))
            }
            D(...a) {
                this.B(...a.map(b => ({
                    Ka: !0,
                    Ya: 16,
                    be: vg(b)
                })))
            }
            g(...a) {
                this.B(...a.map(b => ({
                    Ka: !1,
                    Ya: 1,
                    be: vg(b)
                })))
            }
        },
        Zo = class extends Wo {
            Yh(...a) {
                Yo(this, ...a.map(b => ({
                    Ka: !0,
                    Ya: 3,
                    ve: Bo(b)
                })))
            }
            lb(...a) {
                Yo(this, ...a.map(b => ({
                    Ka: !0,
                    Ya: 7,
                    ve: lo(b)
                })))
            }
            D(...a) {
                Yo(this, ...a.map(b => ({
                    Ka: !0,
                    Ya: 16,
                    ve: po(b)
                })))
            }
            g(...a) {
                Yo(this, ...a.map(b => ({
                    Ka: !1,
                    Ya: 1,
                    ve: Rl(b)
                })))
            }
        };
    var $o = (a, b) => {
            globalThis.fetch(a, {
                method: "POST",
                body: b,
                keepalive: b.length < 65536,
                credentials: "omit",
                mode: "no-cors",
                redirect: "follow"
            }).catch(() => {})
        },
        ap = class extends Xo {
            constructor(a) {
                super(2, a);
                this.j = $o
            }
            B(...a) {
                try {
                    const b = Al(a, this.i);
                    this.j("https://pagead2.googlesyndication.com/pagead/ping?e=1", b)
                } catch (b) {
                    Bl(b, this.i)
                }
            }
        },
        bp = class extends ap {};

    function cp(a) {
        a.l !== null && (clearTimeout(a.l), a.l = null);
        if (a.j.length) {
            var b = Al(a.j, a.i);
            a.F("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.j = []
        }
    }
    var ep = class extends Xo {
            constructor(a, b, c, d, e) {
                super(2, a);
                this.F = $o;
                this.U = b;
                this.I = c;
                this.M = d;
                this.A = e;
                this.j = [];
                this.l = null;
                this.G = !1
            }
            B(...a) {
                try {
                    this.M && Al(this.j.concat(a), this.i).length >= 65536 && cp(this), this.A && !this.G && (this.G = !0, dp(this.A, () => {
                        cp(this)
                    })), this.j.push(...a), this.j.length >= this.I && cp(this), this.j.length && this.l === null && (this.l = setTimeout(() => {
                        cp(this)
                    }, this.U))
                } catch (b) {
                    Bl(b, this.i)
                }
            }
        },
        fp = class extends ep {
            constructor(a, b = 1E3, c = 100, d = !1, e) {
                super(a, b, c, d && !0, e)
            }
        };
    var R = a => {
        var b = "Ff";
        if (a.Ff && a.hasOwnProperty(b)) return a.Ff;
        b = new a;
        return a.Ff = b
    };

    function gp(a, b, c) {
        return b[a] || c
    };

    function hp(a, b) {
        a.i = (c, d) => gp(2, b, () => [])(c, 1, d);
        a.g = () => gp(3, b, () => [])(1)
    }
    class ip {
        i() {
            return []
        }
        g() {
            return []
        }
    }

    function jp(a, b) {
        return R(ip).i(a, b)
    };

    function wl(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof vl ? f = c : (f = new vl, ed(c, (h, k) => {
                var l = f;
                const m = l.l++;
                h = ql(k, h);
                l.g.push(m);
                l.i[m] = h
            }));
            const g = ul(f, "/pagead/gen_204?id=" + b + "&");
            g && Lj(q, g)
        } catch (f) {}
    }

    function kp(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    class lp {
        constructor() {
            this.g = Math.random()
        }
    };
    let mp, np;
    const op = new pl(window);
    (a => {
        mp = a ? ? new lp;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        kp(mp, window.google_srt);
        np = new xl(mp, !0, op);
        np.lg(() => {});
        np.j(!0);
        window.document.readyState == "complete" ? window.google_measure_js_timing || nl(op) : op.g && lb(window, "load", () => {
            window.google_measure_js_timing || nl(op)
        })
    })();
    let pp = (new Date).getTime();
    var qp = {
        bn: 0,
        Zm: 1,
        Wm: 2,
        Rm: 3,
        Xm: 4,
        Sm: 5,
        Ym: 6,
        Um: 7,
        Vm: 8,
        Qm: 9,
        Tm: 10,
        cn: 11
    };
    var rp = {
        en: 0,
        fn: 1,
        dn: 2
    };

    function sp(a, b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
    }

    function tp(a) {
        a = a.map(b => new ak(b.top, b.right, b.bottom, b.left));
        a = up(a);
        return {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left
        }
    }

    function up(a) {
        if (!a.length) throw Error("pso:box:m:nb");
        return a.slice(1).reduce((b, c) => {
            b.left = Math.min(b.left, c.left);
            b.top = Math.min(b.top, c.top);
            b.right = Math.max(b.right, c.right);
            b.bottom = Math.max(b.bottom, c.bottom);
            return b
        }, bk(a[0]))
    };
    var Ob = {
        Un: 0,
        Fm: 1,
        Im: 2,
        Gm: 3,
        Hm: 4,
        Om: 8,
        fo: 9,
        un: 10,
        vn: 11,
        co: 16,
        zm: 17,
        ym: 24,
        rn: 25,
        dm: 26,
        cm: 27,
        ui: 30,
        jn: 32,
        nn: 40,
        mo: 41,
        ho: 42
    };
    var vp = {
            overlays: 1,
            interstitials: 2,
            vignettes: 2,
            inserts: 3,
            immersives: 4,
            list_view: 5,
            full_page: 6,
            side_rails: 7
        },
        wp = {
            [1]: 1,
            [2]: 1,
            [3]: 7,
            [4]: 7,
            [8]: 2,
            [27]: 3,
            [9]: 4,
            [30]: 5
        };
    var xp = 728 * 1.38;

    function yp(a, b = -1) {
        if (a !== a.top) {
            if (b < 0) a = !1;
            else {
                var c = zp(a, !0, !0),
                    d = Ap(a, !0);
                a = c > 0 && d > 0 && Math.abs(1 - a.screen.width / c) <= b && Math.abs(1 - a.screen.height / d) <= b
            }
            a = a ? 0 : 512
        } else a = 0;
        return a
    }

    function Bp(a, b = 420, c = !1, d = !1) {
        return (a = zp(a, c, d)) ? a > b ? 32768 : a < 320 ? 65536 : 0 : 16384
    }

    function Cp(a) {
        return Math.max(0, Dp(a, !0) - Ap(a))
    }

    function Ep(a) {
        a = a.document;
        let b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function Ap(a, b = !1) {
        const c = Ep(a).clientHeight;
        return b ? c * Kd(a) : c
    }

    function zp(a, b = !1, c = !1) {
        c = Ep(a).clientWidth ? ? (c ? a.innerWidth : void 0);
        return b ? c * Kd(a) : c
    }

    function Dp(a, b) {
        const c = Ep(a);
        return b ? (a = Ap(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    }

    function Fp(a, b) {
        return Gp(b) || b === 10 || !a.adCount ? !1 : b == 1 || b == 2 ? !(!a.adCount[1] && !a.adCount[2]) : (a = a.adCount[b]) ? a >= 1 : !1
    }

    function Hp(a, b) {
        return a && a.source ? a.source === b || a.source.parent === b : !1
    }

    function Ip(a) {
        return a.pageYOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    }

    function Jp(a) {
        return a.pageXOffset === void 0 ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollLeft : a.pageXOffset
    }

    function Kp(a) {
        const b = {};
        let c;
        Array.isArray(a) ? c = a : a && a.key_value && (c = a.key_value);
        if (c)
            for (a = 0; a < c.length; a++) {
                const d = c[a];
                if ("key" in d && "value" in d) {
                    const e = d.value;
                    b[d.key] = e == null ? null : String(e)
                }
            }
        return b
    }

    function Lp(a, b, c, d) {
        wl(c, b, {
            c: d.data.substring(0, 500),
            u: a.location.href.substring(0, 500)
        }, !0, .1);
        return !0
    }

    function Mp(a) {
        const b = {
            bottom: "auto",
            clear: "none",
            display: "inline",
            "float": "none",
            height: "auto",
            left: "auto",
            margin: 0,
            "margin-bottom": 0,
            "margin-left": 0,
            "margin-right": "0",
            "margin-top": 0,
            "max-height": "none",
            "max-width": "none",
            opacity: 1,
            overflow: "visible",
            padding: 0,
            "padding-bottom": 0,
            "padding-left": 0,
            "padding-right": 0,
            "padding-top": 0,
            position: "static",
            right: "auto",
            top: "auto",
            "vertical-align": "baseline",
            visibility: "visible",
            width: "auto",
            "z-index": "auto"
        };
        Ia(Object.keys(b), c => {
            Ik(a, c) || Fk(a, c, b[c])
        });
        wd(a)
    }

    function Gp(a) {
        return a === 26 || a === 27 || a === 40 || a === 41
    };

    function Np(a, b) {
        Op(a).forEach(b, void 0)
    }

    function Op(a) {
        const b = [],
            c = a.length;
        for (let d = 0; d < c; d++) b.push(a[d]);
        return b
    };

    function Pp(a, b) {
        return a.g[Qp(b)] !== void 0
    }

    function Rp(a) {
        const b = [];
        for (const c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.i[c]);
        return b
    }

    function Sp(a) {
        const b = [];
        for (const c in a.g) a.g[c] !== void 0 && a.g.hasOwnProperty(c) && b.push(a.g[c]);
        return b
    }
    var Tp = class {
        constructor() {
            this.g = {};
            this.i = {}
        }
        set(a, b) {
            const c = Qp(a);
            this.g[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = Qp(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        Kc() {
            return Rp(this).length
        }
        clear() {
            this.g = {};
            this.i = {}
        }
    };

    function Qp(a) {
        return a instanceof Object ? String(sa(a)) : a + ""
    };
    var Up = class {
        constructor(a) {
            this.g = new Tp;
            if (a)
                for (let b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return Pp(this.g, a)
        }
    };
    const Vp = new Up("IMG AMP-IMG IFRAME AMP-IFRAME HR EMBED OBJECT VIDEO AMP-VIDEO INPUT BUTTON SVG".split(" "));

    function Wp(a, {
        ob: b,
        hb: c,
        Lb: d
    }) {
        return d && c(b) ? b : (b = b.parentElement) ? Xp(a, {
            ob: b,
            hb: c,
            Lb: !0
        }) : null
    }

    function Xp(a, {
        ob: b,
        hb: c,
        Lb: d = !1
    }) {
        const e = Yp({
                ob: b,
                hb: c,
                Lb: d
            }),
            f = a.g.get(e);
        if (f) return f.element;
        b = Wp(a, {
            ob: b,
            hb: c,
            Lb: d
        });
        a.g.set(e, {
            element: b
        });
        return b
    }
    var Zp = class {
        constructor() {
            this.g = new Map
        }
    };

    function Yp({
        ob: a,
        hb: b,
        Lb: c
    }) {
        a = sa(a);
        b = sa(b);
        return `${a}:${b}:${c}`
    };

    function $p(a) {
        Tb(a.document.body.offsetHeight)
    };

    function aq(a) {
        a && typeof a.dispose == "function" && a.dispose()
    };

    function S() {
        this.B = this.B;
        this.G = this.G
    }
    S.prototype.B = !1;
    S.prototype.dispose = function() {
        this.B || (this.B = !0, this.i())
    };
    S.prototype[ha(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function bq(a, b) {
        cq(a, Aa(aq, b))
    }

    function cq(a, b) {
        a.B ? b() : (a.G || (a.G = []), a.G.push(b))
    }
    S.prototype.i = function() {
        if (this.G)
            for (; this.G.length;) this.G.shift()()
    };

    function dq(a) {
        a.g.forEach((b, c) => {
            if (b.overrides.delete(a)) {
                b = Array.from(b.overrides.values()).pop() || b.originalValue;
                var d = a.element;
                b ? d.style.setProperty(c, b.value, b.priority) : d.style.removeProperty(c)
            }
        })
    }

    function eq(a, b, c) {
        c = {
            value: c,
            priority: "important"
        };
        var d = a.g.get(b);
        if (!d) {
            d = a.element;
            var e = d.style.getPropertyValue(b);
            d = {
                originalValue: e ? {
                    value: e,
                    priority: d.style.getPropertyPriority(b)
                } : null,
                overrides: new Map
            };
            a.g.set(b, d)
        }
        d.overrides.delete(a);
        d.overrides.set(a, c);
        a = a.element;
        c ? a.style.setProperty(b, c.value, c.priority) : a.style.removeProperty(b)
    }
    var fq = class extends S {
        constructor(a, b) {
            super();
            this.element = b;
            a = a.googTempStyleOverrideInfo = a.googTempStyleOverrideInfo || new Map;
            var c = a.get(b);
            c ? b = c : (c = new Map, a.set(b, c), b = c);
            this.g = b
        }
        i() {
            dq(this);
            super.i()
        }
    };

    function gq(a) {
        const b = new T(a.getValue());
        a.listen(c => b.g(c));
        return b
    }

    function hq(a, b) {
        const c = new T({
            first: a.O,
            second: b.O
        });
        a.listen(() => c.g({
            first: a.O,
            second: b.O
        }));
        b.listen(() => c.g({
            first: a.O,
            second: b.O
        }));
        return c
    }

    function iq(...a) {
        const b = [...a],
            c = () => b.every(f => f.O),
            d = new T(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return jq(d)
    }

    function kq(...a) {
        const b = [...a],
            c = () => b.findIndex(f => f.O) !== -1,
            d = new T(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return jq(d)
    }

    function jq(a, b = lq) {
        var c = a.O;
        const d = new T(a.O);
        a.listen(e => {
            b(e, c) || (c = e, d.g(e))
        });
        return d
    }

    function mq(a, b, c) {
        return a.i(d => {
            d === b && c()
        })
    }

    function nq(a, b, c) {
        if (a.O === b) return c(), () => {};
        const d = {
            sc: null
        };
        d.sc = mq(a, b, () => {
            d.sc && (d.sc(), d.sc = null);
            c()
        });
        return d.sc
    }

    function oq(a, b, c) {
        jq(a).listen(d => {
            d === b && c()
        })
    }

    function pq(a, b) {
        a.l && a.l();
        a.l = b.listen(c => a.g(c), !0)
    }

    function qq(a, b, c, d) {
        const e = new T(!1);
        var f = null;
        a = a.map(d);
        mq(a, !0, () => {
            f === null && (f = b.setTimeout(() => {
                e.g(!0)
            }, c))
        });
        mq(a, !1, () => {
            e.g(!1);
            f !== null && (b.clearTimeout(f), f = null)
        });
        return jq(e)
    }

    function rq(a) {
        return {
            listen: b => a.listen(b),
            getValue: () => a.O
        }
    }
    var T = class {
        constructor(a) {
            this.O = a;
            this.j = new Map;
            this.A = 1;
            this.l = null
        }
        listen(a, b = !1) {
            const c = this.A++;
            this.j.set(c, a);
            b && a(this.O);
            return () => {
                this.j.delete(c)
            }
        }
        i(a) {
            return this.listen(a, !0)
        }
        B() {
            return this.O
        }
        g(a) {
            this.O = a;
            this.j.forEach(b => {
                b(this.O)
            })
        }
        map(a) {
            const b = new T(a(this.O));
            this.listen(c => b.g(a(c)));
            return b
        }
    };

    function lq(a, b) {
        return a == b
    };

    function sq(a) {
        return new tq(a)
    }

    function uq(a, b) {
        Ia(a.g, c => {
            c(b)
        })
    }
    var vq = class {
        constructor() {
            this.g = []
        }
    };
    class tq {
        constructor(a) {
            this.g = a
        }
        listen(a) {
            this.g.g.push(a)
        }
        map(a) {
            const b = new vq;
            this.listen(c => uq(b, a(c)));
            return sq(b)
        }
        delay(a, b) {
            const c = new vq;
            this.listen(d => {
                a.setTimeout(() => {
                    uq(c, d)
                }, b)
            });
            return sq(c)
        }
    }

    function wq(...a) {
        const b = new vq;
        a.forEach(c => {
            c.listen(d => {
                uq(b, d)
            })
        });
        return sq(b)
    };

    function xq(a) {
        return jq(hq(a.g, a.j).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : yq(c, b)
        }))
    }
    var Aq = class {
        constructor(a) {
            this.i = a;
            this.g = new T(null);
            this.j = new T(null);
            this.l = new vq;
            this.G = b => {
                this.g.O == null && b.touches.length == 1 && this.g.g(b.touches[0])
            };
            this.B = b => {
                const c = this.g.O;
                c != null && (b = zq(c, b.changedTouches), b != null && (this.g.g(null), this.j.g(null), uq(this.l, yq(c, b))))
            };
            this.A = b => {
                var c = this.g.O;
                c != null && (c = zq(c, b.changedTouches), c != null && (this.j.g(c), b.preventDefault()))
            }
        }
    };

    function yq(a, b) {
        return {
            mi: b.pageX - a.pageX,
            ni: b.pageY - a.pageY
        }
    }

    function zq(a, b) {
        if (b == null) return null;
        for (let c = 0; c < b.length; ++c)
            if (b[c].identifier == a.identifier) return b[c];
        return null
    };

    function Bq(a) {
        return jq(hq(a.g, a.i).map(b => {
            var c = b.first;
            b = b.second;
            return c == null || b == null ? null : Cq(c, b)
        }))
    }
    var Dq = class {
        constructor(a, b) {
            this.l = a;
            this.B = b;
            this.g = new T(null);
            this.i = new T(null);
            this.j = new vq;
            this.D = c => {
                this.g.g(c)
            };
            this.A = c => {
                const d = this.g.O;
                d != null && (this.g.g(null), this.i.g(null), uq(this.j, Cq(d, c)))
            };
            this.G = c => {
                this.g.O != null && (this.i.g(c), c.preventDefault())
            }
        }
    };

    function Cq(a, b) {
        return {
            mi: b.screenX - a.screenX,
            ni: b.screenY - a.screenY
        }
    };
    var Gq = (a, b, c) => {
        const d = new Eq(a, b, c);
        return () => Fq(d)
    };

    function Fq(a) {
        if (a.g) return !1;
        if (a.i == null) return Hq(a), !0;
        const b = a.i + a.B - (new Date).getTime();
        if (b < 1) return Hq(a), !0;
        Iq(a, b);
        return !0
    }

    function Hq(a) {
        a.i = (new Date).getTime();
        a.l()
    }

    function Iq(a, b) {
        a.g = !0;
        a.j.setTimeout(() => {
            a.g = !1;
            Hq(a)
        }, b)
    }
    class Eq {
        constructor(a, b, c) {
            this.j = a;
            this.B = b;
            this.l = c;
            this.i = null;
            this.g = !1
        }
    };

    function Jq(a) {
        return Kq(Bq(a.g), xq(a.i))
    }

    function Lq(a) {
        return wq(sq(a.g.j), sq(a.i.l))
    }
    var Mq = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function Kq(a, b) {
        return hq(a, b).map(({
            first: c,
            second: d
        }) => c || d || null)
    };
    var Nq = class {
        constructor() {
            this.cache = new Map
        }
        getBoundingClientRect(a) {
            var b = this.cache.get(a);
            if (b) return b;
            b = a.getBoundingClientRect();
            this.cache.set(a, b);
            return b
        }
    };

    function Oq(a) {
        a.A == null && (a.A = new T(a.D.getBoundingClientRect()));
        return a.A
    }
    var Pq = class extends S {
        constructor(a, b) {
            super();
            this.g = a;
            this.D = b;
            this.F = !1;
            this.A = null;
            this.l = () => {
                Oq(this).g(this.D.getBoundingClientRect())
            }
        }
        j() {
            this.F || (this.F = !0, this.g.addEventListener("resize", this.l), this.g.addEventListener("scroll", this.l));
            return Oq(this)
        }
        i() {
            this.g.removeEventListener("resize", this.l);
            this.g.removeEventListener("scroll", this.l);
            super.i()
        }
    };

    function Qq(a, b) {
        return new Rq(a, b)
    }

    function Sq(a) {
        a.win.requestAnimationFrame(() => {
            a.B || a.j.g(new dk(a.element.offsetWidth, a.element.offsetHeight))
        })
    }

    function Tq(a) {
        a.g || (a.g = !0, a.l.observe(a.element));
        return jq(a.j, ek)
    }
    var Rq = class extends S {
        constructor(a, b) {
            super();
            this.win = a;
            this.element = b;
            this.g = !1;
            this.j = new T(new dk(this.element.offsetWidth, this.element.offsetHeight));
            this.l = new ResizeObserver(() => {
                Sq(this)
            })
        }
        i() {
            this.l.disconnect();
            super.i()
        }
    };

    function Uq(a, b) {
        return {
            top: a.g - b,
            right: a.j + a.i,
            bottom: a.g + b,
            left: a.j
        }
    }
    var Vq = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.i = c
        }
    };

    function Wq(a, b) {
        a = a.getBoundingClientRect();
        return new Xq(a.top + Ip(b), a.bottom - a.top)
    }

    function Yq(a) {
        return new Xq(Math.round(a.g), Math.round(a.i))
    }
    var Xq = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getHeight() {
            return this.i
        }
    };
    var $q = (a, b) => {
        const c = a.google_pso_loaded_fonts || (a.google_pso_loaded_fonts = []),
            d = new Up(c);
        b = b.filter(e => !d.contains(e));
        b.length && (Zq(a, b), Ua(c, b))
    };

    function Zq(a, b) {
        for (const d of b) {
            const e = bd("LINK", a.document);
            e.type = "text/css";
            b = e;
            var c = Uc `//fonts.googleapis.com/css?family=${d}`;
            b.href = ac(c).toString();
            b.rel = "stylesheet";
            a.document.head.appendChild(e)
        }
    };

    function ar(a, b) {
        a.F ? b(a.l) : a.j.push(b)
    }

    function br(a, b) {
        a.F = !0;
        a.l = b;
        a.j.forEach(c => {
            c(a.l)
        });
        a.j = []
    }
    var cr = class extends S {
        constructor(a) {
            super();
            this.g = a;
            this.j = [];
            this.F = !1;
            this.D = this.l = null;
            this.I = Gq(a, 1E3, () => {
                if (this.D != null) {
                    var b = Dp(this.g, !0) - this.D;
                    b > 1E3 && br(this, b)
                }
            });
            this.A = null
        }
        L(a, b) {
            a == null ? (this.D = a = Dp(this.g, !0), this.g.addEventListener("scroll", this.I), b != null && b(a)) : this.A = this.g.setTimeout(() => {
                this.L(void 0, b)
            }, a)
        }
        i() {
            this.A != null && this.g.clearTimeout(this.A);
            this.g.removeEventListener("scroll", this.I);
            this.j = [];
            this.l = null;
            super.i()
        }
    };
    var dr = (a, b) => a.reduce((c, d) => c.concat(b(d)), []);
    var er = class {
        constructor(a = 1) {
            this.g = a
        }
        next() {
            const a = 48271 * this.g % 2147483647;
            this.g = a * 2147483647 < 0 ? a + 2147483647 : a;
            return this.g / 2147483647
        }
    };

    function fr(a, b, c) {
        const d = [];
        for (const e of a.g) b(e) ? d.push(e) : c(e);
        return new gr(d)
    }

    function hr(a) {
        return a.g.slice(0)
    }

    function ir(a, b = 1) {
        a = hr(a);
        const c = new er(b);
        Za(a, () => c.next());
        return new gr(a)
    }
    var gr = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new gr(Ka(this.g, a))
        }
        apply(a) {
            return new gr(a(hr(this)))
        }
        sort(a) {
            return new gr(hr(this).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = hr(this);
            b.push(a);
            return new gr(b)
        }
    };
    var jr = class {
        constructor(a) {
            this.g = new Up(a)
        }
        contains(a) {
            return this.g.contains(a)
        }
    };

    function kr(a) {
        return new lr({
            value: a
        }, null)
    }

    function mr(a) {
        return new lr(null, Error(a))
    }

    function nr(a) {
        try {
            return kr(a())
        } catch (b) {
            return new lr(null, b)
        }
    }

    function or(a) {
        return a.g != null ? a.getValue() : null
    }

    function pr(a, b) {
        a.g != null && b(a.getValue());
        return a
    }

    function qr(a, b) {
        return a.g != null ? a : new lr(null, b(a.i))
    }

    function rr(a, b) {
        return qr(a, c => Error(`${b}${c.message}`))
    }

    function sr(a, b) {
        a.g != null || b(a.i);
        return a
    }
    var lr = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return this.g != null ? (a = a(this.getValue()), a instanceof lr ? a : kr(a)) : this
        }
    };
    var tr = class {
        constructor() {
            this.g = new Tp
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new Up, this.g.set(a, c));
            c.add(b)
        }
    };

    function ur(a) {
        return !a
    }

    function vr(a) {
        return b => {
            for (const c of a) c(b)
        }
    };

    function wr(a) {
        return a !== null
    };
    var xr = class extends N {
        getId() {
            return D(this, 3)
        }
    };
    var yr = class {
        constructor(a, {
            Kg: b,
            yi: c,
            Pj: d,
            Uh: e
        }) {
            this.B = a;
            this.j = c;
            this.l = new gr(b || []);
            this.i = e;
            this.g = d
        }
    };
    var zr = a => {
            var b = a.split("~").filter(c => c.length > 0);
            a = new Tp;
            for (const c of b) b = c.indexOf("."), b == -1 ? a.set(c, "") : a.set(c.substring(0, b), c.substring(b + 1));
            return a
        },
        Br = a => {
            var b = Ar(a);
            a = [];
            for (let c of b) b = String(c.xc), a.push(c.Ib + "." + (b.length <= 20 ? b : b.slice(0, 19) + "_"));
            return a.join("~")
        };
    const Ar = a => {
            const b = [],
                c = a.l;
            c && c.g.length && b.push({
                Ib: "a",
                xc: Cr(c)
            });
            a.j != null && b.push({
                Ib: "as",
                xc: a.j
            });
            a.g != null && b.push({
                Ib: "i",
                xc: String(a.g)
            });
            a.i != null && b.push({
                Ib: "rp",
                xc: String(a.i)
            });
            b.sort(function(d, e) {
                return d.Ib.localeCompare(e.Ib)
            });
            b.unshift({
                Ib: "t",
                xc: Dr(a.B)
            });
            return b
        },
        Dr = a => {
            switch (a) {
                case 0:
                    return "aa";
                case 1:
                    return "ma";
                default:
                    throw Error("Invalid slot type" + a);
            }
        },
        Cr = a => {
            a = hr(a).map(Er);
            a = JSON.stringify(a);
            return gd(a)
        },
        Er = a => {
            const b = {};
            D(a, 7) != null && (b.q = D(a, 7));
            mh(a, 2) != null &&
                (b.o = mh(a, 2));
            mh(a, 5) != null && (b.p = mh(a, 5));
            return b
        };

    function Fr() {
        var a = new Gr;
        return Fh(a, 2, 1)
    }
    var Gr = class extends N {
        setLocation(a) {
            return Fh(this, 1, a)
        }
        i() {
            return xh(this, 1)
        }
    };

    function Hr(a) {
        const b = [].slice.call(arguments).filter(db(e => e === null));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Og || []);
            d = Object.assign(d, e.Lc())
        });
        return new Ir(c, d)
    }

    function Jr(a) {
        switch (a) {
            case 1:
                return new Ir(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new Ir(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new Ir(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new Ir(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function Kr(a) {
        return a == null ? null : new Ir(null, {
            google_ml_rank: a
        })
    }

    function Lr(a) {
        return a == null ? null : new Ir(null, {
            google_placement_id: Br(a)
        })
    }

    function Mr({
        fj: a,
        xj: b = null
    }) {
        if (a == null) return null;
        a = {
            google_daaos_ts: a
        };
        b != null && (a.google_erank = b + 1);
        return new Ir(null, a)
    }
    var Ir = class {
        constructor(a, b) {
            this.Og = a;
            this.g = b
        }
        Lc() {
            return this.g
        }
    };
    var Nr = class extends N {};
    var Or = class extends N {};
    var Pr = class extends N {
        j() {
            return D(this, 2)
        }
        i() {
            return D(this, 5)
        }
        l() {
            return hh(this, Or, 3, Pg())
        }
        B() {
            return wh(this, 4)
        }
        A() {
            return Og(this, 6) ? ? void 0
        }
        G() {
            return Kg(this, Nr, 7)
        }
    };
    var Qr = class extends N {};
    var Rr = class extends N {
        l() {
            return E(this, 12)
        }
        j() {
            return Qf(Gg(this, 13)) ? ? void 0
        }
        i() {
            return vh(this, 23)
        }
    };
    var Sr = class extends N {};
    var Tr = class extends N {
        i() {
            return nh(this, 3)
        }
        j() {
            return lh(this, 6)
        }
    };
    var Ur = class extends N {};
    var Vr = class extends N {};
    var Wr = class extends N {
        ha() {
            return y(this, xr, 1)
        }
        j() {
            return nh(this, 2)
        }
    };
    var Xr = class extends N {};
    var Yr = class extends N {};
    var Zr = class extends N {
            getName() {
                return D(this, 4)
            }
        },
        $r = [1, 2, 3];
    var as = class extends N {
        i() {
            return y(this, Tr, 10)
        }
    };
    var bs = class extends N {
        i() {
            return lh(this, 2)
        }
        j() {
            return lh(this, 3)
        }
    };
    var cs = class extends N {
        i() {
            return Qf(Gg(this, 1))
        }
    };
    var ds = class extends N {};
    var es = class extends N {
        i() {
            return ph(this, 1)
        }
    };
    var fs = class extends N {
        i() {
            return F(this, 1)
        }
        j() {
            return F(this, 2)
        }
    };
    var gs = class extends N {
        l() {
            return E(this, 1)
        }
        B() {
            return E(this, 3)
        }
        A() {
            return E(this, 7)
        }
        i() {
            return E(this, 4)
        }
        j() {
            return E(this, 5)
        }
    };
    var hs = class extends N {
        i() {
            return y(this, es, 6)
        }
        j() {
            return y(this, gs, 12)
        }
    };
    var is = class extends N {};
    var js = class extends N {
        i() {
            return y(this, is, 1)
        }
    };
    var ks = class extends N {};
    var ls = class extends N {};
    var ms = class extends N {
        i() {
            return hh(this, ls, 1, Pg())
        }
    };
    var ns = class extends N {
        setProperty(a) {
            return Dh(this, 1, a)
        }
        getValue() {
            return D(this, 2)
        }
    };
    var os = class extends N {};
    var ps = class extends N {};
    var qs = class extends N {
        ha() {
            return y(this, xr, 1)
        }
        j() {
            return nh(this, 2)
        }
    };
    var rs = class extends N {};
    var ss = class extends N {};
    var ts = class extends N {
        i() {
            return sh(this, 6)
        }
    };
    var us = class extends N {
        yf() {
            return Kg(this, ss, 2)
        }
    };
    var vs = class extends N {
        i() {
            return ph(this, 1)
        }
    };
    var ws = class extends N {};
    var ys = class extends N {
            i() {
                return uh(this, ws, 2, xs)
            }
        },
        xs = [1, 2];
    var zs = class extends N {
        i() {
            return y(this, ys, 3)
        }
    };
    var As = class extends N {};
    var Bs = class extends N {
        i() {
            return hh(this, As, 1, Pg())
        }
    };
    var Cs = class extends N {
        i() {
            return sh(this, 1)
        }
        j() {
            return y(this, zs, 3)
        }
    };

    function Ds(a) {
        return hh(a, qs, 1, Pg())
    }
    var Es = sj(class extends N {
        i() {
            return y(this, Rr, 15)
        }
    });
    var Fs = class extends N {},
        Gs = sj(Fs);

    function Hs(a) {
        try {
            const b = a.localStorage.getItem("google_ama_settings");
            return b ? Gs(b) : null
        } catch (b) {
            return null
        }
    }

    function Is(a, b) {
        if (a.lf !== void 0) {
            var c = Hs(b);
            c || (c = new Fs);
            a.lf !== void 0 && yh(c, 2, a.lf);
            a = Date.now() + 864E5;
            Number.isFinite(a) && Bh(c, 1, Math.round(a));
            c = Hh(c);
            try {
                b.localStorage.setItem("google_ama_settings", c)
            } catch (d) {}
        } else if ((c = Hs(b)) && Rf(Gg(c, 1)) < Date.now()) try {
            b.localStorage.removeItem("google_ama_settings")
        } catch (d) {}
    };
    var Js = {
            Tb: "ama_success",
            kb: .1,
            yb: !0,
            Wb: !0
        },
        Ks = {
            Tb: "ama_failure",
            kb: .1,
            yb: !0,
            Wb: !0
        },
        Ls = {
            Tb: "ama_coverage",
            kb: .1,
            yb: !0,
            Wb: !0
        },
        Ms = {
            Tb: "ama_opt",
            kb: .1,
            yb: !0,
            Wb: !1
        },
        Ns = {
            Tb: "ama_auto_rs",
            kb: 1,
            yb: !0,
            Wb: !1
        },
        Os = {
            Tb: "ama_constraints",
            kb: 0,
            yb: !0,
            Wb: !0
        };

    function Ps(a, b) {
        Qs(a.i, Ns, { ...b,
            evt: "place",
            vh: Ap(a.win),
            eid: a.g.i() ? .i() || 0,
            hl: y(a.g, fs, 5) ? .i() || ""
        })
    }

    function Rs(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && al(c.stack, "") || "");
        Ps(a, b)
    }
    var Ss = class {
        constructor(a, b, c) {
            this.win = a;
            this.i = b;
            this.g = c
        }
    };
    const Ts = ["-webkit-text-fill-color"];

    function Us(a) {
        if (Gc) {
            {
                const c = cd(a.document.body, a);
                if (c) {
                    a = {};
                    var b = c.length;
                    for (let d = 0; d < b; ++d) a[c[d]] = "initial";
                    a = Vs(a)
                } else a = Ws()
            }
        } else a = Ws();
        return a
    }
    var Ws = () => {
        const a = {
            all: "initial"
        };
        Ia(Ts, b => {
            a[b] = "unset"
        });
        return a
    };

    function Vs(a) {
        Ia(Ts, b => {
            delete a[b]
        });
        return a
    };
    var Xs = class {
        constructor(a) {
            this.g = a
        }
        Jc(a) {
            const b = a.document.createElement("div");
            u(b, Us(a));
            u(b, {
                width: "100%",
                "max-width": "1000px",
                margin: "auto"
            });
            b.appendChild(this.g);
            const c = a.document.createElement("div");
            u(c, Us(a));
            u(c, {
                width: "100%",
                "text-align": "center",
                display: "block",
                padding: "5px 5px 2px",
                "box-sizing": "border-box",
                "background-color": "#FFF"
            });
            c.appendChild(b);
            return c
        }
    };

    function Ys(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];
            var c = a.className ? a.className.split(/\s+/) : [];a = {};
            for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
            for (c = 0; c < b.length; ++c)
                if (!a[b[c]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    }

    function Zs(a) {
        return Op(a.querySelectorAll("ins.adsbygoogle-ablated-ad-slot"))
    };

    function $s(a, b) {
        a = Dk(new rk(a), "DIV");
        const c = a.style;
        c.width = "100%";
        c.height = "auto";
        c.clear = b ? "both" : "none";
        return a
    }

    function at(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        Ys(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    }

    function bt(a) {
        if (a && a.parentNode) {
            const b = a.parentNode;
            b.removeChild(a);
            Ys(b) && (b.style.display = b.getAttribute("data-init-display") || "none")
        }
    };
    var U = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        V = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        ct = class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        },
        dt = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        },
        et = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var ft = new V(619278254, 10),
        gt = new U(687716473),
        ht = new U(1377),
        it = new U(676894296, !0),
        jt = new U(682658313),
        kt = new U(1381),
        lt = new V(1130, 100),
        mt = new V(1339, .3),
        nt = new V(1032, 200),
        ot = new ct(14),
        pt = new V(1224, .01),
        qt = new V(1346, 6),
        rt = new V(1347, 3),
        st = new U(1367),
        tt = new U(1260),
        ut = new U(316),
        vt = new U(1290),
        wt = new U(334),
        xt = new V(1263, -1),
        yt = new V(54),
        zt = new V(1323, -1),
        At = new V(1265, -1),
        Bt = new V(1264, -1),
        Ct = new U(1291),
        Dt = new U(1267, !0),
        Et = new U(1266),
        Ft = new U(313),
        Gt = new V(66, -1),
        Ht = new V(65, -1),
        It = new U(1256),
        Jt = new U(369),
        Kt = new U(1241, !0),
        Lt = new U(368),
        Mt = new U(1300, !0),
        Nt = new dt(1273, ["en", "de", "fr", "es", "ja"]),
        Ot = new dt(1261, ["44786015", "44786016"]),
        Pt = new U(1361),
        Qt = new U(1349),
        Rt = new U(1372, !0),
        St = new U(290),
        Tt = new U(1222),
        Ut = new U(1354),
        Vt = new U(1341),
        Wt = new V(1366),
        Xt = new V(1365),
        Yt = new V(1364, 300),
        Zt = new U(1350),
        $t = new U(1356),
        au = new U(45665162),
        bu = new U(626390500),
        cu = new V(717888910),
        du = new et(627094447, "1 2 3 4 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 24 29 30 34".split(" ")),
        eu = new ct(622128249,
            "#FFFFFF"),
        fu = new V(717888911),
        gu = new ct(622128250, "#1A73E8"),
        hu = new et(641845510, ["33", "38"]),
        iu = new U(686023322, !0),
        ju = new U(566279275),
        ku = new U(622128248),
        lu = new U(566279276),
        mu = new U(681379804, !0),
        nu = new U(717888913),
        ou = new ct(589752731, "#FFFFFF"),
        pu = new ct(589752730, "#1A73E8"),
        qu = new et(635821288, ["29_18", "30_19"]),
        ru = new ct(716722045),
        su = new et(631402549),
        tu = new et(636146137, ["29_5", "30_6"]),
        uu = new U(636570127, !0),
        vu = new V(717888912),
        wu = new et(627094446, "1 2 4 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 24 29 30 34".split(" ")),
        xu = new V(727864505),
        yu = new V(652486359, 3),
        zu = new V(626062006, 670),
        Au = new V(688905693, 2),
        Bu = new V(666400580, 22),
        Cu = new dt(712458671, " ar bn en es fr hi id ja ko mr pt ru sr te th tr uk vi zh".split(" ")),
        Du = new V(687270738, 500),
        Eu = new U(720093567),
        Fu = new et(683929765),
        Gu = new U(713244099),
        Hu = new U(683614711),
        Iu = new U(707519017),
        Ju = new U(506914611),
        Ku = new U(655991266, !0),
        Lu = new U(725532016),
        Mu = new U(686111728, !0),
        Nu = new et(630330362),
        Ou = new V(643258048, .15),
        Pu = new V(643258049, .33938),
        Qu = new V(618163195,
            15E3),
        Ru = new V(624950166, 15E3),
        Su = new V(623405755, 300),
        Tu = new V(508040914, 500),
        Uu = new V(547455356, 49),
        Vu = new V(650548030, 2),
        Wu = new V(650548032, 300),
        Xu = new V(650548031, 1),
        Yu = new V(655966487, 300),
        Zu = new V(655966486, 250),
        $u = new V(469675170, 6E4),
        av = new U(562896595),
        bv = new U(675298507),
        cv = new U(644381219),
        dv = new U(644381220),
        ev = new U(713788640),
        fv = new U(676460084),
        gv = new U(710737579),
        hv = new U(45650663),
        iv = new V(684147713, -1),
        jv = new U(45674344, !0),
        kv = new U(45664474, !0),
        lv = new U(678806782, !0),
        mv = new U(570863962, !0),
        nv = new ct(570879859, "control_1\\.\\d"),
        ov = new V(570863961, 50),
        pv = new U(570879858, !0),
        qv = new V(63, 30),
        rv = new U(1134),
        sv = new U(562874197),
        tv = new U(562874196),
        uv = new U(555237685, !0),
        vv = new U(45460956),
        wv = new U(45414947, !0),
        xv = new V(472785970, 500),
        yv = new V(550718588, 250),
        zv = new V(624290870, 50),
        Av = new U(506738118),
        Bv = new U(77),
        Cv = new U(78),
        Dv = new U(83),
        Ev = new U(80),
        Fv = new U(76),
        Gv = new U(84),
        Hv = new U(1973),
        Iv = new U(188),
        Jv = new U(485990406);
    var Kv = class {
        constructor() {
            const a = {};
            this.j = (b, c) => a[b] != null ? a[b] : c;
            this.B = (b, c) => a[b] != null ? a[b] : c;
            this.A = (b, c) => a[b] != null ? a[b] : c;
            this.g = (b, c) => a[b] != null ? a[b] : c;
            this.l = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.i = () => {}
        }
    };

    function W(a) {
        return R(Kv).j(a.g, a.defaultValue)
    }

    function X(a) {
        return R(Kv).B(a.g, a.defaultValue)
    }

    function Lv(a) {
        return R(Kv).A(a.g, a.defaultValue)
    }

    function Mv(a) {
        return R(Kv).l(a.g, a.defaultValue)
    };
    var Ov = (a, b, c, d = 0) => {
            var e = Nv(b, c, d);
            if (e.L) {
                for (c = b = e.L; c = e.Ld(c);) b = c;
                e = {
                    anchor: b,
                    position: e.je
                }
            } else e = {
                anchor: b,
                position: c
            };
            a["google-ama-order-assurance"] = d;
            at(a, e.anchor, e.position)
        },
        Pv = (a, b, c, d = 0) => {
            W(Ft) ? Ov(a, b, c, d) : at(a, b, c)
        };

    function Nv(a, b, c) {
        const d = f => {
                f = Qv(f);
                return f == null ? !1 : c < f
            },
            e = f => {
                f = Qv(f);
                return f == null ? !1 : c > f
            };
        switch (b) {
            case 0:
                return {
                    L: Rv(a.previousSibling, d),
                    Ld: f => Rv(f.previousSibling, d),
                    je: 0
                };
            case 2:
                return {
                    L: Rv(a.lastChild, d),
                    Ld: f => Rv(f.previousSibling, d),
                    je: 0
                };
            case 3:
                return {
                    L: Rv(a.nextSibling, e),
                    Ld: f => Rv(f.nextSibling, e),
                    je: 3
                };
            case 1:
                return {
                    L: Rv(a.firstChild, e),
                    Ld: f => Rv(f.nextSibling, e),
                    je: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function Qv(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function Rv(a, b) {
        return a && b(a) ? a : null
    };

    function Sv(a, b) {
        try {
            const c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function Tv(a, b) {
        const c = a.google_reactive_ad_format === 40,
            d = a.google_reactive_ad_format === 16;
        return !!a.google_ad_resizable && (!a.google_reactive_ad_format || c) && !d && !!b.navigator && /iPhone|iPod|iPad|Android|BlackBerry/.test(b.navigator.userAgent) && b === b.top
    }

    function Uv(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function Vv(a, b, c) {
        a = Sv(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function Wv(a, b) {
        b = b.parentElement;
        return b ? (a = cd(b, a)) ? a.direction : "" : ""
    }

    function Xv(a, b, c) {
        if (Vv(a, b, c) !== 0) {
            Uv(b, c, "0px");
            var d = Vv(a, b, c);
            Uv(b, c, `${-1*d}px`);
            a = Vv(a, b, c);
            a !== 0 && a !== d && Uv(b, c, `${d/(a-d)*d}px`)
        }
    };
    const Yv = RegExp("(^| )adsbygoogle($| )");

    function Zv(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = Cc(d.property);
            a[e] = d.value
        }
    }

    function $v(a, b, c, d, e, f) {
        a = aw(a, e);
        a.ta.setAttribute("data-ad-format", d ? d : "auto");
        bw(a, b, c, f);
        return a
    }

    function cw(a, b, c = null) {
        a = aw(a, {});
        bw(a, b, null, c);
        return a
    }

    function bw(a, b, c, d) {
        var e = [];
        if (d = d && d.Og) a.wb.className = d.join(" ");
        a = a.ta;
        a.className = "adsbygoogle";
        a.setAttribute("data-ad-client", b);
        c && a.setAttribute("data-ad-slot", c);
        e.length && a.setAttribute("data-ad-channel", e.join("+"))
    }

    function aw(a, b) {
        const c = $s(a, b.clearBoth || !1);
        var d = c.style;
        d.textAlign = "center";
        b.ie && Zv(d, b.ie);
        a = Dk(new rk(a), "INS");
        d = a.style;
        d.display = "block";
        d.margin = "auto";
        d.backgroundColor = "transparent";
        b.wg && (d.marginTop = b.wg);
        b.Ve && (d.marginBottom = b.Ve);
        b.nc && Zv(d, b.nc);
        c.appendChild(a);
        return {
            wb: c,
            ta: a
        }
    }

    function dw(a, b, c) {
        b.dataset.adsbygoogleStatus = "reserved";
        b.className += " adsbygoogle-noablate";
        const d = {
            element: b
        };
        c = c && c.Lc();
        if (b.hasAttribute("data-pub-vars")) {
            try {
                c = JSON.parse(b.getAttribute("data-pub-vars"))
            } catch (e) {
                return
            }
            b.removeAttribute("data-pub-vars")
        }
        c && (d.params = c);
        (a.adsbygoogle = a.adsbygoogle || []).push(d)
    }

    function ew(a) {
        const b = Zs(a.document);
        Ia(b, function(c) {
            const d = fw(a, c);
            var e;
            if (e = d) {
                e = (e = Sv(c, a)) ? e.y : 0;
                const f = Ap(a);
                e = !(e < f)
            }
            e && (c.setAttribute("data-pub-vars", JSON.stringify(d)), c.removeAttribute("height"), c.style.removeProperty("height"), c.removeAttribute("width"), c.style.removeProperty("width"), dw(a, c))
        })
    }

    function fw(a, b) {
        b = b.getAttribute("google_element_uid");
        a = a.google_sv_map;
        if (!b || !a || !a[b]) return null;
        a = a[b];
        b = {};
        for (let c in $a) a[$a[c]] && (b[$a[c]] = a[$a[c]]);
        return b
    };
    var hw = (a, b, c) => {
        if (!b || !c) return !1;
        var d = b.parentElement;
        const e = c.parentElement;
        if (!d || !e || d != e) return !1;
        d = 0;
        for (b = b.nextSibling; d < 10 && b;) {
            if (b == c) return !0;
            if (gw(a, b)) break;
            b = b.nextSibling;
            d++
        }
        return !1
    };
    const gw = (a, b) => {
        if (b.nodeType == 3) return b.nodeType == 3 ? (b = b.data, a = b.indexOf("&") != -1 ? zc(b, a.document) : b, a = /\S/.test(a)) : a = !1, a;
        if (b.nodeType == 1) {
            var c = a.getComputedStyle(b);
            if (c.opacity == "0" || c.display == "none" || c.visibility == "hidden") return !1;
            if ((c = b.tagName) && Vp.contains(c.toUpperCase())) return !0;
            b = b.childNodes;
            for (c = 0; c < b.length; c++)
                if (gw(a, b[c])) return !0
        }
        return !1
    };
    var iw = a => {
        if (a >= 460) return a = Math.min(a, 1200), Math.ceil(a < 800 ? a / 4 : 200);
        a = Math.min(a, 600);
        return a <= 420 ? Math.ceil(a / 1.2) : Math.ceil(a / 1.91) + 130
    };
    var jw = class {
        constructor() {
            this.g = {
                clearBoth: !0
            }
        }
        i(a, b, c, d) {
            return $v(d.document, a, null, null, this.g, b)
        }
        j(a) {
            return iw(Math.min(a.screen.width || 0, a.screen.height || 0))
        }
    };

    function kw(a) {
        const b = [];
        Np(a.getElementsByTagName("p"), function(c) {
            lw(c) >= 100 && b.push(c)
        });
        return b
    }

    function lw(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        let b = 0;
        Np(a.childNodes, function(c) {
            b += lw(c)
        });
        return b
    }

    function mw(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function nw(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function ow(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.l)
        } catch (d) {}
        if (!c.length) return [];
        b = Ta(c);
        b = nw(a, b);
        typeof a.i === "number" && (c = a.i, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.j === "number") {
            c = [];
            for (let d = 0; d < b.length; d++) {
                const e = kw(b[d]);
                let f = a.j;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    var pw = class {
        constructor(a, b, c, d) {
            this.l = a;
            this.i = b;
            this.j = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.l,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.g
            })
        }
    };
    var qw = class {
        constructor() {
            this.g = Uc `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        ia(a, b, c = .01, d = "jserror") {
            if (Math.random() > c) return !1;
            b.error && b.meta && b.id || (b = new Yk(b, {
                context: a,
                id: d
            }));
            q.google_js_errors = q.google_js_errors || [];
            q.google_js_errors.push(b);
            q.error_rep_loaded || (ad(q.document, this.g), q.error_rep_loaded = !0);
            return !1
        }
        Wa(a, b) {
            try {
                return b()
            } catch (c) {
                if (!this.ia(a, c, .01, "jserror")) throw c;
            }
        }
        Xa(a, b, c) {
            return (...d) => this.Wa(a, () => b.apply(c, d))
        }
        Fa(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.ia(a, c instanceof Error ? c : Error(c), void 0)
            })
        }
    };

    function rw(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function sw(a, b, c, d) {
        const e = d || window,
            f = typeof queueMicrotask !== "undefined";
        return function(...g) {
            f && queueMicrotask(() => {
                e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                e.google_rum_task_id_counter += 1
            });
            const h = hl();
            let k, l = 3;
            try {
                k = b.apply(this, g)
            } catch (m) {
                l = 13;
                if (!c) throw m;
                c(a, m)
            } finally {
                e.google_measure_js_timing && h && rw({
                    label: a.toString(),
                    value: h,
                    duration: (hl() || 0) - h,
                    type: l,
                    ...(f && {
                        taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                    })
                }, e)
            }
            return k
        }
    }

    function tw(a, b) {
        return sw(754, a, (c, d) => {
            (new qw).ia(c, d)
        }, b)
    };

    function uw(a, b, c) {
        return sw(a, b, void 0, c).apply()
    }

    function vw(a, b) {
        return tw(a, b).apply()
    }

    function ww(a) {
        if (!a) return null;
        var b = D(a, 7);
        if (D(a, 1) || a.getId() || sh(a, 4).length > 0) {
            var c = a.getId(),
                d = D(a, 1),
                e = sh(a, 4);
            b = mh(a, 2);
            var f = mh(a, 5);
            a = xw(nh(a, 6));
            let g = "";
            d && (g += d);
            c && (g += "#" + mw(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + mw(e[c]);
            b = (e = g) ? new pw(e, b, f, a) : null
        } else b = b ? new pw(b, mh(a, 2), mh(a, 5), xw(nh(a, 6))) : null;
        return b
    }
    const yw = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function xw(a) {
        return a == null ? a : yw[a]
    }

    function zw(a) {
        const b = [];
        for (let c = 0; c < a.length; c++) {
            const d = D(a[c], 1),
                e = a[c].getValue();
            d && e != null && b.push({
                property: d,
                value: e
            })
        }
        return b
    }

    function Aw(a, b) {
        const c = {};
        a && (c.wg = D(a, 1), c.Ve = D(a, 2), c.clearBoth = !!lh(a, 3));
        b && (c.ie = zw(hh(b, ns, 3, Pg()).map(d => lg(d))), c.nc = zw(hh(b, ns, 4, Pg()).map(d => lg(d))));
        return c
    }
    const Bw = {
            1: 0,
            2: 1,
            3: 2,
            4: 3
        },
        Cw = {
            0: 1,
            1: 2,
            2: 3,
            3: 4
        };
    var Dw = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            return $v(d.document, a, null, null, this.g, b)
        }
        j() {
            return null
        }
    };
    var Ew = class {
        constructor(a) {
            this.i = a
        }
        g(a) {
            a = Math.floor(a.i);
            const b = iw(a);
            return new Ir(["ap_container"], {
                google_reactive_ad_format: 27,
                google_responsive_auto_format: 16,
                google_max_num_ads: 1,
                google_ad_type: this.i,
                google_ad_format: a + "x" + b,
                google_ad_width: a,
                google_ad_height: b
            })
        }
    };
    var Fw = class {
        constructor(a, b) {
            this.l = a;
            this.i = b
        }
        g() {
            return this.l
        }
        j() {
            return this.i
        }
    };
    var Gw = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            var e = hh(this.g, os, 9, Pg()).length > 0 ? hh(this.g, os, 9, Pg())[0] : null,
                f = Aw(fh(this.g, ps, 3), e);
            if (!e) return null;
            if (e = D(e, 1)) {
                d = d.document;
                var g = c.tagName;
                c = Dk(new rk(d), g);
                c.style.clear = f.clearBoth ? "both" : "none";
                g == "A" && (c.style.display = "block");
                c.style.padding = "0px";
                c.style.margin = "0px";
                f.ie && Zv(c.style, f.ie);
                d = Dk(new rk(d), "INS");
                f.nc && Zv(d.style, f.nc);
                c.appendChild(d);
                f = {
                    wb: c,
                    ta: d
                };
                f.ta.setAttribute("data-ad-type", "text");
                f.ta.setAttribute("data-native-settings-key",
                    e);
                bw(f, a, null, b);
                a = f
            } else a = null;
            return a
        }
        j() {
            var a = hh(this.g, os, 9, Pg()).length > 0 ? hh(this.g, os, 9, Pg())[0] : null;
            if (!a) return null;
            a = hh(a, ns, 3, Pg());
            for (let b = 0; b < a.length; b++) {
                const c = a[b];
                if (D(c, 1) == "height" && parseInt(c.getValue(), 10) > 0) return parseInt(c.getValue(), 10)
            }
            return null
        }
    };
    var Hw = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            if (!this.g) return null;
            const e = this.g.google_ad_format || null,
                f = this.g.google_ad_slot || null;
            if (c = c.style) {
                var g = [];
                for (let h = 0; h < c.length; h++) {
                    const k = c.item(h);
                    k !== "width" && k !== "height" && g.push({
                        property: k,
                        value: c.getPropertyValue(k)
                    })
                }
                c = {
                    nc: g
                }
            } else c = {};
            a = $v(d.document, a, f, e, c, b);
            a.ta.setAttribute("data-pub-vars", JSON.stringify(this.g));
            return a
        }
        j() {
            return this.g ? parseInt(this.g.google_ad_height, 10) || null : null
        }
        Lc() {
            return this.g
        }
    };
    var Iw = class {
        constructor(a) {
            this.i = a
        }
        g() {
            return new Ir([], {
                google_ad_type: this.i,
                google_reactive_ad_format: 26,
                google_ad_format: "fluid"
            })
        }
    };
    var Jw = class {
        constructor(a, b) {
            this.l = a;
            this.i = b
        }
        j() {
            return this.i
        }
        g(a) {
            a = ow(this.l, a.document);
            return a.length > 0 ? a[0] : null
        }
    };

    function Kw(a, b, c) {
        const d = [];
        for (let t = 0; t < a.length; t++) {
            var e = a[t];
            var f = t,
                g = b,
                h = c,
                k = e.ha();
            if (k) {
                var l = ww(k);
                if (l) {
                    var m = e.j();
                    m = Bw[m];
                    var n = m === void 0 ? null : m;
                    if (n === null) e = null;
                    else {
                        m = (m = y(e, ps, 3)) ? lh(m, 3) : null;
                        l = new Jw(l, n);
                        n = th(e, 10).slice(0);
                        mh(k, 5) != null && n.push(1);
                        var p = h ? h : {};
                        h = mh(e, 12);
                        k = Kg(e, Gr, 4) ? y(e, Gr, 4) : null;
                        xh(e, 8) == 1 ? (p = p.Pi || null, e = new Lw(l, new Dw(Aw(y(e, ps, 3), null)), p, m, 0, n, k, g, f, h, e)) : e = xh(e, 8) == 2 ? new Lw(l, new Gw(e), p.Qj || new Iw("text"), m, 1, n, k, g, f, h, e) : null
                    }
                } else e = null
            } else e =
                null;
            e !== null && d.push(e)
        }
        return d
    }

    function Mw(a) {
        return a.l
    }

    function Nw(a) {
        return a.xa
    }

    function Ow(a) {
        return a.A instanceof Hw ? a.A.Lc() : null
    }

    function Pw(a, b, c) {
        Pp(a.M, b) || a.M.set(b, []);
        a.M.get(b).push(c)
    }

    function Qw(a) {
        return a.A.j(a.g)
    }

    function Rw(a, b = null, c = null) {
        return new Lw(a.D, b || a.A, c || a.U, a.F, a.Yb, a.Pc, a.ue, a.g, a.pa, a.G, a.i, a.B, a.Z)
    }
    var Lw = class {
        constructor(a, b, c, d, e, f, g, h, k, l = null, m = null, n = null, p = null) {
            this.D = a;
            this.A = b;
            this.U = c;
            this.F = d;
            this.Yb = e;
            this.Pc = f;
            this.ue = g ? g : new Gr;
            this.g = h;
            this.pa = k;
            this.G = l;
            this.i = m;
            (a = !m) || (a = !(m.ha() && wh(m.ha(), 5) != null));
            this.xa = !a;
            this.B = n;
            this.Z = p;
            this.I = [];
            this.l = !1;
            this.M = new Tp
        }
        ca() {
            return this.g
        }
        j() {
            return this.D.j()
        }
    };

    function Sw(a, b, c, d, e, f) {
        const g = Fr();
        return new Lw(new Fw(c, e), new jw, new Ew(a), !0, 2, [], g, d, null, null, null, b, f)
    }

    function Tw(a, b, c, d, e) {
        const f = Fr();
        return new Lw(new Fw(b, d), new Dw({
            clearBoth: !0
        }), null, !0, 2, [], f, c, null, null, null, a, e)
    };
    var Uw = class {
        constructor(a, b, c) {
            this.articleStructure = a;
            this.element = b;
            this.win = c
        }
        ca() {
            return this.win
        }
        B(a) {
            return Sw(a, this.articleStructure, this.element, this.win, 3, null)
        }
        j() {
            return Tw(this.articleStructure, this.element, this.win, 3, null)
        }
    };
    const Vw = {
        TABLE: {
            Bc: new jr([1, 2])
        },
        THEAD: {
            Bc: new jr([0, 3, 1, 2])
        },
        TBODY: {
            Bc: new jr([0, 3, 1, 2])
        },
        TR: {
            Bc: new jr([0, 3, 1, 2])
        },
        TD: {
            Bc: new jr([0, 3])
        }
    };

    function Ww(a, b, c, d) {
        const e = c.childNodes;
        c = c.querySelectorAll(b);
        b = [];
        for (const f of c) c = Ha(e, f), c < 0 || b.push(new Xw(a, [f], c, f, 3, zk(f).trim(), d));
        return b
    }

    function Yw(a, b, c) {
        let d = [];
        const e = [],
            f = b.childNodes,
            g = f.length;
        let h = 0,
            k = "";
        for (let n = 0; n < g; n++) {
            var l = f[n];
            if (l.nodeType == 1 || l.nodeType == 3) {
                if (l.nodeType != 1) var m = null;
                else l.tagName == "BR" ? m = l : (m = c.getComputedStyle(l).getPropertyValue("display"), m = m == "inline" || m == "inline-block" ? null : l);
                m ? (d.length && k && e.push(new Xw(a, d, n - 1, m, 0, k, c)), d = [], h = n + 1, k = "") : (d.push(l), l = zk(l).trim(), k += l && k ? " " + l : l)
            }
        }
        d.length && k && e.push(new Xw(a, d, h, b, 2, k, c));
        return e
    }

    function Zw(a, b) {
        return a.g - b.g
    }
    var Xw = class {
        constructor(a, b, c, d, e, f, g) {
            this.l = a;
            this.yd = b.slice(0);
            this.g = c;
            this.Ce = d;
            this.De = e;
            this.A = f;
            this.i = g
        }
        ca() {
            return this.i
        }
        B(a) {
            return Sw(a, this.l, this.Ce, this.i, this.De, this.g)
        }
        j() {
            return Tw(this.l, this.Ce, this.i, this.De, this.g)
        }
    };

    function $w(a) {
        return Sa(a.A ? Yw(a.g, a.j, a.i) : [], a.B ? Ww(a.g, a.B, a.j, a.i) : []).filter(b => {
            var c = b.Ce.tagName;
            c ? (c = Vw[c.toUpperCase()], b = c != null && c.Bc.contains(b.De)) : b = !1;
            return !b
        })
    }
    var ax = class {
        constructor(a, b, c) {
            this.j = a;
            this.B = b.vd;
            this.A = b.eh;
            this.g = b.articleStructure;
            this.i = c;
            this.l = b.Jg
        }
    };

    function bx(a, b) {
        if (!b) return !1;
        const c = sa(b),
            d = a.g.get(c);
        if (d != null) return d;
        if (b.nodeType == 1 && (b.tagName == "UL" || b.tagName == "OL") && a.i.getComputedStyle(b).getPropertyValue("list-style-type") != "none") return a.g.set(c, !0), !0;
        b = bx(a, b.parentNode);
        a.g.set(c, b);
        return b
    }

    function cx(a, b) {
        return Na(b.yd, c => bx(a, c))
    }
    var dx = class {
        constructor(a) {
            this.g = new Tp;
            this.i = a
        }
    };
    var ex = class {
        constructor(a, b) {
            this.l = a;
            this.g = [];
            this.i = [];
            this.j = b
        }
    };
    var gx = (a, {
            sh: b = !1,
            mg: c = !1,
            Fh: d = c ? 2 : 3,
            kg: e = null
        } = {}) => {
            a = $w(a);
            return fx(a, {
                sh: b,
                mg: c,
                Fh: d,
                kg: e
            })
        },
        fx = (a, {
            sh: b = !1,
            mg: c = !1,
            Fh: d = c ? 2 : 3,
            kg: e = null
        } = {}) => {
            if (d < 2) throw Error("minGroupSize should be at least 2, found " + d);
            var f = a.slice(0);
            f.sort(Zw);
            a = [];
            b = new ex(b, e);
            for (const g of f) {
                e = {
                    ke: g,
                    Nd: g.A.length < 51 ? !1 : b.j != null ? !cx(b.j, g) : !0
                };
                if (b.l || e.Nd) b.g.length ? (f = b.g[b.g.length - 1].ke, f = hw(f.ca(), f.yd[f.yd.length - 1], e.ke.yd[0])) : f = !0, f ? (b.g.push(e), e.Nd && b.i.push(e.ke)) : (b.g = [e], b.i = e.Nd ? [e.ke] : []);
                if (b.i.length >=
                    d) {
                    e = b;
                    f = c ? 0 : 1;
                    if (f < 0 || f >= e.i.length) e = null;
                    else {
                        for (f = e.i[f]; e.g.length && !e.g[0].Nd;) e.g.shift();
                        e.g.shift();
                        e.i.shift();
                        e = f
                    }
                    e && a.push(e)
                }
            }
            return a
        };
    var ix = (a, b, c = !1) => {
            a = hx(a, b);
            const d = new dx(b);
            return dr(a, e => gx(e, {
                mg: c,
                kg: d
            }))
        },
        jx = (a, b) => {
            a = hx(a, b);
            const c = new dx(b);
            return dr(a, d => {
                if (d.l) {
                    var e = d.g;
                    var f = d.i;
                    d = d.j.querySelectorAll(d.l);
                    var g = [];
                    for (var h of d) g.push(new Uw(e, h, f));
                    e = g
                } else e = [];
                d = e.slice(0);
                if (d.length) {
                    e = [];
                    f = d[0];
                    for (g = 1; g < d.length; g++) {
                        const m = d[g];
                        h = f;
                        b: {
                            if (h.element.hasAttributes())
                                for (l of h.element.attributes)
                                    if (l.name.toLowerCase() === "style" && l.value.toLowerCase().includes("background-image")) {
                                        var k = !0;
                                        break b
                                    }
                            k =
                            h.element.tagName;k = k === "IMG" || k === "SVG"
                        }(k || h.element.textContent.length > 1) && !bx(c, f.element) && hw(m.ca(), f.element, m.element) && e.push(f);
                        f = m
                    }
                    var l = e
                } else l = [];
                return l
            })
        },
        hx = (a, b) => {
            const c = new Tp;
            a.forEach(d => {
                var e = ww(fh(d, xr, 1));
                if (e) {
                    var f = e.toString();
                    Pp(c, f) || c.set(f, {
                        articleStructure: d,
                        Ii: e,
                        vd: null,
                        eh: !1,
                        Jg: null
                    });
                    e = c.get(f);
                    (f = (f = y(d, xr, 2)) ? D(f, 7) : null) ? e.vd = e.vd ? e.vd + "," + f : f: e.eh = !0;
                    d = y(d, xr, 4);
                    e.Jg = d ? D(d, 7) : null
                }
            });
            return Sp(c).map(d => {
                const e = ow(d.Ii, b.document);
                return e.length ? new ax(e[0],
                    d, b) : null
            }).filter(d => d != null)
        };
    var kx = a => a ? .google_ad_slot ? kr(new yr(1, {
            yi: a.google_ad_slot
        })) : mr("Missing dimension when creating placement id"),
        mx = a => {
            switch (a.Yb) {
                case 0:
                case 1:
                    var b = a.i;
                    b == null ? a = null : (a = b.ha(), a == null ? a = null : (b = b.j(), a = b == null ? null : new yr(0, {
                        Kg: [a],
                        Uh: b
                    })));
                    return a != null ? kr(a) : mr("Missing dimension when creating placement id");
                case 2:
                    return a = lx(a), a != null ? kr(a) : mr("Missing dimension when creating placement id");
                default:
                    return mr("Invalid type: " + a.Yb)
            }
        };
    const lx = a => {
        if (a == null || a.B == null) return null;
        const b = y(a.B, xr, 1),
            c = y(a.B, xr, 2);
        if (b == null || c == null) return null;
        const d = a.Z;
        if (d == null) return null;
        a = a.j();
        return a == null ? null : new yr(0, {
            Kg: [b, c],
            Pj: d,
            Uh: Cw[a]
        })
    };

    function nx(a) {
        const b = Ow(a.ea);
        return (b ? kx(b) : mx(a.ea)).map(c => Br(c))
    }

    function ox(a) {
        a.g = a.g || nx(a);
        return a.g
    }

    function px(a, b) {
        if (a.ea.l) throw Error("AMA:AP:AP");
        Pv(b, a.ha(), a.ea.j());
        a = a.ea;
        a.l = !0;
        b != null && a.I.push(b)
    }
    const qx = class {
        constructor(a, b, c) {
            this.ea = a;
            this.i = b;
            this.la = c;
            this.g = null
        }
        ha() {
            return this.i
        }
        fill(a, b) {
            var c = this.ea;
            (a = c.A.i(a, b, this.i, c.g)) && px(this, a.wb);
            return a
        }
    };

    function rx(a, b) {
        return vw(() => {
            const c = [],
                d = [];
            try {
                var e = [];
                for (var f = 0; f < a.length; f++) {
                    var g = a[f],
                        h = g.D.g(g.g);
                    h && e.push({
                        Ph: g,
                        anchorElement: h
                    })
                }
                for (g = 0; g < e.length; g++) {
                    f = d;
                    var k = f.push; {
                        var l = e[g];
                        const B = l.anchorElement,
                            G = l.Ph;
                        var m = G.F,
                            n = G.g.document.createElement("div");
                        n.className = "google-auto-placed";
                        var p = n.style;
                        p.textAlign = "center";
                        p.width = "100%";
                        p.height = "0px";
                        p.clear = m ? "both" : "none";
                        h = n;
                        try {
                            Pv(h, B, G.j());
                            var t = h
                        } catch (L) {
                            throw bt(h), L;
                        }
                    }
                    k.call(f, t)
                }
                const v = Ip(b),
                    w = Jp(b);
                for (k = 0; k < d.length; k++) {
                    const B =
                        d[k].getBoundingClientRect(),
                        G = e[k];
                    c.push(new qx(G.Ph, G.anchorElement, new Vq(B.left + w, B.top + v, B.right - B.left)))
                }
            } finally {
                for (e = 0; e < d.length; e++) bt(d[e])
            }
            return c
        }, b)
    };
    const yx = {
            1: "0.5vp",
            2: "300px"
        },
        zx = {
            1: 700,
            2: 1200
        },
        Ax = {
            [1]: {
                di: "3vp",
                pg: "1vp",
                ci: "0.3vp"
            },
            [2]: {
                di: "900px",
                pg: "300px",
                ci: "90px"
            }
        };

    function Bx(a, b, c) {
        var d = Cx(a),
            e = Ap(a) || zx[d],
            f = void 0;
        c && (f = (c = (c = Dx(hh(c, Pr, 2, Pg()), d)) ? y(c, Nr, 7) : void 0) ? Ex(c, e) : void 0);
        c = f;
        f = Cx(a);
        a = Ap(a) || zx[f];
        const g = Fx(Ax[f].pg, a);
        a = g === null ? Gx(f, a) : new Hx(g, g, Ix(g, 8), 8, .3, c);
        c = Fx(Ax[d].di, e);
        f = Fx(Ax[d].pg, e);
        d = Fx(Ax[d].ci, e);
        e = a.j;
        c && d && f && b !== void 0 && (e = b <= .5 ? f + (1 - 2 * b) * (c - f) : d + (2 - 2 * b) * (f - d));
        return new Hx(e, e, Ix(e, a.i), a.i, a.l, a.g)
    }

    function Jx(a, b) {
        const c = Qf(Gg(a, 4));
        a = Og(a, 5);
        return c == null || a == null ? b : new Hx(a, 0, [], c, 1)
    }

    function Kx(a, b) {
        const c = Cx(a);
        a = Ap(a) || zx[c];
        if (!b) return Gx(c, a);
        if (b = Dx(hh(b, Pr, 2, Pg()), c))
            if (b = Lx(b, a)) return b;
        return Gx(c, a)
    }

    function Mx(a) {
        const b = Cx(a);
        a = Ap(a) || zx[b];
        return Gx(b, a)
    }

    function Nx() {
        return W(vt) ? new Hx(0, null, [], 8, .3) : new Hx(0, null, [], 3, null)
    }

    function Ox(a, b) {
        let c = {
            Vc: a.j,
            Cb: a.A
        };
        for (let d of a.B) d.adCount <= b && (c = d.gd);
        return c
    }

    function Px(a, b, c) {
        var d = lh(b, 2);
        b = y(b, Pr, 1);
        var e = Cx(c);
        var f = Ap(c) || zx[e];
        c = Fx(b ? .j(), f) ? ? a.j;
        e = Fx(b ? .i(), f) ? ? a.A;
        d = d ? [] : Qx(b ? .l(), f) ? ? a.B;
        const g = b ? .B() ? ? a.i,
            h = b ? .A() ? ? a.l;
        a = (b ? .G() ? Ex(y(b, Nr, 7), f) : null) ? ? a.g;
        return new Hx(c, e, d, g, h, a)
    }

    function Rx(a, b) {
        var c = Cx(b);
        const d = new Qr,
            e = new Pr;
        let f = !1;
        var g = X(xt);
        g >= 0 && (zh(e, 4, g), f = !0);
        g = null;
        c === 1 ? (c = X(Bt), c >= 0 && (g = c + "vp")) : (c = X(At), c >= 0 && (g = c + "px"));
        c = X(zt);
        c >= 0 && (g = c + "px");
        g !== null && (Dh(e, 2, g), f = !0);
        c = W(Dt) ? "0px" : null;
        c !== null && (Dh(e, 5, c), f = !0);
        if (W(Et)) yh(d, 2, !0), f = !0;
        else if (c !== null || g !== null) {
            const m = [];
            for (const n of a.B) {
                var h = m,
                    k = h.push;
                var l = new Or;
                l = zh(l, 1, n.adCount);
                l = Dh(l, 3, c ? ? n.gd.Cb + "px");
                l = Dh(l, 2, g ? ? n.gd.Vc + "px");
                k.call(h, l)
            }
            ih(e, 3, m)
        }
        return f ? (z(d, 1, e), Px(a, d, b)) : a
    }
    var Hx = class {
        constructor(a, b, c, d, e, f) {
            this.j = a;
            this.A = b;
            this.B = c.sort((g, h) => g.adCount - h.adCount);
            this.i = d;
            this.l = e;
            this.g = f
        }
    };

    function Dx(a, b) {
        for (let c of a)
            if (xh(c, 1) == b) return c;
        return null
    }

    function Qx(a, b) {
        if (a === void 0) return null;
        const c = [];
        for (let d of a) {
            a = mh(d, 1);
            const e = Fx(D(d, 2), b);
            if (typeof a !== "number" || e === null) return null;
            c.push({
                adCount: a,
                gd: {
                    Vc: e,
                    Cb: Fx(D(d, 3), b)
                }
            })
        }
        return c
    }

    function Lx(a, b) {
        const c = Fx(a.j(), b),
            d = Fx(a.i(), b);
        if (c === null) return null;
        const e = mh(a, 4);
        if (e == null) return null;
        var f = a.l();
        f = Qx(f, b);
        if (f === null) return null;
        const g = y(a, Nr, 7);
        b = g ? Ex(g, b) : void 0;
        return new Hx(c, d, f, e, Og(a, 6), b)
    }

    function Gx(a, b) {
        a = Fx(yx[a], b);
        return W(vt) ? new Hx(a === null ? Infinity : a, null, [], 8, .3) : new Hx(a === null ? Infinity : a, null, [], 3, null)
    }

    function Fx(a, b) {
        if (!a) return null;
        const c = parseFloat(a);
        return isNaN(c) ? null : a.endsWith("px") ? c : a.endsWith("vp") ? c * b : null
    }

    function Cx(a) {
        a = zp(a) >= 900;
        return Gb() && !a ? 1 : 2
    }

    function Ix(a, b) {
        if (b < 4) return [];
        const c = Math.ceil(b / 2);
        return [{
            adCount: c,
            gd: {
                Vc: a * 2,
                Cb: a * 2
            }
        }, {
            adCount: c + Math.ceil((b - c) / 2),
            gd: {
                Vc: a * 3,
                Cb: a * 3
            }
        }]
    }

    function Ex(a, b) {
        const c = Fx(D(a, 2), b) || 0,
            d = mh(a, 3) || 1;
        return {
            Gh: c,
            Ch: d,
            uc: Fx(D(a, 1), b) || 0
        }
    };

    function Sx(a, b, c) {
        return sp({
            top: a.g.top - (c + 1),
            right: a.g.right + (c + 1),
            bottom: a.g.bottom + (c + 1),
            left: a.g.left - (c + 1)
        }, b.g)
    }

    function Tx(a) {
        if (!a.length) return null;
        const b = tp(a.map(c => c.g));
        a = a.reduce((c, d) => c + d.i, 0);
        return new Ux(b, a)
    }
    var Ux = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function to() {
        return "m202502180101"
    };
    var Vx = qj(qo);
    var so = qj(uo);

    function Wx(a, b) {
        return b(a) ? a : void 0
    }

    function Xx(a, b, c, d, e) {
        c = c instanceof Yk ? c.error : c;
        var f = new yo;
        const g = new xo;
        try {
            var h = Fd(window);
            Ch(g, 1, h)
        } catch (p) {}
        try {
            var k = R(ip).g();
            Yg(g, 2, k, zf)
        } catch (p) {}
        try {
            Eh(g, 3, window.document.URL)
        } catch (p) {}
        h = z(f, 2, g);
        k = new wo;
        b = M(k, 1, b);
        try {
            var l = Qe(c ? .name) ? c.name : "Unknown error";
            Eh(b, 2, l)
        } catch (p) {}
        try {
            var m = Qe(c ? .message) ? c.message : `Caught ${c}`;
            Eh(b, 3, m)
        } catch (p) {}
        try {
            var n = Qe(c ? .stack) ? c.stack : Error().stack;
            n && Yg(b, 4, n.split(/\n\s*/), Xf)
        } catch (p) {}
        l = C(h, 1, zo, b);
        if (e) {
            m = 0;
            switch (e.errSrc) {
                case "LCC":
                    m =
                        1;
                    break;
                case "PVC":
                    m = 2
            }
            n = ro();
            b = Wx(e.shv, Qe);
            n = Eh(n, 2, b);
            m = M(n, 6, m);
            n = lg(Vx());
            b = Wx(e.es, Ye());
            n = Yg(n, 1, b, zf).g();
            m = z(m, 4, n);
            n = Wx(e.client, Qe);
            m = Dh(m, 3, n);
            n = Wx(e.slotname, Qe);
            m = Eh(m, 7, n);
            e = Wx(e.tag_origin, Qe);
            e = Eh(m, 8, e).g()
        } else e = ro().g();
        e = C(l, 6, Ao, e);
        d = Ch(e, 5, d ? ? 1);
        a.Yh(d)
    };
    let Yx, Zx = 64;

    function $x() {
        try {
            return Yx ? ? (Yx = new Uint32Array(64)), Zx >= 64 && (crypto.getRandomValues(Yx), Zx = 0), Yx[Zx++]
        } catch (a) {
            return Math.floor(Math.random() * 2 ** 32)
        }
    };
    var by = class {
        constructor() {
            this.g = ay
        }
    };

    function ay() {
        return {
            pk: $x() + ($x() & 2 ** 21 - 1) * 2 ** 32,
            hj: Number.MAX_SAFE_INTEGER
        }
    };
    var dy = class {
        constructor(a = !1) {
            this.H = cy;
            this.i = a;
            this.g = null;
            this.l = this.ia
        }
        lg(a) {
            this.g = a
        }
        j() {}
        Wa(a, b, c) {
            let d;
            try {
                d = b()
            } catch (e) {
                b = this.i;
                try {
                    b = this.l(a, Zk(e), void 0, c)
                } catch (f) {
                    this.ia(217, f)
                }
                if (b) window.console ? .error ? .(e);
                else throw e;
            }
            return d
        }
        Xa(a, b, c, d) {
            return (...e) => this.Wa(a, () => b.apply(c, e), d)
        }
        Fa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.ia(a, d instanceof Error ? d : Error(d), void 0, c)
            })
        }
        ia(a, b, c, d) {
            try {
                c = c === void 0 ? 100 : c === 0 ? 0 : 1 / c;
                var e = (new by).g();
                if (c > 0 && e.pk * c <= e.hj) {
                    var f = this.H;
                    e = {};
                    if (this.g) try {
                        this.g(e)
                    } catch (g) {}
                    if (d) try {
                        d(e)
                    } catch (g) {}
                    Xx(f, a, b, c, e)
                }
            } catch (g) {}
            return this.i
        }
    };
    var ey = class extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, ey) : this.stack = Error().stack || ""
        }
    };
    let cy, fy, gy, hy;
    const iy = new pl(q);
    (function(a, b, c = !0) {
        typeof q.google_srt !== "number" && (q.google_srt = Math.random());
        fy = a || new lp;
        kp(fy, q.google_srt);
        gy = new xl(fy, c, iy);
        gy.j(!0);
        cy = b || new fp(to(), 1E3);
        hy = new dy(c);
        q.document.readyState === "complete" ? q.google_measure_js_timing || nl(iy) : iy.g && lb(q, "load", () => {
            q.google_measure_js_timing || nl(iy)
        })
    })();

    function jy(a, b, c) {
        return W(kt) ? hy.Wa(a, b, c) : gy.Wa(a, b, c)
    }

    function ky(a, b) {
        return W(kt) ? hy.Xa(a, b) : gy.Xa(a, b)
    }

    function ly(a, b, c) {
        W(kt) ? hy.Fa(a, b, c) : gy.Fa(a, b, c)
    }

    function my(a, b, c = .01) {
        const d = R(ip).g();
        !b.eid && d.length && (b.eid = d.toString());
        wl(fy, a, b, !0, c)
    }

    function ny(a, b, c = .01, d) {
        return W(kt) ? hy.ia(a, b, c, d, void 0) : gy.ia(a, b, c, d, void 0)
    }

    function oy() {
        return W(kt) ? hy : gy
    };

    function py(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };
    var uy = (a, b) => {
        var c = Ta(b.document.querySelectorAll(".google-auto-placed"));
        const d = Ta(b.document.querySelectorAll("ins.adsbygoogle[data-anchor-status]")),
            e = qy(b),
            f = ry(b),
            g = sy(b),
            h = Ta(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = Ta(b.document.querySelectorAll("div.googlepublisherpluginad")),
            l = Ta(b.document.querySelectorAll("html > ins.adsbygoogle"));
        let m = [].concat(Ta(b.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), Ta(b.document.querySelectorAll("body ins.adsbygoogle")));
        b = [];
        for (const [n, p] of [
                [a.Md, c],
                [a.Vb, d],
                [a.Nj, e],
                [a.Cf, f],
                [a.Df, g],
                [a.Lj, h],
                [a.Mj, k],
                [a.Oj, l]
            ]) n === !1 ? b = b.concat(p) : m = m.concat(p);
        a = ty(m);
        c = ty(b);
        a = a.slice(0);
        for (const n of c)
            for (c = 0; c < a.length; c++)(n.contains(a[c]) || a[c].contains(n)) && a.splice(c, 1);
        return a
    };
    const vy = a => {
            const b = py(a);
            return b ? Ka(La(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
        },
        qy = a => Ta(a.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]")),
        ry = a => (vy(a) || Ta(a.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(Ta(a.document.querySelectorAll("iframe[id^=google_ads_iframe]"))),
        sy = a => Ta(a.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]"));
    var ty = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };
    var wy = ky(453, uy),
        xy = ky(454, (a, b) => {
            const c = Ta(b.document.querySelectorAll(".google-auto-placed")),
                d = Ta(b.document.querySelectorAll("ins.adsbygoogle[data-anchor-status]")),
                e = qy(b),
                f = ry(b),
                g = sy(b),
                h = Ta(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
                k = Ta(b.document.querySelectorAll("div.googlepublisherpluginad"));
            b = Ta(b.document.querySelectorAll("html > ins.adsbygoogle"));
            return ty([].concat(a.Md === !0 ? c : [], a.Vb === !0 ? d : [], a.Nj === !0 ? e : [], a.Cf === !0 ? f : [], a.Df === !0 ? g : [], a.Lj === !0 ? h : [], a.Mj ===
                !0 ? k : [], a.Oj === !0 ? b : []))
        });

    function yy(a, b, c) {
        const d = zy(a);
        b = Ay(d, b, c);
        return new By(a, d, b)
    }

    function Cy(a) {
        return (a.bottom - a.top) * (a.right - a.left) > 1
    }

    function Dy(a) {
        return a.g.map(b => b.box)
    }

    function Ey(a) {
        return a.g.reduce((b, c) => b + c.box.bottom - c.box.top, 0)
    }
    var By = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b.slice(0);
            this.l = c.slice(0);
            this.i = null
        }
    };

    function zy(a) {
        const b = wy({
                Vb: !1
            }, a),
            c = Jp(a),
            d = Ip(a);
        return b.map(e => {
            const f = e.getBoundingClientRect();
            return (e = !!e.className && e.className.indexOf("google-auto-placed") != -1) || Cy(f) ? {
                box: {
                    top: f.top + d,
                    right: f.right + c,
                    bottom: f.bottom + d,
                    left: f.left + c
                },
                Io: e ? 1 : 0
            } : null
        }).filter(db(e => e === null))
    }

    function Ay(a, b, c) {
        return b != void 0 && a.length <= (c != void 0 ? c : 8) ? Fy(a, b) : La(a, d => new Ux(d.box, 1))
    }

    function Fy(a, b) {
        a = La(a, d => new Ux(d.box, 1));
        const c = [];
        for (; a.length > 0;) {
            let d = a.pop(),
                e = !0;
            for (; e;) {
                e = !1;
                for (let f = 0; f < a.length; f++)
                    if (Sx(d, a[f], b)) {
                        d = Tx([d, a[f]]);
                        Array.prototype.splice.call(a, f, 1);
                        e = !0;
                        break
                    }
            }
            c.push(d)
        }
        return c
    };

    function Gy(a, b, c) {
        const d = Uq(c, b);
        return !Na(a, e => sp(e, d))
    }

    function Hy(a, b, c, d, e) {
        e = e.la;
        const f = Uq(e, b),
            g = Uq(e, c),
            h = Uq(e, d);
        return !Na(a, k => sp(k, g) || sp(k, f) && !sp(k, h))
    }

    function Iy(a, b, c, d) {
        const e = Dy(a);
        if (Gy(e, b, d.la)) return !0;
        if (!Hy(e, b, c.Gh, c.uc, d)) return !1;
        const f = new Ux(Uq(d.la, 0), 1);
        a = Ka(a.l, g => Sx(g, f, c.uc));
        b = Ma(a, (g, h) => g + h.i);
        return a.length === 0 || b > c.Ch ? !1 : !0
    };
    var Jy = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function Ky(a, b) {
        const c = new tr,
            d = new Up;
        b.forEach(e => {
            if (uh(e, Xr, 1, $r)) {
                e = uh(e, Xr, 1, $r);
                if (y(e, Wr, 1) && y(e, Wr, 1).ha() && y(e, Wr, 2) && y(e, Wr, 2).ha()) {
                    const g = Ly(a, y(e, Wr, 1).ha()),
                        h = Ly(a, y(e, Wr, 2).ha());
                    if (g && h)
                        for (var f of Jy({
                                anchor: g,
                                position: y(e, Wr, 1).j()
                            }, {
                                anchor: h,
                                position: y(e, Wr, 2).j()
                            })) c.set(sa(f.anchor), f.position)
                }
                y(e, Wr, 3) && y(e, Wr, 3).ha() && (f = Ly(a, y(e, Wr, 3).ha())) && c.set(sa(f), y(e, Wr, 3).j())
            } else uh(e, Yr, 2, $r) ? My(a, uh(e, Yr, 2, $r), c) : uh(e, Vr, 3, $r) && Ny(a, uh(e, Vr, 3, $r), d)
        });
        return new Oy(c, d)
    }
    var Oy = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };
    const My = (a, b, c) => {
            y(b, Wr, 2) ? (b = y(b, Wr, 2), (a = Ly(a, b.ha())) && c.set(sa(a), b.j())) : y(b, xr, 1) && (a = Py(a, y(b, xr, 1))) && a.forEach(d => {
                d = sa(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        Ny = (a, b, c) => {
            y(b, xr, 1) && (a = Py(a, y(b, xr, 1))) && a.forEach(d => {
                c.add(sa(d))
            })
        },
        Ly = (a, b) => (a = Py(a, b)) && a.length > 0 ? a[0] : null,
        Py = (a, b) => (b = ww(b)) ? ow(b, a) : null;
    var Qy = class {
        constructor() {
            this.g = Ed();
            this.i = 0
        }
    };

    function Ry(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (Sy(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function Ty(a) {
        a = Uy(a);
        return a.has("all") || a.has("after")
    }

    function Vy(a) {
        a = Uy(a);
        return a.has("all") || a.has("before")
    }

    function Uy(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function Sy(a) {
        const b = Uy(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var Wy = class {
        constructor() {
            this.g = new Set;
            this.i = new Qy
        }
    };

    function Xy(a) {
        return function(b) {
            return rx(b, a)
        }
    }

    function Yy(a) {
        const b = Ap(a);
        return b ? Aa(Zy, b + Ip(a)) : ab
    }

    function $y(a, b, c) {
        if (a < 0) throw Error("ama::ead:nd");
        if (a === Infinity) return ab;
        const d = Dy(c || yy(b));
        return e => Gy(d, a, e.la)
    }

    function az(a, b, c, d) {
        if (a < 0 || b.Gh < 0 || b.Ch < 0 || b.uc < 0) throw Error("ama::ead:nd");
        return a === Infinity ? ab : e => Iy(d || yy(c, b.uc), a, b, e)
    }

    function bz(a) {
        if (!a.length) return ab;
        const b = new jr(a);
        return c => b.contains(c.Yb)
    }

    function cz(a) {
        return function(b) {
            for (let c of b.Pc)
                if (a.indexOf(c) > -1) return !1;
            return !0
        }
    }

    function dz(a) {
        return a.length ? function(b) {
            const c = b.Pc;
            return a.some(d => c.indexOf(d) > -1)
        } : bb
    }

    function ez(a, b) {
        if (a <= 0) return bb;
        const c = Ep(b).scrollHeight - a;
        return function(d) {
            return d.la.g <= c
        }
    }

    function fz(a) {
        const b = {};
        a && a.forEach(c => {
            b[c] = !0
        });
        return function(c) {
            return !b[nh(c.ue, 2) || 0]
        }
    }

    function gz(a) {
        return a.length ? b => a.includes(nh(b.ue, 1) || 0) : bb
    }

    function hz(a, b) {
        const c = Ky(a, b);
        return function(d) {
            var e = d.ha();
            d = Cw[d.ea.j()];
            var f = c.i,
                g = sa(e);
            f = f.g.get(g);
            if (!(f = f ? f.contains(d) : !1)) a: {
                if (c.g.contains(sa(e))) switch (d) {
                    case 2:
                    case 3:
                        f = !0;
                        break a;
                    default:
                        f = !1;
                        break a
                }
                for (e = e.parentElement; e;) {
                    if (c.g.contains(sa(e))) {
                        f = !0;
                        break a
                    }
                    e = e.parentElement
                }
                f = !1
            }
            return !f
        }
    }

    function iz() {
        const a = new Wy;
        return function(b) {
            var c = b.ha(),
                d = Cw[b.ea.j()];
            a: switch (d) {
                case 1:
                    b = Ty(c.previousElementSibling) || Vy(c);
                    break a;
                case 4:
                    b = Ty(c) || Vy(c.nextElementSibling);
                    break a;
                case 2:
                    b = Vy(c.firstElementChild);
                    break a;
                case 3:
                    b = Ty(c.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + d);
            }
            c = Ry(a, c, d);
            d = a.i;
            my("ama_exclusion_zone", {
                typ: b ? c ? "siuex" : "siex" : c ? "suex" : "noex",
                cor: d.g,
                num: d.i++,
                dvc: td()
            }, .1);
            return !(b || c)
        }
    }
    const Zy = (a, b) => b.la.g >= a,
        jz = (a, b, c) => {
            c = c.la.i;
            return a <= c && c <= b
        };

    function kz(a, b, c, d, e) {
        var f = lz(mz(a, b), a);
        if (f.length === 0) {
            var g = !!y(b, ms, 6) ? .i() ? .length;
            f = y(b, hs, 28) ? .j() ? .j() && g ? lz(nz(a, b), a) : f
        }
        if (f.length === 0) return Rs(d, "pfno"), [];
        b = f;
        a = e.Dd ? oz(a, b, c) : {
            tb: b,
            Fd: null
        };
        const {
            tb: h,
            Fd: k
        } = a;
        f = h;
        return f.length === 0 && k ? (Rs(d, k), []) : [f[e.Zk ? 0 : e.Xk ? Math.floor(f.length / 4) : Math.floor(f.length / 2)]]
    }

    function oz(a, b, c) {
        c = c ? hh(c, Zr, 5, Pg()) : [];
        const d = hz(a.document, c),
            e = iz();
        b = b.filter(f => d(f));
        if (b.length === 0) return {
            tb: [],
            Fd: "pfaz"
        };
        b = b.filter(f => e(f));
        return b.length === 0 ? {
            tb: [],
            Fd: "pfet"
        } : {
            tb: b,
            Fd: null
        }
    }

    function pz(a, b) {
        return a.la.g - b.la.g
    }

    function mz(a, b) {
        const c = y(b, ms, 6);
        if (!c) return [];
        b = y(b, hs, 28) ? .j();
        return (b ? .i() ? jx(c.i(), a) : ix(c.i(), a, !!b ? .l())).map(d => d.j())
    }

    function nz(a, b) {
        b = Ds(b) || [];
        return Kw(b, a, {}).filter(c => !c.Pc.includes(6))
    }

    function lz(a, b) {
        a = rx(a, b);
        const c = Yy(b);
        a = a.filter(d => c(d));
        return a.sort(pz)
    };
    var qz = {},
        rz = {},
        sz = {},
        tz = {},
        uz = {};

    function vz() {
        throw Error("Do not instantiate directly");
    }
    vz.prototype.Qg = null;
    vz.prototype.Jc = function() {
        return this.content
    };
    vz.prototype.toString = function() {
        return this.content
    };

    function wz(a) {
        if (a.Rg !== qz) throw Error("Sanitized content was not of kind HTML.");
        return oc(a.toString())
    }

    function xz() {
        vz.call(this)
    }
    Da(xz, vz);
    xz.prototype.Rg = qz;

    function yz(a) {
        if (a != null) switch (a.Qg) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function zz(a) {
        return Az(a, qz) ? a : a instanceof nc ? Bz(pc(a).toString()) : Bz(String(String(a)).replace(Cz, Dz), yz(a))
    }
    var Bz = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            d !== void 0 && (c.Qg = d);
            return c
        }
    }(xz);

    function Ez(a) {
        return Fz(String(a), () => "").replace(Gz, "&lt;")
    }
    const Hz = RegExp.prototype.hasOwnProperty("sticky"),
        Iz = new RegExp((Hz ? "" : "^") + "(?:!|/?([a-zA-Z][a-zA-Z0-9:-]*))", Hz ? "gy" : "g");

    function Fz(a, b) {
        const c = [],
            d = a.length;
        let e = 0,
            f = [],
            g, h, k = 0;
        for (; k < d;) {
            switch (e) {
                case 0:
                    var l = a.indexOf("<", k);
                    if (l < 0) {
                        if (c.length === 0) return a;
                        c.push(a.substring(k));
                        k = d
                    } else c.push(a.substring(k, l)), h = l, k = l + 1, Hz ? (Iz.lastIndex = k, l = Iz.exec(a)) : (Iz.lastIndex = 0, l = Iz.exec(a.substring(k))), l ? (f = ["<", l[0]], g = l[1], e = 1, k += l[0].length) : c.push("<");
                    break;
                case 1:
                    l = a.charAt(k++);
                    switch (l) {
                        case "'":
                        case '"':
                            let m = a.indexOf(l, k);
                            m < 0 ? k = d : (f.push(l, a.substring(k, m + 1)), k = m + 1);
                            break;
                        case ">":
                            f.push(l);
                            c.push(b(f.join(""),
                                g));
                            e = 0;
                            f = [];
                            h = g = null;
                            break;
                        default:
                            f.push(l)
                    }
                    break;
                default:
                    throw Error();
            }
            e === 1 && k >= d && (k = h + 1, c.push("<"), e = 0, f = [], h = g = null)
        }
        return c.join("")
    }

    function Jz(a, b) {
        a = a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>");
        return b ? a.replace(/{/g, " \\{").replace(/}/g, " \\}").replace(/\/\*/g, "/ *").replace(/\\$/, "\\ ") : a
    }

    function Y(a) {
        return Az(a, qz) ? String(Ez(a.Jc())).replace(Kz, Dz) : String(a).replace(Cz, Dz)
    }

    function Lz(a) {
        a = String(a);
        const b = (d, e, f) => {
            const g = Math.min(e.length - f, d.length);
            for (let k = 0; k < g; k++) {
                var h = e[f + k];
                if (d[k] !== ("A" <= h && h <= "Z" ? h.toLowerCase() : h)) return !1
            }
            return !0
        };
        for (var c = 0;
            (c = a.indexOf("<", c)) != -1;) {
            if (b("\x3c/script", a, c) || b("\x3c!--", a, c)) return "zSoyz";
            c += 1
        }
        return a
    }

    function Mz(a) {
        if (a == null) return " null ";
        if (Az(a, rz)) return a.Jc();
        switch (typeof a) {
            case "boolean":
            case "number":
                return " " + a + " ";
            default:
                return "'" + Nz(String(a)) + "'"
        }
    }
    const Oz = /['()]/g;

    function Pz(a) {
        return "%" + a.charCodeAt(0).toString(16)
    }

    function Qz(a) {
        a = encodeURIComponent(String(a));
        Oz.lastIndex = 0;
        return Oz.test(a) ? a.replace(Oz, Pz) : a
    }

    function Rz(a) {
        Az(a, sz) || Az(a, tz) ? a = Sz(a) : dc(a) ? a = Sz(ec(a)) : a instanceof Zb ? a = Sz(ac(a).toString()) : (a = String(a), a = Tz.test(a) ? a.replace(Uz, Vz) : "about:invalid#zSoyz");
        return a
    }

    function Z(a) {
        return Az(a, uz) ? Jz(a.Jc(), !1) : a == null ? "" : a instanceof wc ? Jz(xc(a), !1) : Jz(String(a), !0)
    }

    function Az(a, b) {
        return a != null && a.Rg === b
    }
    const Wz = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\v": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    };

    function Dz(a) {
        return Wz[a]
    }
    const Xz = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\v": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    };

    function Yz(a) {
        return Xz[a]
    }
    const Zz = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function Vz(a) {
        return Zz[a]
    }
    const Cz = /[\x00\x22\x26\x27\x3c\x3e]/g,
        Kz = /[\x00\x22\x27\x3c\x3e]/g,
        $z = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
        Uz = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        Tz = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i,
        aA = /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^ftp:|^data:image\/[a-z0-9+-]+;base64,[a-z0-9+\/]+=*$|^blob:/i,
        bA = /^[a-zA-Z0-9+\/_-]+={0,2}$/;

    function Nz(a) {
        return String(a).replace($z, Yz)
    }

    function Sz(a) {
        return String(a).replace(Uz, Vz)
    }

    function cA(a) {
        a = String(a);
        return bA.test(a) ? a : "zSoyz"
    }
    const Gz = /</g;
    /* 
     
     
     Copyright Mathias Bynens <http://mathiasbynens.be/> 
     
     Permission is hereby granted, free of charge, to any person obtaining 
     a copy of this software and associated documentation files (the 
     "Software"), to deal in the Software without restriction, including 
     without limitation the rights to use, copy, modify, merge, publish, 
     distribute, sublicense, and/or sell copies of the Software, and to 
     permit persons to whom the Software is furnished to do so, subject to 
     the following conditions: 
     
     The above copyright notice and this permission notice shall be 
     included in all copies or substantial portions of the Software. 
     
     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
     EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
     MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
     NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE 
     LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION 
     OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
     WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
    */
    const dA = Math.floor;
    var eA = /^xn--/,
        fA = /[\x2E\u3002\uFF0E\uFF61]/g;
    const gA = {
        Fn: "Overflow: input needs wider integers to process",
        Cn: "Illegal input >= 0x80 (not a basic code point)",
        mn: "Invalid input"
    };

    function hA(a) {
        throw RangeError(gA[a]);
    }

    function iA(a, b) {
        const c = a.split("@");
        let d = "";
        c.length > 1 && (d = c[0] + "@", a = c[1]);
        a = a.replace(fA, ".");
        a = a.split(".").map(b).join(".");
        return d + a
    }

    function jA(a) {
        return iA(a, b => {
            if (eA.test(b) && b.length > 4) {
                b = b.slice(4).toLowerCase();
                const h = [],
                    k = b.length;
                let l = 0,
                    m = 128;
                var c = 72,
                    d = b.lastIndexOf("-");
                d < 0 && (d = 0);
                for (var e = 0; e < d; ++e) b.charCodeAt(e) >= 128 && hA("Illegal input >= 0x80 (not a basic code point)"), h.push(b.charCodeAt(e));
                for (d = d > 0 ? d + 1 : 0; d < k;) {
                    e = l;
                    for (let n = 1, p = 36;; p += 36) {
                        d >= k && hA("Invalid input");
                        var f = b.charCodeAt(d++);
                        f = f - 48 < 10 ? f - 22 : f - 65 < 26 ? f - 65 : f - 97 < 26 ? f - 97 : 36;
                        (f >= 36 || f > dA((2147483647 - l) / n)) && hA("Overflow: input needs wider integers to process");
                        l += f * n;
                        var g = p <= c ? 1 : p >= c + 26 ? 26 : p - c;
                        if (f < g) break;
                        f = 36 - g;
                        n > dA(2147483647 / f) && hA("Overflow: input needs wider integers to process");
                        n *= f
                    }
                    f = h.length + 1;
                    c = l - e;
                    g = 0;
                    c = e == 0 ? dA(c / 700) : c >> 1;
                    for (c += dA(c / f); c > 455; g += 36) c = dA(c / 35);
                    c = dA(g + 36 * c / (c + 38));
                    dA(l / f) > 2147483647 - m && hA("Overflow: input needs wider integers to process");
                    m += dA(l / f);
                    l %= f;
                    h.splice(l++, 0, m)
                }
                b = String.fromCodePoint.apply(null, h)
            }
            return b
        })
    };

    function kA(a, b, c) {
        var d = a.Ca.contentWindow;
        a.Qa ? (b = {
            action: "search",
            searchTerm: b,
            rsToken: c
        }, b.experimentId = a.Na, a.sb.length > 0 && (b.adfiliateWp = a.sb), a.postMessage(d, b)) : (d = d.google.search.cse.element.getElement(a.Pb), c = {
            rsToken: c,
            hostName: a.host
        }, a.Pa || typeof a.Na !== "number" || (c.afsExperimentId = a.Na), a.sb.length > 0 && (c.adfiliateWp = a.sb), d.execute(b, void 0, c))
    }
    var lA = class {
        constructor(a) {
            this.Ca = a.Ca;
            this.Ia = a.Ia;
            this.Pb = a.Pb;
            this.Sa = a.Sa;
            this.hd = a.hd;
            this.host = a.location.host;
            this.origin = a.location.origin;
            this.language = a.language;
            this.Xb = a.Xb;
            this.Na = a.Na;
            this.Wc = a.Wc || !1;
            this.Qa = a.Qa;
            this.Eb = a.Eb;
            this.g = a.ng || !1;
            this.Pa = a.Pa || !1;
            this.sb = a.sb || "";
            this.og = !!a.og
        }
        postMessage(a, b) {
            a ? .postMessage(b, "https://www.gstatic.com")
        }
        L() {
            this.Ca.setAttribute("id", "prose-iframe");
            this.Ca.setAttribute("width", "100%");
            this.Ca.setAttribute("height", "100%");
            this.Ca.style.cssText =
                "box-sizing:border-box;border:unset;";
            var a = "https://www.google.com/s2/favicons?sz=64&domain_url=" + encodeURIComponent(this.host);
            var b = ic(a, hc) || cc;
            var c = jA(this.host.startsWith("www.") ? this.host.slice(4) : this.host),
                d = {};
            a = this.Pb;
            var e = this.Sa,
                f = this.hd;
            const g = this.host;
            c = this.Xb.replace("${website}", c);
            var h = this.Wc;
            const k = this.g,
                l = this.og,
                m = d && d.Qb,
                n = d && d.Ug;
            d = Bz;
            h = "<style" + (m ? ' nonce="' + Y(cA(m)) + '"' : "") + ">.cse-favicon {display: block; float: left; height: 16px; position: absolute; left: 15px; width: 16px;}.cse-header {font-size: 16px; font-family: Arial; margin-left: 35px; margin-top: 6px; margin-bottom: unset; line-height: 16px;}.gsc-search-box {max-width: 520px !important;}.gsc-input {padding-right: 0 !important;}.gsc-input-box {border-radius: 16px 0 0 16px !important;}.gsc-search-button-v2 {border-left: 0 !important; border-radius: 0 16px 16px 0 !important; min-height: 30px !important; margin-left: 0 !important;}.gsc-cursor-page, .gsc-cursor-next-page, .gsc-cursor-numbered-page {color: #1a73e8 !important;}.gsc-cursor-chevron {fill: #1a73e8 !important;}.gsc-cursor-box {text-align: center !important;}.gsc-cursor-current-page {color: #000 !important;}.gcsc-find-more-on-google-root, .gcsc-find-more-on-google {display: none !important;}.prose-container {max-width: 652px;}#prose-empty-serp-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 52px; position: relative; width: 248px; height: 259px; margin: auto; top: 100px;}#prose-empty-serp-icon-image {display: flex; flex-direction: row; justify-content: center; align-items: center; padding: 30px; gap: 10px; width: 124px; height: 124px; border-radius: 62px; flex: none; order: 1; flex-grow: 0; position: absolute; top: 0;}#prose-empty-serp-text-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 19px; width: 248px; height: 83px; flex: none; order: 2; align-self: stretch; flex-grow: 0; position: absolute; top: 208px;}#prose-empty-serp-text-div {display: flex; flex-direction: column; align-items: flex-start; padding: 0; gap: 11px; width: 248px; height: 83px; flex: none; order: 0; align-self: stretch; flex-grow: 0;}#prose-empty-serp-supporting-text {width: 248px; height: 40px; font-family: 'Arial'; font-style: normal; font-weight: 400; font-size: 14px; line-height: 20px; text-align: center; letter-spacing: 0.2px; color: #202124; flex: none; order: 1; align-self: stretch; flex-grow: 0;}</style>" +
                (h ? "<script" + (n ? ' nonce="' + Y(cA(n)) + '"' : "") + '>window.__gcse={initializationCallback:function(){top.postMessage({action:"init",adChannel:"' + Nz(f) + '"},top.location.origin);}};\x3c/script>' : "") + '<div class="prose-container"><img class="cse-favicon" src="';
            Az(b, sz) || Az(b, tz) ? b = Sz(b) : dc(b) ? b = Sz(ec(b)) : b instanceof Zb ? b = Sz(ac(b).toString()) : (b = String(b), b = aA.test(b) ? b.replace(Uz, Vz) : "about:invalid#zSoyz");
            a = d(h + Y(b) + '" alt="' + Y(g) + ' icon"><p class="cse-header"><strong>' + zz(c) + "</strong></p>" + (l ? '<div class="gcse-searchresults-only" data-gname="' +
                Y(a) + '" data-adclient="' + Y(e) + '" data-adchannel="' + Y(f) + '" data-as_sitesearch="' + Y(g) + '" data-personalizedAds="false"></div>' : '<div class="gcse-search" data-gname="' + Y(a) + '" data-adclient="' + Y(e) + '" data-adchannel="' + Y(f) + '" data-as_sitesearch="' + Y(g) + '" data-personalizedAds="false"></div>') + "</div>" + (k ? "<div id=\"prose-empty-serp-container\"><img id='prose-empty-serp-icon-image' src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI0IiBoZWlnaHQ9IjEyNCIgdmlld0JveD0iMCAwIDEyNCAxMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMjQiIGhlaWdodD0iMTI0IiByeD0iNjIiIGZpbGw9IiNGMUYzRjQiLz4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik02OS4zNiA2NS4zODY3TDg0LjY0IDgwLjY2NjdMODAuNjY2NyA4NC42NEw2NS4zODY3IDY5LjM2QzYyLjUzMzMgNzEuNDEzMyA1OS4wOTMzIDcyLjY2NjcgNTUuMzMzMyA3Mi42NjY3QzQ1Ljc2IDcyLjY2NjcgMzggNjQuOTA2NyAzOCA1NS4zMzMzQzM4IDQ1Ljc2IDQ1Ljc2IDM4IDU1LjMzMzMgMzhDNjQuOTA2NyAzOCA3Mi42NjY3IDQ1Ljc2IDcyLjY2NjcgNTUuMzMzM0M3Mi42NjY3IDU5LjA5MzMgNzEuNDEzMyA2Mi41MzMzIDY5LjM2IDY1LjM4NjdaTTU1LjMzMzMgNDMuMzMzM0M0OC42OTMzIDQzLjMzMzMgNDMuMzMzMyA0OC42OTMzIDQzLjMzMzMgNTUuMzMzM0M0My4zMzMzIDYxLjk3MzMgNDguNjkzMyA2Ny4zMzMzIDU1LjMzMzMgNjcuMzMzM0M2MS45NzMzIDY3LjMzMzMgNjcuMzMzMyA2MS45NzMzIDY3LjMzMzMgNTUuMzMzM0M2Ny4zMzMzIDQ4LjY5MzMgNjEuOTczMyA0My4zMzMzIDU1LjMzMzMgNDMuMzMzM1oiIGZpbGw9IiM5QUEwQTYiLz4KPC9zdmc+Cg==' alt=''><div id='prose-empty-serp-text-container'><div id='prose-empty-serp-text-div'><div id='prose-empty-serp-supporting-text'>Search this website by entering a keyword.</div></div></div></div>" :
                ""));
            a = wz(a);
            this.Qa ? (a = this.Ca, e = Uc `https://www.gstatic.com/prose/protected/${this.Eb||"558153351"}/iframe.html?cx=${this.Ia}&host=${this.host}&hl=${this.language}&lrh=${this.Xb}&client=${this.Sa}&origin=${this.origin}`, a.src = ac(e).toString()) : (e = new Map([
                ["cx", this.Ia],
                ["language", this.language]
            ]), this.Pa && (f = Array.isArray(this.Na) ? this.Na : [this.Na], f.length && e.set("fexp", f.join())), e = Vc(Uc `https://cse.google.com/cse.js`, e), e = ac(e).toString(), e = oc(`<script src="${Lc(e)}"` + ">\x3c/script>"), a = Sc("body", {
                style: "margin:0;"
            }, [a, e]), this.Ca.srcdoc = pc(a))
        }
    };

    function mA(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = [])) : a.google_reactive_ads_global_state = new nA;
        return a.google_reactive_ads_global_state
    }
    var nA = class {
            constructor() {
                this.wasPlaTagProcessed = !1;
                this.wasReactiveAdConfigReceived = {};
                this.adCount = {};
                this.wasReactiveAdVisible = {};
                this.stateForType = {};
                this.reactiveTypeEnabledInAsfe = {};
                this.wasReactiveTagRequestSent = !1;
                this.reactiveTypeDisabledByPublisher = {};
                this.tagSpecificState = {};
                this.messageValidationEnabled = !1;
                this.floatingAdsStacking = new oA;
                this.sideRailProcessedFixedElements = new Set;
                this.sideRailAvailableSpace = new Map;
                this.sideRailPlasParam = new Map;
                this.sideRailMutationCallbacks = [];
                this.g =
                    null;
                this.clickTriggeredInterstitialMayBeDisplayed = !1
            }
        },
        oA = class {
            constructor() {
                this.maxZIndexRestrictions = {};
                this.nextRestrictionId = 0;
                this.maxZIndexListeners = []
            }
        };

    function pA(a, b) {
        return new qA(a, b)
    }

    function rA(a) {
        const b = sA(a);
        Ia(a.floatingAdsStacking.maxZIndexListeners, c => c(b))
    }

    function sA(a) {
        a = fd(a.floatingAdsStacking.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }

    function tA(a, b) {
        Ra(a.floatingAdsStacking.maxZIndexListeners, c => c === b)
    }
    var uA = class {
        constructor(a) {
            this.floatingAdsStacking = mA(a).floatingAdsStacking
        }
    };

    function vA(a) {
        if (a.g == null) {
            var b = a.controller,
                c = a.Ab;
            const d = b.floatingAdsStacking.nextRestrictionId++;
            b.floatingAdsStacking.maxZIndexRestrictions[d] = c;
            rA(b);
            a.g = d
        }
    }

    function wA(a) {
        if (a.g != null) {
            var b = a.controller;
            delete b.floatingAdsStacking.maxZIndexRestrictions[a.g];
            rA(b);
            a.g = null
        }
    }
    var qA = class {
        constructor(a, b) {
            this.controller = a;
            this.Ab = b;
            this.g = null
        }
    };

    function xA(a) {
        a = a.activeElement;
        const b = a ? .shadowRoot;
        return b ? xA(b) || a : a
    }

    function yA(a, b) {
        return zA(b, a.document.body).flatMap(c => AA(c))
    }

    function zA(a, b) {
        var c = a;
        for (a = []; c && c !== b;) {
            a.push(c);
            let e;
            var d;
            (d = c.parentElement) || (c = c.getRootNode(), d = ((e = c.mode && c.host ? c : null) == null ? void 0 : e.host) || null);
            c = d
        }
        return c !== b ? [] : a
    }

    function AA(a) {
        const b = a.parentElement;
        return b ? Array.from(b.children).filter(c => c !== a) : []
    };

    function BA(a) {
        a.g !== null && (a.g.tj.forEach(b => {
            b.inert = !1
        }), a.g.Ck ? .focus(), a.g = null)
    }

    function CA(a, b) {
        BA(a);
        const c = xA(a.win.document);
        b = yA(a.win, b).filter(d => !d.inert);
        b.forEach(d => {
            d.inert = !0
        });
        a.g = {
            Ck: c,
            tj: b
        }
    }
    var DA = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
        Ae() {
            BA(this)
        }
    };

    function EA(a) {
        return new FA(a, new fq(a, a.document.body), new fq(a, a.document.documentElement), new fq(a, a.document.documentElement))
    }

    function GA(a) {
        eq(a.j, "scroll-behavior", "auto");
        const b = HA(a.win);
        b.activePageScrollPreventers.add(a);
        b.previousWindowScroll === null && (b.previousWindowScroll = a.win.scrollY);
        eq(a.g, "position", "fixed");
        eq(a.g, "top", `${-b.previousWindowScroll}px`);
        eq(a.g, "width", "100%");
        eq(a.g, "overflow-x", "hidden");
        eq(a.g, "overflow-y", "hidden");
        eq(a.i, "overflow-x", "hidden");
        eq(a.i, "overflow-y", "hidden")
    }

    function IA(a) {
        dq(a.g);
        dq(a.i);
        const b = HA(a.win);
        b.activePageScrollPreventers.delete(a);
        b.activePageScrollPreventers.size === 0 && (a.win.scrollTo(0, b.previousWindowScroll || 0), b.previousWindowScroll = null);
        dq(a.j)
    }
    var FA = class {
        constructor(a, b, c, d) {
            this.win = a;
            this.g = b;
            this.i = c;
            this.j = d
        }
    };

    function HA(a) {
        return a.googPageScrollPreventerInfo = a.googPageScrollPreventerInfo || {
            previousWindowScroll: null,
            activePageScrollPreventers: new Set
        }
    }

    function JA(a) {
        return a.googPageScrollPreventerInfo && a.googPageScrollPreventerInfo.activePageScrollPreventers.size > 0 ? !0 : !1
    };

    function KA(a, b) {
        return LA(`#${a}`, b)
    }

    function MA(a, b) {
        return LA(`.${a}`, b)
    }

    function LA(a, b) {
        b = b.querySelector(a);
        if (!b) throw Error(`Element (${a}) does not exist`);
        return b
    };

    function NA(a, b) {
        const c = a.document.createElement("div");
        u(c, Us(a));
        a = c.attachShadow({
            mode: "open"
        });
        b && c.classList.add(b);
        return {
            mb: c,
            shadowRoot: a
        }
    };

    function OA(a, b) {
        b = NA(a, b);
        a.document.body.appendChild(b.mb);
        return b
    }

    function PA(a, b) {
        const c = new T(b.O);
        oq(b, !0, () => void c.g(!0));
        oq(b, !1, () => {
            a.setTimeout(() => {
                b.O || c.g(!1)
            }, 700)
        });
        return jq(c)
    };

    function QA(a) {
        var b = {},
            c = a.Hd,
            d = a.fg,
            e = a.Ed;
        const f = a.xd,
            g = a.Mg,
            h = a.zIndex,
            k = a.Pe;
        a = a.Ua;
        b = b && b.Qb;
        c = "<style" + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + ">#hd-drawer-container {position: fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + Z(h) + "; pointer-events: none;}#hd-drawer-container.hd-revealed {pointer-events: auto;}#hd-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.hd-revealed > #hd-modal-background {opacity: 0.5;}#hd-drawer {position: absolute; top: 0; height: 100%; width: " +
            Z(c) + "; background-color: white; display: flex; flex-direction: column; box-sizing: border-box; padding-bottom: ";
        d = d ? a ? 20 : 16 : 0;
        c += Z(d) + "px; transition: transform " + Z(k) + "s ease-in-out;" + (e ? "left: 0; border-top-right-radius: " + Z(d) + "px; border-bottom-right-radius: " + Z(d) + "px; transform: translateX(-100%);" : "right: 0; border-top-left-radius: " + Z(d) + "px; border-bottom-left-radius: " + Z(d) + "px; transform: translateX(100%);") + "}.hd-revealed > #hd-drawer {transform: translateY(0);}#hd-control-bar {" + (a ?
                "height: 24px;" : "padding: 5px;") + "}.hd-control-button {border: none; background: none; cursor: pointer;" + (a ? "" : "padding: 5px;") + "}#hd-back-arrow-button {" + (e ? "float: right;" : "float: left;") + "}#hd-close-button {" + (e ? "float: left;" : "float: right;") + '}#hd-content-container {flex-grow: 1; overflow: auto;}#hd-content-container::-webkit-scrollbar * {background: transparent;}.hd-hidden {visibility: hidden;}</style><div id="hd-drawer-container" class="hd-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="hd-modal-background"></div><div id="hd-drawer"><div id="hd-control-bar"><button id="hd-back-arrow-button" class="hd-control-button hd-hidden" aria-label="' +
            Y(g) + '">';
        e = a ? "#5F6368" : "#444746";
        c += '<svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + Y(e) + '"><path d="m12 20-8-8 8-8 1.425 1.4-5.6 5.6H20v2H7.825l5.6 5.6Z"/></svg></button><button id="hd-close-button" class="hd-control-button" aria-label="' + Y(f) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + Y(e) + '"><path d="M6.4 19 5 17.6 10.6 12 5 6.4 6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4Z"/></svg></button></div><div id="hd-content-container"></div></div></div>';
        return Bz(c)
    };

    function RA(a) {
        a = a.top;
        if (!a) return null;
        try {
            var b = a.history
        } catch (c) {
            b = null
        }
        b = b && b.pushState && typeof b.pushState === "function" ? b : null;
        if (!b) return null;
        if (a.googNavStack) return a.googNavStack;
        b = new SA(a, b);
        b.L();
        return b ? a.googNavStack = b : null
    }

    function TA(a, b) {
        return b ? b.googNavStackId === a.g ? b : null : null
    }

    function UA(a, b) {
        for (let c = b.length - 1; c >= 0; --c) {
            const d = c === 0;
            a.K.requestAnimationFrame(() => void b[c].Nk({
                isFinal: d
            }))
        }
    }

    function VA(a, b) {
        b = Wa(a.stack, b, (c, d) => c - d.mh.googNavStackStateId);
        if (b >= 0) return a.stack.splice(b, a.stack.length - b);
        b = -b - 1;
        return a.stack.splice(b, a.stack.length - b)
    }
    class SA extends S {
        constructor(a, b) {
            super();
            this.K = a;
            this.history = b;
            this.stack = [];
            this.g = Math.random() * 1E9 >>> 0;
            this.l = 0;
            this.j = c => {
                (c = TA(this, c.state)) ? UA(this, VA(this, c.googNavStackStateId + .5)): UA(this, this.stack.splice(0, this.stack.length))
            }
        }
        pushEvent() {
            const a = {
                    googNavStackId: this.g,
                    googNavStackStateId: this.l++
                },
                b = new Promise(c => {
                    this.stack.push({
                        Nk: c,
                        mh: a
                    })
                });
            this.history.pushState(a, "");
            return {
                navigatedBack: b,
                triggerNavigateBack: () => {
                    const c = VA(this, a.googNavStackStateId);
                    var d;
                    if (d = c.length >
                        0) {
                        d = c[0].mh;
                        const e = TA(this, this.history.state);
                        d = e && e.googNavStackId === d.googNavStackId && e.googNavStackStateId === d.googNavStackStateId
                    }
                    d && this.history.go(-c.length);
                    UA(this, c)
                }
            }
        }
        L() {
            this.K.addEventListener("popstate", this.j)
        }
        i() {
            this.K.removeEventListener("popstate", this.j);
            super.i()
        }
    };

    function WA(a) {
        return (a = RA(a)) ? new XA(a) : null
    }

    function YA(a) {
        if (!a.g) {
            var {
                navigatedBack: b,
                triggerNavigateBack: c
            } = a.l.pushEvent();
            a.g = c;
            b.then(() => {
                a.g && !a.B && (a.g = null, uq(a.j))
            })
        }
    }
    var XA = class extends S {
        constructor(a) {
            super();
            this.l = a;
            this.j = new vq;
            this.g = null
        }
    };

    function ZA(a, b, c) {
        var d = c.hf ? null : new DA(a);
        const e = pA(new uA(a), c.zIndex - 1);
        b = $A(a, b, c);
        d = new aB(a, b, d, c.Hc, EA(a), e);
        d.L();
        (c.Yg || c.Yg === void 0) && bB(d);
        c.Ec && ((a = WA(a)) ? cB(d, a, c.Tf) : c.Tf ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function bB(a) {
        a.A = b => {
            b.key === "Escape" && a.g.O && a.collapse()
        };
        a.win.document.body.addEventListener("keydown", a.A)
    }

    function cB(a, b, c) {
        oq(a.g, !0, () => {
            try {
                YA(b)
            } catch (d) {
                c ? .(d)
            }
        });
        oq(a.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        sq(b.j).listen(() => void a.collapse());
        bq(a, b)
    }

    function dB(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.D
    }

    function eB(a) {
        a.win.setTimeout(() => {
            a.g.O && dB(a).Ja.focus()
        }, 500)
    }

    function fB(a) {
        const {
            Rf: b,
            aj: c
        } = dB(a);
        b.addEventListener("click", () => void a.collapse());
        c.addEventListener("click", () => void a.collapse())
    }

    function gB(a) {
        oq(a.j, !1, () => {
            dB(a).Ja.classList.add("hd-hidden")
        })
    }
    var aB = class extends S {
        constructor(a, b, c, d = !0, e, f) {
            super();
            this.win = a;
            this.D = b;
            this.l = c;
            this.Hc = d;
            this.g = new T(!1);
            this.j = PA(a, this.g);
            oq(this.j, !0, () => {
                GA(e);
                vA(f)
            });
            oq(this.j, !1, () => {
                IA(e);
                wA(f)
            })
        }
        show({
            Wg: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            dB(this).Ja.classList.remove("hd-hidden");
            $p(this.win);
            dB(this).Ja.classList.add("hd-revealed");
            this.g.g(!0);
            this.l && (CA(this.l, dB(this).nb.mb), this.Hc && eB(this));
            a && oq(this.j, !1, () => {
                this.dispose()
            })
        }
        collapse() {
            dB(this).Ja.classList.remove("hd-revealed");
            this.g.g(!1);
            this.l ? .Ae()
        }
        isVisible() {
            return this.j
        }
        L() {
            fB(this);
            gB(this)
        }
        i() {
            this.A && this.win.document.body.removeEventListener("keydown", this.A);
            const a = this.D.nb.mb,
                b = a.parentNode;
            b && b.removeChild(a);
            this.l ? .Ae();
            super.i()
        }
    };

    function $A(a, b, c) {
        const d = OA(a, c.jf),
            e = d.shadowRoot;
        e.appendChild(Ek(new rk(a.document), wz(QA({
            Hd: c.Hd,
            fg: c.fg ? ? !0,
            Ed: c.Ed || !1,
            xd: c.xd,
            Mg: c.Mg || "",
            zIndex: c.zIndex,
            Pe: .5,
            Ua: c.Ua || !1
        }))));
        const f = KA("hd-drawer-container", e);
        c.rf ? .i(g => {
            f.setAttribute("aria-label", g)
        });
        c = KA("hd-content-container", e);
        c.appendChild(b);
        $p(a);
        return {
            Ja: f,
            Rf: KA("hd-modal-background", e),
            cf: c,
            aj: KA("hd-close-button", e),
            Lo: KA("hd-back-arrow-button", e),
            nb: d
        }
    };

    function hB(a) {
        var b = {};
        const c = a.xk,
            d = a.Ej;
        var e = a.zIndex,
            f = a.Pe;
        a = a.Ua;
        b = b && b.Qb;
        e = "<style" + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + ">#ved-drawer-container {position:  fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + Z(e) + "; pointer-events: none;}#ved-drawer-container.ved-revealed {pointer-events: auto;}#ved-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.ved-revealed > #ved-modal-background {opacity: 0.5;}#ved-ui-revealer {position: absolute; left: 0; bottom: 0; width: 100%; height: " +
            Z(d) + "%; transition: transform " + Z(f) + "s ease-in-out; transform: translateY(100%);}#ved-ui-revealer.ved-no-animation {transition-property: none;}.ved-revealed > #ved-ui-revealer {transform: translateY(0);}#ved-scroller-container {position: absolute; left: 0; bottom: 0; width: 100%; height: 100%; clip-path: inset(0 0 -50px 0 round ";
        f = a ? 20 : 28;
        e += Z(f) + "px);}#ved-scroller {position: relative; width: 100%; height: 100%; overflow-y: scroll; -ms-overflow-style: none; scrollbar-width: none; overflow-y: scroll; overscroll-behavior: none; scroll-snap-type: y mandatory;}#ved-scroller.ved-scrolling-paused {overflow: hidden;}#ved-scroller.ved-no-snap {scroll-snap-type: none;}#ved-scroller::-webkit-scrollbar {display: none;}#ved-scrolled-stack {width: 100%; height: 100%; overflow: visible;}#ved-scrolled-stack.ved-with-background {background-color: white;}.ved-snap-point-top {scroll-snap-align: start;}.ved-snap-point-bottom {scroll-snap-align: end;}#ved-fully-closed-anchor {height: " +
            Z(c / d * 100) + "%;}.ved-with-background #ved-fully-closed-anchor {background-color: white;}#ved-partially-extended-anchor {height: " + Z((d - c) / d * 100) + "%;}.ved-with-background #ved-partially-extended-anchor {background-color: white;}#ved-moving-handle-holder {scroll-snap-stop: always;}.ved-with-background #ved-moving-handle-holder {background-color: white;}#ved-fixed-handle-holder {position: absolute; left: 0; top: 0; width: 100%;}#ved-visible-scrolled-items {display: flex; flex-direction: column; min-height: " +
            Z(c / d * 100) + "%;}#ved-content-background {width: 100%; flex-grow: 1; padding-top: 1px; margin-top: -1px; background-color: white;}#ved-content-sizer {overflow: hidden; width: 100%; height: 100%;}#ved-content-container {width: 100%;}#ved-over-scroll-block {display: flex; flex-direction: column; position: absolute; bottom: 0; left: 0; width: 100%; height: " + Z(c / d * 100) + "%; pointer-events: none;}#ved-over-scroll-handle-spacer {height: " + Z(80) + "px;}#ved-over-scroll-background {flex-grow: 1; background-color: white;}.ved-handle {align-items: flex-end; border-radius: " +
            Z(f) + "px " + Z(f) + "px 0 0; background: white; display: flex; height: " + Z(30) + "px; justify-content: center; cursor: grab;}.ved-handle-icon {" + (a ? "background: #dadce0; width: 50px;" : "background: #747775; opacity: 0.4; width: 32px;") + 'border-radius: 2px; height: 4px; margin-bottom: 8px;}.ved-hidden {visibility: hidden;}</style><div id="ved-drawer-container" class="ved-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="ved-modal-background"></div><div id="ved-ui-revealer"><div id="ved-over-scroll-block" class="ved-hidden"><div id=\'ved-over-scroll-handle-spacer\'></div><div id=\'ved-over-scroll-background\'></div></div><div id="ved-scroller-container"><div id="ved-scroller"><div id="ved-scrolled-stack"><div id="ved-fully-closed-anchor" class="ved-snap-point-top"></div><div id="ved-partially-extended-anchor" class="ved-snap-point-top"></div><div id="ved-visible-scrolled-items"><div id="ved-moving-handle-holder" class="ved-snap-point-top">' +
            iB("ved-moving-handle") + '</div><div id="ved-content-background"><div id="ved-content-sizer" class="ved-snap-point-bottom"><div id="ved-content-container"></div></div></div></div></div></div></div><div id="ved-fixed-handle-holder" class="ved-hidden">' + iB("ved-fixed-handle") + "</div></div></div>";
        return Bz(e)
    }

    function iB(a) {
        return Bz('<div class="ved-handle" id="' + Y(a) + '"><div class="ved-handle-icon"></div></div>')
    };

    function jB(a) {
        return Jq(a.g).map(b => b ? kB(a, b) : 0)
    }

    function kB(a, b) {
        switch (a.direction) {
            case 0:
                return lB(-b.ni);
            case 1:
                return lB(-b.mi);
            default:
                throw Error(`Unhandled direction: ${a.direction}`);
        }
    }

    function mB(a) {
        return Lq(a.g).map(b => kB(a, b))
    }
    var nB = class {
        constructor(a) {
            this.g = a;
            this.direction = 0
        }
    };

    function lB(a) {
        return a === 0 ? 0 : a
    };

    function oB(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.D
    }

    function pB(a) {
        a.win.setTimeout(() => {
            a.g.O && oB(a).Ja.focus()
        }, 500)
    }

    function qB(a) {
        oB(a).Ja.classList.remove("ved-hidden");
        $p(a.win);
        const {
            ra: b,
            ib: c
        } = oB(a);
        c.getBoundingClientRect().top <= b.getBoundingClientRect().top || rB(a);
        oB(a).Ja.classList.add("ved-revealed");
        a.g.g(!0);
        a.j && (CA(a.j, oB(a).nb.mb), a.Hc && pB(a))
    }

    function sB(a) {
        return PA(a.win, a.g)
    }

    function tB(a, b) {
        const c = new T(b());
        sq(a.I).listen(() => void c.g(b()));
        return jq(c)
    }

    function uB(a) {
        const {
            ra: b,
            he: c
        } = oB(a);
        return tB(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function vB(a) {
        const {
            ra: b,
            he: c
        } = oB(a);
        return tB(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top - 1)
    }

    function wB(a) {
        const {
            ra: b
        } = oB(a);
        return tB(a, () => b.scrollTop === b.scrollHeight - b.clientHeight)
    }

    function xB(a) {
        return kq(uB(a), wB(a))
    }

    function yB(a) {
        const {
            ra: b,
            ib: c
        } = oB(a);
        return tB(a, () => c.getBoundingClientRect().top < b.getBoundingClientRect().top - 1)
    }

    function rB(a) {
        oB(a).ib.classList.add("ved-snap-point-top");
        var b = zB(a, oB(a).ib);
        oB(a).ra.scrollTop = b;
        AB(a)
    }

    function BB(a) {
        mq(uB(a), !0, () => {
            const {
                gh: b,
                dd: c
            } = oB(a);
            b.classList.remove("ved-hidden");
            c.classList.add("ved-with-background")
        });
        mq(uB(a), !1, () => {
            const {
                gh: b,
                dd: c
            } = oB(a);
            b.classList.add("ved-hidden");
            c.classList.remove("ved-with-background")
        })
    }

    function CB(a) {
        const b = Qq(a.win, oB(a).cf);
        Tq(b).i(() => void DB(a));
        bq(a, b)
    }

    function EB(a) {
        mq(FB(a), !0, () => {
            oB(a).Lh.classList.remove("ved-hidden")
        });
        mq(FB(a), !1, () => {
            oB(a).Lh.classList.add("ved-hidden")
        })
    }

    function GB(a) {
        const b = () => void uq(a.F),
            {
                Rf: c,
                ib: d,
                Dj: e
            } = oB(a);
        c.addEventListener("click", b);
        d.addEventListener("click", b);
        e.addEventListener("click", b);
        oq(HB(a), !0, b)
    }

    function IB(a) {
        oq(sB(a), !1, () => {
            rB(a);
            oB(a).Ja.classList.add("ved-hidden")
        })
    }

    function AB(a) {
        nq(a.l, !1, () => void uq(a.I))
    }

    function DB(a) {
        if (!a.l.O) {
            var {
                Sg: b,
                cf: c
            } = oB(a), d = c.getBoundingClientRect().height;
            d = Math.max(JB(a), d);
            a.l.g(!0);
            var e = KB(a);
            b.style.setProperty("height", `${d}px`);
            e();
            a.win.requestAnimationFrame(() => {
                a.win.requestAnimationFrame(() => {
                    a.l.g(!1)
                })
            })
        }
    }

    function FB(a) {
        const {
            ra: b,
            ib: c
        } = oB(a);
        return tB(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function HB(a) {
        return iq(a.A.map(ur), LB(a))
    }

    function LB(a) {
        return tB(a, () => oB(a).ra.scrollTop === 0)
    }

    function zB(a, b) {
        ({
            dd: a
        } = oB(a));
        a = a.getBoundingClientRect().top;
        return b.getBoundingClientRect().top - a
    }

    function MB(a, b) {
        a.A.g(!0);
        const {
            dd: c,
            ra: d
        } = oB(a);
        d.scrollTop = 0;
        d.classList.add("ved-scrolling-paused");
        c.style.setProperty("margin-top", `-${b}px`);
        return () => void NB(a, b)
    }

    function NB(a, b) {
        const {
            dd: c,
            ra: d
        } = oB(a);
        c.style.removeProperty("margin-top");
        d.classList.remove("ved-scrolling-paused");
        oB(a).ra.scrollTop = b;
        AB(a);
        a.A.g(!1)
    }

    function KB(a) {
        const b = oB(a).ra.scrollTop;
        MB(a, b);
        return () => void NB(a, b)
    }

    function JB(a) {
        const {
            ra: b,
            he: c,
            Sg: d,
            ib: e
        } = oB(a);
        a = b.getBoundingClientRect();
        const f = c.getBoundingClientRect();
        var g = d.getBoundingClientRect();
        const h = e.getBoundingClientRect();
        g = g.top - f.top;
        return Math.max(a.height - h.height - g, Math.min(a.height, a.bottom - f.top) - g)
    }
    var OB = class extends S {
        constructor(a, b, c, d, e = !0) {
            super();
            this.win = a;
            this.D = b;
            this.M = c;
            this.j = d;
            this.Hc = e;
            this.F = new vq;
            this.I = new vq;
            this.g = new T(!1);
            this.A = new T(!1);
            this.l = new T(!1)
        }
        L() {
            rB(this);
            BB(this);
            CB(this);
            EB(this);
            GB(this);
            IB(this);
            oB(this).ra.addEventListener("scroll", () => void AB(this))
        }
        i() {
            const a = this.D.nb.mb,
                b = a.parentNode;
            b && b.removeChild(a);
            this.j ? .Ae();
            super.i()
        }
    };

    function PB(a, b, c) {
        const d = OA(a, c.jf),
            e = d.shadowRoot;
        e.appendChild(Ek(new rk(a.document), wz(hB({
            xk: c.Nh * 100,
            Ej: c.hh * 100,
            zIndex: c.zIndex,
            Pe: .5,
            Ua: c.Ua || !1
        }))));
        const f = KA("ved-drawer-container", e);
        c.rf ? .i(g => {
            f.setAttribute("aria-label", g)
        });
        c = KA("ved-content-container", e);
        c.appendChild(b);
        $p(a);
        return {
            Ja: f,
            Rf: KA("ved-modal-background", e),
            ii: KA("ved-ui-revealer", e),
            ra: KA("ved-scroller", e),
            dd: KA("ved-scrolled-stack", e),
            Dj: KA("ved-fully-closed-anchor", e),
            ib: KA("ved-partially-extended-anchor", e),
            Sg: KA("ved-content-sizer",
                e),
            cf: c,
            Uo: KA("ved-moving-handle", e),
            he: KA("ved-moving-handle-holder", e),
            Bj: KA("ved-fixed-handle", e),
            gh: KA("ved-fixed-handle-holder", e),
            Lh: KA("ved-over-scroll-block", e),
            nb: d
        }
    };

    function QB(a, b, c) {
        var d = pA(new uA(a), c.zIndex - 1);
        b = PB(a, b, c);
        const e = c.hf ? null : new DA(a);
        var f = b.Bj;
        f = new Mq(new Dq(a, f), new Aq(f));
        var g = f.g;
        g.B.addEventListener("mousedown", g.D);
        g.l.addEventListener("mouseup", g.A);
        g.l.addEventListener("mousemove", g.G, {
            passive: !1
        });
        g = f.i;
        g.i.addEventListener("touchstart", g.G);
        g.i.addEventListener("touchend", g.B);
        g.i.addEventListener("touchmove", g.A, {
            passive: !1
        });
        b = new OB(a, b, new nB(f), e, c.Hc);
        b.L();
        d = new RB(a, b, EA(a), d);
        bq(d, b);
        d.L();
        c.Ec && ((a = WA(a)) ? SB(d, a, c.Tf) :
            c.Tf ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function SB(a, b, c) {
        oq(a.g.g, !0, () => {
            try {
                YA(b)
            } catch (d) {
                c ? .(d)
            }
        });
        oq(a.g.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        sq(b.j).listen(() => void a.collapse());
        bq(a, b)
    }

    function TB(a) {
        oq(iq(xB(a.g), yB(a.g)), !0, () => {
            oB(a.g).ib.classList.remove("ved-snap-point-top")
        });
        mq(vB(a.g), !0, () => {
            oB(a.g).ra.classList.add("ved-no-snap")
        });
        mq(vB(a.g), !1, () => {
            oB(a.g).ra.classList.remove("ved-no-snap")
        });
        oq(vB(a.g), !1, () => {
            var b = a.g;
            var c = oB(b).he;
            c = MB(b, zB(b, c));
            b.win.setTimeout(c, 100)
        })
    }

    function UB(a) {
        const b = a.g.M;
        jB(b).listen(c => {
            c = -c;
            if (c > 0) {
                const {
                    ii: d
                } = oB(a.g);
                d.classList.add("ved-no-animation");
                d.style.setProperty("transform", `translateY(${c}px)`)
            } else({
                ii: c
            } = oB(a.g)), c.classList.remove("ved-no-animation"), c.style.removeProperty("transform")
        });
        mB(b).listen(c => {
            -c > 30 && a.collapse()
        })
    }
    var RB = class extends S {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.g = b;
            oq(sB(b), !0, () => {
                GA(c);
                vA(d)
            });
            oq(sB(b), !1, () => {
                IA(c);
                wA(d)
            })
        }
        show({
            Wg: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            qB(this.g);
            a && oq(sB(this.g), !1, () => {
                this.dispose()
            })
        }
        collapse() {
            var a = this.g;
            oB(a).Ja.classList.remove("ved-revealed");
            a.g.g(!1);
            a.j ? .Ae()
        }
        isVisible() {
            return sB(this.g)
        }
        L() {
            sq(this.g.F).listen(() => {
                this.collapse()
            });
            TB(this);
            UB(this);
            $p(this.win)
        }
    };

    function VB(a, b) {
        return td() === 2 ? QB(a.win, b, {
            Nh: .95,
            hh: .95,
            zIndex: 2147483645,
            Ec: !0,
            Ua: !0
        }) : ZA(a.win, b, {
            Hd: "min(65vw, 768px)",
            xd: "",
            Ed: !1,
            zIndex: 2147483645,
            Ec: !0,
            fg: !1,
            Ua: !0
        })
    }

    function WB(a) {
        ((d, e) => {
            d[e] = d[e] || function() {
                (d[e].q = d[e].q || []).push(arguments)
            };
            d[e].t = (new Date).getTime()
        })(a.win, "_googCsa");
        const b = a.I.map(d => ({
                container: d,
                relatedSearches: 5
            })),
            c = {
                pubId: a.Sa,
                styleId: "5134551505",
                hl: a.language,
                fexp: a.l,
                channel: "AutoRsVariant",
                resultsPageBaseUrl: "http://google.com",
                resultsPageQueryParam: "q",
                relatedSearchTargeting: "content",
                relatedSearchResultClickedCallback: a.Ma.bind(a),
                relatedSearchUseResultCallback: !0,
                cx: a.Ia
            };
        a.U && (c.adLoadedCallback = a.Z.bind(a));
        a.Pa && a.j instanceof
        Array && (c.fexp = a.j.join(","));
        a.win._googCsa("relatedsearch", c, b)
    }

    function XB(a) {
        a.win.addEventListener("message", b => {
            b.origin === "https://www.gstatic.com" && b.data.action === "resize" && (a.g.style.height = `${Math.ceil(b.data.height)+1}px`)
        })
    }
    var YB = class extends S {
        constructor(a, b, c, d, e, f, g, h, k = () => {}) {
            super();
            this.win = a;
            this.I = b;
            this.F = e;
            this.l = f;
            this.Qa = !0;
            this.Eb = h;
            this.xa = k;
            this.language = d ? .i() || "en";
            this.pa = d ? .j() || "Search results from ${website}";
            this.U = W(Kt);
            this.Sa = c.replace("ca", "partner");
            this.D = new rk(a.document);
            this.g = Dk(this.D, "IFRAME");
            this.Ia = g.g ? g.Ia : "9d449ff4a772956c6";
            this.j = (this.Pa = !0, R(ip).g().concat(this.l));
            this.A = new lA({
                Ca: this.g,
                Ia: this.Ia,
                Pb: "auto-rs-prose",
                Sa: this.Sa,
                hd: "AutoRsVariant",
                location: a.location,
                language: this.language,
                Xb: this.pa,
                Na: this.j,
                Qa: this.Qa,
                Eb: this.Eb,
                Wc: !1,
                ng: !1,
                Pa: this.Pa
            });
            this.M = VB(this, this.g);
            bq(this, this.M)
        }
        L() {
            this.I.length !== 0 && (this.U || uw(1075, () => {
                this.A.L()
            }, this.win), uw(1076, () => {
                const a = Dk(this.D, "SCRIPT");
                rc(a, Uc `https://www.google.com/adsense/search/async-ads.js`);
                this.win.document.head.appendChild(a)
            }, this.win), WB(this), Ps(this.F, {
                sts: "ok"
            }), this.Qa && XB(this))
        }
        Z(a, b) {
            b ? uw(1075, () => {
                this.A.L()
            }, this.win) : (this.xa(), Rs(this.F, "pfns"))
        }
        Ma(a, b) {
            kA(this.A, a, b);
            (() => {
                if (!this.Qa) {
                    const c =
                        new ResizeObserver(async e => {
                            this.g.height = "0";
                            await new Promise(f => {
                                this.win.requestAnimationFrame(f)
                            });
                            this.g.height = e[0].target.scrollHeight.toString()
                        }),
                        d = () => {
                            const e = this.g.contentDocument ? .documentElement;
                            e ? c.observe(e) : (console.warn("iframe body missing"), setTimeout(d, 1E3))
                        };
                    d()
                }
                this.M.show()
            })()
        }
    };
    var ZB = class {
        constructor(a, b) {
            this.g = a;
            this.Ia = b
        }
    };
    var $B = class {
        constructor(a, b, c) {
            this.B = a;
            this.i = b;
            this.A = c;
            this.l = "autors-widget";
            this.g = null;
            this.j = new T(null)
        }
        L() {
            var a = this.i.ea;
            a = $s(a.g.document, a.F || !1);
            const b = this.A.Jc(this.B);
            a.appendChild(b);
            this.l && (a.className = this.l);
            this.g = a;
            px(this.i, this.g);
            this.j.g(b)
        }
    };
    async function aC(a) {
        await new Promise(b => {
            setTimeout(() => {
                a.run();
                b()
            })
        })
    }

    function bC(a) {
        if ((!a.Dd || !cC(a.config, a.ba, a.i)) && dC(y(a.g, fs, 5), a.i)) {
            var b = a.g.j();
            b = kz(a.win, a.config, a.ba, a.i, {
                Zk: !!b ? .B(),
                Dd: a.Dd,
                Vo: !!b ? .i(),
                Xk: !!b ? .A()
            });
            b = eC(b, a.win);
            var c = Object.keys(b),
                d = Object.values(b),
                e = a.g.i() ? .i() || 0,
                f = fC(a.g),
                g = String(F(a.g, 13));
            if (!y(a.config, bs, 25) ? .i()) {
                var h = () => {
                    d.forEach(k => {
                        k.g && k.g.parentNode && k.g.parentNode.removeChild(k.g);
                        k.g = null;
                        k.j.g(null)
                    })
                };
                uw(1074, () => {
                    (new YB(a.win, c, a.webPropertyCode, y(a.g, fs, 5), a.i, e, f, g, h)).L()
                }, a.win)
            }
        }
    }
    var gC = class {
        constructor(a, b, c, d, e) {
            this.win = a;
            this.config = c;
            this.webPropertyCode = d;
            this.ba = e;
            this.Dd = !0;
            this.g = y(this.config, hs, 28);
            this.i = new Ss(a, b, this.g)
        }
        run() {
            try {
                bC(this)
            } catch (a) {
                Rs(this.i, "pfere", a)
            }
        }
    };

    function cC(a, b, c) {
        a = y(a, hs, 28) ? .i() ? .i() || 0;
        const d = R(Kv).g(Ot.g, Ot.defaultValue);
        return d && d.includes(a.toString()) ? !1 : (b ? th(b, 2) : []).length === 0 ? (Rs(c, "pfeu"), !0) : !1
    }

    function dC(a, b) {
        const c = R(Kv).g(Nt.g, Nt.defaultValue);
        a = a ? .i() || "";
        return c && c.length !== 0 && !c.includes(a.toString()) ? (Rs(b, "pflna"), !1) : !0
    }

    function eC(a, b) {
        const c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            const f = "autors-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            d = new $B(b, d, new Xs(g));
            d.L();
            c[f] = d
        }
        return c
    }

    function fC(a) {
        return new ZB(E(a, 11) || !1, F(a, 8) || "")
    };
    var hC = (a, b) => {
        const c = [];
        y(a, rs, 18) && c.push(2);
        b.ba && c.push(0);
        y(a, hs, 28) && I(y(a, hs, 28), 1) == 1 && c.push(1);
        y(a, ds, 32) && c.push(6);
        y(a, us, 34) && E(y(a, us, 34), 3) && c.push(7);
        return c
    };
    var iC = a => a.googlefc = a.googlefc || {},
        jC = a => {
            a = a.googlefc = a.googlefc || {};
            return a.__fcusi = a.__fcusi || {}
        },
        kC = a => {
            a = a.googlefc = a.googlefc || {};
            if (!a.getFloatingToolbarTranslatedMessages) return null;
            if (a = a.getFloatingToolbarTranslatedMessages()) {
                var b = new is;
                b = Dh(b, 1, a.defaultFloatingToolbarToggleExpansionText);
                b = Dh(b, 2, a.defaultFloatingToolbarTogglePrivacySettings);
                a = Dh(b, 3, a.defaultFloatingToolbarDismissPrivacySettings).g()
            } else a = null;
            return a
        };

    function lC(a, b) {
        b = b.filter(c => y(c, Gr, 4) ? .i() === 5 && xh(c, 8) === 1);
        b = Kw(b, a);
        a = rx(b, a);
        a.sort((c, d) => d.la.g - c.la.g);
        return a[0] || null
    };

    function mC({
        qg: a,
        uf: b,
        Uf: c,
        rg: d,
        vf: e,
        Vf: f
    }) {
        const g = [];
        for (let n = 0; n < f; n++)
            for (let p = 0; p < c; p++) {
                var h = p,
                    k = c - 1,
                    l = n,
                    m = f - 1;
                g.push({
                    x: a + (k === 0 ? 0 : h / k) * (b - a),
                    y: d + (m === 0 ? 0 : l / m) * (e - d)
                })
            }
        return g
    }

    function nC(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };

    function oC(a, b) {
        var c = mC({
            qg: b.left,
            uf: b.right,
            Uf: 10,
            rg: b.top,
            vf: b.bottom,
            Vf: 10
        });
        b = new Set;
        for (const d of c)(c = pC(a, d)) && b.add(c);
        return b
    }

    function qC(a, b) {
        for (const c of b)
            if (b = pC(a, c)) return b;
        return null
    }

    function rC(a, b, c) {
        if (Kk(b, "position") !== "fixed") return null;
        var d = b.getAttribute("class") === "GoogleActiveViewInnerContainer" || Nk(b).width <= 1 && Nk(b).height <= 1 || a.g.rj && !a.g.rj(b) ? !0 : !1;
        a.g.fh && a.g.fh(b, c, d);
        return d ? null : b
    }

    function pC(a, b) {
        var c = nC(a.K.document, b);
        if (c) {
            var d;
            if (!(d = rC(a, c, b))) a: {
                d = a.K.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    const e = rC(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    }
    var sC = class {
        constructor(a, b = {}) {
            this.K = a;
            this.g = b
        }
    };
    var tC = class {
        constructor(a, b, c) {
            this.position = a;
            this.Kb = b;
            this.zf = c
        }
    };

    function uC(a, b) {
        this.start = a < b ? a : b;
        this.end = a < b ? b : a
    };

    function vC(a, b, c) {
        var d = Ap(a);
        d = new tC(b.jc.Hh(b.vb), b.Kb + 2 * b.vb, Math.min(d, b.Wd) - b.jc.Kd() + 2 * b.vb);
        d = d.position.Tg(a, d.Kb, d.zf);
        var e = zp(a),
            f = Ap(a);
        c = wC(a, new ak(Ib(d.top, 0, f - 1), Ib(d.right, 0, e - 1), Ib(d.bottom, 0, f - 1), Ib(d.left, 0, e - 1)), c);
        f = xC(c);
        let g = d.top;
        e = [];
        for (let h = 0; h < f.length; h++) f[h].start > g && e.push(new uC(g, f[h].start)), g = f[h].end;
        g < d.bottom && e.push(new uC(g, d.bottom));
        a = Ap(a);
        d = [];
        for (f = e.length - 1; f >= 0; f--) d.push(new uC(a - e[f].end, a - e[f].start));
        a: {
            for (const h of d)
                if (a = h.start + b.vb, a >
                    b.jc.Kd() + b.Kf ? a = null : (d = Math.min(h.end - b.vb, b.Wd) - a, a = d < b.Qf ? null : {
                        position: b.jc.li(a),
                        Tc: d
                    }), a) {
                    b = a;
                    break a
                }
            b = null
        }
        return {
            Ue: b,
            Ko: c
        }
    }

    function wC(a, b, c) {
        const d = oC(new sC(a), b);
        c.forEach(e => void d.delete(e));
        return d
    }

    function xC(a) {
        return Array.from(a).map(yC).sort((b, c) => b.start - c.start)
    }

    function yC(a) {
        a = a.getBoundingClientRect();
        return new uC(a.top, a.bottom)
    };

    function zC({
        ga: a,
        Da: b
    }) {
        return new AC(a, b)
    }
    var AC = class {
        constructor(a, b) {
            this.ga = a;
            this.Da = b
        }
        Hh(a) {
            return new AC(this.ga - a, this.Da - a)
        }
        Tg(a, b, c) {
            a = Ap(a) - this.ga - c;
            return new ak(a, this.Da + b, a + c, this.Da)
        }
        Lg(a) {
            a.bottom = `${this.ga}px`;
            a.left = `${this.Da}px`;
            a.right = ""
        }
        ih() {
            return 0
        }
        Kd() {
            return this.ga
        }
        li(a) {
            return new AC(a, this.Da)
        }
    };

    function BC({
        ga: a,
        La: b
    }) {
        return new CC(a, b)
    }
    var CC = class {
        constructor(a, b) {
            this.ga = a;
            this.La = b
        }
        Hh(a) {
            return new CC(this.ga - a, this.La - a)
        }
        Tg(a, b, c) {
            var d = zp(a);
            a = Ap(a) - this.ga - c;
            d = d - this.La - b;
            return new ak(a, d + b, a + c, d)
        }
        Lg(a) {
            a.bottom = `${this.ga}px`;
            a.right = `${this.La}px`;
            a.left = ""
        }
        ih() {
            return 1
        }
        Kd() {
            return this.ga
        }
        li(a) {
            return new CC(a, this.La)
        }
    };

    function DC(a) {
        var b = {};
        const c = a.wj,
            d = a.cj,
            e = a.Ui,
            f = a.Rk,
            g = a.Vi;
        a = a.Ti;
        b = b && b.Qb;
        return Bz('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"' + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + '/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text_old:400,500,700" rel="stylesheet"' + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + "><style" + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + ">.ft-styless-button {border: none; background: none; user-select: none; cursor: pointer; border-radius: " +
            Z(16) + "px;}.ft-container {position: fixed;}.ft-menu {position: absolute; bottom: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); min-height: " + Z(e) + "px;}.ft-menu:not(.ft-multiple-buttons *) {transition: padding 0.25s 0.25s, margin 0.25s 0.25s, border-radius 0.25s 0.25s, background-color 0s 0.5s; padding: 0; margin: " + Z(a) + "px; border-radius: " + Z(16) + "px; background-color: rgba(255, 255, 255, 0);}.ft-multiple-buttons .ft-menu {transition: margin 0.25s, padding 0.25s, border-radius 0.25s 0.25s, background-color 0s; padding: " +
            Z(a) + "px; margin: 0; border-radius: " + Z(16 + a) + "px; background-color: rgba(255, 255, 255, 1);}.ft-left-pos .ft-menu {left: 0;}.ft-right-pos .ft-menu {right: 0;}.ft-container.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}.ft-container:not(.ft-hidden) {transition: opacity 0.25s, bottom 0.5s ease; opacity: 1;}.google-symbols {font-size: 26px; color: #3c4043;}.ft-button-holder {display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 0;}.ft-flip-vertically {transform: scaleY(-1);}.ft-expand-toggle {width: " +
            Z(e) + "px; height: " + Z(e) + "px;}.ft-collapsed .ft-expand-icon {transition: transform 0.25s; transform: rotate(180deg);}.ft-expand-icon:not(.ft-collapsed *) {transition: transform 0.25s; transform: rotate(0deg);}.ft-button {position: relative; height: " + Z(e) + "px; margin-bottom: " + Z(g) + "px; transform: margin 0.25s 0.25s;}.ft-button.ft-last-button {margin-bottom: 0;}.ft-button > button {position: relative; height: " + Z(e) + "px; width: " + Z(e) + "px; margin: 0; padding: 0; border: none;}.ft-button > button > * {position: relative;}.ft-button .ft-highlighter {position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); height: " +
            Z(e - 6) + "px; width: " + Z(e - 6) + "px; border-radius: " + Z(e / 2) + "px; background-color: #d2e3fc; opacity: 0; transition: opacity 0.25s;}.ft-button.ft-highlighted .ft-highlighter {opacity: 1;}.ft-button-corner-info {display: none;}.ft-button.ft-show-corner-info .ft-button-corner-info {position: absolute; left: -5px; top: 4px; background: #b3261e; border: 1.5px solid #ffffff; box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3), 0 1px 3px 1px rgba(60, 64, 67, 0.15); border-radius: 100px; color: ffffff; font-family: 'Google Sans Text'; font-style: normal; font-weight: 700; font-size: 11px; line-height: 14px; min-width: 16px; height: 16px; display: flex; flex-direction: row; justify-content: center; align-items: center;}.ft-separator {display: block; width: 100%; height: " +
            Z(f) + "px;}.ft-separator > span {display: block; width: 28px; margin: 0 auto 10px auto; height: 0; border-bottom: 1px solid #dadce0;}.ft-expand-toggle-container {height: " + Z(e) + "px;}.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}:not(.ft-hidden) {transition: opacity 0.25s; opacity: 1;}.ft-collapsed .ft-collapsible, .ft-collapsible.ft-collapsed, .ft-expand-toggle-container.ft-collapsed {transition: opacity 0.25s, margin 0.25s 0.25s, height 0.25s 0.25s, overflow 0.25s 0s, visibility 1s 0s; height: 0; opacity: 0; overflow: hidden; visibility: hidden; margin: 0;}.ft-collapsible:not(.ft-collapsed *):not(.ft-collapsed), .ft-expand-toggle-container:not(.ft-collapsed) {transition: margin 0.25s, height 0.25s, opacity 0.25s 0.25s; opacity: 1;}.ft-symbol-font-load-test {position: fixed; left: -1000px; top: -1000px; font-size: 26px; visibility: hidden;}.ft-reg-bubble {position: absolute; bottom: 0; padding: 10px 10px 0 10px; background: #fff; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); border-radius: " +
            Z(16) + "px; max-width: calc(90vw - " + Z(e * 2) + "px); width: 300px; height: 200px;}.ft-left-pos .ft-reg-bubble {left: " + Z(e + 10 + a) + "px;}.ft-right-pos .ft-reg-bubble {right: " + Z(e + 10 + a) + "px;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-collapsed {transition: width 0.25s ease-in 0.25s, height 0.25s ease-in 0.25s, opacity 0.05s linear 0.45s, overflow 0s 0.25s, visibility 0s 0.5s; width: 0; overflow: hidden; opacity: 0; visibility: hidden;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-no-messages {height: 0 !important;}.ft-reg-bubble:not(.ft-collapsed *):not(.ft-collapsed) {transition: width 0.25s ease-out, height 0.25s ease-out, opacity 0.05s linear;}.ft-reg-bubble-content {display: flex; flex-direction: row; max-width: calc(90vw - " +
            Z(e * 2) + 'px); width: 300px;}.ft-collapsed .ft-reg-bubble-content {transition: opacity 0.25s; opacity: 0;}.ft-reg-bubble-content:not(.ft-collapsed *) {transition: opacity 0.25s 0.25s; opacity: 1;}.ft-reg-message-holder {flex-grow: 1; display: flex; flex-direction: column; height: auto;}.ft-reg-controls {flex-grow: 0; padding-left: 5px;}.ft-reg-bubble-close-icon {font-size: 16px;}.ft-reg-message {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; padding-bottom: 5px; margin-bottom: 5px; border-bottom: 1px solid #dadce0;}.ft-reg-message:last-of-type {border-bottom: none;}.ft-reg-message-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0; text-align: start;}.ft-display-none {display: none;}</style><toolbar id="ft-floating-toolbar" class="ft-container ft-hidden"><div class="ft-menu"><div class="ft-button-holder"></div><div class="ft-separator ft-collapsible ft-collapsed"><span></span></div><div class="ft-bottom-button-holder"></div><div class="ft-expand-toggle-container"><button class="ft-expand-toggle ft-styless-button" aria-controls="ft-floating-toolbar" aria-label="' +
            Y(c) + '"><span class="google-symbols ft-expand-icon" aria-hidden="true">expand_more</span></button></div></div><div id="ft-reg-bubble" class="ft-reg-bubble ft-collapsed ft-no-messages"><div class="ft-reg-bubble-content"><div class="ft-reg-message-holder"></div><div class="ft-reg-controls"><button class="ft-reg-bubble-close ft-styless-button" aria-controls="ft-reg-bubble" aria-label="' + Y(d) + '"><span class="google-symbols ft-reg-bubble-close-icon" aria-hidden="true">close</span></button></div></div></div></toolbar><span inert class="ft-symbol-font-load-test"><span class="ft-symbol-reference google-symbols" aria-hidden="true">keyboard_double_arrow_right</span><span class="ft-text-reference" aria-hidden="true">keyboard_double_arrow_right</span></span>')
    }

    function EC(a) {
        const b = a.googleIconName,
            c = a.backgroundColorCss,
            d = a.iconColorCss;
        return Bz('<div class="ft-button ft-collapsible ft-collapsed ft-last-button"><button class="ft-styless-button" aria-label="' + Y(a.ariaLabel) + '" style="background-color: ' + Y(Z(c)) + '"><span class="ft-highlighter"></span><span class="google-symbols" style="color: ' + Y(Z(d)) + '" aria-hidden="true">' + zz(b) + '</span></button><span class="ft-button-corner-info"></span></div>')
    };
    const FC = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500,700"];

    function GC(a, b) {
        a = new HC(a, b, IC(a, b));
        a.L();
        return a
    }

    function JC() {
        ({
            wc: a
        } = {
            wc: 2
        });
        var a;
        return a > 1 ? 50 : 120
    }

    function KC(a, b, c) {
        LC(a) === 0 && b.classList.remove("ft-collapsed");
        MC(b, c);
        $p(a.win);
        b.classList.remove("ft-collapsed");
        NC(a);
        return () => void OC(a, b, c)
    }

    function PC(a) {
        QC(a.g.ja.Uc).length === 0 ? (a.l.O ? .Gk(), a.l.g(null), a.g.ja.yf.g(!1), a.g.ja.uh.g(!1), a.g.ja.Gf.g(!1)) : (a.g.ja.yf.g(!0), RC(a))
    }

    function SC(a, {
        zi: b = 0,
        Jo: c = 0
    }) {
        b = Math.max(QC(a.g.Nb).length + b, 0);
        c = Math.max(QC(a.g.ub).length + c, 0);
        const d = b + c;
        let e = d * 50;
        b > 0 && c > 0 && (e += 11);
        e += Math.max(0, d - 1) * 10;
        d >= a.j.wc && (e += 60);
        d > 1 && (e += 10);
        return e
    }

    function LC(a) {
        const b = a.g.ub;
        return QC(a.g.Nb).length + QC(b).length
    }

    function NC(a) {
        const b = a.g.ub,
            c = a.g.separator;
        QC(a.g.Nb).length > 0 && QC(b).length > 0 ? c.classList.remove("ft-collapsed") : c.classList.add("ft-collapsed");
        LC(a) >= a.j.wc ? a.g.th.g(!0) : a.g.th.g(!1);
        LC(a) > 1 ? a.g.lh.g(!0) : a.g.lh.g(!1);
        LC(a) > 0 ? a.g.isVisible.g(!0) : a.g.isVisible.g(!1);
        TC(a);
        UC(a)
    }

    function OC(a, b, c) {
        b.classList.contains("ft-removing") || (b.classList.add("ft-removing"), b.classList.add("ft-collapsed"), NC(a), a.win.setTimeout(() => {
            c.removeChild(b)
        }, 750))
    }

    function TC(a) {
        const b = QC(a.g.Nb).concat(QC(a.g.ub));
        b.forEach(c => {
            c.classList.remove("ft-last-button")
        });
        LC(a) >= a.j.wc || b[b.length - 1] ? .classList.add("ft-last-button")
    }

    function UC(a) {
        const b = QC(a.g.Nb).concat(QC(a.g.ub)).filter(c => !c.classList.contains("ft-reg-button"));
        a.F.g(b.length > 0)
    }

    function VC(a) {
        Np(a.g.ja.Uc.children, b => {
            const c = a.g.ja.Yc;
            OC(a, b, a.g.ja.Uc);
            const d = c.get(b);
            c.delete(b);
            d ? .isDismissed.g(!0)
        });
        PC(a)
    }

    function RC(a) {
        if (!a.l.O) {
            var b = WC(a.win, {
                googleIconName: "verified_user",
                ariaLabel: F(a.j.Va, 2),
                orderingIndex: 0,
                onClick: () => {
                    a.g.ja.uh.g(!a.g.ja.isVisible.O);
                    for (const [, c] of a.g.ja.Yc) c.yh = !0;
                    a.g.ja.Gf.g(!1)
                },
                backgroundColorCss: "#fff"
            });
            b.qd.classList.add("ft-reg-button");
            KC(a, b.qd, a.g.ub);
            pq(b.Wj, a.g.ja.isVisible);
            a.l.g({
                Oo: b,
                Gk: () => void OC(a, b.qd, a.g.ub)
            })
        }
    }

    function XC(a) {
        var b = a.g.ja.Gf,
            c = b.g;
        a: {
            for ([, d] of a.g.ja.Yc)
                if (a = d, a.showUnlessUserInControl && !a.yh) {
                    var d = !0;
                    break a
                }
            d = !1
        }
        c.call(b, d)
    }

    function YC(a) {
        a.g.ja.bj.listen(() => {
            VC(a)
        })
    }
    var HC = class extends S {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.j = b;
            this.g = c;
            this.l = new T(null);
            this.F = new T(!1)
        }
        addButton(a) {
            a = WC(this.win, a);
            return KC(this, a.qd, this.g.Nb)
        }
        addRegulatoryMessage(a) {
            const b = this.g.ja.Uc,
                c = ZC(this.win, a);
            MC(c.Nf, b);
            this.g.ja.Yc.set(c.Nf, c);
            PC(this);
            return {
                showUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !0;
                    XC(this)
                },
                hideUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !1;
                    XC(this)
                },
                isDismissed: rq(c.isDismissed),
                removeCallback: () => {
                    var d = c.Nf;
                    const e = this.g.ja.Uc;
                    d.parentNode === e && e.removeChild(d);
                    this.g.ja.Yc.delete(d);
                    PC(this)
                }
            }
        }
        I() {
            return jq(this.l.map(a => a != null))
        }
        D() {
            return jq(this.F)
        }
        A() {
            return [this.g.container]
        }
        i() {
            const a = this.g.nb.mb;
            a.parentNode ? .removeChild(a);
            super.i()
        }
        L() {
            $q(this.win, FC);
            pq(this.g.dl, this.j.Ab);
            this.win.document.body.appendChild(this.g.nb.mb);
            YC(this)
        }
    };

    function IC(a, b) {
        const c = NA(a),
            d = c.shadowRoot;
        d.appendChild(Ek(new rk(a.document), wz(DC({
            wj: F(b.Va, 1),
            cj: F(b.Va, 3),
            Ui: 50,
            Rk: 11,
            Vi: 10,
            Ti: 5
        }))));
        const e = MA("ft-container", d),
            f = MA("ft-expand-toggle", d),
            g = MA("ft-expand-toggle-container", d),
            h = new T(null);
        h.i(p => {
            e.style.zIndex = String(p ? ? 2147483647)
        });
        const k = new T(!0);
        mq(k, !0, () => {
            e.classList.remove("ft-collapsed");
            f.setAttribute("aria-expanded", "true")
        });
        mq(k, !1, () => {
            e.classList.add("ft-collapsed");
            f.setAttribute("aria-expanded", "false")
        });
        f.addEventListener("click",
            () => {
                k.g(!k.O)
            });
        const l = new T(!1);
        mq(l, !0, () => {
            g.classList.remove("ft-collapsed");
            e.classList.add("ft-toolbar-collapsible")
        });
        mq(l, !1, () => {
            g.classList.add("ft-collapsed");
            e.classList.remove("ft-toolbar-collapsible");
            k.g(!0)
        });
        const m = new T(!1);
        mq(m, !0, () => {
            e.classList.add("ft-multiple-buttons")
        });
        mq(m, !1, () => {
            e.classList.remove("ft-multiple-buttons")
        });
        b.position.i(p => {
            if (p) {
                p.Lg(e.style);
                p = p.ih();
                switch (p) {
                    case 0:
                        e.classList.add("ft-left-pos");
                        e.classList.remove("ft-right-pos");
                        break;
                    case 1:
                        e.classList.add("ft-right-pos");
                        e.classList.remove("ft-left-pos");
                        break;
                    default:
                        throw Error(`Unknown HorizontalAnchoring: ${p}`);
                }
                $p(a)
            }
        });
        const n = new T(!1);
        b = iq($C(a, d), n, b.position.map(p => p !== null));
        mq(b, !0, () => {
            e.classList.remove("ft-hidden")
        });
        mq(b, !1, () => {
            e.classList.add("ft-hidden")
        });
        b = aD(a, MA("ft-reg-bubble", d));
        return {
            container: e,
            Nb: MA("ft-button-holder", d),
            ub: MA("ft-bottom-button-holder", d),
            separator: MA("ft-separator", d),
            nb: c,
            dl: h,
            So: k,
            th: l,
            lh: m,
            isVisible: n,
            ja: b
        }
    }

    function aD(a, b) {
        const c = new T(!1),
            d = new T(!1),
            e = kq(c, d);
        mq(e, !0, () => {
            b.classList.remove("ft-collapsed")
        });
        mq(e, !1, () => {
            b.classList.add("ft-collapsed")
        });
        const f = new T(!1);
        mq(f, !0, () => {
            b.classList.remove("ft-no-messages")
        });
        mq(f, !1, () => {
            b.classList.add("ft-no-messages")
        });
        const g = MA("ft-reg-bubble-close", b),
            h = new vq;
        g.addEventListener("click", () => {
            uq(h)
        });
        const k = MA("ft-reg-message-holder", b);
        Tq(Qq(a, k)).i(() => {
            b.style.height = `${k.offsetHeight}px`
        });
        return {
            Uc: k,
            uh: c,
            Gf: d,
            isVisible: e,
            yf: f,
            Yc: new Map,
            bj: sq(h)
        }
    }

    function WC(a, b) {
        const c = Ek(new rk(a.document), wz(EC({
            googleIconName: b.googleIconName,
            ariaLabel: b.ariaLabel,
            backgroundColorCss: b.backgroundColorCss || "#e2eaf6",
            iconColorCss: b.iconColorCss || "#3c4043"
        })));
        b.buttonExtension ? .styleSheet && c.appendChild(b.buttonExtension.styleSheet);
        if (b.cornerNumber !== void 0) {
            const d = Ib(Math.round(b.cornerNumber), 0, 99);
            MA("ft-button-corner-info", c).appendChild(a.document.createTextNode(String(d)));
            c.classList.add("ft-show-corner-info")
        }
        c.orderingIndex = b.orderingIndex;
        b.onClick &&
            LA("BUTTON", c).addEventListener("click", b.onClick);
        a = new T(!1);
        mq(a, !0, () => {
            c.classList.add("ft-highlighted")
        });
        mq(a, !1, () => {
            c.classList.remove("ft-highlighted")
        });
        return {
            qd: c,
            Wj: a
        }
    }

    function ZC(a, b) {
        a = new rk(a.document);
        var c = Bz('<div class="ft-reg-message"><button class="ft-reg-message-button"></button><div class="ft-reg-message-info"></div></div>');
        a = Ek(a, wz(c));
        c = MA("ft-reg-message-button", a);
        b.regulatoryMessage.actionButton ? (c.appendChild(b.regulatoryMessage.actionButton.buttonText), c.addEventListener("click", b.regulatoryMessage.actionButton.onClick)) : c.classList.add("ft-display-none");
        c = MA("ft-reg-message-info", a);
        b.regulatoryMessage.informationText ? c.appendChild(b.regulatoryMessage.informationText) :
            c.classList.add("ft-display-none");
        a.orderingIndex = b.orderingIndex;
        return {
            Nf: a,
            showUnlessUserInControl: !1,
            yh: !1,
            isDismissed: new T(!1)
        }
    }

    function MC(a, b) {
        a: {
            var c = Array.from(b.children);
            for (let d = 0; d < c.length; ++d)
                if (c[d].orderingIndex >= a.orderingIndex) {
                    c = d;
                    break a
                }
            c = c.length
        }
        b.insertBefore(a, b.childNodes[c] || null)
    }

    function QC(a) {
        return Array.from(a.children).filter(b => !b.classList.contains("ft-removing"))
    }

    function $C(a, b) {
        const c = new T(!1),
            d = MA("ft-symbol-font-load-test", b);
        b = MA("ft-symbol-reference", d);
        const e = MA("ft-text-reference", d),
            f = Qq(a, b);
        nq(Tq(f).map(g => g.width > 0 && g.width < e.offsetWidth / 2), !0, () => {
            c.g(!0);
            d.parentNode ? .removeChild(d);
            f.dispose()
        });
        return c
    };

    function bD(a) {
        const b = new vq,
            c = Gq(a, 2500, () => void uq(b));
        return new cD(a, () => void dD(a, () => void c()), sq(b))
    }

    function eD(a) {
        const b = new MutationObserver(() => {
            a.g()
        });
        b.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class", "style"]
        });
        cq(a, () => void b.disconnect())
    }

    function fD(a) {
        a.win.addEventListener("resize", a.g);
        cq(a, () => void a.win.removeEventListener("resize", a.g))
    }
    var cD = class extends S {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.g = b;
            this.l = c;
            this.j = !1
        }
    };

    function dD(a, b) {
        b();
        a.setTimeout(b, 1500)
    };

    function gD(a) {
        return a.g[a.g.length - 1]
    }
    var iD = class {
        constructor() {
            this.j = hD;
            this.g = [];
            this.i = new Set
        }
        add(a) {
            if (this.i.has(a)) return !1;
            const b = Wa(this.g, a, this.j);
            this.g.splice(b >= 0 ? b : -b - 1, 0, a);
            this.i.add(a);
            return !0
        }
        first() {
            return this.g[0]
        }
        has(a) {
            return this.i.has(a)
        }
        delete(a) {
            Ra(this.g, b => b === a);
            return this.i.delete(a)
        }
        clear() {
            this.i.clear();
            return this.g.splice(0, this.g.length)
        }
        size() {
            return this.g.length
        }
    };

    function jD(a) {
        var b = a.Tc.O;
        let c;
        for (; a.j.ej() > b && (c = a.i.first());) {
            var d = a,
                e = c;
            kD(d, e);
            d.g.add(e)
        }
        for (;
            (d = gD(a.g)) && a.j.Jj() <= b;) lD(a, d);
        for (;
            (d = gD(a.g)) && (c = a.i.first()) && d.priority > c.priority;) b = a, e = c, kD(b, e), b.g.add(e), lD(a, d)
    }

    function lD(a, b) {
        a.g.delete(b);
        a.i.add(b) && (b.xg = a.j.addButton(b.buttonSpec));
        b.isInToolbar.g(!0)
    }

    function kD(a, b) {
        b.xg && b.xg();
        b.xg = void 0;
        a.i.delete(b);
        b.isInToolbar.g(!1)
    }
    var mD = class {
        constructor(a, b) {
            this.Tc = a;
            this.j = b;
            this.g = new iD;
            this.i = new iD;
            this.l = 0;
            this.Tc.listen(() => void jD(this))
        }
        addButton(a) {
            const b = {
                buttonSpec: a.buttonSpec,
                priority: a.priority,
                Bg: this.l++,
                isInToolbar: new T(!1)
            };
            this.g.add(b);
            jD(this);
            return {
                isInToolbar: rq(jq(b.isInToolbar)),
                removeCallback: () => {
                    kD(this, b);
                    this.g.delete(b);
                    jD(this)
                }
            }
        }
    };

    function hD(a, b) {
        return a.priority === b.priority ? b.Bg - a.Bg : a.priority - b.priority
    };

    function nD(a) {
        if (!JA(a.win)) {
            if (a.j.O) {
                const b = Ip(a.win);
                if (b > a.g + 100 || b < a.g - 100) a.j.g(!1), a.g = Cp(a.win)
            }
            a.l && a.win.clearTimeout(a.l);
            a.l = a.win.setTimeout(() => void oD(a), 200)
        }
    }

    function oD(a) {
        if (!JA(a.win)) {
            var b = Cp(a.win);
            a.g && a.g > b && (a.g = b);
            b = Ip(a.win);
            b >= a.g - 100 && (a.g = Math.max(a.g, b), a.j.g(!0))
        }
    }
    var pD = class extends S {
        constructor(a) {
            super();
            this.win = a;
            this.j = new T(!1);
            this.g = 0;
            this.l = null;
            this.A = () => void nD(this)
        }
        L() {
            this.win.addEventListener("scroll", this.A);
            this.g = Cp(this.win);
            oD(this)
        }
        i() {
            this.win.removeEventListener("scroll", this.A);
            this.j.g(!1);
            super.i()
        }
    };

    function qD(a) {
        if (!a.g) {
            var b = new pD(a.win);
            b.L();
            a.g = jq(b.j);
            bq(a, b)
        }
        return a.g
    }

    function rD(a, b, c) {
        const d = a.j.addRegulatoryMessage(b.messageSpec);
        b.messageSpec.regulatoryMessage.disableFloatingToolbarAutoShow || sD(a, d, c);
        nq(c, !0, () => {
            d.removeCallback()
        })
    }

    function sD(a, b, c) {
        a = qD(a);
        const d = mq(a, !0, () => void b.showUnlessUserInControl()),
            e = mq(a, !1, () => void b.hideUnlessUserInControl());
        mq(gq(b.isDismissed), !0, () => {
            d();
            e()
        });
        nq(c, !0, () => {
            d();
            e()
        })
    }
    var tD = class extends S {
        constructor(a, b) {
            super();
            this.win = a;
            this.j = b;
            this.g = null
        }
        addRegulatoryMessage(a) {
            const b = new T(!1),
                c = nq(qD(this), !0, () => {
                    rD(this, a, b)
                });
            return {
                removeCallback: () => {
                    b.g(!0);
                    c()
                }
            }
        }
    };

    function uD(a, b) {
        a.googFloatingToolbarManager || (a.googFloatingToolbarManager = new vD(a, b));
        return a.googFloatingToolbarManager
    }

    function wD(a) {
        a.g || (a.g = xD(a.win, a.j, a.Ab), bq(a, a.g.Sb), bq(a, a.g.Th), yD(a), zD(a, a.g.Sb));
        return a.g
    }

    function AD(a) {
        a.Ab.O === null && a.g ? .position.g(BD(a))
    }

    function CD(a) {
        a.win.requestAnimationFrame(() => void AD(a))
    }

    function BD(a) {
        var b = [];
        a.g ? .Sb ? .D().B() ? (b.push(() => DD(a)), b.push(() => ED(a))) : (b.push(() => ED(a)), b.push(() => DD(a)));
        a.g ? .Sb ? .I() ? .B() && b.push(() => {
            const c = Ap(a.win);
            return {
                position: zC({
                    ga: Math.floor(c / 3),
                    Da: 10
                }),
                Tc: 0
            }
        });
        for (const c of b)
            if (b = c()) return b;
        return null
    }

    function yD(a) {
        a.win.googFloatingToolbarManagerAsyncPositionUpdate ? CD(a) : AD(a)
    }

    function zD(a, b) {
        const c = bD(a.win);
        c.j || (eD(c), fD(c), c.j = !0);
        c.l.listen(() => void yD(a));
        bq(a, c);
        b.I().listen(() => void yD(a));
        b.D().listen(() => void yD(a));
        a.Ab.listen(() => void yD(a))
    }

    function DD(a) {
        var b = a.win;
        const c = Ap(a.win);
        return vC(b, {
            jc: BC({
                ga: 50,
                La: 10
            }),
            Kf: Math.floor(c / 3),
            Kb: 60,
            Qf: JC(),
            Wd: Math.floor(c / 2),
            vb: 20
        }, [...(a.g ? .Sb.A() ? ? []), a.win.document.body]).Ue
    }

    function ED(a) {
        var b = a.win;
        const c = Ap(a.win);
        return vC(b, {
            jc: zC({
                ga: 50,
                Da: 10
            }),
            Kf: Math.floor(c / 3),
            Kb: 60,
            Qf: JC(),
            Wd: Math.floor(c / 2),
            vb: 40
        }, [...(a.g ? .Sb.A() ? ? []), a.win.document.body]).Ue
    }
    class vD extends S {
        constructor(a, b) {
            super();
            this.win = a;
            this.j = b;
            this.g = null;
            this.Ab = FD(this.win, this)
        }
        addButton(a) {
            return wD(this).nk.addButton(a)
        }
        addRegulatoryMessage(a) {
            return wD(this).Th.addRegulatoryMessage(a)
        }
    }

    function xD(a, b, c) {
        const d = new T(null),
            e = GC(a, {
                wc: 2,
                position: d.map(f => f ? .position ? ? null),
                Va: b,
                Ab: c
            });
        b = new mD(d.map(f => f ? .Tc || 0), {
            addButton: f => e.addButton(f),
            ej: () => SC(e, {}),
            Jj: () => SC(e, {
                zi: 1
            })
        });
        a = new tD(a, {
            addRegulatoryMessage: f => e.addRegulatoryMessage(f)
        });
        return {
            Sb: e,
            position: d,
            nk: b,
            Th: a
        }
    }

    function FD(a, b) {
        const c = new uA(a),
            d = new T(null),
            e = f => void d.g(f);
        cq(b, () => {
            tA(c, e)
        });
        c.floatingAdsStacking.maxZIndexListeners.push(e);
        d.g(sA(c));
        return d
    };
    const GD = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500"];

    function HD(a, b, c, d, e) {
        a = new ID(a, b, c, d, e);
        if (a.l) {
            $q(a.win, GD);
            var f = a.win;
            b = a.message;
            c = NA(f);
            e = c.shadowRoot;
            d = e.appendChild;
            f = new rk(f.document);
            var g = (g = {}, g.Qb);
            g = Bz('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"' + (g ? ' nonce="' + Y(cA(g)) + '"' : "") + '/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text_old:400,500" rel="stylesheet"' + (g ? ' nonce="' + Y(cA(g)) + '"' : "") + "><style" + (g ? ' nonce="' + Y(cA(g)) +
                '"' : "") + '>.ipr-container {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; color: #000; border-top: 2px solid rgb(236, 237, 237); border-bottom: 2px solid rgb(236, 237, 237); background-color: #fff; padding: 5px; margin: 5px 0; text-align: center;}.ipr-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ipr-display-none {display: none;}</style><div class="ipr-container"><button class="ipr-button"></button><div class="ipr-info"></div></div>');
            d.call(e, Ek(f, wz(g)));
            d = MA("ipr-container", e);
            e = MA("ipr-button", d);
            b.actionButton ? (e.appendChild(b.actionButton.buttonText), e.addEventListener("click", b.actionButton.onClick)) : e.classList.add("ipr-display-none");
            d = MA("ipr-info", d);
            b.informationText ? d.appendChild(b.informationText) : d.classList.add("ipr-display-none");
            a.g = c.mb;
            px(a.l, a.g);
            a.j && a.j(cn(1));
            JD(a)
        } else KD(a);
        return a
    }

    function JD(a) {
        const b = new cr(a.win);
        b.L(2E3);
        bq(a, b);
        ar(b, () => {
            LD(a);
            KD(a);
            b.dispose()
        })
    }

    function KD(a) {
        const b = uD(a.win, a.A).addRegulatoryMessage({
            messageSpec: {
                regulatoryMessage: a.message,
                orderingIndex: 0
            }
        });
        cq(a, () => void b.removeCallback());
        a.j && a.j(cn(2))
    }

    function LD(a) {
        a.g && (a.g.parentNode ? .removeChild(a.g), a.g = null)
    }
    var ID = class extends S {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.l = b;
            this.message = c;
            this.A = d;
            this.j = e;
            this.g = null
        }
        i() {
            LD(this);
            super.i()
        }
    };
    var ND = (a, b, c, d) => MD(a, b, c, d);

    function MD(a, b, c, d) {
        const e = HD(a, lC(a, d), {
            actionButton: {
                buttonText: a.document.createTextNode(b),
                onClick: c
            }
        }, OD(a));
        return () => e.dispose()
    }

    function OD(a) {
        if (a = kC(a)) return a;
        ny(1234, Error("No messages"));
        return (new is).g()
    };

    function PD(a, b) {
        b && (a.g = ND(a.i, b.localizedDnsText, () => QD(a, b), a.l))
    }

    function RD(a) {
        const b = iC(a.i);
        b.callbackQueue = b.callbackQueue || [];
        jC(a.i).overrideDnsLink = !0;
        b.callbackQueue.push({
            INITIAL_US_STATES_DATA_READY: c => PD(a, c)
        })
    }

    function QD(a, b) {
        vA(a.j);
        b.openConfirmationDialog(c => {
            c && a.g && (a.g(), a.g = null);
            wA(a.j)
        })
    }
    var SD = class {
        constructor(a, b, c) {
            this.i = a;
            this.j = pA(b, 2147483643);
            this.l = c;
            this.g = null
        }
    };

    function TD(a) {
        UD(a.j, b => {
            var c = a.i,
                d = b.Ok,
                e = b.Ki,
                f = b.showRevocationMessage;
            b = lC(c, a.l);
            d = {
                actionButton: {
                    buttonText: c.document.createTextNode(d),
                    onClick: f
                },
                informationText: c.document.createTextNode(e)
            };
            e = kC(c);
            e || (ny(1233, Error("No messages")), e = (new is).g());
            HD(c, b, d, e)
        }, () => {
            wA(a.g);
            VD(a)
        })
    }

    function WD(a) {
        vA(a.g);
        TD(a)
    }

    function VD(a) {
        a.i.__tcfapi ? a.i.__tcfapi("addEventListener", 2, (b, c) => {
            c && b.eventStatus == "cmpuishown" ? vA(a.g) : wA(a.g)
        }) : ny(1250, Error("No TCF API function"))
    }
    var XD = class {
        constructor(a, b, c, d) {
            this.i = a;
            this.g = pA(b, 2147483643);
            this.l = c;
            this.j = d
        }
    };
    var YD = a => {
            if (!a || nh(a, 1) == null) return !1;
            a = I(a, 1);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoConsentUiStatus: " + a);
            }
        },
        ZD = a => {
            if (!a || nh(a, 3) == null) return !1;
            a = I(a, 3);
            switch (a) {
                case 1:
                    return !0;
                case 2:
                    return !1;
                default:
                    throw Error("Unhandled AutoCcpaUiStatus: " + a);
            }
        },
        $D = a => a ? E(a, 5) === !0 : !1;

    function aE(a) {
        let b = a.location.href;
        if (a === a.top) return {
            url: b,
            If: !0
        };
        let c = !1;
        const d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        (a = a.location.ancestorOrigins) && (a = a[a.length - 1]) && b.indexOf(a) === -1 && (c = !1, b = a);
        return {
            url: b,
            If: c
        }
    };

    function bE(a, b) {
        ed(a, (c, d) => {
            b[d] = c
        })
    }

    function cE(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && Xc(b); b = b.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function dE() {
        if (eE) return eE;
        const a = ok() || window,
            b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? eE = b : a.google_persistent_state_async = eE = new fE
    }

    function gE(a, b, c) {
        b = hE[b] || `google_ps_${b}`;
        a = a.S;
        const d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function iE(a, b, c) {
        return gE(a, b, () => c)
    }

    function jE(a, b, c) {
        return a.S[hE[b] || `google_ps_${b}`] = c
    }

    function kE(a, b) {
        return jE(a, b, iE(a, b, 0) + 1)
    }

    function lE() {
        var a = dE();
        return iE(a, 20, {})
    }

    function mE() {
        var a = dE();
        const b = iE(a, 31, !1);
        b || jE(a, 31, !0);
        return !b
    }

    function nE() {
        var a = dE();
        const b = iE(a, 41, !1);
        b || jE(a, 41, !0);
        return !b
    }

    function oE() {
        var a = dE();
        return iE(a, 26)
    }

    function pE() {
        var a = dE();
        return iE(a, 28, [])
    }

    function qE() {
        var a = dE();
        return gE(a, 39, rE)
    }
    var fE = class {
            constructor() {
                this.S = {}
            }
        },
        eE = null;
    const hE = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function sE(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function tE(a, b) {
        a = sE(a);
        a.processed_sra_frame_pingbacks = a.processed_sra_frame_pingbacks || {};
        const c = !a.processed_sra_frame_pingbacks[b];
        a.processed_sra_frame_pingbacks[b] = !0;
        return c
    };

    function dp(a, b) {
        a.g.size > 0 || uE(a);
        const c = a.g.get(0);
        c ? c.push(b) : a.g.set(0, [b])
    }

    function vE(a, b, c, d) {
        lb(b, c, d);
        cq(a, () => mb(b, c, d))
    }

    function wE(a, b) {
        a.j !== 1 && (a.j = 1, a.g.size > 0 && xE(a, b))
    }

    function uE(a) {
        a.win.document.visibilityState ? vE(a, a.win.document, "visibilitychange", b => {
            a.win.document.visibilityState === "hidden" && wE(a, b);
            a.win.document.visibilityState === "visible" && (a.j = 0)
        }) : "onpagehide" in a.win ? (vE(a, a.win, "pagehide", b => {
            wE(a, b)
        }), vE(a, a.win, "pageshow", () => {
            a.j = 0
        })) : vE(a, a.win, "beforeunload", b => {
            wE(a, b)
        })
    }

    function xE(a, b) {
        for (let c = 9; c >= 0; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var yE = class extends S {
        constructor(a) {
            super();
            this.win = a;
            this.j = 0;
            this.g = new Map
        }
    };
    async function zE(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} ${200}`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function AE(a) {
        const b = a.g.pc;
        return b !== null && b !== 0 ? b : a.g.pc = Fd(a.win)
    }

    function BE(a) {
        var b = a.g.wpc;
        if (b === null || b === "") b = a.g, a = a.win, a = a.google_ad_client ? String(a.google_ad_client) : sE(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? "", b = b.wpc = a;
        return b
    }

    function CE(a, b) {
        var c = new go;
        var d = AE(a);
        c = Ch(c, 1, d);
        d = BE(a);
        c = Eh(c, 2, d);
        c = fo(c, a.g.sd);
        return Ch(c, 7, Math.round(b || a.win.performance.now()))
    }

    function DE(a, b, c) {
        b(a.H.ce.ze.ld).Ea(c)
    }

    function EE(a, b, c) {
        b(a.H.ce.ze.ld).Xc(c)
    }
    async function FE(a) {
        await zE(a.win, () => !(!AE(a) || !BE(a)))
    }

    function GE() {
        var a = R(HE);
        a.i && (a.g.tar += 1)
    }

    function IE(a) {
        var b = R(HE);
        if (b.i) {
            var c = b.l;
            a(c);
            b.g.cc = vg(c)
        }
    }
    async function JE(a, b, c) {
        if (a.i && c.length && !a.g.lgdp.includes(Number(b))) {
            a.g.lgdp.push(Number(b));
            var d = a.win.performance.now();
            await FE(a);
            var e = a.H,
                f = e.lb;
            a = CE(a, d);
            d = new Rm;
            b = M(d, 1, b);
            c = Yg(b, 2, c, zf);
            c = C(a, 9, ho, c);
            f.call(e, c)
        }
    }
    async function KE(a, b) {
        await FE(a);
        var c = CE(a);
        b = C(c, 5, ho, b);
        a.i && !a.g.le.includes(2) && (a.g.le.push(2), a.H.lb(b))
    }
    async function LE(a, b, c) {
        await FE(a);
        var d = a.H,
            e = d.lb;
        a = fo(CE(a, c), 1);
        b = C(a, 6, ho, b);
        e.call(d, b)
    }
    async function ME(a, b, c) {
        await FE(a);
        DE(a, d => b(d.ai), c)
    }
    async function NE(a, b, c) {
        await FE(a);
        EE(a, d => b(d.ai), c)
    }
    async function OE(a, b) {
        await FE(a);
        var c = a.H,
            d = c.lb;
        a = fo(CE(a), 1);
        b = C(a, 13, ho, b);
        d.call(c, b)
    }
    async function PE(a, b) {
        if (a.i) {
            await FE(a);
            var c = a.H,
                d = c.lb;
            a = CE(a);
            b = C(a, 11, ho, b);
            d.call(c, b)
        }
    }
    async function QE(a, b) {
        await FE(a);
        var c = a.H,
            d = c.lb;
        a = fo(CE(a), 1);
        b = C(a, 14, ho, b);
        d.call(c, b)
    }
    async function RE(a, b) {
        await FE(a);
        var c = a.H,
            d = c.lb;
        a = fo(CE(a), 1);
        b = C(a, 16, ho, b);
        d.call(c, b)
    }
    var HE = class {
        constructor(a, b) {
            this.win = ok() || window;
            this.j = b ? ? new yE(this.win);
            this.H = a ? ? new fp(to(), 100, 100, !0, this.j);
            this.g = gE(dE(), 33, () => {
                const c = X(lt);
                return {
                    sd: c,
                    ssp: c > 0 && dd() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get i() {
            return this.g.ssp
        }
        get eb() {
            return this.g.cu
        }
        set eb(a) {
            this.g.cu = a
        }
        get l() {
            return jy(1227, () => Ih(Sm, tg(this.g.cc || []))) || new Sm
        }
    };
    var SE = class {
        constructor(a, b, c, d, e) {
            this.i = a;
            this.j = b;
            this.g = c;
            this.B = d;
            this.l = e || null
        }
        run() {
            if (this.i.adsbygoogle_ama_fc_has_run !== !0) {
                var a = YD(this.g),
                    b = ZD(this.g),
                    c = !1;
                a && (WD(new XD(this.i, this.B, this.l || hh(this.g, qs, 4, Pg()), this.j)), c = !0);
                b && (RD(new SD(this.i, this.B, this.l || hh(this.g, qs, 4, Pg()))), c = !0);
                IE(d => {
                    d = J(d, 9, !0);
                    d = J(d, 10, a);
                    J(d, 11, b)
                });
                $D(this.g) && (c = !0);
                c && (this.j.start(!0), this.i.adsbygoogle_ama_fc_has_run = !0)
            }
        }
    };

    function TE(a, b, c, d, e, f) {
        try {
            const g = a.g,
                h = bd("SCRIPT", g);
            h.async = !0;
            rc(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", () => {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", () => {
                c > 0 ? TE(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (g) {
            f()
        }
    }

    function UE(a, b, c = () => {}, d = () => {}) {
        TE(qk(a), b, 0, !1, c, d)
    };

    function VE(a = null) {
        a = a || q;
        return a.googlefc || (a.googlefc = {})
    };
    Pb(qp).map(a => Number(a));
    Pb(rp).map(a => Number(a));
    const WE = q.URL;

    function XE(a) {
        const b = c => encodeURIComponent(c).replace(/[!()~']|(%20)/g, d => ({
            "!": "%21",
            "(": "%28",
            ")": "%29",
            "%20": "+",
            "'": "%27",
            "~": "%7E"
        })[d]);
        return Array.from(a, c => b(c[0]) + "=" + b(c[1])).join("&")
    };

    function YE(a) {
        var b = (new WE(a.location.href)).searchParams;
        a = b.get("fcconsent");
        b = b.get("fc");
        return b === "alwaysshow" ? b : a === "alwaysshow" ? a : null
    }

    function ZE(a) {
        const b = ["ab", "gdpr", "consent", "ccpa", "monetization"];
        return (a = (new WE(a.location.href)).searchParams.get("fctype")) && b.indexOf(a) !== -1 ? a : null
    }

    function $E(a) {
        var b = new WE(a),
            c = {
                search: "",
                hash: ""
            };
        a = {};
        b && (a.protocol = b.protocol, a.username = b.username, a.password = b.password, a.hostname = b.hostname, a.port = b.port, a.pathname = b.pathname, a.search = b.search, a.hash = b.hash);
        Object.assign(a, c);
        if (a.port && a.port[0] === ":") throw Error("port should not start with ':'");
        a.hash && a.hash[0] != "#" && (a.hash = "#" + a.hash);
        c.search ? c.search[0] != "?" && (a.search = "?" + c.search) : c.searchParams && (a.search = "?" + XE(c.searchParams), a.searchParams = void 0);
        b = "";
        a.protocol && (b += a.protocol +
            "//");
        c = a.username;
        var d = a.password;
        b = b + (c && d ? c + ":" + d + "@" : c ? c + "@" : d ? ":" + d + "@" : "") + (a.hostname || "");
        a.port && (b += ":" + a.port);
        b += a.pathname || "";
        b += a.search || "";
        b += a.hash || "";
        a = (new WE(b)).toString();
        a.charAt(a.length - 1) === "/" && (a = a.substring(0, a.length - 1));
        return a.toString().length <= 1E3 ? a : null
    };

    function aF(a, b) {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = bd("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var bF = sj(class extends N {});

    function cF(a) {
        if (a.g) return a.g;
        a.M && a.M(a.j) ? a.g = a.j : a.g = sd(a.j, a.U);
        return a.g ? ? null
    }

    function dF(a) {
        a.l || (a.l = b => {
            try {
                var c = a.I ? a.I(b) : void 0;
                if (c) {
                    var d = c.ag,
                        e = a.F.get(d);
                    e && (e.Ak || a.F.delete(d), e.ec ? .(e.ij, c.payload))
                }
            } catch (f) {}
        }, lb(a.j, "message", a.l))
    }

    function eF(a, b, c) {
        if (cF(a))
            if (a.g === a.j)(b = a.D.get(b)) && b(a.g, c);
            else {
                var d = a.A.get(b);
                if (d && d.Rc) {
                    dF(a);
                    var e = ++a.Z;
                    a.F.set(e, {
                        ec: d.ec,
                        ij: d.Sd(c),
                        Ak: b === "addEventListener"
                    });
                    a.g.postMessage(d.Rc(c, e), "*")
                }
            }
    }
    var fF = class extends S {
        constructor(a, b, c, d) {
            super();
            this.U = b;
            this.M = c;
            this.I = d;
            this.D = new Map;
            this.Z = 0;
            this.A = new Map;
            this.F = new Map;
            this.l = void 0;
            this.j = a
        }
        i() {
            delete this.g;
            this.D.clear();
            this.A.clear();
            this.F.clear();
            this.l && (mb(this.j, "message", this.l), delete this.l);
            delete this.j;
            delete this.I;
            super.i()
        }
    };
    const gF = (a, b) => {
            const c = {
                cb: d => {
                    d = bF(d);
                    b.Ta({
                        yc: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        hF = {
            Sd: a => a.Ta,
            Rc: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            ec: (a, b) => {
                a({
                    yc: b
                })
            }
        };

    function iF(a) {
        a = bF(a.data.__fciReturn);
        return {
            payload: a,
            ag: ph(a, 1)
        }
    }

    function jF(a, b = !1) {
        if (b) return !1;
        a.j || (a.g = !!cF(a.caller), a.j = !0);
        return a.g
    }

    function kF(a) {
        return new Promise(b => {
            jF(a) && eF(a.caller, "getDataWithCallback", {
                command: "loaded",
                Ta: c => {
                    b(c.yc)
                }
            })
        })
    }

    function lF(a, b) {
        jF(a) && eF(a.caller, "getDataWithCallback", {
            command: "prov",
            spsp: Hh(b),
            Ta: () => {}
        })
    }
    var mF = class extends S {
        constructor(a) {
            super();
            this.g = this.j = !1;
            this.caller = new fF(a, "googlefcPresent", void 0, iF);
            this.caller.D.set("getDataWithCallback", gF);
            this.caller.A.set("getDataWithCallback", hF)
        }
        i() {
            this.caller.dispose();
            super.i()
        }
    };

    function nF(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }

    function oF(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = nF(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (Oj({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function pF(a, b = {}) {
        return oF(a) ? a.gdprApplies === !1 ? !0 : a.tcString === "tcunavailable" ? !b.idpcApplies : (b.idpcApplies || a.gdprApplies !== void 0 || b.Ro) && (b.idpcApplies || typeof a.tcString === "string" && a.tcString.length) ? qF(a, "1", 0) : !0 : !1
    }

    function qF(a, b, c) {
        a: {
            if (a.publisher && a.publisher.restrictions) {
                var d = a.publisher.restrictions[b];
                if (d !== void 0) {
                    d = d["755"];
                    break a
                }
            }
            d = void 0
        }
        if (d === 0) return !1;
        let e = c;c === 2 ? (e = 0, d === 2 && (e = 1)) : c === 3 && (e = 1, d === 1 && (e = 0));
        if (e === 0) a = a.purpose && a.vendor ? (c = rF(a.vendor.consents, "755")) && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH" ? !0 : c && rF(a.purpose.consents, b) : !0;
        else {
            var f;
            e === 1 ? f = a.purpose && a.vendor ? rF(a.purpose.legitimateInterests, b) && rF(a.vendor.legitimateInterests, "755") : !0 : f = !0;
            a = f
        }
        return a
    }

    function rF(a, b) {
        return !(!a || !a[b])
    }

    function sF(a, b, c) {
        return a.gdprApplies === !1 ? !0 : b.every(d => qF(a, d, c))
    }

    function tF(a) {
        if (a.g) return a.g;
        a.g = sd(a.j, "__tcfapiLocator");
        return a.g
    }

    function uF(a) {
        return typeof a.j.__tcfapi === "function" || tF(a) != null
    }

    function vF(a, b, c, d) {
        c || (c = () => {});
        var e = a.j;
        typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : tF(a) ? (wF(a), e = ++a.I, a.D[e] = c, a.g && a.g.postMessage({
            __tcfapiCall: {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }
        }, "*")) : c({}, !1)
    }

    function xF(a, b) {
        let c = {
            internalErrorState: 0,
            internalBlockOnErrors: a.A
        };
        const d = fb(() => b(c));
        let e = 0;
        a.F !== -1 && (e = setTimeout(() => {
            e = 0;
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, a.F));
        vF(a, "addEventListener", f => {
            f && (c = f, c.internalErrorState = nF(c), c.internalBlockOnErrors = a.A, oF(c) ? (c.internalErrorState !== 0 && (c.tcString = "tcunavailable"), vF(a, "removeEventListener", null, c.listenerId), (f = e) && clearTimeout(f), d()) : (c.cmpStatus === "error" || c.internalErrorState !== 0) && (f = e) && clearTimeout(f))
        })
    }

    function wF(a) {
        if (!a.l) {
            var b = c => {
                try {
                    var d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                    a.D[d.callId](d.returnValue, d.success)
                } catch (e) {}
            };
            a.l = b;
            lb(a.j, "message", b)
        }
    }
    var yF = class extends S {
        constructor(a, b = {}) {
            super();
            this.g = null;
            this.D = {};
            this.I = 0;
            this.l = null;
            this.j = a;
            this.F = b.timeoutMs ? ? 500;
            this.A = b.Qi ? ? !1
        }
        i() {
            this.D = {};
            this.l && (mb(this.j, "message", this.l), delete this.l);
            delete this.D;
            delete this.j;
            delete this.g;
            super.i()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.A
            };
            const c = fb(() => a(b));
            let d = 0;
            this.F !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.F));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState =
                    nF(b), b.internalBlockOnErrors = this.A, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                vF(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && vF(this, "removeEventListener", null, a.listenerId)
        }
    };

    function UD(a, b, c) {
        const d = VE(a.win);
        d.callbackQueue = d.callbackQueue || [];
        d.callbackQueue.push({
            CONSENT_DATA_READY: () => {
                const e = VE(a.win),
                    f = new yF(a.win);
                uF(f) && xF(f, g => {
                    g.cmpId === 300 && g.tcString && g.tcString !== "tcunavailable" && g.gdprApplies && b({
                        Ok: (0, e.getDefaultConsentRevocationText)(),
                        Po: (0, e.getDefaultConsentRevocationCloseText)(),
                        Ki: (0, e.getDefaultConsentRevocationAttestationText)(),
                        showRevocationMessage: () => {
                            (0, e.showRevocationMessage)()
                        }
                    })
                });
                c()
            }
        })
    }

    function zF(a, b = !1, c) {
        const d = {};
        try {
            const f = YE(a.win),
                g = ZE(a.win);
            d.fc = f;
            d.fctype = g
        } catch (f) {}
        let e;
        try {
            e = $E(a.win.location.href)
        } catch (f) {}
        b && e && (d.href = e);
        b = AF(a.g, d);
        UE(a.win, b, () => {}, () => {});
        c && lF(new mF(a.win), c)
    }
    var BF = class {
        constructor(a, b) {
            this.win = a;
            this.g = b
        }
        start(a = !1, b) {
            if (this.win === this.win.top) try {
                aF(this.win, "googlefcPresent"), zF(this, a, b)
            } catch (c) {}
        }
    };

    function AF(a, b) {
        a = Uc `https://fundingchoicesmessages.google.com/i/${a}`;
        return Vc(a, { ...b,
            ers: 2
        })
    };
    const CF = new Set(["ARTICLE", "SECTION"]);
    var DF = class {
        constructor(a) {
            this.g = a
        }
    };

    function EF(a, b) {
        return Array.from(b.classList).map(c => `${a}=${c}`)
    }

    function FF(a) {
        return a.classList.length > 0
    }

    function GF(a) {
        return CF.has(a.tagName)
    };
    var HF = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function IF(a) {
        return ra(a) && a.nodeType == 1 && a.tagName == "FIGURE" ? a : (a = a.parentNode) ? IF(a) : null
    };
    var JF = a => {
        var b = a.src;
        const c = a.getAttribute("data-src") || a.getAttribute("data-lazy-src");
        (b && b.startsWith("data:") && c ? c : b || c) ? (a.getAttribute("srcset"), b = (b = IF(a)) ? (b = b.getElementsByTagName("figcaption")[0]) ? b.textContent : null : null, a = new HF(a, b || a.getAttribute("alt") || null)) : a = null;
        return a
    };
    var KF = class {
        constructor() {
            this.map = new Map
        }
        clear() {
            this.map.clear()
        }
        delete(a, b) {
            const c = this.map.get(a);
            return c ? (b = c.delete(b), c.size === 0 && this.map.delete(a), b) : !1
        }
        get(a) {
            return [...(this.map.get(a) ? ? [])]
        }
        keys() {
            return this.map.keys()
        }
        add(a, b) {
            let c = this.map.get(a);
            c || this.map.set(a, c = new Set);
            c.add(b)
        }
        get size() {
            let a = 0;
            for (const b of this.map.values()) a += b.size;
            return a
        }
        values() {
            const a = this.map;
            return function() {
                return function*() {
                    for (const b of a.values()) yield* b
                }()
            }()
        }[Symbol.iterator]() {
            const a =
                this.map;
            return function() {
                return function*() {
                    for (const [b, c] of a) {
                        const d = b,
                            e = c;
                        for (const f of e) yield [d, f]
                    }
                }()
            }()
        }
    };

    function LF(a) {
        return [a[0],
            [...a[1]]
        ]
    };

    function MF(a) {
        return Array.from(NF(a).map.values()).filter(b => b.size >= 3).map(b => [...b])
    }

    function OF(a, b) {
        return b.every(c => {
            var d = a.g.getBoundingClientRect(c.g);
            if (d = d.height >= 50 && d.width >= a.B) {
                var e = a.g.getBoundingClientRect(c.g);
                d = a.l;
                e = new uC(e.left, e.right);
                d = Math.max(d.start, e.start) <= Math.min(d.end, e.end)
            }
            return d && Xp(a.j, {
                ob: c.g,
                hb: PF,
                Lb: !0
            }) === null
        })
    }

    function QF(a) {
        return MF(a).sort(RF).find(b => OF(a, b)) || []
    }

    function NF(a) {
        return SF(Array.from(a.win.document.getElementsByTagName("IMG")).map(JF).filter(wr), b => {
            var c = [...EF("CLASS_NAME", b.g)],
                d = b.g.parentElement;
            d = [...(d ? EF("PARENT_CLASS_NAME", d) : [])];
            var e = b.g.parentElement ? .parentElement;
            e = [...(e ? EF("GRANDPARENT_CLASS_NAME", e) : [])];
            var f = (f = Xp(a.i.g, {
                ob: b.g,
                hb: FF
            })) ? EF("NEAREST_ANCESTOR_CLASS_NAME", f) : [];
            return [...c, ...d, ...e, ...f, ...(b.i ? ["HAS_CAPTION=true"] : []), ...(Xp(a.i.g, {
                ob: b.g,
                hb: GF
            }) ? ["ARTICLE_LIKE_ANCESTOR=true"] : [])]
        })
    }
    var TF = class {
        constructor(a, b, c, d, e) {
            var f = new Nq;
            this.win = a;
            this.l = b;
            this.B = c;
            this.g = f;
            this.j = d;
            this.i = e
        }
    };

    function SF(a, b) {
        const c = new KF;
        for (const d of a)
            for (const e of b(d)) c.add(e, d);
        return c
    }

    function PF(a) {
        return a.tagName === "A" && a.hasAttribute("href")
    }

    function RF(a, b) {
        return b.length - a.length
    };

    function UF(a) {
        const b = a.l.parentNode;
        if (!b) throw Error("Image not in the DOM");
        const c = VF(a.j),
            d = WF(a.j);
        c.appendChild(d);
        b.insertBefore(c, a.l.nextSibling);
        a.A.j().i(e => {
            var f = a.j;
            const g = d.getBoundingClientRect(),
                h = g.top - e.top,
                k = g.left - e.left,
                l = g.width - e.width;
            e = g.height - e.height;
            Math.abs(h) < 1 && Math.abs(k) < 1 && Math.abs(l) < 1 && Math.abs(e) < 1 || (f = f.getComputedStyle(d), u(d, {
                top: parseInt(f.top, 10) - h + "px",
                left: parseInt(f.left, 10) - k + "px",
                width: parseInt(f.width, 10) - l + "px",
                height: parseInt(f.height, 10) - e + "px"
            }))
        });
        return d
    }

    function XF(a) {
        a.g || (a.g = UF(a));
        return a.g
    }
    var YF = class extends S {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.l = b;
            this.A = c;
            this.g = null
        }
        i() {
            if (this.g) {
                var a = this.g;
                const b = a.parentNode;
                b && b.removeChild(a);
                this.g = null
            }
            super.i()
        }
    };

    function WF(a) {
        const b = a.document.createElement("div");
        u(b, Us(a));
        u(b, {
            position: "absolute",
            left: "0",
            top: "0",
            width: "0",
            height: "0",
            "pointer-events": "none"
        });
        return b
    }

    function VF(a) {
        const b = a.document.createElement("div");
        u(b, Us(a));
        u(b, {
            position: "relative",
            width: "0",
            height: "0"
        });
        return b
    };

    function ZF(a) {
        const b = new T(a.dataset.adStatus || null);
        (new MutationObserver(() => {
            b.g(a.dataset.adStatus || null)
        })).observe(a, {
            attributes: !0
        });
        return jq(b)
    };
    const $F = ["Google Material Icons", "Roboto"];

    function aG({
        win: a,
        wa: b,
        Kj: c,
        webPropertyCode: d,
        Va: e,
        V: f
    }) {
        const g = new Pq(a, c);
        c = new YF(a, c, g);
        bq(c, g);
        a = new bG(a, d, e, b, c, f);
        bq(a, c);
        a.L()
    }
    var bG = class extends S {
        constructor(a, b, c, d, e, f) {
            super();
            this.win = a;
            this.webPropertyCode = b;
            this.Va = c;
            this.wa = d;
            this.j = e;
            this.V = f;
            this.g = new T(!1)
        }
        L() {
            const a = cG(this.win, this.webPropertyCode, this.Va);
            XF(this.j).appendChild(a.sj);
            dw(this.win, a.ta);
            ZF(a.ta).i(b => {
                if (b !== null) {
                    switch (b) {
                        case "unfilled":
                            this.dispose();
                            break;
                        case "filled":
                            this.g.g(!0);
                            break;
                        default:
                            this.V ? .reportError("Unhandled AdStatus: " + String(b)), this.dispose()
                    }
                    this.V ? .Jk(this.wa, b)
                }
            });
            nq(this.g, !0, () => void a.Tj.g(!0));
            a.oj.listen(() =>
                void this.dispose());
            a.nj.listen(() => void this.V ? .Hk(this.wa))
        }
    };

    function cG(a, b, c) {
        const d = new T(!1),
            e = a.document.createElement("div");
        u(e, Us(a));
        u(e, {
            position: "absolute",
            top: "50%",
            left: "0",
            transform: "translateY(-50%)",
            width: "100%",
            height: "100%",
            overflow: "hidden",
            "background-color": "rgba(0, 0, 0, 0.75)",
            opacity: "0",
            transition: "opacity 0.25s ease-in-out",
            "box-sizing": "border-box",
            padding: "40px 5px 5px 5px"
        });
        mq(d, !0, () => void u(e, {
            opacity: "1"
        }));
        mq(d, !1, () => void u(e, {
            opacity: "0"
        }));
        const f = a.document.createElement("div");
        u(f, Us(a));
        u(f, {
            display: "block",
            width: "100%",
            height: "100%"
        });
        e.appendChild(f);
        const {
            sa: g,
            Rj: h
        } = dG(a, b);
        f.appendChild(g);
        e.appendChild(eG(a, F(c, 1)));
        b = fG(a, F(c, 2));
        e.appendChild(b.Wi);
        b.bf.listen(() => void d.g(!1));
        return {
            Tj: d,
            sj: e,
            ta: h,
            nj: b.bf,
            oj: b.bf.delay(a, 450)
        }
    }

    function eG(a, b) {
        const c = a.document.createElement("div");
        u(c, Us(a));
        u(c, {
            position: "absolute",
            top: "10px",
            width: "100%",
            color: "white",
            "font-family": "Roboto",
            "font-size": "12px",
            "line-height": "16px",
            "text-align": "center"
        });
        c.appendChild(a.document.createTextNode(b));
        return c
    }

    function fG(a, b) {
        const c = a.document.createElement("button");
        c.setAttribute("aria-label", b);
        u(c, Us(a));
        u(c, {
            position: "absolute",
            top: "10px",
            right: "10px",
            display: "block",
            cursor: "pointer",
            width: "24px",
            height: "24px",
            "font-size": "24px",
            "user-select": "none",
            color: "white"
        });
        b = a.document.createElement("gm-icon");
        b.className = "google-material-icons";
        b.appendChild(a.document.createTextNode("close"));
        c.appendChild(b);
        const d = new vq;
        c.addEventListener("click", () => void uq(d));
        return {
            Wi: c,
            bf: sq(d)
        }
    }

    function dG(a, b) {
        a = $v(a.document, b, null, null, {});
        return {
            sa: a.wb,
            Rj: a.ta
        }
    };

    function gG({
        target: a,
        threshold: b = 0
    }) {
        const c = new hG;
        c.L(a, b);
        return c
    }
    var hG = class extends S {
        constructor() {
            super();
            this.g = new T(!1)
        }
        L(a, b) {
            const c = new IntersectionObserver(d => {
                for (const e of d)
                    if (e.target === a) {
                        this.g.g(e.isIntersecting);
                        break
                    }
            }, {
                threshold: b
            });
            c.observe(a);
            cq(this, () => void c.disconnect())
        }
    };

    function iG(a) {
        const b = jG(a.win, wh(a.g, 2) ? ? 250, wh(a.g, 3) ? ? 300);
        let c = 1;
        return QF(a.l).map(d => ({
            wa: c++,
            image: d,
            pb: b(d)
        }))
    }

    function kG(a, b) {
        const c = gG({
            target: b.image.g,
            threshold: Og(a.g, 4) ? ? void 0 ? ? .8
        });
        a.j.push(c);
        nq(qq(c.g, a.win, wh(a.g, 5) ? ? 3E3, d => d), !0, () => {
            if (a.i < (wh(a.g, 1) ? ? 1)) {
                aG({
                    win: a.win,
                    wa: b.wa,
                    Kj: b.image.g,
                    webPropertyCode: a.webPropertyCode,
                    Va: a.Va,
                    V: a.V
                });
                a.i++;
                if (!(a.i < (wh(a.g, 1) ? ? 1)))
                    for (; a.j.length;) a.j.pop() ? .dispose();
                a.V ? .Ik(b.wa)
            }
        })
    }
    var mG = class {
        constructor(a, b, c, d, e, f) {
            this.win = a;
            this.webPropertyCode = b;
            this.g = c;
            this.Va = d;
            this.l = e;
            this.V = f;
            this.j = [];
            this.i = 0
        }
        run() {
            const a = iG(this);
            a.filter(lG).forEach(b => void kG(this, b));
            this.V ? .Kk(a.map(b => ({
                wa: b.wa,
                pb: b.pb
            })))
        }
    };

    function lG(a) {
        return a.pb.rejectionReasons.length === 0
    }

    function jG(a, b, c) {
        const d = Ap(a);
        return e => {
            e = e.g.getBoundingClientRect();
            const f = [];
            e.width < b && f.push(1);
            e.height < c && f.push(2);
            e.top <= d && f.push(3);
            return {
                Kb: e.width,
                zf: e.height,
                pj: e.top - d,
                rejectionReasons: f
            }
        }
    };

    function nG(a, b) {
        a.wa = b;
        return a
    }
    var oG = class {
        constructor(a, b, c, d, e) {
            this.B = a;
            this.webPropertyCode = b;
            this.hostname = c;
            this.j = d;
            this.l = e;
            this.errorMessage = this.i = this.wa = this.g = null
        }
    };

    function pG(a, b) {
        return new oG(b, a.webPropertyCode, a.hostname, a.i, a.l)
    }

    function qG(a, b, c) {
        var d = a.j++;
        a.g === null ? (a.g = gl(), a = 0) : a = gl() - a.g;
        var e = b.B,
            f = b.webPropertyCode,
            g = b.hostname,
            h = b.j,
            k = b.l.map(encodeURIComponent).join(",");
        if (b.g) {
            var l = {
                imcnt: b.g.length
            };
            var m = Math.min(b.g.length, 10);
            for (let n = 0; n < m; n++) {
                const p = `im${n}`;
                l[`${p}_id`] = b.g[n].wa;
                l[`${p}_s_w`] = b.g[n].pb.Kb;
                l[`${p}_s_h`] = b.g[n].pb.zf;
                l[`${p}_s_dbf`] = b.g[n].pb.pj;
                b.g[n].pb.rejectionReasons.length > 0 && (l[`${p}_s_rej`] = b.g[n].pb.rejectionReasons.join(","))
            }
        } else l = null;
        my("abg::imovad", {
            typ: e,
            wpc: f,
            hst: g,
            pvsid: h,
            peid: k,
            rate: c,
            num: d,
            tim: a,
            ...(b.wa === null ? {} : {
                imid: b.wa
            }),
            ...(b.i === null ? {} : {
                astat: b.i
            }),
            ...(b.errorMessage === null ? {} : {
                errm: b.errorMessage
            }),
            ...l
        }, c)
    }
    var rG = class {
        constructor(a, b, c, d) {
            this.webPropertyCode = a;
            this.hostname = b;
            this.i = c;
            this.l = d;
            this.j = 0;
            this.g = null
        }
        Kk(a) {
            var b = pG(this, "fndi");
            b.g = a;
            qG(this, b, a.length > 0 ? 1 : .1)
        }
        Ik(a) {
            a = nG(pG(this, "adpl"), a);
            qG(this, a, 1)
        }
        Jk(a, b) {
            a = nG(pG(this, "adst"), a);
            a.i = b;
            qG(this, a, 1)
        }
        Hk(a) {
            a = nG(pG(this, "adis"), a);
            qG(this, a, 1)
        }
        reportError(a) {
            var b = pG(this, "err");
            b.errorMessage = a;
            qG(this, b, .1)
        }
    };

    function sG(a, b, c) {
        return (a = a.i()) && lh(a, 11) ? c.map(d => d.j()) : c.map(d => d.B(b))
    };
    var tG = class extends N {
        getHeight() {
            return oh(this, 2)
        }
    };

    function uG(a, b) {
        return zh(a, 1, b)
    }

    function vG(a, b) {
        return ih(a, 2, b)
    }
    var wG = class extends N {};
    var xG = class extends N {};
    var yG = class extends N {},
        zG = [1, 2];
    const AG = new Set([7, 1]);
    var BG = class {
        constructor() {
            this.j = new KF;
            this.l = []
        }
        g(a, b) {
            AG.has(b) || sr(pr(ox(a), c => void this.j.add(c, b)), c => void this.l.push(c))
        }
        i(a, b) {
            for (const c of a) this.g(c, b)
        }
    };

    function CG(a) {
        return new Ir(["pedestal_container"], {
            google_reactive_ad_format: 30,
            google_phwr: 2.189,
            google_ad_width: Math.floor(a),
            google_ad_format: "autorelaxed",
            google_full_width_responsive: !0,
            google_enable_content_recommendations: !0,
            google_content_recommendation_ui_type: "pedestal"
        })
    }
    var DG = class {
        g(a) {
            return CG(Math.floor(a.i))
        }
    };
    var EG = class extends N {};

    function FG(a, b) {
        var c = b.adClient;
        if (typeof c !== "string" || !c) return !1;
        a.Ee = c;
        a.j = !!b.adTest;
        c = b.pubVars;
        ra(c) && (a.C = c);
        if (Array.isArray(b.fillMessage) && b.fillMessage.length > 0) {
            a.A = {};
            for (const d of b.fillMessage) a.A[d.key] = d.value
        }
        a.l = b.adWidth;
        a.i = b.adHeight;
        Pk(a.l) && Pk(a.i) || my("rctnosize", b);
        return !0
    }
    var GG = class {
        constructor() {
            this.A = this.C = this.j = this.Ee = null;
            this.i = this.l = 0
        }
        G() {
            return !0
        }
    };

    function HG(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            const b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return b === "__storage_test__"
        } catch (b) {
            return !1
        }
    }

    function IG(a, b = []) {
        const c = Date.now();
        return Ka(b, d => c - d < a * 1E3)
    }

    function JG(a, b, c) {
        try {
            const d = a.getItem(c);
            if (!d) return [];
            let e;
            try {
                e = JSON.parse(d)
            } catch (f) {}
            if (!Array.isArray(e) || Na(e, f => !Number.isInteger(f))) return a.removeItem(c), [];
            e = IG(b, e);
            e.length || a ? .removeItem(c);
            return e
        } catch (d) {
            return null
        }
    }

    function KG(a, b, c) {
        return b <= 0 || a == null || !HG(a) ? null : JG(a, b, c)
    };

    function LG(a, b, c) {
        let d = 0;
        try {
            var e = d |= yp(a);
            const h = zp(a),
                k = a.innerWidth;
            var f = h && k ? h / k : 0;
            d = e | (f ? f > 1.05 ? 262144 : f < .95 ? 524288 : 0 : 131072);
            d |= Bp(a);
            d |= a.innerHeight >= a.innerWidth ? 0 : 8;
            d |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            var g;
            if (g = b) g = KG(c, 3600, "__lsv__") ? .length !== 0;
            g && (d |= 134217728)
        } catch (h) {
            d |= 32
        }
        return d
    };
    var MG = class extends GG {
        constructor() {
            super(...arguments);
            this.B = !1;
            this.g = null
        }
        G(a) {
            this.B = !!a.enableAma;
            if (a = a.amaConfig) try {
                var b = Es(a)
            } catch (c) {
                b = null
            } else b = null;
            this.g = b;
            return !0
        }
    };
    var NG = {};

    function OG(a, b, c) {
        let d = PG(a, c, b);
        if (!d) return !0;
        const e = c.G.i;
        for (; d.jb && d.jb.length;) {
            const f = d.jb.shift(),
                g = Qw(f.ea);
            if (g && !(g <= d.od)) c.A ? .g(f, 18);
            else if (QG(c, f, {
                    Td: d.od
                })) {
                if (d.kd.g.length + 1 >= e) return c.A ? .i(d.jb, 19), !0;
                d = PG(a, c, b);
                if (!d) return !0
            }
        }
        return c.j
    }
    const PG = (a, b, c) => {
        var d = b.G.i,
            e = b.G.l,
            f = b.G;
        f = yy(b.ca(), f.g ? f.g.uc : void 0, d);
        if (f.g.length >= d) return b.A ? .i(RG(b, f, {
            types: a
        }, c), 19), null;
        e ? (d = f.i || (f.i = Ep(f.j).scrollHeight || null), e = !d || d < 0 ? -1 : f.i * e - Ey(f)) : e = void 0;
        const g = (d = e == null || e >= 50) ? RG(b, f, {
            types: a
        }, c) : null;
        d || b.A ? .i(RG(b, f, {
            types: a
        }, c), 18);
        return {
            kd: f,
            od: e,
            jb: g
        }
    };
    NG[2] = Aa(function(a, b) {
        a = RG(b, yy(b.ca()), {
            types: a,
            qb: Mx(b.ca())
        }, 2);
        if (a.length == 0) return !0;
        for (let c = 0; c < a.length; c++)
            if (QG(b, a[c])) return !0;
        return b.j ? (b.l.push(11), !0) : !1
    }, [0]);
    NG[5] = Aa(OG, [0], 5);
    NG[10] = Aa(function(a, b) {
        a = [];
        const c = b.jd;
        c.includes(3) && a.push(2);
        c.includes(1) && a.push(0);
        c.includes(2) && a.push(1);
        return OG(a, 10, b)
    }, 10);
    NG[3] = function(a) {
        if (!a.j) return !1;
        const b = RG(a, yy(a.ca()), {
            types: [0],
            qb: Mx(a.ca())
        }, 3);
        if (b.length == 0) return !0;
        for (let c = b.length - 1; c >= 0; c--)
            if (QG(a, b[c])) return !0;
        a.l.push(11);
        return !0
    };
    const TG = a => {
            const b = a.ca().document.body.getBoundingClientRect().width;
            SG(a, CG(b))
        },
        VG = (a, b) => {
            var c = {
                types: [0],
                qb: Nx(),
                Mk: [5]
            };
            c = RG(a, yy(a.ca()), c, 8);
            UG(a, c.reverse(), b)
        },
        UG = (a, b, c) => {
            for (const d of b)
                if (b = c.g(d.la), QG(a, d, {
                        Fe: b
                    })) return !0;
            return !1
        };
    NG[8] = function(a) {
        var b = a.ca().document;
        if (b.readyState != "complete") return b.addEventListener("readystatechange", () => NG[8](a), {
            once: !0
        }), !0;
        if (!a.j) return !1;
        if (!a.Pd()) return !0;
        b = {
            types: [0],
            qb: Nx(),
            dg: [2, 4, 5]
        };
        b = RG(a, yy(a.ca()), b, 8);
        const c = new DG;
        if (UG(a, b, c)) return !0;
        if (a.B.Zg) switch (a.B.Oh || 0) {
            case 1:
                VG(a, c);
                break;
            default:
                TG(a)
        }
        return !0
    };
    NG[6] = Aa(OG, [2], 6);
    NG[7] = Aa(OG, [1], 7);
    NG[9] = function(a) {
        const b = PG([0, 2], a, 9);
        if (!b || !b.jb) return a.l.push(17), a.j;
        for (var c of b.jb) {
            var d = a.B.wf || null;
            d == null ? d = null : (d = Rw(c.ea, new WG, new XG(d, a.ca())), d = new qx(d, c.ha(), c.la));
            if (d && !(Qw(d.ea) > b.od) && QG(a, d, {
                    Td: b.od,
                    Xe: !0
                })) return a = d.ea.I, c = c.ea, a = a.length > 0 ? a[0] : null, c.l = !0, a != null && c.I.push(a), !0
        }
        a.l.push(17);
        return a.j
    };
    var WG = class {
        i(a, b, c, d) {
            return cw(d.document, a, b)
        }
        j(a) {
            return Ap(a) || 0
        }
    };
    var YG = class {
        constructor(a, b, c) {
            this.i = a;
            this.g = b;
            this.kd = c
        }
        Ba(a) {
            return this.g ? az(this.i, this.g, a, this.kd) : $y(this.i, a, this.kd)
        }
        va() {
            return this.g ? 16 : 9
        }
    };
    var ZG = class {
        constructor(a) {
            this.Ge = a
        }
        Ba(a) {
            return hz(a.document, this.Ge)
        }
        va() {
            return 11
        }
    };
    var $G = class {
        constructor(a) {
            this.Cb = a
        }
        Ba(a) {
            return ez(this.Cb, a)
        }
        va() {
            return 13
        }
    };
    var aH = class {
        Ba(a) {
            return Yy(a)
        }
        va() {
            return 12
        }
    };
    var bH = class {
        constructor(a) {
            this.Gc = a
        }
        Ba() {
            return cz(this.Gc)
        }
        va() {
            return 2
        }
    };
    var cH = class {
        constructor(a) {
            this.g = a
        }
        Ba() {
            return fz(this.g)
        }
        va() {
            return 3
        }
    };
    var dH = class {
        Ba() {
            return iz()
        }
        va() {
            return 17
        }
    };
    var eH = class {
        constructor(a) {
            this.g = a
        }
        Ba() {
            return bz(this.g)
        }
        va() {
            return 1
        }
    };
    var fH = class {
        Ba() {
            return db(Mw)
        }
        va() {
            return 7
        }
    };
    var gH = class {
        constructor(a) {
            this.dg = a
        }
        Ba() {
            return dz(this.dg)
        }
        va() {
            return 6
        }
    };
    var hH = class {
        constructor(a) {
            this.g = a
        }
        Ba() {
            return gz(this.g)
        }
        va() {
            return 5
        }
    };
    var iH = class {
        constructor(a, b) {
            this.minWidth = a;
            this.maxWidth = b
        }
        Ba() {
            return Aa(jz, this.minWidth, this.maxWidth)
        }
        va() {
            return 10
        }
    };
    var jH = class {
        constructor(a) {
            this.l = a.i.slice(0);
            this.i = a.g.slice(0);
            this.j = a.j;
            this.B = a.l;
            this.g = a.B
        }
    };

    function kH(a) {
        var b = new lH;
        b.B = a;
        b.i.push(new eH(a));
        return b
    }

    function mH(a, b) {
        a.i.push(new gH(b));
        return a
    }

    function nH(a, b) {
        a.i.push(new bH(b));
        return a
    }

    function oH(a, b) {
        a.i.push(new hH(b));
        return a
    }

    function pH(a, b) {
        a.i.push(new cH(b));
        return a
    }

    function qH(a) {
        a.i.push(new fH);
        return a
    }

    function rH(a) {
        a.g.push(new aH);
        return a
    }

    function sH(a, b = 0, c, d) {
        a.g.push(new YG(b, c, d));
        return a
    }

    function tH(a, b = 0, c = Infinity) {
        a.g.push(new iH(b, c));
        return a
    }

    function uH(a) {
        a.g.push(new dH);
        return a
    }

    function vH(a, b = 0) {
        a.g.push(new $G(b));
        return a
    }

    function wH(a, b) {
        a.j = b;
        return a
    }
    var lH = class {
        constructor() {
            this.j = 0;
            this.l = !1;
            this.i = [].slice(0);
            this.g = [].slice(0)
        }
        build() {
            return new jH(this)
        }
    };
    var XG = class {
        constructor(a, b) {
            this.i = a;
            this.j = b
        }
        g() {
            var a = this.i,
                b = this.j;
            const c = a.C || {};
            c.google_ad_client = a.Ee;
            c.google_ad_height = Ap(b) || 0;
            c.google_ad_width = zp(b) || 0;
            c.google_reactive_ad_format = 9;
            b = new EG;
            b = yh(b, 1, a.B);
            a.g && z(b, 2, a.g);
            c.google_rasc = Hh(b);
            a.j && (c.google_adtest = "on");
            return new Ir(["fsi_container"], c)
        }
    };
    var xH = Br(new yr(0, {})),
        yH = Br(new yr(1, {})),
        zH = a => a === xH || a === yH;

    function AH(a, b, c) {
        Pp(a.g, b) || a.g.set(b, []);
        a.g.get(b).push(c)
    }
    var BH = class {
        constructor() {
            this.g = new Tp
        }
    };

    function CH(a, b) {
        a.G.wpc = b;
        return a
    }

    function DH(a, b) {
        for (let c = 0; c < a.B.length; c++)
            if (a.B[c] == b) return a;
        a.B.push(b);
        return a
    }

    function EH(a, b) {
        for (let c = 0; c < b.length; c++) DH(a, b[c]);
        return a
    }

    function FH(a, b) {
        a.j = a.j ? a.j : b;
        return a
    }
    var GH = class {
        constructor(a) {
            this.G = {};
            this.G.c = a;
            this.B = [];
            this.j = null;
            this.A = [];
            this.D = 0
        }
        l(a) {
            const b = Qb(this.G);
            this.D > 0 && (b.t = this.D);
            b.err = this.B.join();
            b.warn = this.A.join();
            this.j && (b.excp_n = this.j.name, b.excp_m = this.j.message && this.j.message.substring(0, 512), b.excp_s = this.j.stack && al(this.j.stack, ""));
            b.w = 0 < a.innerWidth ? a.innerWidth : null;
            b.h = 0 < a.innerHeight ? a.innerHeight : null;
            return b
        }
    };

    function HH(a, b) {
        b && (a.g.apv = D(b, 4), Kg(b, cs, 23) && (a.g.sat = "" + y(b, cs, 23).i()));
        return a
    }

    function IH(a, b) {
        a.g.afm = b.join(",");
        return a
    }
    var JH = class extends GH {
        constructor(a) {
            super(a);
            this.g = {}
        }
        l(a) {
            try {
                this.g.su = a.location.hostname
            } catch (b) {
                this.g.su = "_ex"
            }
            a = super.l(a);
            Sb(a, this.g);
            return a
        }
    };

    function KH(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function LH(a, b, c, d = 30) {
        c.length <= d ? a[b] = MH(c) : (a[b] = MH(c.slice(0, d)), a[b + "_c"] = c.length.toString())
    }

    function MH(a) {
        const b = a.length > 0 && typeof a[0] === "string";
        a = a.map(c => c ? .toString() ? ? "null");
        b && (a = a.map(c => ha(c, "replaceAll").call(c, "~", "")));
        return a.join("~")
    }

    function NH(a) {
        return a == null ? "null" : typeof a === "string" ? a : typeof a === "boolean" ? a ? "1" : "0" : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function OH(a, b) {
        a.i.op = NH(b)
    }

    function PH(a, b, c) {
        LH(a.i, "fap", b);
        a.i.fad = NH(c)
    }

    function QH(a, b, c) {
        LH(a.i, "fmp", b);
        a.i.fmd = NH(c)
    }

    function RH(a, b, c) {
        LH(a.i, "vap", b);
        a.i.vad = NH(c)
    }

    function SH(a, b, c) {
        LH(a.i, "vmp", b);
        a.i.vmd = NH(c)
    }

    function TH(a, b, c) {
        LH(a.i, "pap", b);
        a.i.pad = NH(c)
    }

    function UH(a, b, c) {
        LH(a.i, "pmp", b);
        a.i.pmd = NH(c)
    }

    function VH(a, b) {
        LH(a.i, "psq", b)
    }
    var WH = class extends JH {
        constructor(a) {
            super(0);
            Object.assign(this, a);
            this.i = {};
            this.errors = []
        }
        l(a) {
            a = super.l(a);
            Object.assign(a, this.i);
            this.errors.length > 0 && (a.e = MH(this.errors));
            return a
        }
    };

    function XH(a, b, c) {
        const d = b.ea;
        Pp(a.g, d) || a.g.set(d, new YH(or(ox(b)) ? ? ""));
        c(a.g.get(d))
    }

    function ZH(a, b) {
        XH(a, b, c => {
            c.g = !0
        })
    }

    function $H(a, b) {
        XH(a, b, c => {
            c.i = !0
        })
    }

    function aI(a, b) {
        XH(a, b, c => {
            c.j = !0
        });
        a.M.push(b.ea)
    }

    function bI(a, b, c) {
        XH(a, b, d => {
            d.Zb = c
        })
    }

    function cI(a, b, c) {
        const d = [];
        let e = 0;
        for (const f of c.filter(b)) zH(f.Zb ? ? "") ? ++e : (b = a.i.get(f.Zb ? ? "", null), d.push(b));
        return {
            list: d.sort((f, g) => (f ? ? -1) - (g ? ? -1)),
            ac: e
        }
    }

    function dI(a, b) {
        OH(b, a.i.Kc());
        var c = Sp(a.g).filter(f => (f.Gb.startsWith(xH) ? 0 : 1) === 0),
            d = Sp(a.g).filter(f => (f.Gb.startsWith(xH) ? 0 : 1) === 1),
            e = cI(a, f => f.g, c);
        PH(b, e.list, e.ac);
        e = cI(a, f => f.g, d);
        QH(b, e.list, e.ac);
        e = cI(a, f => f.i, c);
        RH(b, e.list, e.ac);
        e = cI(a, f => f.i, d);
        SH(b, e.list, e.ac);
        c = cI(a, f => f.j, c);
        TH(b, c.list, c.ac);
        d = cI(a, f => f.j, d);
        UH(b, d.list, d.ac);
        VH(b, a.M.map(f => a.g.get(f) ? .Zb).map(f => a.i.get(f) ? ? null))
    }

    function Dm() {
        var a = R(eI);
        if (!a.B) return sm();
        const b = Bm(Am(zm(ym(xm(wm(vm(um(rm(qm(new tm, a.B ? ? []), a.I ? ? []), a.A), a.D), a.F), a.U), a.Z), a.G ? ? 0), Sp(a.g).map(c => {
            var d = new pm;
            d = Eh(d, 1, c.Gb);
            var e = a.i.get(c.Zb ? ? "", -1);
            d = Ch(d, 2, e);
            d = J(d, 3, c.g);
            return J(d, 4, c.i)
        })), a.M.map(c => a.g.get(c) ? .Zb).map(c => a.i.get(c) ? ? -1));
        a.j != null && J(b, 6, a.j);
        a.l != null && Zg(b, 13, Tf(a.l), "0");
        return b
    }
    var eI = class {
        constructor() {
            this.l = this.I = this.B = null;
            this.F = this.D = !1;
            this.j = null;
            this.Z = this.A = this.U = !1;
            this.G = null;
            this.i = new Tp;
            this.g = new Tp;
            this.M = []
        }
    };
    class YH {
        constructor(a) {
            this.j = this.i = this.g = !1;
            this.Zb = null;
            this.Gb = a
        }
    };
    var fI = class {
        constructor(a) {
            this.i = a;
            this.g = -1
        }
    };

    function gI(a) {
        let b = 0;
        for (; a;)(!b || a.previousElementSibling || a.nextElementSibling) && b++, a = a.parentElement;
        return b
    };

    function hI(a, b) {
        const c = a.I.filter(d => Rp(d.zd).every(e => d.zd.get(e) === b.get(e)));
        return c.length === 0 ? (a.i.push(19), null) : c.reduce((d, e) => d.zd.Kc() > e.zd.Kc() ? d : e, c[0])
    }

    function iI(a, b) {
        b = ox(b);
        if (b.g == null) return a.i.push(18), null;
        b = b.getValue();
        if (Pp(a.j, b)) return a.j.get(b);
        var c = zr(b);
        c = hI(a, c);
        a.j.set(b, c);
        return c
    }
    var jI = class {
        constructor(a) {
            this.g = a;
            this.j = new Tp;
            this.I = (y(a, Bs, 2) ? .i() || []).map(b => {
                const c = zr(F(b, 1)),
                    d = ph(b, 2);
                return {
                    zd: c,
                    Rh: d,
                    Gb: F(b, 1)
                }
            });
            this.i = []
        }
        F() {
            const a = R(eI);
            var b = this.l();
            a.B = b;
            b = this.A();
            a.I = b;
            b = this.B();
            b != null && (a.l = b);
            b = !!this.g.j() ? .i() ? .i();
            a.F = b;
            b = new Tp;
            for (const c of y(this.g, Bs, 2) ? .i() ? ? []) b.set(F(c, 1), ph(c, 2));
            a.i = b
        }
        G() {
            return [...this.i]
        }
        l() {
            return [...this.g.i()]
        }
        A() {
            return [...Qg(this.g, 4, Qf, Pg(), void 0, 0)]
        }
        B() {
            return y(this.g, vs, 5) ? .i() ? ? null
        }
        D(a) {
            const b = iI(this, a);
            b ? .Gb != null && bI(R(eI), a, b.Gb)
        }
        M(a) {
            return a.length == 0 ? !0 : .75 <= (new gr(a)).filter(b => {
                b = iI(this, b) ? .Gb || "";
                return b != "" && !(b === xH || b === yH)
            }).g.length / a.length
        }
    };

    function kI(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => (iI(a.g, c) ? .Rh ? ? Number.MAX_VALUE) - (iI(a.g, d) ? .Rh ? ? Number.MAX_VALUE))
    }

    function lI(a, b) {
        var c = b.la.g,
            d = Math,
            e = d.min;
        const f = b.ha(),
            g = b.ea.j();
        c += 200 * e.call(d, 20, g == 0 || g == 3 ? gI(f.parentElement) : gI(f));
        a = a.i;
        a.g < 0 && (a.g = Ep(a.i).scrollHeight || 0);
        a = a.g - b.la.g;
        a = c + (a > 1E3 ? 0 : 2 * (1E3 - a));
        b.ha();
        return a
    }

    function mI(a, b) {
        return b.g.length == 0 ? b : b.sort((c, d) => lI(a, c) - lI(a, d))
    }

    function nI(a, b) {
        return b.sort((c, d) => {
            const e = c.ea.G,
                f = d.ea.G;
            var g;
            e == null || f == null ? g = e == null && f == null ? lI(a, c) - lI(a, d) : e == null ? 1 : -1 : g = e - f;
            return g
        })
    }
    var oI = class {
        constructor(a, b = null) {
            this.i = new fI(a);
            this.g = b && new jI(b)
        }
    };

    function pI(a, b, c = 0, d) {
        var e = a.i;
        for (var f of b.l) e = fr(e, f.Ba(a.j), qI(f.va(), c));
        f = e = e.apply(Xy(a.j));
        for (const g of b.i) f = fr(f, g.Ba(a.j), vr([rI(g.va(), c), h => {
            d ? .g(h, g.va())
        }]));
        switch (b.j) {
            case 1:
                f = mI(a.g, f);
                break;
            case 2:
                f = nI(a.g, f);
                break;
            case 3:
                const g = R(eI);
                f = kI(a.g, f);
                e.forEach(h => {
                    ZH(g, h);
                    a.g.g ? .D(h)
                });
                f.forEach(h => $H(g, h))
        }
        b.B && (f = ir(f, Bc(a.j.location.href + a.j.localStorage.google_experiment_mod)));
        b.g ? .length === 1 && AH(a.l, b.g[0], {
            tb: e.g.length,
            ji: f.g.length
        });
        return hr(f)
    }
    var sI = class {
        constructor(a, b, c = null) {
            this.i = new gr(a);
            this.g = new oI(b, c);
            this.j = b;
            this.l = new BH
        }
    };
    const qI = (a, b) => c => Pw(c, b, a),
        rI = (a, b) => c => Pw(c.ea, b, a);

    function tI(a, b, c, d) {
        a: {
            switch (b) {
                case 0:
                    a = uI(vI(c), a);
                    break a;
                case 3:
                    a = uI(c, a);
                    break a;
                case 2:
                    const e = c.lastChild;
                    a = uI(e ? e.nodeType == 1 ? e : vI(e) : null, a);
                    break a
            }
            a = !1
        }
        if (d = !a && !(!d && b == 2 && !wI(c))) b = b == 1 || b == 2 ? c : c.parentNode,
        d = !(b && !Ys(b) && b.offsetWidth <= 0);
        return d
    }

    function uI(a, b) {
        if (!a) return !1;
        a = cd(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function vI(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function wI(a) {
        return !!a.nextSibling || !!a.parentNode && wI(a.parentNode)
    };
    const xI = !Fc && !Db();

    function yI(a) {
        if (/-[a-z]/.test("adFormat")) return null;
        if (xI && a.dataset) {
            if (Fb() && !("adFormat" in a.dataset)) return null;
            a = a.dataset.adFormat;
            return a === void 0 ? null : a
        }
        return a.getAttribute("data-" + "adFormat".replace(/([A-Z])/g, "-$1").toLowerCase())
    };

    function zI(a, b, c) {
        if (!b) return null;
        const d = vk(document, "INS");
        d.id = "google_pedestal_container";
        d.style.width = "100%";
        d.style.zIndex = "-1";
        if (c) {
            var e = a.getComputedStyle(c),
                f = "";
            if (e && e.position !== "static") {
                var g = c.parentNode.lastElementChild;
                for (f = e.position; g && g !== c;) {
                    if (a.getComputedStyle(g).display !== "none") {
                        f = a.getComputedStyle(g).position;
                        break
                    }
                    g = g.previousElementSibling
                }
            }
            if (c = f) d.style.position = c
        }
        b.appendChild(d);
        if (d) {
            var h = a.document;
            f = h.createElement("div");
            f.style.width = "100%";
            f.style.height =
                "2000px";
            c = Ap(a);
            e = h.body.scrollHeight;
            a = a.innerHeight;
            g = h.body.getBoundingClientRect().bottom;
            d.appendChild(f);
            var k = f.getBoundingClientRect().top;
            h = h.body.getBoundingClientRect().top;
            d.removeChild(f);
            f = e;
            e <= a && c > 0 && g > 0 && (f = g - h);
            a = k - h >= .8 * f
        } else a = !1;
        return a ? d : (b.removeChild(d), null)
    }

    function AI(a) {
        const b = a.document.body;
        var c = zI(a, b, null);
        if (c) return c;
        if (a.document.body) {
            c = Math.floor(a.document.body.getBoundingClientRect().width);
            for (var d = [{
                    element: a.document.body,
                    depth: 0,
                    height: 0
                }], e = -1, f = null; d.length > 0;) {
                const h = d.pop(),
                    k = h.element;
                var g = h.height;
                h.depth > 0 && g > e && (e = g, f = k);
                if (h.depth < 5)
                    for (g = 0; g < k.children.length; g++) {
                        const l = k.children[g],
                            m = l.getBoundingClientRect().width;
                        (m == null || c == null ? 0 : m >= c * .9 && m <= c * 1.01) && d.push({
                            element: l,
                            depth: h.depth + 1,
                            height: l.getBoundingClientRect().height
                        })
                    }
            }
            c =
                f
        } else c = null;
        return c ? zI(a, c.parentNode || b, c) : null
    }

    function BI(a) {
        let b = 0;
        try {
            b |= yp(a), Gb() || (b |= 1048576), Math.floor(a.document.body.getBoundingClientRect().width) <= 1200 || (b |= 32768), CI(a) && (b |= 33554432)
        } catch (c) {
            b |= 32
        }
        return b
    }

    function CI(a) {
        a = a.document.getElementsByClassName("adsbygoogle");
        for (let b = 0; b < a.length; b++)
            if (yI(a[b]) === "autorelaxed") return !0;
        return !1
    };

    function DI(a) {
        const b = Dp(a, !0),
            c = Ep(a).scrollWidth,
            d = Ep(a).scrollHeight;
        let e = "unknown";
        a && a.document && a.document.readyState && (e = a.document.readyState);
        var f = Ip(a);
        const g = [];
        var h = [];
        const k = [],
            l = [];
        var m = [],
            n = [],
            p = [];
        let t = 0,
            v = 0,
            w = Infinity,
            B = Infinity,
            G = null;
        var L = uy({
            Vb: !1
        }, a);
        for (var A of L) {
            L = A.getBoundingClientRect();
            const ia = b - (L.bottom + f);
            var H = void 0,
                K = void 0;
            if (A.className && A.className.indexOf("adsbygoogle-ablated-ad-slot") != -1) {
                H = A.getAttribute("google_element_uid");
                K = a.google_sv_map;
                if (!H ||
                    !K || !K[H]) continue;
                H = (K = Xk(K[H])) ? K.height : 0;
                K = K ? K.width : 0
            } else if (H = L.bottom - L.top, K = L.right - L.left, H <= 1 || K <= 1) continue;
            g.push(H);
            k.push(K);
            l.push(H * K);
            A.className && A.className.indexOf("google-auto-placed") != -1 ? (v += 1, A.className && A.className.indexOf("pedestal_container") != -1 && (G = H)) : (w = Math.min(w, ia), n.push(L), t += 1, h.push(H), m.push(H * K));
            B = Math.min(B, ia);
            p.push(L)
        }
        w = w === Infinity ? null : w;
        B = B === Infinity ? null : B;
        f = EI(n);
        p = EI(p);
        h = FI(b, h);
        n = FI(b, g);
        m = FI(b * c, m);
        A = FI(b * c, l);
        return new GI(a, {
            qj: e,
            Zf: b,
            wk: c,
            uk: d,
            ek: t,
            Li: v,
            Ni: HI(g),
            Oi: HI(k),
            Mi: HI(l),
            lk: f,
            kk: p,
            jk: w,
            ik: B,
            gf: h,
            ff: n,
            Hi: m,
            Gi: A,
            yk: G
        })
    }

    function II(a, b, c, d) {
        const e = Gb() && !(zp(a.i) >= 900);
        d = Ka(d, f => Pa(a.j, f)).join(",");
        return {
            wpc: b,
            su: c,
            eid: d,
            doc: a.g.qj,
            pg_h: JI(a.g.Zf),
            pg_w: JI(a.g.wk),
            pg_hs: JI(a.g.uk),
            c: JI(a.g.ek),
            aa_c: JI(a.g.Li),
            av_h: JI(a.g.Ni),
            av_w: JI(a.g.Oi),
            av_a: JI(a.g.Mi),
            s: JI(a.g.lk),
            all_s: JI(a.g.kk),
            b: JI(a.g.jk),
            all_b: JI(a.g.ik),
            d: JI(a.g.gf),
            all_d: JI(a.g.ff),
            ard: JI(a.g.Hi),
            all_ard: JI(a.g.Gi),
            pd_h: JI(a.g.yk),
            dt: e ? "m" : "d"
        }
    }
    class GI {
        constructor(a, b) {
            this.i = a;
            this.g = b;
            this.j = "633794002 633794005 21066126 21066127 21065713 21065714 21065715 21065716 42530887 42530888 42530889 42530890 42530891 42530892 42530893".split(" ")
        }
    }

    function HI(a) {
        return Lb.apply(null, Ka(a, b => b > 0)) || null
    }

    function FI(a, b) {
        return a <= 0 ? null : Kb.apply(null, b) / a
    }

    function EI(a) {
        let b = Infinity;
        for (let e = 0; e < a.length - 1; e++)
            for (let f = e + 1; f < a.length; f++) {
                var c = a[e],
                    d = a[f];
                c = Math.max(Math.max(0, c.left - d.right, d.left - c.right), Math.max(0, c.top - d.bottom, d.top - c.bottom));
                c > 0 && (b = Math.min(c, b))
            }
        return b !== Infinity ? b : null
    }

    function JI(a) {
        return a == null ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function KI(a) {
        var b = wy({
            Vb: !1,
            Md: !1
        }, a);
        a = (Ap(a) || 0) - Ip(a);
        let c = 0;
        for (let d = 0; d < b.length; d++) {
            const e = b[d].getBoundingClientRect();
            Cy(e) && e.top <= a && (c += 1)
        }
        return c > 0
    }

    function LI(a) {
        const b = {};
        var c = wy({
            Vb: !1,
            Md: !1,
            Cf: !1,
            Df: !1
        }, a).map(d => d.getBoundingClientRect()).filter(Cy);
        b.Cg = c.length;
        c = xy({
            Cf: !0
        }, a).map(d => d.getBoundingClientRect()).filter(Cy);
        b.Xg = c.length;
        c = xy({
            Df: !0
        }, a).map(d => d.getBoundingClientRect()).filter(Cy);
        b.Ih = c.length;
        c = xy({
            Md: !0
        }, a).map(d => d.getBoundingClientRect()).filter(Cy);
        b.Hg = c.length;
        c = (Ap(a) || 0) - Ip(a);
        c = wy({
            Vb: !1
        }, a).map(d => d.getBoundingClientRect()).filter(Cy).filter(za(MI, null, c));
        b.Dg = c.length;
        a = DI(a);
        c = a.g.gf != null ? a.g.gf : null;
        c !=
            null && (b.Bh = c);
        a = a.g.ff != null ? a.g.ff : null;
        a != null && (b.Eg = a);
        return b
    }

    function QG(a, b, {
        Td: c,
        Fe: d,
        Xe: e
    } = {}) {
        return uw(997, () => NI(a, b, {
            Td: c,
            Fe: d,
            Xe: e
        }), a.g)
    }

    function RG(a, b, c, d) {
        var e = c.qb ? c.qb : a.G;
        const f = Ox(e, b.g.length);
        e = a.B.Fg ? e.g : void 0;
        const g = uH(vH(rH(tH(sH(qH(oH(pH(mH(nH(kH(c.types), a.xa), c.dg || []), a.pa), c.Mk || [])), f.Vc || void 0, e, b), c.minWidth, c.maxWidth)), f.Cb || void 0));
        a.Z && g.g.push(new ZG(a.Z));
        b = 1;
        a.zb() && (b = 3);
        wH(g, b);
        a.B.bi && (g.l = !0);
        return uw(995, () => pI(a.i, g.build(), d, a.A || void 0), a.g)
    }

    function SG(a, b) {
        const c = AI(a.g);
        if (c) {
            const d = Hr(a.U, b),
                e = $v(a.g.document, a.F, null, null, {}, d);
            e && (Pv(e.wb, c, 2, 256), uw(996, () => OI(a, e, d), a.g))
        }
    }

    function PI(a) {
        return a.I ? a.I : a.I = a.g.google_ama_state
    }

    function NI(a, b, {
        Td: c,
        Fe: d,
        Xe: e
    } = {}) {
        const f = b.ea;
        if (f.l) return !1;
        var g = b.ha(),
            h = f.j();
        if (!tI(a.g, h, g, a.j)) return !1;
        h = null;
        f.Pc ? .includes(6) ? (h = Math.round(g.getBoundingClientRect().height), h = new Ir(null, {
            google_max_responsive_height: c == null ? h : Math.min(c, h),
            google_full_width_responsive: "false"
        })) : h = c == null ? null : new Ir(null, {
            google_max_responsive_height: c
        });
        c = Jr(nh(f.ue, 2) || 0);
        g = Kr(f.G);
        const k = QI(a, f),
            l = RI(a),
            m = Hr(a.U, f.U ? f.U.g(b.la) : null, h, d || null, c, g, k, l),
            n = b.fill(a.F, m);
        if (e && !SI(a, n, m) || !uw(996,
                () => OI(a, n, m), a.g)) return !1;
        Yj(9, [f.G, f.Yb]);
        a.zb() && aI(R(eI), b);
        return !0
    }

    function QI(a, b) {
        return or(sr(mx(b).map(Lr), () => {
            a.l.push(18)
        }))
    }

    function RI(a) {
        if (!a.zb()) return null;
        var b = a.i.g.g ? .A();
        if (b == null) return null;
        b = b.join("~");
        a = a.i.g.g ? .B() ? ? null;
        return Mr({
            fj: b,
            xj: a
        })
    }

    function SI(a, b, c) {
        if (!b) return !1;
        var d = b.ta,
            e = d.style.width;
        d.style.width = "100%";
        var f = d.offsetWidth;
        d.style.width = e;
        d = a.g;
        e = b.ta;
        c = c && c.Lc() || {};
        var g = X(mt);
        if (d !== d.top) g = $c(d) ? 3 : 16;
        else if (zp(d) < 488)
            if (d.innerHeight >= d.innerWidth) {
                var h = zp(d);
                if (!h || (h - f) / h > g) g = 6;
                else {
                    if (g = c.google_full_width_responsive !== "true") b: {
                        h = e.parentElement;
                        for (g = zp(d); h; h = h.parentElement) {
                            const k = cd(h, d);
                            if (!k) continue;
                            const l = md(k.width);
                            if (l && !(l >= g) && k.overflow !== "visible") {
                                g = !0;
                                break b
                            }
                        }
                        g = !1
                    }
                    g = g ? 7 : !0
                }
            } else g = 5;
        else g =
            4;
        if (g !== !0) f = g;
        else {
            if (!(c = c.google_full_width_responsive === "true")) a: {
                do
                    if ((c = cd(e, d)) && c.position == "fixed") {
                        c = !1;
                        break a
                    }
                while (e = e.parentElement);
                c = !0
            }
            c ? (d = zp(d), f = d - f, f = d && f >= 0 ? !0 : d ? f < -10 ? 11 : f < 0 ? 14 : 12 : 10) : f = 9
        }
        if (f) {
            a = a.g;
            b = b.ta;
            if (d = Wv(a, b)) f = b.style, f.border = f.borderStyle = f.outline = f.outlineStyle = f.transition = "none", f.borderSpacing = f.padding = "0", Uv(b, d, "0px"), f.width = `${zp(a)}px`, Xv(a, b, d), f.zIndex = "30";
            return !0
        }
        bt(b.wb);
        return !1
    }

    function OI(a, b, c) {
        if (!b) return !1;
        try {
            dw(a.g, b.ta, c)
        } catch (d) {
            return bt(b.wb), a.l.push(6), !1
        }
        return !0
    }
    var TI = class {
        constructor(a, b, c, d, e = {}, f = [], g = !1) {
            this.i = a;
            this.F = b;
            this.g = c;
            this.G = d.qb;
            this.xa = d.Gc || [];
            this.U = d.zj || null;
            this.pa = d.kj || [];
            this.Z = d.Ge || [];
            this.B = e;
            this.j = !1;
            this.D = [];
            this.l = [];
            this.M = this.I = void 0;
            this.jd = f;
            this.A = g ? new BG : null
        }
        ca() {
            return this.g
        }
        zb() {
            if ((this.i.g.g ? .l().length ? ? 0) == 0) return !1;
            if (this.M === void 0) {
                const a = wH(rH(qH(kH([0, 1, 2]))), 1).build(),
                    b = uw(995, () => pI(this.i, a), this.g);
                this.M = this.i.g.g ? .M(b) || !1
            }
            return this.M
        }
        Hf() {
            return !!this.B.Vh
        }
        Pd() {
            return !CI(this.g)
        }
        Ma() {
            return this.A
        }
    };
    const MI = (a, b) => b.top <= a;

    function UI(a, b, c, d, e, f = 0, g = 0) {
        this.bb = a;
        this.ne = f;
        this.me = g;
        this.errors = b;
        this.Jb = c;
        this.g = d;
        this.i = e
    };
    var VI = (a, {
        Pd: b = !1,
        Hf: c = !1,
        Pk: d = !1,
        zb: e = !1
    } = {}) => {
        const f = [];
        d && f.push(9);
        if (e) {
            a.includes(4) && !c && b && f.push(8);
            a.includes(1) && f.push(1);
            d = a.includes(3);
            e = a.includes(2);
            const g = a.includes(1);
            (d || e || g) && f.push(10)
        } else a.includes(3) && f.push(6), a.includes(4) && !c && b && f.push(8), a.includes(1) && f.push(1, 5), a.includes(2) && f.push(7);
        a.includes(4) && c && b && f.push(8);
        return f
    };

    function WI(a, b, c) {
        a = VI(a, {
            Pd: b.Pd(),
            Hf: b.Hf(),
            Pk: !!b.B.wf,
            zb: b.zb()
        });
        return new XI(a, b, c)
    }

    function YI(a, b) {
        const c = NG[b];
        return c ? uw(998, () => c(a.g), a.B) : (a.g.D.push(12), !0)
    }

    function ZI(a, b) {
        return new Promise(c => {
            setTimeout(() => {
                c(YI(a, b))
            })
        })
    }

    function $I(a) {
        a.g.j = !0;
        return Promise.all(a.i.map(b => ZI(a, b))).then(b => {
            b.includes(!1) && a.g.D.push(5);
            a.i.splice(0, a.i.length)
        })
    }
    var XI = class {
        constructor(a, b, c) {
            this.l = a.slice(0);
            this.i = a.slice(0);
            this.j = Qa(this.i, 1);
            this.g = b;
            this.B = c
        }
    };
    var aJ = class {
        constructor(a) {
            this.g = a;
            this.exception = void 0
        }
    };

    function bJ(a) {
        return $I(a).then(() => {
            var b = a.g.i.i.filter(Mw).g.length;
            var c = a.g.D.slice(0);
            var d = a.g;
            d = [...d.l, ...(d.i.g.g ? .G() || [])];
            b = new UI(b, c, d, a.g.i.i.g.length, a.g.i.l.g, a.g.i.i.filter(Mw).filter(Nw).g.length, a.g.i.i.filter(Nw).g.length);
            return new aJ(b)
        })
    };
    var cJ = class {
        g() {
            return new Ir([], {
                google_reactive_ad_format: 40,
                google_tag_origin: "qs"
            })
        }
    };
    var dJ = class {
        g() {
            return new Ir(["adsbygoogle-resurrected-ad-slot"], {})
        }
    };

    function eJ(a) {
        return Zs(a.g.document).map(b => {
            const c = new Fw(b, 3);
            b = new Hw(fw(a.g, b));
            return new Lw(c, b, a.i, !1, 0, [], null, a.g, null)
        })
    }
    var fJ = class {
        constructor(a) {
            var b = new dJ;
            this.g = a;
            this.i = b || null
        }
    };
    const gJ = {
        wg: "10px",
        Ve: "10px"
    };

    function hJ(a) {
        return Op(a.g.document.querySelectorAll("INS.adsbygoogle-placeholder")).map(b => new Lw(new Fw(b, 1), new Dw(gJ), a.i, !1, 0, [], null, a.g, null))
    }
    var iJ = class {
        constructor(a, b) {
            this.g = a;
            this.i = b || null
        }
    };

    function jJ(a, b) {
        const c = [];
        b.forEach((d, e) => {
            c.push(ha(e, "replaceAll").call(e, "~", "_") + "--" + d.map(f => Number(f)).join("_"))
        });
        LH(a.g, "cnstr", c, 80)
    }
    var kJ = class extends GH {
        constructor() {
            super(-1);
            this.g = {}
        }
        l(a) {
            a = super.l(a);
            Object.assign(a, this.g);
            return a
        }
    };

    function lJ(a, b) {
        return a == null ? b + "ShouldNotBeNull" : a == 0 ? b + "ShouldNotBeZero" : a < -1 ? b + "ShouldNotBeLessMinusOne" : null
    }

    function mJ(a, b, c) {
        const d = lJ(c.Id, "gapsMeasurementWindow") || lJ(c.Ic, "gapsPerMeasurementWindow") || lJ(c.Sc, "maxGapsToReport");
        return d != null ? mr(d) : c.Gg || c.Ic != -1 || c.Sc != -1 ? kr(new nJ(a, b, c)) : mr("ShouldHaveLimits")
    }

    function oJ(a) {
        return PI(a.j) && PI(a.j).placed || []
    }

    function pJ(a) {
        return oJ(a).map(b => Yq(Wq(b.element, a.g)))
    }

    function qJ(a) {
        return oJ(a).map(b => b.index)
    }

    function rJ(a, b) {
        const c = b.ea;
        return !a.A && c.i && nh(c.i, 8) != null && nh(c.i, 8) == 1 ? [] : c.l ? (c.I || []).map(d => Yq(Wq(d, a.g))) : [Yq(new Xq(b.la.g, 0))]
    }

    function sJ(a) {
        a.sort((e, f) => e.g - f.g);
        const b = [];
        let c = 0;
        for (let e = 0; e < a.length; ++e) {
            var d = a[e];
            let f = d.g;
            d = d.g + d.i;
            f <= c ? c = Math.max(c, d) : (b.push(new Xq(c, f - c)), c = d)
        }
        return b
    }

    function tJ(a, b) {
        b = b.map(c => {
            var d = new tG;
            d = zh(d, 1, c.g);
            c = c.getHeight();
            return zh(d, 2, c)
        });
        return vG(uG(new wG, a), b)
    }

    function uJ(a) {
        const b = hh(a, tG, 2, Pg()).map(c => `G${oh(c,1)}~${c.getHeight()}`);
        return `W${oh(a,1)}${b.join("")}`
    }

    function vJ(a, b) {
        const c = [];
        let d = 0;
        for (const e of Rp(b)) {
            const f = b.get(e);
            f.sort((g, h) => h.getHeight() - g.getHeight());
            a.F || f.splice(a.B, f.length);
            !a.G && d + f.length > a.i && f.splice(a.i - d, f.length);
            c.push(tJ(e, f));
            d += f.length;
            if (!a.G && d >= a.i) break
        }
        return c
    }

    function wJ(a) {
        const b = hh(a, wG, 5, Pg()).map(c => uJ(c));
        return `M${oh(a,1)}H${oh(a,2)}C${oh(a,3)}B${Number(!!E(a,4))}${b.join("")}`
    }

    function xJ(a) {
        var b = rx(hr(a.j.i.i), a.g),
            c = pJ(a),
            d = new Up(qJ(a));
        for (var e = 0; e < b.length; ++e)
            if (!d.contains(e)) {
                var f = rJ(a, b[e]);
                c.push(...f)
            }
        c.push(new Xq(0, 0));
        c.push(Yq(new Xq(Ep(a.g).scrollHeight, 0)));
        b = sJ(c);
        c = new Tp;
        for (d = 0; d < b.length; ++d) e = b[d], f = a.D ? 0 : Math.floor(e.g / a.l), Pp(c, f) || c.set(f, []), c.get(f).push(e);
        b = vJ(a, c);
        c = new xG;
        c = zh(c, 1, a.i);
        c = zh(c, 2, a.l);
        c = zh(c, 3, a.B);
        a = yh(c, 4, a.A);
        return ih(a, 5, b)
    }

    function yJ(a) {
        a = xJ(a);
        return wJ(a)
    }
    var nJ = class {
        constructor(a, b, c) {
            this.D = c.Id == -1;
            this.l = c.Id;
            this.F = c.Ic == -1;
            this.B = c.Ic;
            this.G = c.Sc == -1;
            this.i = c.Sc;
            this.A = c.rh;
            this.j = b;
            this.g = a
        }
    };

    function Qs(a, b, c) {
        let d = b.kb;
        b.Wb && W(It) && (d = 1, "r" in c && (c.r += "F"));
        d <= 0 || (!b.yb || "pvc" in c || (c.pvc = Fd(a.g)), my(b.Tb, c, d))
    }

    function zJ(a, b, c) {
        c = c.l(a.g);
        b.yb && (c.pvc = Fd(a.g));
        0 <= b.kb && (c.r = b.kb, Qs(a, b, c))
    }
    var AJ = class {
        constructor(a) {
            this.g = a
        }
    };
    const BJ = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function CJ(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        my("ama", b, .01)
    }

    function DJ(a) {
        const b = {};
        ed(BJ, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };

    function EJ(a) {
        const b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                const e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function FJ(a) {
        let b = "";
        const c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            const e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function GJ(a, b) {
        a = th(a, 2);
        if (!a) return !1;
        for (let c = 0; c < a.length; c++)
            if (a[c] == b) return !0;
        return !1
    }

    function HJ(a, b) {
        a = FJ(EJ(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        const c = gd(a),
            d = IJ(a);
        return b.find(e => {
            const f = Kg(e, Ur, 7) ? Cf(Gg(y(e, Ur, 7), 1)) : Cf(Gg(e, 1));
            e = Kg(e, Ur, 7) ? nh(y(e, Ur, 7), 2) : 2;
            if (typeof f !== "number") return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function IJ(a) {
        const b = {};
        for (;;) {
            b[gd(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };

    function JJ(a, b) {
        try {
            b.removeItem("google_ama_config")
        } catch (c) {
            CJ(a, {
                lserr: 1
            })
        }
    };
    var LJ = (a, b, c, d, e, f, g = null, h = null) => {
            KJ(a, new AJ(a), b, c, d, e, f, g, h)
        },
        KJ = (a, b, c, d, e, f, g, h = null, k = null) => {
            if (c)
                if (d) {
                    var l = hC(d, e);
                    try {
                        const m = new MJ(a, b, c, d, e, l, f, g, h, k);
                        uw(990, () => NJ(m), a)
                    } catch (m) {
                        Xj() && Yj(15, [m]), zJ(b, Ks, FH(DH(CH(IH(HH(new JH(0), d), l), c), 1), m)), KE(R(HE), Hm(new Qm, am(1)))
                    }
                } else zJ(b, Ks, DH(CH(new JH(0), c), 8)), KE(R(HE), Hm(new Qm, am(8)));
            else zJ(b, Ks, DH(new JH(0), 9)), KE(R(HE), Hm(new Qm, am(9)))
        };

    function NJ(a) {
        a.I.forEach(b => {
            switch (b) {
                case 0:
                    uw(991, () => OJ(a), a.g);
                    break;
                case 1:
                    uw(1073, () => {
                        aC(new gC(a.g, a.A, a.j, a.B, a.i.ba))
                    }, a.g);
                    break;
                case 2:
                    PJ(a);
                    break;
                case 7:
                    uw(1203, () => {
                        var c = y(a.j, us, 34);
                        if (c) {
                            var d = a.g,
                                e = a.B,
                                f = c.g();
                            c = d.location.hostname;
                            var g = y(f, ts, 1) ? .i() ? ? [];
                            c = new rG(e, c, Fd(q), g);
                            if (g = y(f, ts, 1))
                                if (f = y(f, ss, 2)) {
                                    $q(d, $F);
                                    const l = new Zp;
                                    var h = d.innerWidth;
                                    var k = .375 * h;
                                    h = new uC(k, h - k);
                                    k = d.innerWidth;
                                    k = zp(d) >= 900 ? .2 * k : .5 * k;
                                    (new mG(d, e, g, f, new TF(d, h, k, l, new DF(l)), c)).run()
                                } else c.reportError("No messages");
                            else c.reportError("No settings")
                        }
                    }, a.g);
                    break;
                case 6:
                    uw(1270, () => a.runAutoGames(), a.g)
            }
        })
    }

    function OJ(a) {
        var b = W(vt) ? void 0 : a.i.Bk;
        let c = null;
        c = W(vt) ? Mx(a.g) : Kx(a.g, b);
        if (a.i.ba && Kg(a.i.ba, Tr, 10)) {
            var d = Og(a.i.ba.i(), 1);
            d !== null && d !== void 0 && (c = Bx(a.g, d, b));
            W(Mt) && a.i.ba.i() ? .i() === 2 && (c = Jx(a.i.ba.i(), c))
        }
        Kg(a.j, Qr, 26) && (c = Px(c, y(a.j, Qr, 26), a.g));
        c = Rx(c, a.g);
        b = a.i.ba ? th(a.i.ba, 6) : [];
        d = a.i.ba ? hh(a.i.ba, Zr, 5, Pg()) : [];
        const e = a.i.ba ? th(a.i.ba, 2) : [],
            f = uw(993, () => {
                var g = a.j,
                    h = Ds(g),
                    k = a.i.ba && GJ(a.i.ba, 1) ? "text_image" : "text",
                    l = new cJ,
                    m = Kw(h, a.g, {
                        Pi: l,
                        Qj: new Iw(k)
                    });
                h.length != m.length && a.F.push(13);
                m = m.concat(hJ(new iJ(a.g, l)));
                h = W(Jt);
                l = y(g, Cs, 24) ? .j() ? .i() ? .i() || !1;
                if (h || l) h = eJ(new fJ(a.g)), l = R(eI), m = m.concat(h), l.U = !0, l.G = h.length, a.D === "n" && (a.D = y(g, Cs, 24) ? .i() ? .length ? "o" : "p");
                h = W(Mt) && a.i.ba.i() ? .i() === 2 && a.i.ba.i() ? .j();
                h = W(tt) || h;
                a: {
                    if (l = y(g, ms, 6))
                        for (n of l.i())
                            if (Kg(n, xr, 4)) {
                                var n = !0;
                                break a
                            }
                    n = !1
                }
                h && n ? (n = m.concat, h = a.g, (l = y(g, ms, 6)) ? (h = jx(l.i(), h), k = sG(g, k, h)) : k = [], k = n.call(m, k)) : (n = m.concat, h = a.g, (l = y(g, ms, 6)) ? (h = ix(l.i(), h), k = sG(g, k, h)) : k = [], k = n.call(m, k));
                m = k;
                g = y(g, Cs, 24);
                return new sI(m,
                    a.g, g)
            }, a.g);
        a.l = new TI(f, a.B, a.g, {
            qb: c,
            zj: a.U,
            Gc: a.i.Gc,
            kj: b,
            Ge: d
        }, QJ(a), e, W(It));
        PI(a.l) ? .optimization ? .ablatingThisPageview && !a.l.zb() && (ew(a.g), R(eI).A = !0, a.D = "f");
        a.G = WI(e, a.l, a.g);
        uw(992, () => bJ(a.G), a.g).then(uw(994, () => a.xa.bind(a), a.g), a.pa.bind(a))
    }

    function PJ(a) {
        const b = y(a.j, rs, 18);
        b && (new SE(a.g, new BF(a.g, a.B), b, new uA(a.g), Ds(a.j))).run()
    }

    function QJ(a) {
        const b = W(Lt);
        if (!a.j.i()) return {
            bi: b,
            Zg: !1,
            Vh: !1,
            zk: 0,
            Oh: 0,
            Fg: RJ(a),
            wf: a.M
        };
        const c = a.j.i();
        return {
            bi: b || E(c, 14),
            Zg: E(c, 5),
            Vh: E(c, 6),
            zk: qh(c, 8),
            Oh: nh(c, 10),
            Fg: RJ(a),
            wf: a.M
        }
    }

    function RJ(a) {
        return W(Ct) || W(Mt) && a.i.ba ? .i() ? .i() === 2 ? !1 : a.i.ba && Kg(a.i.ba, Tr, 10) ? (Og(a.i.ba.i(), 1) || 0) >= .5 : !0
    }

    function SJ(a, b) {
        var c = new JH(b.bb);
        c.g.pp = b.me;
        c.g.ppp = b.ne;
        c.g.ppos = b.placementPositionDiffs;
        c.g.eatf = b.zc;
        c.g.eatfAbg = b.Ac;
        c.g.reatf = b.Ub;
        c.g.a = a.G.l.slice(0).join(",");
        c = IH(HH(c, a.j), a.I);
        var d = b.Ha;
        d && (c.g.as_count = d.Cg, c.g.d_count = d.Xg, c.g.ng_count = d.Ih, c.g.am_count = d.Hg, c.g.atf_count = d.Dg, c.g.mdns = KH(d.Bh), c.g.alldns = KH(d.Eg));
        d = b.hc;
        d != null && (c.g.allp = d);
        if (d = b.Gd) {
            var e = [];
            for (var f of Rp(d))
                if (d.get(f).length > 0) {
                    var g = d.get(f)[0];
                    e.push("(" + [f, g.tb, g.ji].join() + ")")
                }
            c.g.fd = e.join(",")
        }
        f =
            b.Zf;
        f != null && (c.g.pgh = f);
        c.g.abl = b.kh;
        c.g.rr = a.D;
        a = EH(EH(CH(c, a.B), b.errors), a.F);
        c = b.Jb;
        for (e = 0; e < c.length; e++) a: {
            f = a;d = c[e];
            for (g = 0; g < f.A.length; g++)
                if (f.A[g] == d) break a;f.A.push(d)
        }
        b.exception !== void 0 && DH(FH(a, b.exception), 1);
        return a
    }

    function TJ(a, b) {
        var c = SJ(a, b);
        zJ(a.A, b.errors.length > 0 || a.F.length > 0 || b.exception !== void 0 ? Ks : Js, c);
        if (y(a.j, Cs, 24)) {
            a.l.i.g.g ? .F();
            b = PI(a.l);
            const d = R(eI);
            d.j = !!b ? .optimization ? .ablationFromStorage;
            b ? .optimization ? .ablatingThisPageview && (d.D = !0);
            d.Z = !!b ? .optimization ? .availableAbg;
            b = R(eI);
            c = new WH(c);
            b.B ? (c.i.sl = MH(b.B ? ? []), c.i.daaos = MH(b.I ? ? []), c.i.ab = NH(b.D), c.i.rr = NH(b.U), c.i.oab = NH(b.F), b.j != null && (c.i.sab = NH(b.j)), b.A && (c.i.fb = NH(b.A)), c.i.ls = NH(b.Z), OH(c, b.i.Kc()), b.G != null && (c.i.rp = NH(b.G)),
                b.l != null && (c.i.expl = NH(b.l)), dI(b, c)) : c.errors.push("irr");
            zJ(a.A, Ms, c)
        }
        c = a.l ? .Ma();
        W(It) && c != null && (c = new Map([...c.j.map.entries()].map(LF)), b = new kJ, jJ(b, c), zJ(a.A, Os, b))
    }

    function UJ(a, b) {
        const c = R(HE);
        if (c.i) {
            var d = new Qm,
                e = b.Jb.filter(g => g !== null),
                f = a.F.concat(b.errors, b.exception ? [1] : []).filter(g => g !== null);
            Mm(Jm(Pm(Om(Nm(Lm(Km(Em(Gm(Im(Fm(d, a.G.l.slice(0).map(g => {
                var h = new $l;
                return Fh(h, 1, g)
            })), e.map(g => {
                var h = new cm;
                return Fh(h, 1, g)
            })), f.map(g => am(g))), y(a.j, cs, 23) ? .i()), b.bb), b.hc), b.Ub), b.zc), b.Ac), a.I.map(g => g.toString())), jm(im(hm(gm(fm(em(dm(new km, b.Ha ? .Cg), b.Ha ? .Xg), b.Ha ? .Ih), b.Ha ? .Hg), b.Ha ? .Dg), b.Ha ? .Bh), b.Ha ? .Eg));
            if (b.Gd)
                for (let g of Rp(b.Gd)) {
                    e = new Xg;
                    for (let h of b.Gd.get(g)) om(e, mm(lm(new nm, h.tb), h.ji));
                    Wg(d).set(g.toString(), e)
                }
            y(a.j, Cs, 24) && Cm(d);
            KE(c, d)
        }
    }

    function VJ(a, b, c) {
        {
            var d = PI(a.l),
                e = b.g;
            const f = e.g,
                g = e.me;
            let h = e.bb,
                k = e.ne,
                l = e.errors.slice(),
                m = e.Jb.slice(),
                n = b.exception;
            const p = sE(a.g).had_ads_ablation ? ? !1;
            d ? (d.numAutoAdsPlaced ? h += d.numAutoAdsPlaced : a.G.j && m.push(13), d.exception !== void 0 && (n = d.exception), d.numPostPlacementsPlaced && (k += d.numPostPlacementsPlaced), c = {
                bb: h,
                me: g,
                ne: k,
                hc: f,
                errors: e.errors.slice(),
                Jb: m,
                exception: n,
                Ub: c,
                zc: !!d.eatf,
                Ac: !!d.eatfAbg,
                kh: p
            }) : (m.push(12), a.G.j && m.push(13), c = {
                bb: h,
                me: g,
                ne: k,
                hc: f,
                errors: l,
                Jb: m,
                exception: n,
                Ub: c,
                zc: !1,
                Ac: !1,
                kh: p
            })
        }
        c.Ha = LI(a.l.g);
        if (b = b.g.i) c.Gd = b;
        c.Zf = Ep(a.g).scrollHeight;
        if (Xj() || y(a.j, bs, 25) ? .j()) {
            d = hr(a.l.i.i);
            b = [];
            for (const f of d) {
                d = {};
                e = f.M;
                for (const g of Rp(e)) d[g] = e.get(g);
                d = {
                    anchorElement: f.D.g(f.g),
                    position: f.j(),
                    clearBoth: f.F,
                    locationType: f.Yb,
                    placed: f.l,
                    placementProto: f.i ? vg(f.i) : null,
                    articleStructure: f.B ? vg(f.B) : null,
                    rejectionReasons: d
                };
                b.push(d)
            }
            Yj(14, [{
                placementIdentifiers: b
            }, a.l.F, c.Ha])
        }
        return c
    }

    function WJ(a, b) {
        var c = a.l.g;
        c = c.googleSimulationState = c.googleSimulationState || {};
        c.amaConfigPlacementCount = b.hc;
        c.numAutoAdsPlaced = b.bb;
        c.hasAtfAd = b.Ub;
        b.exception !== void 0 && (c.exception = b.exception);
        a.l != null && (a = mJ(a.g, a.l, {
            Id: -1,
            Ic: -1,
            Sc: -1,
            rh: !0,
            Gg: !0
        }), a.g != null ? (c.placementPositionDiffs = yJ(a.getValue()), b = xJ(a.getValue()), a = new yG, a = C(a, 2, zG, b), c.placementPositionDiffsReport = Hh(a)) : (b = a.i.message, c.placementPositionDiffs = "E" + b, a = new yG, a = $g(a, 1, zG, Yf(b)), c.placementPositionDiffsReport = Hh(a)))
    }

    function XJ(a, b) {
        TJ(a, {
            bb: 0,
            hc: void 0,
            errors: [],
            Jb: [],
            exception: b,
            Ub: void 0,
            zc: void 0,
            Ac: void 0,
            Ha: void 0
        });
        UJ(a, {
            bb: 0,
            hc: void 0,
            errors: [],
            Jb: [],
            exception: b,
            Ub: void 0,
            zc: void 0,
            Ac: void 0,
            Ha: void 0
        })
    }
    var MJ = class {
        constructor(a, b, c, d, e, f, g, h, k, l) {
            this.g = a;
            this.A = b;
            this.B = c;
            this.j = d;
            this.i = e;
            this.I = f;
            this.U = k || null;
            this.F = [];
            this.M = l;
            this.Ma = g;
            this.Z = h;
            this.D = "n"
        }
        runAutoGames() {
            const a = y(this.j, ds, 32);
            a && this.Z.runAutoGames({
                win: this.g,
                webPropertyCode: this.B,
                config: a.g(),
                floatingToolbarManager: uD(this.g, y(this.j, js, 33) ? .i() ? .g() ? ? null),
                Ji: y(this.j, ms, 6) ? .i() ? ? [],
                jb: Ds(this.j) ? ? [],
                storage: this.Ma ? ? void 0
            })
        }
        xa(a) {
            try {
                const b = KI(this.l.g) || void 0;
                Is({
                    lf: b
                }, this.g);
                const c = VJ(this, a, KI(this.l.g));
                Kg(this.j,
                    bs, 25) && lh(y(this.j, bs, 25), 1) && WJ(this, c);
                TJ(this, c);
                UJ(this, c);
                ky(753, () => {
                    if (W(wt) && this.l != null) {
                        var d = mJ(this.g, this.l, {
                                Id: X(Ht),
                                Ic: X(Gt),
                                Sc: X(yt),
                                rh: !0,
                                Gg: !1
                            }),
                            e = Qb(c);
                        d.g != null ? (d = yJ(d.getValue()), e.placementPositionDiffs = d) : e.placementPositionDiffs = "E" + d.i.message;
                        e = SJ(this, e);
                        zJ(this.A, Ls, e)
                    }
                })()
            } catch (b) {
                XJ(this, b)
            }
        }
        pa(a) {
            XJ(this, a)
        }
    };
    var YJ = class extends N {},
        ZJ = sj(YJ);

    function $J(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? nr(() => ZJ(c)) : kr(null)
    };

    function aK(a) {
        this.g = a || {
            cookie: ""
        }
    }
    aa = aK.prototype;
    aa.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        typeof c === "object" && (h = c.Wh, g = c.te || !1, f = c.domain || void 0, e = c.path || void 0, d = c.Ud);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        d === void 0 && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (d < 0 ? "" : d == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + d * 1E3)).toUTCString()) + (g ? ";secure" : "") + (h != null ? ";samesite=" + h : "")
    };
    aa.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = tb(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };

    function bK(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            Ud: 0,
            path: c,
            domain: d
        })
    }
    aa.isEmpty = function() {
        return !this.g.cookie
    };
    aa.Kc = function() {
        return this.g.cookie ? (this.g.cookie || "").split(";").length : 0
    };
    aa.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [],
            c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = tb(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; a >= 0; a--) bK(this, b[a])
    };

    function cK(a, b = window) {
        if (a.i()) try {
            return b.localStorage
        } catch {}
        return null
    }
    let dK;

    function eK(a) {
        return dK ? dK : a.origin === "null" ? dK = !1 : dK = fK(a)
    }

    function fK(a) {
        if (!a.navigator.cookieEnabled) return !1;
        const b = new aK(a.document);
        if (!b.isEmpty()) return !0;
        b.set("TESTCOOKIESENABLED", "1", {
            Ud: 60,
            Wh: a.isSecureContext ? "none" : void 0,
            te: a.isSecureContext || void 0
        });
        if (b.get("TESTCOOKIESENABLED") !== "1") return !1;
        bK(b, "TESTCOOKIESENABLED");
        return !0
    }

    function gK(a, b) {
        b = b.origin !== "null" ? b.document.cookie : null;
        return b === null ? null : (new aK({
            cookie: b
        })).get(a) || ""
    }

    function hK(a, b, c, d) {
        d.origin !== "null" && (d.isSecureContext && (c = { ...c,
            Wh: "none",
            te: !0
        }), (new aK(d.document)).set(a, b, c))
    };

    function iK(a, b) {
        return yh(a, 5, b)
    }

    function jK(a, b) {
        return yh(a, 12, b)
    }
    var kK = class extends N {
        l() {
            return D(this, 1) != null
        }
        j() {
            return D(this, 2) != null
        }
        B() {
            return E(this, 3)
        }
        i() {
            return E(this, 5)
        }
    };
    var nK = ({
        win: a,
        Oa: b,
        oh: c = !1,
        qh: d = !1
    }) => lK({
        win: a,
        Oa: b,
        oh: c,
        qh: d
    }) ? (b = iE(dE(), 24)) ? mK(a, iK(new kK, pF(b))) : new lr(null, Error("tcunav")) : mK(a, iK(new kK, !0));

    function lK({
        win: a,
        Oa: b,
        oh: c,
        qh: d
    }) {
        if (!(d = !d && uF(new yF(a)))) {
            if (c = !c) {
                if (b) {
                    a = $J(a);
                    if (a.g != null)
                        if ((a = a.getValue()) && nh(a, 1) != null) b: switch (a = I(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else ny(806, a.i), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function mK(a, b) {
        return (a = cK(b, a)) ? kr(a) : new lr(null, Error("unav"))
    };
    var oK = class extends N {};
    var pK = class {
        constructor(a, b, c, d, e, f) {
            this.g = a;
            this.B = b;
            this.G = c;
            this.l = d;
            this.i = !1;
            this.j = e;
            this.A = f
        }
        run() {
            const a = W(jv) ? this.l : y(this.G, rs, 1);
            if (this.i) {
                var b = this.g;
                if (this.j && !YD(a)) {
                    var c = new YJ;
                    c = Fh(c, 1, 1)
                } else c = null;
                if (c) {
                    c = Hh(c);
                    try {
                        b.localStorage.setItem("google_auto_fc_cmp_setting", c)
                    } catch (d) {}
                }
            }
            b = YD(a) && (this.j || this.A);
            a && b && (new SE(this.g, new BF(this.g, this.B), a, new uA(this.g))).run()
        }
    };
    var qK = class extends N {
        getName() {
            return I(this, 1)
        }
        getVersion() {
            return F(this, 3)
        }
    };
    var rK = [0, nj, -1, hj];
    var sK = class extends N {
        Fj() {
            return I(this, 3)
        }
    };
    const tK = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var uK = class extends N {
        getVersion() {
            return oh(this, 2)
        }
    };

    function vK(a) {
        return a.includes("~") ? a.split("~").slice(1) : []
    };

    function wK(a) {
        return Td(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function xK(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function yK(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    }

    function zK(a, b) {
        a = wK(a);
        return a.length < b ? a.padEnd(b, "0") : a
    };

    function AK(a) {
        var b = wK(a),
            c = xK(b.slice(0, 6));
        a = xK(b.slice(6, 12));
        var d = new uK;
        c = Ah(d, 1, c);
        a = Ah(c, 2, a);
        b = b.slice(12);
        c = xK(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = xK(e[0]) === 0;
            e = e.slice(1);
            var g = BK(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = yK(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = BK(e, b);
                g = yK(f);
                for (let l = 0; l <= g; l++) d.push(h + l);
                e = e.slice(f.length)
            }
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return Yg(a, 3, d, zf)
    }

    function BK(a, b) {
        const c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var CK = class extends N {
        i() {
            return I(this, 1)
        }
        j() {
            return I(this, 2)
        }
    };
    var DK = class extends N {};
    var EK = class extends N {
        getVersion() {
            return oh(this, 1)
        }
    };
    var FK = class extends N {};

    function GK(a) {
        var b = new HK;
        return z(b, 1, a)
    }
    var HK = class extends N {};
    const IK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        JK = 6 + IK.reduce((a, b) => a + b);

    function KK(a) {
        if (a.length === 0) throw Error("Cannot decode empty USCA section string.");
        var b = a.split(".");
        if (b.length > 2) throw Error(`Expected at most 1 sub-section but got ${b.length-1} when decoding ${a}.`);
        a = b[0];
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = zK(a, JK),
            d = xK(c.slice(0, 6));
        c = c.slice(6);
        if (d !== 1) throw Error(`Unable to decode unsupported USCA Section specification version ${d} - only version 1 is supported.`);
        var e = 0;
        a = [];
        for (let f = 0; f < IK.length; f++) {
            const g =
                IK[f];
            a.push(xK(c.slice(e, e + g)));
            e += g
        }
        c = new EK;
        d = Ah(c, 1, d);
        c = a.shift();
        d = M(d, 2, c);
        c = a.shift();
        d = M(d, 3, c);
        c = a.shift();
        d = M(d, 4, c);
        c = a.shift();
        d = M(d, 5, c);
        c = a.shift();
        d = M(d, 6, c);
        c = new DK;
        e = a.shift();
        c = M(c, 1, e);
        e = a.shift();
        c = M(c, 2, e);
        e = a.shift();
        c = M(c, 3, e);
        e = a.shift();
        c = M(c, 4, e);
        e = a.shift();
        c = M(c, 5, e);
        e = a.shift();
        c = M(c, 6, e);
        e = a.shift();
        c = M(c, 7, e);
        e = a.shift();
        c = M(c, 8, e);
        e = a.shift();
        c = M(c, 9, e);
        d = z(d, 7, c);
        c = new CK;
        e = a.shift();
        c = M(c, 1, e);
        e = a.shift();
        c = M(c, 2, e);
        d = z(d, 8, c);
        c = a.shift();
        d = M(d, 9, c);
        c = a.shift();
        d = M(d, 10, c);
        c = a.shift();
        d = M(d, 11, c);
        a = a.shift();
        a = M(d, 12, a);
        if (b.length === 1) b = GK(a);
        else {
            a = GK(a);
            b = b[1];
            if (b.length === 0) throw Error("Cannot decode empty GPC segment string.");
            d = zK(b, 3);
            b = xK(d.slice(0, 2));
            if (b < 0 || b > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${b}.`);
            b += 1;
            d = xK(d.charAt(2));
            c = new FK;
            b = M(c, 2, b);
            b = J(b, 1, !!d);
            b = z(a, 2, b)
        }
        return b
    };
    var LK = class extends N {};
    var MK = class extends N {
        getVersion() {
            return oh(this, 1)
        }
    };
    var NK = class extends N {};

    function OK(a) {
        var b = new PK;
        return z(b, 1, a)
    }
    var PK = class extends N {};
    const QK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        RK = 6 + QK.reduce((a, b) => a + b);

    function SK(a) {
        if (a.length === 0) throw Error("Cannot decode empty USCO section string.");
        var b = a.split(".");
        if (b.length > 2) throw Error(`Expected at most 2 segments but got ${b.length} when decoding ${a}.`);
        a = b[0];
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = zK(a, RK),
            d = xK(c.slice(0, 6));
        c = c.slice(6);
        if (d !== 1) throw Error(`Unable to decode unsupported USCO Section specification version ${d} - only version 1 is supported.`);
        var e = 0;
        a = [];
        for (let f = 0; f < QK.length; f++) {
            const g =
                QK[f];
            a.push(xK(c.slice(e, e + g)));
            e += g
        }
        c = new MK;
        d = Ah(c, 1, d);
        c = a.shift();
        d = M(d, 2, c);
        c = a.shift();
        d = M(d, 3, c);
        c = a.shift();
        d = M(d, 4, c);
        c = a.shift();
        d = M(d, 5, c);
        c = a.shift();
        d = M(d, 6, c);
        c = new LK;
        e = a.shift();
        c = M(c, 1, e);
        e = a.shift();
        c = M(c, 2, e);
        e = a.shift();
        c = M(c, 3, e);
        e = a.shift();
        c = M(c, 4, e);
        e = a.shift();
        c = M(c, 5, e);
        e = a.shift();
        c = M(c, 6, e);
        e = a.shift();
        c = M(c, 7, e);
        d = z(d, 7, c);
        c = a.shift();
        d = M(d, 8, c);
        c = a.shift();
        d = M(d, 9, c);
        c = a.shift();
        d = M(d, 10, c);
        a = a.shift();
        a = M(d, 11, a);
        if (b.length === 1) b = OK(a);
        else {
            a = OK(a);
            b = b[1];
            if (b.length ===
                0) throw Error("Cannot decode empty GPC segment string.");
            d = zK(b, 3);
            b = xK(d.slice(0, 2));
            if (b < 0 || b > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${b}.`);
            b += 1;
            d = xK(d.charAt(2));
            c = new NK;
            b = M(c, 2, b);
            b = J(b, 1, !!d);
            b = z(a, 2, b)
        }
        return b
    };
    var TK = class extends N {
        i() {
            return I(this, 1)
        }
        j() {
            return I(this, 2)
        }
        l() {
            return I(this, 3)
        }
    };
    var UK = class extends N {};
    var VK = class extends N {
        getVersion() {
            return oh(this, 1)
        }
    };
    var WK = class extends N {};

    function XK(a) {
        var b = new YK;
        return z(b, 1, a)
    }
    var YK = class extends N {};
    const ZK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        $K = 6 + ZK.reduce((a, b) => a + b);

    function aL(a) {
        if (a.length === 0) throw Error("Cannot decode empty usct section string.");
        var b = a.split(".");
        if (b.length > 2) throw Error(`Expected at most 2 segments but got ${b.length} when decoding ${a}.`);
        a = b[0];
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = zK(a, $K),
            d = xK(c.slice(0, 6));
        c = c.slice(6);
        if (d !== 1) throw Error(`Unable to decode unsupported USCT Section specification version ${d} - only version 1 is supported.`);
        var e = 0;
        a = [];
        for (let f = 0; f < ZK.length; f++) {
            const g =
                ZK[f];
            a.push(xK(c.slice(e, e + g)));
            e += g
        }
        c = new VK;
        d = Ah(c, 1, d);
        c = a.shift();
        d = M(d, 2, c);
        c = a.shift();
        d = M(d, 3, c);
        c = a.shift();
        d = M(d, 4, c);
        c = a.shift();
        d = M(d, 5, c);
        c = a.shift();
        d = M(d, 6, c);
        c = new UK;
        e = a.shift();
        c = M(c, 1, e);
        e = a.shift();
        c = M(c, 2, e);
        e = a.shift();
        c = M(c, 3, e);
        e = a.shift();
        c = M(c, 4, e);
        e = a.shift();
        c = M(c, 5, e);
        e = a.shift();
        c = M(c, 6, e);
        e = a.shift();
        c = M(c, 7, e);
        e = a.shift();
        c = M(c, 8, e);
        d = z(d, 7, c);
        c = new TK;
        e = a.shift();
        c = M(c, 1, e);
        e = a.shift();
        c = M(c, 2, e);
        e = a.shift();
        c = M(c, 3, e);
        d = z(d, 8, c);
        c = a.shift();
        d = M(d, 9, c);
        c = a.shift();
        d = M(d, 10, c);
        a = a.shift();
        a = M(d, 11, a);
        if (b.length === 1) b = XK(a);
        else {
            a = XK(a);
            b = b[1];
            if (b.length === 0) throw Error("Cannot decode empty GPC segment string.");
            d = zK(b, 3);
            b = xK(d.slice(0, 2));
            if (b < 0 || b > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${b}.`);
            b += 1;
            d = xK(d.charAt(2));
            c = new WK;
            b = M(c, 2, b);
            b = J(b, 1, !!d);
            b = z(a, 2, b)
        }
        return b
    };
    var bL = class extends N {
        i() {
            return I(this, 1)
        }
        j() {
            return I(this, 2)
        }
        l() {
            return I(this, 3)
        }
    };
    var cL = class extends N {};
    var dL = class extends N {
        getVersion() {
            return oh(this, 1)
        }
    };
    const eL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        fL = 6 + eL.reduce((a, b) => a + b);

    function gL(a) {
        if (a.length === 0) throw Error("Cannot decode empty USFL section string.");
        var b = zK(a, fL),
            c = xK(b.slice(0, 6));
        b = b.slice(6);
        if (c !== 1) throw Error(`Unable to decode unsupported USFL Section specification version ${c} - only version 1 is supported.`);
        var d = 0;
        a = [];
        for (let e = 0; e < eL.length; e++) {
            const f = eL[e];
            a.push(xK(b.slice(d, d + f)));
            d += f
        }
        b = new dL;
        c = Ah(b, 1, c);
        b = a.shift();
        c = M(c, 2, b);
        b = a.shift();
        c = M(c, 3, b);
        b = a.shift();
        c = M(c, 4, b);
        b = a.shift();
        c = M(c, 5, b);
        b = a.shift();
        c = M(c, 6, b);
        b = new cL;
        d = a.shift();
        b = M(b, 1, d);
        d = a.shift();
        b = M(b, 2, d);
        d = a.shift();
        b = M(b, 3, d);
        d = a.shift();
        b = M(b, 4, d);
        d = a.shift();
        b = M(b, 5, d);
        d = a.shift();
        b = M(b, 6, d);
        d = a.shift();
        b = M(b, 7, d);
        d = a.shift();
        b = M(b, 8, d);
        c = z(c, 7, b);
        b = new bL;
        d = a.shift();
        b = M(b, 1, d);
        d = a.shift();
        b = M(b, 2, d);
        d = a.shift();
        b = M(b, 3, d);
        c = z(c, 8, b);
        b = a.shift();
        c = M(c, 9, b);
        b = a.shift();
        c = M(c, 10, b);
        b = a.shift();
        c = M(c, 11, b);
        a = a.shift();
        return M(c, 12, a)
    };
    var hL = class extends N {
        i() {
            return I(this, 1)
        }
        j() {
            return I(this, 2)
        }
    };
    var iL = class extends N {};
    var jL = class extends N {
        getVersion() {
            return oh(this, 1)
        }
    };
    var kL = class extends N {};

    function lL(a) {
        var b = new mL;
        return z(b, 1, a)
    }
    var mL = class extends N {};
    const nL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        oL = 6 + nL.reduce((a, b) => a + b);

    function pL(a) {
        if (a.length === 0) throw Error("Cannot decode empty USNat section string.");
        var b = a.split(".");
        if (b.length > 2) throw Error(`Expected at most 2 segments but got ${b.length} when decoding ${a}.`);
        a = b[0];
        if (a.length === 0) throw Error("Cannot decode empty core segment string.");
        var c = zK(a, oL),
            d = xK(c.slice(0, 6));
        c = c.slice(6);
        if (d !== 1) throw Error(`Unable to decode unsupported USNat Section specification version ${d} - only version 1 is supported.`);
        var e = 0;
        a = [];
        for (let f = 0; f < nL.length; f++) {
            const g =
                nL[f];
            a.push(xK(c.slice(e, e + g)));
            e += g
        }
        c = new jL;
        d = Ah(c, 1, d);
        c = a.shift();
        d = M(d, 2, c);
        c = a.shift();
        d = M(d, 3, c);
        c = a.shift();
        d = M(d, 4, c);
        c = a.shift();
        d = M(d, 5, c);
        c = a.shift();
        d = M(d, 6, c);
        c = a.shift();
        d = M(d, 7, c);
        c = a.shift();
        d = M(d, 8, c);
        c = a.shift();
        d = M(d, 9, c);
        c = a.shift();
        d = M(d, 10, c);
        c = new iL;
        e = a.shift();
        c = M(c, 1, e);
        e = a.shift();
        c = M(c, 2, e);
        e = a.shift();
        c = M(c, 3, e);
        e = a.shift();
        c = M(c, 4, e);
        e = a.shift();
        c = M(c, 5, e);
        e = a.shift();
        c = M(c, 6, e);
        e = a.shift();
        c = M(c, 7, e);
        e = a.shift();
        c = M(c, 8, e);
        e = a.shift();
        c = M(c, 9, e);
        e = a.shift();
        c = M(c,
            10, e);
        e = a.shift();
        c = M(c, 11, e);
        e = a.shift();
        c = M(c, 12, e);
        d = z(d, 11, c);
        c = new hL;
        e = a.shift();
        c = M(c, 1, e);
        e = a.shift();
        c = M(c, 2, e);
        d = z(d, 12, c);
        c = a.shift();
        d = M(d, 13, c);
        c = a.shift();
        d = M(d, 14, c);
        c = a.shift();
        d = M(d, 15, c);
        a = a.shift();
        a = M(d, 16, a);
        if (b.length === 1) b = lL(a);
        else {
            a = lL(a);
            b = b[1];
            if (b.length === 0) throw Error("Cannot decode empty GPC segment string.");
            d = zK(b, 3);
            b = xK(d.slice(0, 2));
            if (b < 0 || b > 1) throw Error(`Attempting to decode unknown GPC segment subsection type ${b}.`);
            b += 1;
            d = xK(d.charAt(2));
            c = new kL;
            b = M(c,
                2, b);
            b = J(b, 1, !!d);
            b = z(a, 2, b)
        }
        return b
    };
    var qL = class extends N {};
    var rL = class extends N {
        getVersion() {
            return oh(this, 1)
        }
    };
    const sL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        tL = 6 + sL.reduce((a, b) => a + b);

    function uL(a) {
        if (a.length === 0) throw Error("Cannot decode empty USVA section string.");
        var b = zK(a, tL),
            c = xK(b.slice(0, 6));
        b = b.slice(6);
        if (c !== 1) throw Error(`Unable to decode unsupported USVA Section specification version ${c} - only version 1 is supported.`);
        var d = 0;
        a = [];
        for (let e = 0; e < sL.length; e++) {
            const f = sL[e];
            a.push(xK(b.slice(d, d + f)));
            d += f
        }
        b = new rL;
        c = Ah(b, 1, c);
        b = a.shift();
        c = M(c, 2, b);
        b = a.shift();
        c = M(c, 3, b);
        b = a.shift();
        c = M(c, 4, b);
        b = a.shift();
        c = M(c, 5, b);
        b = a.shift();
        c = M(c, 6, b);
        b = new qL;
        d = a.shift();
        b = M(b, 1, d);
        d = a.shift();
        b = M(b, 2, d);
        d = a.shift();
        b = M(b, 3, d);
        d = a.shift();
        b = M(b, 4, d);
        d = a.shift();
        b = M(b, 5, d);
        d = a.shift();
        b = M(b, 6, d);
        d = a.shift();
        b = M(b, 7, d);
        d = a.shift();
        b = M(b, 8, d);
        c = z(c, 7, b);
        b = a.shift();
        c = M(c, 8, b);
        b = a.shift();
        c = M(c, 9, b);
        b = a.shift();
        c = M(c, 10, b);
        a = a.shift();
        return M(c, 11, a)
    };
    var vL = class extends N {};

    function wL(a, b) {
        return Yg(a, 1, b, xf)
    }

    function xL(a, b) {
        return Yg(a, 2, b, xf)
    }

    function yL(a, b) {
        return Yg(a, 3, b, zf)
    }

    function zL(a, b) {
        Yg(a, 4, b, zf)
    }
    var AL = class extends N {};

    function BL(a, b) {
        return Ch(a, 1, b)
    }

    function CL(a) {
        var b = Number; {
            var c = Gg(a, 1);
            const d = typeof c;
            c = c == null ? c : d === "bigint" ? String(mf(64, c)) : wf(c) ? d === "string" ? Ef(c) : Ff(c) : void 0
        }
        b = b(c ? ? "0");
        a = oh(a, 2);
        return new Date(b * 1E3 + a / 1E6)
    }
    var DL = class extends N {};

    function EL(a, b) {
        return Ah(a, 1, b)
    }

    function FL(a, b) {
        return z(a, 2, b)
    }

    function GL(a, b) {
        return z(a, 3, b)
    }

    function HL(a, b) {
        return Ah(a, 4, b)
    }

    function IL(a, b) {
        return Ah(a, 5, b)
    }

    function JL(a, b) {
        return Ah(a, 6, b)
    }

    function KL(a, b) {
        return Eh(a, 7, b)
    }

    function LL(a, b) {
        return Ah(a, 8, b)
    }

    function ML(a, b) {
        return Ah(a, 9, b)
    }

    function NL(a, b) {
        return J(a, 10, b)
    }

    function OL(a, b) {
        return J(a, 11, b)
    }

    function PL(a, b) {
        return Yg(a, 12, b, xf)
    }

    function QL(a, b) {
        return Yg(a, 13, b, xf)
    }

    function RL(a, b) {
        return Yg(a, 14, b, xf)
    }

    function SL(a, b) {
        return J(a, 15, b)
    }

    function TL(a, b) {
        return Eh(a, 16, b)
    }

    function UL(a, b) {
        return Yg(a, 17, b, zf)
    }

    function VL(a, b) {
        return Yg(a, 18, b, zf)
    }

    function WL(a, b) {
        return ih(a, 19, b)
    }
    var XL = class extends N {
        getVersion() {
            return oh(this, 1)
        }
    };
    var YL = class extends N {};
    var ZL = "a".charCodeAt(),
        $L = Pb(qp),
        aM = Pb(rp);

    function bM(a, b) {
        if (a.g + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.i.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function cM(a) {
        a = bM(a, 36);
        var b = BL(new DL, Math.floor(a / 10));
        return Ah(b, 2, a % 10 * 1E8)
    }

    function dM(a) {
        return String.fromCharCode(ZL + bM(a, 6)) + String.fromCharCode(ZL + bM(a, 6))
    }

    function eM(a) {
        let b = bM(a, 12);
        const c = [];
        for (; b--;) {
            var d = !!bM(a, 1) === !0,
                e = bM(a, 16);
            if (d)
                for (d = bM(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function fM(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (bM(a, 1)) {
                const f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function gM(a) {
        const b = bM(a, 16);
        return !!bM(a, 1) === !0 ? (a = eM(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : fM(a, b)
    }

    function hM(a) {
        const b = [];
        let c = bM(a, 12);
        for (; c--;) {
            const k = bM(a, 6);
            var d = bM(a, 2),
                e = eM(a),
                f = b,
                g = f.push;
            var h = new vL;
            h = M(h, 1, k);
            d = M(h, 2, d);
            e = Yg(d, 3, e, zf);
            g.call(f, e)
        }
        return b
    }
    var iM = class {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.i = a;
            this.g = 0
        }
        skip(a) {
            this.g += a
        }
    };
    var jM = a => {
        try {
            const b = Td(a).map(f => f.toString(2).padStart(8, "0")).join(""),
                c = new iM(b);
            if (bM(c, 3) !== 3) return null;
            const d = xL(wL(new AL, fM(c, 24, $L)), fM(c, 24, $L)),
                e = bM(c, 6);
            e !== 0 && zL(yL(d, fM(c, e)), fM(c, e));
            return d
        } catch (b) {
            return null
        }
    };
    var kM = a => {
        try {
            const b = Td(a).map(d => d.toString(2).padStart(8, "0")).join(""),
                c = new iM(b);
            return WL(VL(UL(TL(SL(RL(QL(PL(OL(NL(ML(LL(KL(JL(IL(HL(GL(FL(EL(new XL, bM(c, 6)), cM(c)), cM(c)), bM(c, 12)), bM(c, 12)), bM(c, 6)), dM(c)), bM(c, 12)), bM(c, 6)), !!bM(c, 1)), !!bM(c, 1)), fM(c, 12, aM)), fM(c, 24, $L)), fM(c, 24, $L)), !!bM(c, 1)), dM(c)), gM(c)), gM(c)), hM(c))
        } catch (b) {
            return null
        }
    };
    var mM = a => {
        if (!a) return null;
        a = a.split(".");
        if (a.length > 4) return null;
        var b = kM(a[0]);
        if (!b) return null;
        var c = new YL;
        b = z(c, 1, b);
        a.shift();
        for (const d of a) switch (lM(d)) {
            case 1:
            case 2:
                break;
            case 3:
                a = jM(d);
                if (!a) return null;
                z(b, 2, a);
                break;
            default:
                return null
        }
        return b
    };
    const lM = a => {
        try {
            const b = Td(a).map(c => c.toString(2).padStart(8, "0")).join("");
            return bM(new iM(b), 3)
        } catch (b) {
            return -1
        }
    };
    var oM = a => {
        var b = mM(a);
        if (!b || !a) return null;
        var c = y(b, XL, 1),
            d = y(b, AL, 2) || new AL;
        b = oh(c, 9);
        var e = oh(c, 4),
            f = oh(c, 5),
            g = E(c, 10),
            h = E(c, 11),
            k = F(c, 16),
            l = E(c, 15);
        var m = th(c, 13);
        m = nM(m, $L);
        var n = th(c, 14);
        m = {
            consents: m,
            legitimateInterests: nM(n, $L)
        };
        n = rh(c, 17);
        n = nM(n);
        var p = rh(c, 18);
        n = {
            consents: n,
            legitimateInterests: nM(p)
        };
        p = th(c, 12);
        p = nM(p, aM);
        var t = hh(c, vL, 19, Pg());
        c = {};
        for (var v of t) {
            t = I(v, 1);
            c[t] = c[t] || {};
            for (var w of rh(v, 3)) c[t][w] = I(v, 2)
        }
        v = th(d, 1);
        v = nM(v, $L);
        w = th(d, 2);
        w = nM(w, $L);
        t = rh(d, 3);
        t = nM(t);
        d =
            rh(d, 4);
        return {
            tcString: a,
            tcfPolicyVersion: b,
            gdprApplies: !0,
            cmpId: e,
            cmpVersion: f,
            isServiceSpecific: g,
            useNonStandardStacks: h,
            publisherCC: k,
            purposeOneTreatment: l,
            purpose: m,
            vendor: n,
            specialFeatureOptins: p,
            publisher: {
                restrictions: c,
                consents: v,
                legitimateInterests: w,
                customPurposes: {
                    consents: t,
                    legitimateInterests: nM(d)
                }
            }
        }
    };
    const nM = (a, b) => {
        const c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (const d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var qM = (a, b) => {
        try {
            var c = Td(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new iM(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = b;
            d.skip(78);
            c.cmpId = bM(d, 12);
            c.cmpVersion = bM(d, 12);
            d.skip(30);
            c.tcfPolicyVersion = bM(d, 6);
            c.isServiceSpecific = !!bM(d, 1);
            c.useNonStandardStacks = !!bM(d, 1);
            c.specialFeatureOptins = pM(fM(d, 12, aM), aM);
            c.purpose = {
                consents: pM(fM(d, 24, $L), $L),
                legitimateInterests: pM(fM(d, 24, $L), $L)
            };
            c.purposeOneTreatment = !!bM(d, 1);
            c.publisherCC = dM(d);
            c.vendor = {
                consents: pM(gM(d), null),
                legitimateInterests: pM(gM(d), null)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const pM = (a, b) => {
        const c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (const d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };

    function Yo(a, ...b) {
        try {
            const c = encodeURIComponent(Qd(Cl(b, a.i)));
            a.j(`${"https://pagead2.googlesyndication.com/pagead/ping"}?e=${4}&d=${c}`)
        } catch (c) {
            Bl(c, a.i)
        }
    }
    var rM = class extends Zo {
        constructor(a) {
            super(7, to());
            this.j = a
        }
    };
    var sM = class extends N {
        i() {
            return D(this, 2) != null
        }
    };
    var tM = class extends N {
        l() {
            return D(this, 2) != null
        }
    };
    var uM = class extends N {
        j() {
            return D(this, 1) != null
        }
    };
    var vM = sj(class extends N {});

    function wM(a) {
        a = xM(a);
        try {
            var b = a ? vM(a) : null
        } catch (c) {
            b = null
        }
        return b ? y(b, uM, 4) || null : null
    }

    function xM(a) {
        a = (new aK(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function yM(a) {
        a.__tcfapiPostMessageReady || zM(new AM(a))
    }

    function zM(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.win.__tcfapi)(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.win.addEventListener("message", a.g);
        a.win.__tcfapiPostMessageReady = !0
    }
    var AM = class {
        constructor(a) {
            this.win = a
        }
    };

    function BM(a) {
        a.__uspapiPostMessageReady || CM(new DM(a))
    }

    function CM(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.win.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.win.addEventListener("message", a.g);
        a.win.__uspapiPostMessageReady = !0
    }
    var DM = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
    };
    var EM = class extends N {};
    var FM = sj(class extends N {
        i() {
            return D(this, 1) != null
        }
    });

    function GM(a, b) {
        function c(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 4));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function d(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function e(n) {
            if (n.length < 12) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(8, 12));
            n = l(n);
            return "1" + p + n + "N"
        }

        function f(n) {
            if (n.length < 18) return null;
            var p = h(n.slice(0, 8));
            p = k(p);
            n = h(n.slice(12, 18));
            n = l(n);
            return "1" + p + n + "N"
        }

        function g(n) {
            if (n.length < 10) return null;
            var p = h(n.slice(0, 6));
            p = k(p);
            n = h(n.slice(6, 10));
            n = l(n);
            return "1" + p + n + "N"
        }

        function h(n) {
            const p = [];
            let t = 0;
            for (let v = 0; v < n.length / 2; v++) p.push(xK(n.slice(t, t + 2))), t += 2;
            return p
        }

        function k(n) {
            return n.every(p => p === 1) ? "Y" : "N"
        }

        function l(n) {
            return n.some(p => p === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = wK(a[0]);
        const m = xK(a.slice(0, 6));
        a = a.slice(6);
        if (m !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function HM(a) {
        !a.l || a.win.__uspapi || a.win.frames.__uspapiLocator || (a.win.__uspapiManager = "fc", aF(a.win, "__uspapiLocator"), Ba("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && d({
                version: 1,
                uspString: a.i && !E(a.j, 3) ? "1---" : a.l
            }, !0)
        }, a.win), BM(a.win))
    }

    function IM(a) {
        !a.tcString || a.win.__tcfapi || a.win.frames.__tcfapiLocator || (a.win.__tcfapiManager = "fc", aF(a.win, "__tcfapiLocator"), a.win.__tcfapiEventListeners = a.win.__tcfapiEventListeners || [], Ba("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.2 || c <= 1)) d(null, !1);
                else {
                    var f = a.win.__tcfapiEventListeners;
                    c = a.i && !E(a.j, 1);
                    switch (b) {
                        case "ping":
                            d({
                                gdprApplies: !c,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.2",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            e =
                                f.push(d);
                            b = !c;
                            --e;
                            a.tcString ? (b = qM(a.tcString, b), b.addtlConsent = a.g != null ? a.g : void 0, b.cmpStatus = "loaded", b.eventStatus = "tcloaded", e != null && (b.listenerId = e)) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && f[e] ? (f[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
                }
        }, a.win), yM(a.win))
    }

    function JM(a) {
        if (!a ? .i() || F(a, 1).length === 0 || hh(a, EM, 2, Pg()).length === 0) return null;
        const b = F(a, 1);
        let c;
        try {
            var d = AK(b.split("~")[0]);
            c = vK(b)
        } catch (e) {
            return null
        }
        a = hh(a, EM, 2, Pg()).reduce((e, f) => ph(KM(e), 1) > ph(KM(f), 1) ? e : f);
        d = rh(d, 3).indexOf(oh(a, 1));
        return d === -1 || d >= c.length ? null : {
            uspString: GM(c[d], oh(a, 1)),
            ef: CL(KM(a))
        }
    }

    function LM(a) {
        a = a.find(b => b && I(b, 1) === 13);
        if (a ? .i()) try {
            return FM(F(a, 2))
        } catch (b) {}
        return null
    }

    function KM(a) {
        return Kg(a, DL, 2) ? y(a, DL, 2) : BL(new DL, 0)
    }
    var MM = class {
        constructor(a, b, c) {
            this.win = a;
            this.j = b;
            this.i = c;
            b = xM(this.win.document);
            try {
                var d = b ? vM(b) : null
            } catch (e) {
                d = null
            }(b = d) ? (d = y(b, tM, 5) || null, b = hh(b, sM, 7, Pg()), b = LM(b ? ? []), d = {
                Ng: d,
                jh: b
            }) : d = {
                Ng: null,
                jh: null
            };
            b = d;
            d = JM(b.jh);
            b = b.Ng;
            b ? .l() && F(b, 2).length !== 0 ? (c = Kg(b, DL, 1) ? y(b, DL, 1) : BL(new DL, 0), b = {
                uspString: F(b, 2),
                ef: CL(c)
            }) : b = null;
            this.l = b && d ? d.ef > b.ef ? d.uspString : b.uspString : b ? b.uspString : d ? d.uspString : null;
            this.tcString = (d = wM(a.document)) && d.j() ? F(d, 1) : null;
            this.g = (a = wM(a.document)) && D(a, 2) !=
                null ? F(a, 2) : null
        }
    };

    function NM() {
        const a = vb();
        return a ? Na("AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;WebOS".split(";"), b => ub(a, b)) || ub(a, "OMI/") && !ub(a, "XiaoMi/") ? !0 : ub(a, "Presto") && ub(a, "Linux") && !ub(a, "X11") && !ub(a, "Android") && !ub(a, "Mobi") : !1
    };

    function OM(a) {
        const b = a[0] / 255,
            c = a[1] / 255;
        a = a[2] / 255;
        return (b <= .03928 ? b / 12.92 : Math.pow((b + .055) / 1.055, 2.4)) * .2126 + (c <= .03928 ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4)) * .7152 + (a <= .03928 ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4)) * .0722
    }
    var PM = (a, b) => {
        a = OM(a);
        b = OM(b);
        return (Math.max(a, b) + .05) / (Math.min(a, b) + .05)
    };
    var QM = (a, b, c, d = null) => {
            const e = g => {
                let h;
                try {
                    h = JSON.parse(g.data)
                } catch (k) {
                    return
                }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
            };
            lb(a, "message", e);
            let f = !1;
            return () => {
                let g = !1;
                f || (f = !0, g = mb(a, "message", e));
                return g
            }
        },
        RM = (a, b, c, d = null) => {
            const e = QM(a, b, cb(c, () => e()), d);
            return e
        },
        SM = (a, b, c, d, e) => {
            if (!(e <= 0) && (c.googMsgType = b, a.postMessage(JSON.stringify(c), d), a = a.frames))
                for (let f = 0; f < a.length; ++f) e > 1 && SM(a[f], b, c, d, --e)
        };

    function TM(a, b, c, d) {
        return QM(a, "fullscreen", d.Xa(952, (e, f) => {
            if (f.source === b) {
                if (!("eventType" in e)) throw Error(`bad message ${JSON.stringify(e)}`);
                delete e.googMsgType;
                c(e)
            }
        }))
    };
    class UM {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };
    async function VM(a) {
        return a.A.promise
    }
    async function WM(a) {
        return a.j.promise
    }
    async function XM(a) {
        return a.l.promise
    }

    function YM(a, b) {
        b.type = "err_st";
        b.slot = a.slotType;
        b.freq = .25;
        a.qem && (b.qem = a.qem);
        b.tag_type = a.D.Tk;
        b.version = a.D.version;
        wl(a.H, "fullscreen_tag", b, !1, .25)
    }
    class ZM extends S {
        constructor(a, b, c, d, e) {
            var f = fy;
            super();
            this.slotType = a;
            this.pubWin = b;
            this.df = c;
            this.Aa = d;
            this.H = f;
            this.D = e;
            this.g = 1;
            this.qem = null;
            this.A = new UM;
            this.j = new UM;
            this.l = new UM
        }
        L() {
            const a = TM(this.pubWin, this.df, b => {
                if (b.eventType === "adError") this.l.resolve(), this.g = 4;
                else if (b.eventType === "adReady" && this.g === 1) this.qem = b.qem, b.slotType !== this.slotType && (YM(this, {
                    cur_st: this.g,
                    evt: b.eventType,
                    adp_tp: b.slotType
                }), this.g = 4), this.A.resolve(), this.g = 2;
                else if (b.eventType === "adClosed" &&
                    this.g === 2) this.j.resolve(b.result), this.g = 3;
                else if (b.eventType !== "adClosed" || this.g !== 3) YM(this, {
                    cur_st: this.g,
                    evt: b.eventType
                }), this.g = 4
            }, this.Aa);
            cq(this, a)
        }
    };
    var $M = Promise;
    class aN {
        constructor(a) {
            this.j = a
        }
        i(a, b, c) {
            this.j.then(d => {
                d.i(a, b, c)
            })
        }
        g(a, b) {
            return this.j.then(c => c.g(a, b))
        }
    };
    class bN {
        constructor(a) {
            this.data = a
        }
    };

    function cN(a, b) {
        dN(a, b);
        return new eN(a)
    }
    class eN {
        constructor(a) {
            this.j = a
        }
        i(a, b, c = []) {
            const d = new MessageChannel;
            dN(d.port1, b);
            this.j.postMessage(a, [d.port2].concat(c))
        }
        g(a, b) {
            return new $M(c => {
                this.i(a, c, b)
            })
        }
    }

    function dN(a, b) {
        b && (a.onmessage = c => {
            b(new bN(c.data, cN(c.ports[0])))
        })
    };
    var fN = class {
        constructor(a) {
            this.g = a
        }
    };
    const gN = a => {
        const b = Object.create(null);
        (typeof a === "string" ? [a] : a).forEach(c => {
            if (c === "null") throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
            b[c] = !0
        });
        return c => b[c] === !0
    };
    var iN = ({
        destination: a,
        Ca: b,
        origin: c,
        We: d = "ZNWN1d",
        onMessage: e,
        Kh: f
    }) => hN({
        destination: a,
        Gj: () => b.contentWindow,
        qk: c instanceof fN ? c : typeof c === "function" ? new fN(c) : new fN(gN(c)),
        We: d,
        onMessage: e,
        Kh: f
    });
    const hN = ({
        destination: a,
        Gj: b,
        qk: c,
        Xo: d,
        We: e,
        onMessage: f,
        Kh: g
    }) => new aN(new $M((h, k) => {
        const l = m => {
            m.source && m.source === b() && c.g(m.origin) && (m.data.n || m.data) === e && (a.removeEventListener("message", l, !1), d && m.data.t !== d ? k(Error(`Token mismatch while establishing channel "${e}". Expected ${d}, but received ${m.data.t}.`)) : (h(cN(m.ports[0], f)), g && g(m)))
        };
        a.addEventListener("message", l, !1)
    }));
    var jN = qj(Tl);
    var kN = qj(Ul);
    var lN = qj(Wl);
    var mN = qj(Sl);
    var nN = qj(Vl);

    function oN() {
        const {
            promise: a,
            resolve: b
        } = new UM;
        return {
            promise: a,
            resolve: b
        }
    };

    function pN(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        let d = b[a];
        if (d) return d;
        d = oN();
        b[a] = d;
        c();
        return d
    }

    function qN(a, b, c) {
        return pN(a, b, () => {
            ad(b.document, c)
        }).promise
    };
    var rN = class {
        constructor(a) {
            this.qc = a
        }
        runAutoGames({
            win: a,
            webPropertyCode: b,
            config: c,
            floatingToolbarManager: d,
            Ji: e,
            jb: f,
            storage: g
        }) {
            ly(1116, qN(12, a, this.qc).then(h => {
                h.runAutoGames({
                    win: a,
                    webPropertyCode: b,
                    serializedConfig: Hh(c),
                    floatingToolbarManager: d,
                    serializedArticleStructures: e.map(k => Hh(k)),
                    serializedPlacements: f.map(k => Hh(k)),
                    storage: g
                })
            }))
        }
    };
    var sN = {
            em: "google_ads_preview",
            Bm: "google_mc_lab",
            Km: "google_anchor_debug",
            Jm: "google_bottom_anchor_debug",
            INTERSTITIAL: "google_ia_debug",
            hn: "google_scr_debug",
            ln: "google_ia_debug_allow_onclick",
            Hn: "googleads",
            ui: "google_pedestal_debug",
            bo: "google_responsive_slot_preview",
            ao: "google_responsive_dummy_ad"
        },
        tN = {
            google_bottom_anchor_debug: 1,
            google_anchor_debug: 2,
            google_ia_debug: 8,
            google_scr_debug: 9,
            googleads: 2,
            google_pedestal_debug: 30
        };
    var uN = {
        INTERSTITIAL: 1,
        BOTTOM_ANCHOR: 2,
        TOP_ANCHOR: 3,
        1: "INTERSTITIAL",
        2: "BOTTOM_ANCHOR",
        3: "TOP_ANCHOR"
    };

    function vN(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        b = wN(b);
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    }

    function wN(a) {
        let b = "";
        ed(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    }

    function xN() {
        var a = q.location;
        let b = !1;
        ed(sN, c => {
            vN(a, c) && (b = !0)
        });
        return b
    }

    function yN(a, b) {
        switch (a) {
            case 1:
                return vN(b, "google_ia_debug");
            case 2:
                return vN(b, "google_bottom_anchor_debug");
            case 3:
                return vN(b, "google_anchor_debug") || vN(b, "googleads")
        }
    };

    function zN(a) {
        var b = window;
        return a.google_adtest === "on" || a.google_adbreak_test === "on" || b.location.host.endsWith("h5games.usercontent.goog") || b.location.host === "gamesnacks.com" ? b.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(c => Math.floor(Number(c))).filter(c => !isNaN(c) && c > 0) || [] : []
    };

    function AN(a, b) {
        b && !a.g && (b = BN(b), a.g = b.id, a.j = b.creationTimeSeconds)
    }
    var CN = class {
            constructor() {
                this.l = new Date(Date.now());
                this.j = this.g = null;
                this.i = {
                    [3]: {},
                    [4]: {},
                    [5]: {}
                };
                this.i[3] = {
                    [71]: (...a) => {
                        var b = this.g;
                        var c = this.l,
                            d = Number(a[0]);
                        a = Number(a[1]);
                        b = b !== null ? gd(`${"w5uHecUBa2S"}:${d}:${b}`) % a === Math.floor(c.valueOf() / 864E5) % a : void 0;
                        return b
                    }
                };
                this.i[4] = {
                    [15]: () => {
                        var a = Number(this.j || void 0);
                        isNaN(a) ? a = void 0 : (a = new Date(a * 1E3), a = a.getFullYear() * 1E4 + (a.getMonth() + 1) * 100 + a.getDate());
                        return a
                    }
                }
            }
        },
        DN;
    let EN = void 0;

    function FN() {
        Le(EN, Oe);
        return EN
    };

    function GN(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : Mb(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && typeof e === "string" && Array.isArray(d))
        } catch (b) {
            return {}
        }
    };

    function HN(a = q) {
        return a.ggeac || (a.ggeac = {})
    };

    function IN(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function JN(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    }

    function KN(a = navigator) {
        try {
            return !!a.protectedAudience ? .queryFeatureSupport ? .("deprecatedRenderURLReplacements")
        } catch (b) {
            return !1
        }
    }

    function LN(a, b, c = b.document) {
        return !!(a && "sharedStorage" in b && b.sharedStorage && JN("shared-storage", c))
    };

    function MN(a = dd()) {
        return b => gd(`${b} + ${a}`) % 1E3
    };

    function NN(a, b) {
        a.g = gp(14, b, () => {})
    }
    class ON {
        constructor() {
            this.g = () => {}
        }
    }

    function PN(a) {
        R(ON).g(a)
    };

    function QN(a = HN()) {
        hp(R(ip), a);
        RN(a);
        NN(R(ON), a);
        R(Kv).i()
    }

    function RN(a) {
        const b = R(Kv);
        b.j = (c, d) => gp(5, a, () => !1)(c, d, 1);
        b.B = (c, d) => gp(6, a, () => 0)(c, d, 1);
        b.A = (c, d) => gp(7, a, () => "")(c, d, 1);
        b.g = (c, d) => gp(8, a, () => [])(c, d, 1);
        b.l = (c, d) => gp(17, a, () => [])(c, d, 1);
        b.i = () => {
            gp(15, a, () => {})(1)
        }
    };

    function BN(a) {
        var b = a.split(":");
        a = b.find(c => c.indexOf("ID=") === 0) || null;
        b = b.find(c => c.indexOf("T=") === 0) ? .substring(2) || null;
        return {
            id: a,
            creationTimeSeconds: b
        }
    }

    function SN(a, b, c) {
        return c ? c.i() ? gK(b, a.win) : null : null
    }

    function TN(a, b, c, d) {
        if (d) {
            var e = ph(c, 2) - Date.now() / 1E3;
            e = {
                Ud: Math.max(e, 0),
                path: F(c, 3),
                domain: F(c, 4),
                te: !1
            };
            c = c.getValue();
            d.i() && hK(b, c, e, a.win)
        }
    }

    function UN(a, b, c) {
        if (c && c.i() && gK(b, a.win))
            for (const f of VN(a.win.location.hostname))
                if (c.i()) {
                    var d = b,
                        e = a.win;
                    e.origin !== "null" && bK(new aK(e.document), d, "/", f)
                }
    }
    var WN = class {
        constructor(a) {
            this.win = a
        }
    };

    function VN(a) {
        if (a === "localhost") return ["localhost"];
        a = a.split(".");
        if (a.length < 2) return [];
        const b = [];
        for (let c = 0; c < a.length - 1; ++c) b.push(a.slice(c).join("."));
        return b
    };

    function XN(a, b, c) {
        var d = {
            [0]: MN(Fd(b).toString())
        };
        if (c) {
            c = SN(new WN(b), "__gads", c) || "";
            DN || (DN = new CN);
            b = DN;
            AN(b, c);
            PN(b.i);
            const e = (new RegExp(/(?:^|:)(ID=[^\s:]+)/)).exec(c) ? .[1];
            d[1] = f => e ? MN(e)(f) : void 0
        }
        d = jp(a, d);
        np.Fa(1085, JE(R(HE), a, d))
    }

    function YN(a, b) {
        XN(20, a, b);
        XN(17, a, b)
    }

    function ZN(a) {
        const b = R(ip).g();
        a = zN(a);
        return b.concat(a).join(",")
    }

    function $N(a) {
        const b = fl();
        b && (a.debug_experiment_id = b)
    };

    function aO(a, b) {
        if (a && !sE(a).ads_density_stats_processed && !jk(a) && (sE(a).ads_density_stats_processed = !0, W(St) || dd() < .01)) {
            const c = () => {
                if (a) {
                    var d = II(DI(a), b.google_ad_client, a.location.hostname, ZN(b).split(","));
                    my("ama_stats", d, 1)
                }
            };
            Gd(a, () => {
                q.setTimeout(c, 1E3)
            })
        }
    };

    function bO(a, b, c, d, e, f, g = null) {
        if (e) {
            if (W(ut)) var h = null;
            else try {
                h = e.getItem("google_ama_config")
            } catch (m) {
                h = null
            }
            try {
                var k = h ? Es(h) : null
            } catch (m) {
                k = null
            }
        } else k = null;
        a: {
            if (d) try {
                var l = Es(d);
                break a
            } catch (m) {
                CJ(a, {
                    cfg: 1,
                    inv: 1
                })
            }
            l = null
        }
        if (d = l) {
            if (e) {
                l = new Sr;
                z(d, 3, l);
                k = d ? .i() ? .j() || 1;
                k = Date.now() + 864E5 * k;
                Number.isFinite(k) && Bh(l, 1, Math.round(k));
                l = Eg(d);
                d.i() && (k = new Rr, h = d ? .i() ? .i(), k = yh(k, 23, h), h = d ? .i() ? .l(), k = yh(k, 12, h), z(l, 15, k));
                k = Ds(l);
                for (h = 0; h < k.length; h++) Ig(k[h], 11);
                Ig(l, 22);
                if (W(ut)) JJ(a,
                    e);
                else try {
                    e.setItem("google_ama_config", Hh(l))
                } catch (m) {
                    CJ(a, {
                        lserr: 1
                    })
                }
            }
            l = HJ(a, hh(d, as, 7, Pg()));
            k = {};
            W(vt) || (k.Bk = y(d, ks, 8) || new ks);
            l && (k.ba = l);
            l && GJ(l, 3) && (k.Gc = [1]);
            l = k;
            tE(a, 2) && (Yj(5, [vg(d)]), c = DJ(c), f = new rN(f), k = l.ba, c.google_package = k && D(k, 4) || "", LJ(a, b, d, l, e, f, new Ir(["google-auto-placed"], c), g));
            return !0
        }
        k && (CJ(a, {
            cfg: 1,
            cl: 1
        }), e != null && JJ(a, e));
        return !1
    };

    function cO(a, b) {
        b = b && b[0];
        if (!b) return null;
        b = b.target;
        const c = b.getBoundingClientRect(),
            d = tk(a.g.ca() || window);
        if (c.bottom <= 0 || c.bottom > d.height || c.right <= 0 || c.left >= d.width) return null;
        var e = dO(a, b, c, a.g.g.elementsFromPoint(Ib(c.left + c.width / 2, c.left, c.right - 1), Ib(c.bottom - 1 - 2, c.top, c.bottom - 1)), 1, []),
            f = dO(a, b, c, a.g.g.elementsFromPoint(Ib(c.left + c.width / 2, c.left, c.right - 1), Ib(c.top + 2, c.top, c.bottom - 1)), 2, e.xb),
            g = dO(a, b, c, a.g.g.elementsFromPoint(Ib(c.left + 2, c.left, c.right - 1), Ib(c.top + c.height / 2,
                c.top, c.bottom - 1)), 3, [...e.xb, ...f.xb]);
        const h = dO(a, b, c, a.g.g.elementsFromPoint(Ib(c.right - 1 - 2, c.left, c.right - 1), Ib(c.top + c.height / 2, c.top, c.bottom - 1)), 4, [...e.xb, ...f.xb, ...g.xb]);
        var k = eO(a, b, c),
            l = n => Pa(a.j, n.Db) && Pa(a.l, n.Yf) && Pa(a.i, n.Mh);
        e = Ka([...e.entries, ...f.entries, ...g.entries, ...h.entries], l);
        l = Ka(k, l);
        k = [...e, ...l];
        f = c.left < -2 || c.right > d.width + 2;
        f = k.length > 0 || f;
        g = uk(a.g.g);
        const m = new fk(c.left, c.top, c.width, c.height);
        e = [...La(e, n => new fk(n.Dc.left, n.Dc.top, n.Dc.width, n.Dc.height)), ...Ya(La(l,
            n => hk(m, n.Dc))), ...Ka(hk(m, new fk(0, 0, d.width, d.height)), n => n.top >= 0 && n.top + n.height <= d.height)];
        return {
            entries: k,
            xh: f,
            Xh: {
                scrollX: g.x,
                scrollY: g.y
            },
            target: b,
            mc: c,
            ki: {
                width: d.width,
                height: d.height
            },
            rk: e.length < 20 ? fO(m, e) : gO(c, e)
        }
    }

    function hO(a, b) {
        const c = a.g.ca(),
            d = a.g.g;
        return new Promise((e, f) => {
            const g = c.IntersectionObserver;
            if (g)
                if (d.elementsFromPoint)
                    if (d.createNodeIterator)
                        if (d.createRange)
                            if (c.Range.prototype.getBoundingClientRect) {
                                var h = new g(k => {
                                    const l = new pl,
                                        m = ol(l, () => cO(a, k));
                                    m && (l.i.length && (m.vj = Math.round(Number(l.i[0].duration))), h.disconnect(), e(m))
                                }, iO);
                                h.observe(b)
                            } else f(Error("5"));
            else f(Error("4"));
            else f(Error("3"));
            else f(Error("2"));
            else f(Error("1"))
        })
    }

    function dO(a, b, c, d, e, f) {
        if (c.width === 0 || c.height === 0) return {
            entries: [],
            xb: []
        };
        const g = [],
            h = [];
        for (let m = 0; m < d.length; m++) {
            const n = d[m];
            if (n === b) continue;
            if (Pa(f, n)) continue;
            h.push(n);
            const p = n.getBoundingClientRect();
            if (a.g.contains(n, b)) {
                g.push(jO(a, c, n, p, 1, e));
                continue
            }
            if (a.g.contains(b, n)) {
                g.push(jO(a, c, n, p, 2, e));
                continue
            }
            a: {
                var k = a;
                var l = b;
                const w = k.g.Aj(l, n);
                if (!w) {
                    k = null;
                    break a
                }
                const {
                    Ga: B,
                    Ob: G
                } = kO(k, l, w, n) || {},
                {
                    Ga: L,
                    Ob: A
                } = kO(k, n, w, l) || {};k = B && G && L && A ? G <= A ? {
                    Ga: B,
                    Db: lO[G]
                } : {
                    Ga: L,
                    Db: mO[A]
                } : B && G ? {
                    Ga: B,
                    Db: lO[G]
                } : L && A ? {
                    Ga: L,
                    Db: mO[A]
                } : null
            }
            const {
                Ga: t,
                Db: v
            } = k || {};
            t && v ? g.push(jO(a, c, n, p, v, e, t)) : g.push(jO(a, c, n, p, 9, e))
        }
        return {
            entries: g,
            xb: h
        }
    }

    function eO(a, b, c) {
        const d = [];
        for (b = b.parentElement; b; b = b.parentElement) {
            const f = b.getBoundingClientRect();
            if (f) {
                var e = cd(b, a.g.ca());
                e && e.overflow !== "visible" && (e.overflowY !== "auto" && e.overflowY !== "scroll" && c.bottom > f.bottom + 2 ? d.push(jO(a, c, b, f, 5, 1)) : (e = e.overflowX === "auto" || e.overflowX === "scroll", !e && c.left < f.left - 2 ? d.push(jO(a, c, b, f, 5, 3)) : !e && c.right > f.right + 2 && d.push(jO(a, c, b, f, 5, 4))))
            }
        }
        return d
    }

    function fO(a, b) {
        if (a.width === 0 || a.height === 0 || b.length === 0) return 0;
        let c = 0;
        for (let d = 1; d < 1 << b.length; d++) {
            let e = a,
                f = 0;
            for (let g = 0; g < b.length && (!(d & 1 << g) || (f++, e = gk(e, b[g]), e)); g++);
            e && (c = f % 2 === 1 ? c + (e.width + 1) * (e.height + 1) : c - (e.width + 1) * (e.height + 1))
        }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function gO(a, b) {
        if (a.width === 0 || a.height === 0 || b.length === 0) return 0;
        let c = 0;
        for (let d = a.left; d <= a.right; d++)
            for (let e = a.top; e <= a.bottom; e++)
                for (let f = 0; f < b.length; f++)
                    if (d >= b[f].left && d <= b[f].left + b[f].width && e >= b[f].top && e <= b[f].top + b[f].height) {
                        c++;
                        break
                    }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function jO(a, b, c, d, e, f, g) {
        g = {
            element: c,
            Dc: d,
            Db: e,
            Mh: f,
            Yf: null,
            Ga: g || null
        };
        if (Pa(a.j, e) && Pa(a.i, f)) {
            b = new ak(b.top, b.right - 1, b.bottom - 1, b.left);
            if ((a = nO(a, c)) && ck(b, a)) c = 4;
            else {
                a = oO(c, d);
                e = Jk(c, "paddingLeft");
                f = Jk(c, "paddingRight");
                const h = Jk(c, "paddingTop"),
                    k = Jk(c, "paddingBottom");
                e = new ak(parseFloat(h), parseFloat(f), parseFloat(k), parseFloat(e));
                ck(b, new ak(a.top + e.top, a.right - e.right, a.bottom - e.bottom, a.left + e.left)) ? c = 3 : (c = oO(c, d), c = ck(b, c) ? 2 : 1)
            }
            g.Yf = c
        }
        return g
    }

    function kO(a, b, c, d) {
        const e = [];
        for (var f = b; f && f !== c; f = f.parentElement) e.unshift(f);
        c = a.g.ca();
        for (f = 0; f < e.length; f++) {
            const h = e[f];
            var g = cd(h, c);
            if (g) {
                if (g.position === "fixed") return {
                    Ga: h,
                    Ob: 1
                };
                if (g.position === "sticky" && a.g.contains(h.parentElement, d)) return {
                    Ga: h,
                    Ob: 2
                };
                if (g.position === "absolute") return {
                    Ga: h,
                    Ob: 3
                };
                if (g.cssFloat !== "none") {
                    g = h === e[0];
                    const k = pO(a, e.slice(0, f), h);
                    if (g || k) return {
                        Ga: h,
                        Ob: 4
                    }
                }
            }
        }
        return (a = pO(a, e, b)) ? {
            Ga: a,
            Ob: 5
        } : null
    }

    function pO(a, b, c) {
        const d = c.getBoundingClientRect();
        if (!d) return null;
        for (let e = 0; e < b.length; e++) {
            const f = b[e];
            if (!a.g.contains(f, c)) continue;
            const g = f.getBoundingClientRect();
            if (!g) continue;
            const h = cd(f, a.g.ca());
            if (h && d.bottom > g.bottom + 2 && h.overflowY === "visible") return f
        }
        return null
    }

    function nO(a, b) {
        var c = a.g.g;
        a = c.createRange();
        if (!a) return null;
        c = c.createNodeIterator(b, NodeFilter.SHOW_TEXT, {
            acceptNode: d => d.nodeValue === null || /^[\s\xa0]*$/.test(d.nodeValue) ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT
        });
        for (b = c.nextNode(); c.nextNode(););
        c = c.previousNode();
        if (!b || !c) return null;
        a.setStartBefore(b);
        a.setEndAfter(c);
        a = a.getBoundingClientRect();
        return a.width === 0 || a.height === 0 ? null : new ak(a.top, a.right, a.bottom, a.left)
    }

    function oO(a, b) {
        var c = Jk(a, "borderLeftWidth");
        const d = Jk(a, "borderRightWidth"),
            e = Jk(a, "borderTopWidth");
        a = Jk(a, "borderBottomWidth");
        c = new ak(parseFloat(e), parseFloat(d), parseFloat(a), parseFloat(c));
        return new ak(b.top + c.top, b.right - 1 - c.right, b.bottom - 1 - c.bottom, b.left + c.left)
    }
    var rO = class {
        constructor(a) {
            var b = qO;
            this.j = [5, 8, 9];
            this.l = [3, 4];
            this.i = b;
            this.g = qk(a)
        }
    };
    const qO = [1, 2, 3, 4],
        lO = {
            [1]: 3,
            [4]: 10,
            [3]: 12,
            [2]: 4,
            [5]: 5
        },
        mO = {
            [1]: 6,
            [4]: 11,
            [3]: 13,
            [2]: 7,
            [5]: 8
        },
        iO = {
            threshold: [0, .25, .5, .75, .95, .96, .97, .98, .99, 1]
        };

    function sO(a) {
        a.g != null || a.B || (a.g = new MutationObserver(b => {
            for (const c of b)
                for (const d of c.addedNodes) ra(d) && d.nodeType == 1 && (b = a, d.matches('A[href]:not([href=""])') && uq(b.j, d))
        }), a.g.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0
        }))
    }
    var tO = class extends S {
        constructor(a) {
            super();
            this.win = a;
            this.j = new vq;
            this.g = null;
            cq(this, () => {
                this.g ? .disconnect();
                this.g = null
            })
        }
    };

    function uO(a, b) {
        b.addEventListener("click", () => {
            var c = a.g;
            var d = b.getAttribute("href");
            c = d ? d === "#" ? kr(Tm(4)) : d.startsWith("#") ? kr(Tm(5)) : vO(d, c) : mr("Empty href");
            if (c.g != null) {
                d = c.getValue();
                c = a.V;
                var e = new Vm;
                d = z(e, 1, d);
                c.call(a, d)
            } else a.i(c.i)
        })
    }
    var xO = class {
        constructor(a, b, c) {
            var d = wO();
            this.win = a;
            this.g = b;
            this.V = c;
            this.i = d
        }
        L() {
            const a = new tO(this.win);
            Array.from(a.win.document.querySelectorAll('A[href]:not([href=""])')).forEach(b => {
                uO(this, b)
            });
            sO(a);
            sq(a.j).listen(b => {
                uO(this, b)
            })
        }
    };

    function vO(a, b) {
        return yO(a, b).map(c => yO(b).map(d => {
            if (c.protocol === "http:" || c.protocol === "https:") {
                var e = Tm(2);
                e = Eh(e, 2, `${c.host}${c.pathname}`);
                d = Eh(e, 3, `${d.host}${d.pathname}`)
            } else d = c.protocol === "javascript:" ? Tm(3) : Tm(1);
            return d
        }))
    }

    function yO(a, b) {
        return qr(nr(() => new URL(a, b)), () => Error("Invalid URL"))
    };

    function zO(a) {
        if (a < 0 || !Number.isInteger(a)) return mr(`Not a non-negative integer: ${a}`);
        const b = [];
        do b.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(a % 64)), a = Math.floor(a / 64); while (a > 0);
        return kr(b.reverse().join(""))
    };
    class AO {
        constructor() {
            this.ti = 5E3
        }
        dj() {
            return 5E3
        }
    }

    function BO(a, b) {
        return a.quantizer ? Math.floor(b / 5E3) * 5E3 / a.quantizer.ti : b
    }

    function CO(a, b) {
        b = b.map(c => BO(a, c));
        return DO(b, a.g === void 0 ? void 0 : BO(a, a.g)).map(c => {
            a: {
                var d = EO;
                const e = [];
                for (const f of c) {
                    c = d(f);
                    if (c.g == null) {
                        d = new lr(null, c.i);
                        break a
                    }
                    e.push(c.getValue())
                }
                d = kr(e)
            }
            return d
        }).map(c => c.join(".")).map(c => FO(c, a.quantizer ? .dj()))
    }
    var GO = class {
        constructor(a, b) {
            this.quantizer = a;
            this.g = b
        }
    };

    function EO(a) {
        const b = zO(a.value);
        if (b.g == null) return b;
        const c = b.getValue();
        return a.se === 1 ? kr(`${c}`) : a.se === 2 ? kr(`${c}${"~"}`) : sr(zO(a.se - 2), d => {
            throw d;
        }).map(d => `${c}${"~"}${d}`)
    }

    function DO(a, b) {
        const c = [];
        for (let d = 0; d < a.length; d++) {
            const e = a[d] ? ? b;
            if (e === void 0) return mr("Sparse but no default");
            c.length === 0 || e !== c[c.length - 1].value ? c.push({
                value: e,
                se: 1
            }) : c[c.length - 1].se++
        }
        return kr(c)
    }

    function FO(a, b) {
        return a === "" ? kr("") : HO(b).map(c => `${c}${a}`)
    }

    function HO(a) {
        return a === void 0 || a === 1 ? kr("") : rr(zO(a), "ComFactor: ").map(b => `${"~"}${b}${"."}`)
    };
    var IO = class extends S {
        constructor(a) {
            super();
            this.win = a;
            this.j = new T(!1);
            this.g = () => {
                this.j.g(this.win.document.hasFocus())
            }
        }
        L() {
            this.win.addEventListener("focus", this.g);
            this.win.addEventListener("blur", this.g);
            cq(this, () => void this.win.removeEventListener("focus", this.g));
            cq(this, () => void this.win.removeEventListener("blur", this.g));
            this.j.g(this.win.document.hasFocus())
        }
    };

    function JO(a) {
        a.j.g(a.win.document.visibilityState === "visible")
    }
    var KO = class extends S {
        constructor(a) {
            super();
            this.win = a;
            this.j = new T(!1);
            this.g = () => void JO(this)
        }
        L() {
            this.win.addEventListener("visibilitychange", this.g);
            cq(this, () => void this.win.removeEventListener("visibilitychange", this.g));
            JO(this)
        }
    };

    function LO(a) {
        return a.g !== null ? a.i + a.j() - a.g : a.i
    }
    var NO = class {
        constructor(a) {
            this.win = a;
            this.i = 0;
            this.g = null;
            this.j = MO(this.win)
        }
        start() {
            this.g === null && (this.g = this.j())
        }
    };

    function MO(a) {
        return a.performance && a.performance.now ? () => a.performance.now() : () => Date.now()
    };

    function OO(a) {
        a = new PO(a);
        a.L();
        return a
    }

    function QO(a) {
        const b = Gq(a.win, 1E3, () => void a.handleEvent());
        a.win.addEventListener("scroll", () => void b())
    }

    function RO(a) {
        const b = SO(a.win),
            c = () => {
                const d = SO(a.win),
                    e = Math.abs(d.height - b.height);
                if (Math.abs(d.width - b.width) > 20 || e > 20) a.F = !0, a.win.removeEventListener("resize", c)
            };
        a.win.addEventListener("resize", c)
    }

    function TO(a) {
        a.l = !a.g.O;
        nq(a.g, !1, () => {
            a.win.setTimeout(() => {
                a.l = !0
            }, 100)
        })
    }

    function UO(a) {
        mq(a.g, !0, () => void a.j.start());
        mq(a.g, !1, () => {
            var b = a.j;
            b.g !== null && (b.i += b.j() - b.g);
            b.g = null
        });
        a.D.start()
    }

    function VO(a) {
        var b = a.win.scrollY;
        var c = Ap(a.win);
        b = {
            ye: Math.floor(b / 100),
            Cd: Math.floor((b + c) / 100),
            hi: a.win.performance.now()
        };
        if (b.ye < 0 || b.Cd < 0 || b.ye > 1E3 || b.Cd > 1E3) a.G = !0, a.i = null;
        else {
            if (a.i) {
                c = a.i;
                var d = new uC(c.ye, c.Cd),
                    e = new uC(b.ye, b.Cd);
                var f = Math.max(d.start, e.start);
                d = Math.min(d.end, e.end);
                if (f = f <= d ? new uC(f, d) : null)
                    for (c = b.hi - c.hi, d = f.start; d <= f.end; d++) a.A[d] = (a.A[d] ? ? 0) + c
            }
            a.i = a.B.O ? b : null
        }
    }
    var PO = class {
        constructor(a) {
            this.win = a;
            this.A = [];
            this.F = this.l = this.G = !1;
            this.i = null;
            a = this.win;
            var b = new IO(a);
            b.L();
            b = jq(b.j);
            a = new KO(a);
            a.L();
            this.B = this.g = iq(b, jq(a.j));
            this.j = new NO(this.win);
            this.D = new NO(this.win);
            this.I = new GO((new GO(new AO)).quantizer, 0)
        }
        L() {
            QO(this);
            RO(this);
            TO(this);
            UO(this);
            this.B.listen(() => void VO(this));
            q.setInterval(() => void this.handleEvent(), 5E3);
            this.handleEvent()
        }
        handleEvent() {
            this.B.O && VO(this)
        }
    };

    function SO(a) {
        return new dk(zp(a), Ap(a))
    };

    function WO(a, {
        Oa: b
    }) {
        a = new XO(a, b);
        if (!a.Oa && W(Zt)) {
            b = a.win;
            var c = YO(ZO(a));
            (new xO(b, b.document.baseURI, c)).L()
        }
        $O(a)
    }

    function $O(a) {
        if (W($t)) {
            var b = OO(a.win);
            dp(new yE(a.win), aP(() => {
                var c = ZO(a),
                    d = new Ym,
                    e = CO(b.I, b.A);
                if (e.g == null) throw rr(e, "PVDC: ").i;
                var f = new Xm;
                f = Ah(f, 2, 5E3);
                f = Ah(f, 1, 100);
                e = e.getValue();
                e = Eh(f, 3, e);
                f = SO(b.win);
                var g = new Wm;
                g = Ah(g, 1, f.width);
                f = Ah(g, 2, f.height);
                e = z(e, 4, f);
                f = new Wm;
                f = Ah(f, 1, Ep(b.win).scrollWidth);
                f = Ah(f, 2, Ep(b.win).scrollHeight);
                e = z(e, 5, f);
                e = J(e, 6, b.l);
                f = Math.round(LO(b.D) / 1E3);
                e = Ah(e, 8, f);
                f = Math.round(LO(b.j) / 1E3);
                e = Ah(e, 9, f);
                b.G && jh(e, 7, xf, 1, yf);
                b.F && jh(e, 7, xf, 2, yf);
                d = C(d, 2,
                    Zm, e);
                c(d)
            }))
        }
    }

    function ZO(a) {
        if (!a.V) {
            const b = R(HE);
            a.V = c => {
                OE(b, c)
            }
        }
        return a.V
    }
    var XO = class {
        constructor(a, b) {
            this.win = a;
            this.Oa = b;
            this.V = null
        }
    };

    function YO(a) {
        return b => {
            var c = new Ym;
            b = C(c, 1, Zm, b);
            return void a(b)
        }
    }

    function wO() {
        return a => {
            ny(1243, a, void 0, bP("LCC"))
        }
    }

    function aP(a) {
        return () => void jy(1243, a, bP("PVC"))
    }

    function bP(a) {
        return b => {
            b.errSrc = a
        }
    };
    var cP = class extends S {
        constructor(a, b) {
            super();
            this.value = a;
            cq(this, b)
        }
    };

    function dP(a, b) {
        const c = eP(a.getBoundingClientRect()),
            d = new T(c),
            e = fP(a, b, f => {
                d.g(eP(f.boundingClientRect))
            });
        return new cP(jq(d), () => void e.disconnect())
    }

    function fP(a, b, c) {
        b = new IntersectionObserver(d => {
            d.filter(e => e.target === a).forEach(c)
        }, {
            root: b
        });
        b.observe(a);
        return b
    }

    function eP(a) {
        return a.height > 0 || a.width > 0
    };
    var gP = {
        kn: 0,
        Co: 1,
        Wn: 2,
        0: "INITIAL_RENDER",
        1: "UNRENDER",
        2: "RENDER_BACK"
    };

    function hP(a, b, c) {
        var d = [1, 2];
        const e = dP(b, c),
            f = e.value,
            g = new vq;
        nq(f, !0, () => void iP(a, f, g, d));
        return new cP(sq(g), () => void e.dispose())
    }

    function iP(a, b, c, d) {
        const e = new NO(a);
        let f = new NO(a);
        e.start();
        f.start();
        let g = 0;
        const h = k => {
            k = {
                type: k,
                Jh: ++g,
                hk: LO(f),
                gk: LO(e)
            };
            f = new NO(a);
            f.start();
            return k
        };
        d && !d.includes(0) || uq(c, h(0));
        b.listen(k => {
            k = k ? 2 : 1;
            d && !d.includes(k) || uq(c, h(k))
        })
    };

    function jP(a, b) {
        var c = R(HE);
        jy(1282, () => void kP(a, b, c))
    }

    function kP(a, b, c) {
        const d = lP(a);
        if (!d) throw Error("No adsbygoogle INS found");
        const e = hP(a.pubWin, b, d);
        e.value.listen(f => {
            mP(f, d, c, () => void e.dispose())
        })
    }

    function lP(a) {
        return (a = a.X.parentElement) && Yv.test(a.className) ? a : null
    }

    function mP(a, b, c, d) {
        if (a.Jh > 5) d();
        else {
            var e = a.type === 1;
            d = a.type === 2;
            if (!e && !d) throw Error(`Unsupported event type: ${gP[a.type]}`);
            var f = lg(lN());
            f = Bh(f, 1, a.hk);
            f = Bh(f, 2, a.gk);
            a = Bh(f, 3, a.Jh);
            f = b.dataset.vignetteLoaded;
            var g = lg(jN());
            g = Dh(g, 1, b.dataset.adStatus);
            g = Dh(g, 2, b.dataset.sideRailStatus);
            g = Dh(g, 3, b.dataset.anchorStatus);
            f = yh(g, 4, f !== void 0 ? f === "true" : void 0);
            b = getComputedStyle(b);
            g = mN();
            g = lg(g);
            g = Dh(g, 1, b.display);
            g = Dh(g, 2, b.position);
            g = Dh(g, 3, b.width);
            b = Dh(g, 4, b.height).g();
            b = z(f, 5, b).g();
            a = z(a, 4, b);
            e = e ? nN() : void 0;
            e = C(a, 5, Xl, e);
            d = d ? kN() : void 0;
            d = C(e, 6, Xl, d);
            d = lg(d.g()).g();
            RE(c, d)
        }
    };
    var oP = a => {
        const b = a.C;
        b.google_ad_output == null && (b.google_ad_output = "html");
        if (b.google_ad_client != null) {
            var c;
            (c = String(b.google_ad_client)) ? (c = c.toLowerCase(), c.substring(0, 3) != "ca-" && (c = "ca-" + c)) : c = "";
            b.google_ad_client = c
        }
        b.google_ad_slot != null && (b.google_ad_slot = String(b.google_ad_slot));
        b.google_webgl_support = !!Qj.WebGLRenderingContext;
        b.google_ad_section = b.google_ad_section || b.google_ad_region || "";
        b.google_country = b.google_country || b.google_gl || "";
        c = (new Date).getTime();
        Array.isArray(b.google_color_bg) &&
            (b.google_color_bg = nP(a, b.google_color_bg, c));
        Array.isArray(b.google_color_text) && (b.google_color_text = nP(a, b.google_color_text, c));
        Array.isArray(b.google_color_link) && (b.google_color_link = nP(a, b.google_color_link, c));
        Array.isArray(b.google_color_url) && (b.google_color_url = nP(a, b.google_color_url, c));
        Array.isArray(b.google_color_border) && (b.google_color_border = nP(a, b.google_color_border, c));
        Array.isArray(b.google_color_line) && (b.google_color_line = nP(a, b.google_color_line, c))
    };

    function nP(a, b, c) {
        a.i |= 2;
        return b[c % b.length]
    };
    const pP = {
        google: 1,
        googlegroups: 1,
        gmail: 1,
        googlemail: 1,
        googleimages: 1,
        googleprint: 1
    };
    Uc `https://securepubads.g.doubleclick.net/pagead/js/car.js`;
    Uc `https://securepubads.g.doubleclick.net/pagead/js/cocar.js`;
    var qP = Uc `https://ep3.adtrafficquality.google/ivt/worklet/caw.js`;

    function rP(a) {
        const b = [];
        for (let c = 0; c < 8; ++c) {
            const d = new rM(f => {
                    b.push({
                        url: f
                    })
                }),
                e = M(no(mo(new oo, a), c), 3, 6);
            d.D(e)
        }
        return b
    }
    async function sP(a) {
        const b = window;
        if (b.sharedStorage) try {
            const d = await (await b.sharedStorage.createWorklet(qP.toString(), {
                dataOrigin: "script-origin"
            })).selectURL("ps_caus", rP(a), {
                resolveToConfig: !0,
                savedQuery: "ps_cac"
            });
            if (d) {
                var c = b.document.body;
                const e = document.createElement("fencedframe");
                e.id = "ps_caff";
                e.name = "ps_caff";
                e.mode = "opaque-ads";
                e.config = d;
                Fk(e, "display", "none");
                c.appendChild(e)
            }
        } catch (d) {}
    };

    function tP(a, b) {
        const c = LN(a.isSecureContext, a, a.document),
            d = !!a.sharedStorage ? .createWorklet;
        b && c && d && !iE(dE(), 34, !1) && (jE(dE(), 34, !0), a = sP(Fd(a)), ly(1279, a))
    };

    function uP(a) {
        a = y(a, EK, 1);
        return I(a, 5) === 1 || I(a, 6) === 1 ? !0 : !1
    };

    function vP(a) {
        a = y(a, MK, 1);
        return I(a, 5) === 1 || I(a, 6) === 1 ? !0 : !1
    };

    function wP(a) {
        a = y(a, VK, 1);
        const b = y(a, TK, 8);
        return I(a, 5) === 1 || I(a, 6) === 1 || b ? .j() === 1 || b ? .l() === 1 ? !0 : !1
    };

    function xP(a) {
        const b = y(a, bL, 8);
        return I(a, 5) === 1 || I(a, 6) === 1 || b ? .j() === 1 || b ? .l() === 1 ? !0 : !1
    };

    function yP(a) {
        a = y(a, jL, 1);
        const b = y(a, hL, 12);
        return I(a, 8) === 1 || I(a, 9) === 1 || I(a, 10) === 1 || b ? .i() === 1 ? !0 : !1
    };

    function zP(a) {
        return I(a, 5) === 1 || I(a, 6) === 1 ? !0 : !1
    };
    const AP = (a, b) => {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        BP = (a, b) => {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        CP = {
            Sd: a => a.listener,
            Rc: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }
            }),
            ec: (a, b) => {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        DP = {
            Sd: a => a.listener,
            Rc: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }
            }),
            ec: (a, b) => {
                b = b.__gppReturn;
                const c = b.returnValue.data;
                a ? .(c, b.success)
            }
        };

    function EP(a) {
        let b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            ag: b.__gppReturn.callId
        }
    }

    function FP(a, b) {
        var c = {
            checkChildSignals: !0,
            supportUsfl: W(ev)
        };
        if (!a) return !1;
        var d = AK(a.split("~")[0]);
        a = vK(a);
        d = rh(d, 3);
        for (let f = 0; f < d.length; ++f) {
            var e = d[f];
            if (!b.includes(e)) continue;
            const g = a[f];
            switch (e) {
                case 2:
                    if (c ? .supportTcfeu) {
                        e = oM(g);
                        if (!e) throw Error("Cannot decode TCF V2 section string.");
                        if (!sF(e, ["3", "4"], 0)) return !0
                    }
                    break;
                case 7:
                    if (yP(pL(g))) return !0;
                    break;
                case 8:
                    if (uP(KK(g))) return !0;
                    break;
                case 9:
                    if (zP(uL(g))) return !0;
                    break;
                case 10:
                    if (vP(SK(g))) return !0;
                    break;
                case 12:
                    if (wP(aL(g))) return !0;
                    break;
                case 13:
                    if (c ? .supportUsfl && xP(gL(g))) return !0
            }
        }
        return !1
    }
    var JP = class extends S {
        constructor(a) {
            ({
                timeoutMs: c,
                legacyCmpInteractionEventReporter: b
            } = {});
            var b, c;
            super();
            this.caller = new fF(a, "__gppLocator", d => typeof d.__gpp === "function", EP);
            this.caller.D.set("addEventListener", AP);
            this.caller.A.set("addEventListener", CP);
            this.caller.D.set("removeEventListener", BP);
            this.caller.A.set("removeEventListener", DP);
            this.timeoutMs = c ? ? 500;
            this.legacyCmpInteractionEventReporter = b
        }
        i() {
            this.caller.dispose();
            super.i()
        }
        addEventListener(a) {
            const b = fb(() => {
                    a(GP, !0)
                }),
                c = this.timeoutMs ===
                -1 ? void 0 : setTimeout(() => {
                    b()
                }, this.timeoutMs);
            eF(this.caller, "addEventListener", {
                listener: (d, e) => {
                    clearTimeout(c);
                    try {
                        if (d.pingData ? .gppVersion === void 0 || d.pingData.gppVersion === "1" || d.pingData.gppVersion === "1.0") {
                            this.removeEventListener(d.listenerId);
                            var f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 1,
                                    gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                    applicableSections: [-1]
                                }
                            }
                        } else Array.isArray(d.pingData.applicableSections) ? f = d : (this.removeEventListener(d.listenerId), f = {
                            eventName: "signalStatus",
                            data: "ready",
                            pingData: {
                                internalErrorState: 2,
                                gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                                applicableSections: [-1]
                            }
                        });
                        a(f, e);
                        this.legacyCmpInteractionEventReporter ? .g()
                    } catch {
                        if (d ? .listenerId) try {
                            this.removeEventListener(d.listenerId)
                        } catch {
                            a(HP, !0);
                            return
                        }
                        a(IP, !0)
                    }
                }
            })
        }
        removeEventListener(a) {
            eF(this.caller, "removeEventListener", {
                listener: () => {},
                listenerId: a
            })
        }
    };
    const IP = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        GP = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        HP = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function KP(a) {
        return !a || a.length === 1 && a[0] === -1
    };

    function LP(a) {
        a = new JP(a);
        if (!cF(a.caller)) return Promise.resolve(null);
        const b = dE(),
            c = iE(b, 35);
        if (c) return Promise.resolve(c);
        const d = new Promise(e => {
            e = {
                resolve: e
            };
            const f = iE(b, 36, []);
            f.push(e);
            jE(b, 36, f)
        });
        c || c === null || (jE(b, 35, null), a.addEventListener(e => {
            if (e.pingData.signalStatus === "ready" || KP(e.pingData.applicableSections)) {
                e = e.pingData;
                jE(b, 35, e);
                for (const f of iE(b, 36, [])) f.resolve(e);
                jE(b, 36, [])
            }
        }));
        return d
    };

    function MP(a) {
        a = new yF(a, {
            timeoutMs: -1,
            Qi: !0
        });
        if (!uF(a)) return Promise.resolve(null);
        const b = dE(),
            c = iE(b, 24);
        if (c) return Promise.resolve(c);
        const d = new Promise(e => {
            e = {
                resolve: e
            };
            const f = iE(b, 25, []);
            f.push(e);
            jE(b, 25, f)
        });
        c || c === null || (jE(b, 24, null), a.addEventListener(e => {
            if (oF(e)) {
                jE(b, 24, e);
                for (const f of iE(b, 25, [])) f.resolve(e);
                jE(b, 25, [])
            } else jE(b, 24, null)
        }));
        return d
    };
    const NP = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.Ta({
                    yc: c ? ? void 0,
                    bh: d ? void 0 : 2
                })
            })
        },
        OP = {
            Sd: a => a.Ta,
            Rc: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            ec: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    yc: b.returnValue ? ? void 0,
                    bh: b.success ? void 0 : 2
                })
            }
        };

    function PP(a) {
        let b = {};
        typeof a.data === "string" ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            ag: b.__uspapiReturn.callId
        }
    }

    function QP(a, b) {
        let c = {};
        if (cF(a.caller)) {
            var d = fb(() => {
                b(c)
            });
            eF(a.caller, "getDataWithCallback", {
                Ta: e => {
                    e.bh || (c = e.yc);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    }
    var RP = class extends S {
        constructor(a) {
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new fF(a, "__uspapiLocator", b => typeof b.__uspapi === "function", PP);
            this.caller.D.set("getDataWithCallback", NP);
            this.caller.A.set("getDataWithCallback", OP)
        }
        i() {
            this.caller.dispose();
            super.i()
        }
    };

    function SP(a) {
        const b = new RP(a);
        return new Promise(c => {
            QP(b, d => {
                d && typeof d.uspString === "string" ? c(d.uspString) : c(null)
            })
        })
    }

    function TP(a, {
        Uk: b,
        al: c,
        Ij: d
    }) {
        var e = new kK;
        var f = W(fv) ? Gh(d, 5) ? d.i() : Gh(b, 5) ? b.i() : a.i() : Gh(b, 5) ? b.i() : a.i();
        e = iK(e, f);
        f = W(fv) ? Gh(d, 8) ? E(d, 8) : Gh(b, 8) ? E(b, 8) : void 0 : vh(b, 8);
        e = yh(e, 8, f);
        a = yh(e, 14, vh(a, 14));
        a = yh(a, 3, vh(b, 3));
        a = Dh(a, 2, D(b, 2) ? ? void 0);
        a = Dh(a, 4, D(b, 4) ? ? void 0);
        f = xh(b, 7);
        a = Fh(a, 7, f);
        b = yh(a, 9, vh(b, 9));
        b = Dh(b, 1, D(c, 1) ? ? void 0);
        c = yh(b, 13, vh(c, 13));
        c = Dh(c, 11, D(d, 11) ? ? void 0);
        b = Qg(d, 10, Qf, Pg(), void 0, 0);
        c = Yg(c, 10, b, Df);
        jK(c, vh(d, 12));
        return e
    }
    async function UP(a, {
        Oa: b,
        Vj: c
    }) {
        const [d, e, f] = await Promise.all([MP(a.pubWin), SP(a.pubWin), LP(a.pubWin)]), g = !!b && (W(gv) || !NM());
        b = iK(new kK, !g);
        c = yh(b, 14, c && navigator.globalPrivacyControl);
        b = new kK;
        if (d) {
            var h = iK(b, pF(d, {
                idpcApplies: g
            }));
            h = Dh(h, 2, d.tcString);
            h = Dh(h, 4, d.addtlConsent || "");
            h = Fh(h, 7, d.internalErrorState);
            var k = !sF(d, ["3", "4"], 0);
            h = yh(h, 9, k);
            k = !sF(d, ["2", "7", "9", "10"], 3);
            yh(h, 8, k);
            d.gdprApplies != null && yh(b, 3, d.gdprApplies)
        }
        h = new kK;
        if (e) {
            k = Dh(h, 1, e);
            var l = e.toUpperCase();
            if (l.length ==
                4 && (l.indexOf("-") == -1 || l.substring(1) === "---") && l[0] >= "1" && l[0] <= "9" && tK.hasOwnProperty(l[1]) && tK.hasOwnProperty(l[2]) && tK.hasOwnProperty(l[3])) {
                var m = new sK;
                m = Ah(m, 1, parseInt(l[0], 10));
                m = M(m, 2, tK[l[1]]);
                m = M(m, 3, tK[l[2]]);
                l = M(m, 4, tK[l[3]])
            } else l = null;
            l = l ? .Fj() === 2;
            yh(k, 13, l)
        }
        k = new kK;
        if (f)
            if (f.internalErrorState) Dh(k, 11, f.gppString);
            else if (KP(f.applicableSections)) jK(Yg(k, 10, f.applicableSections, Df), !1), W(fv) && iK(k, !0);
        else if (l = Yg(k, 10, f.applicableSections, Df), Dh(l, 11, f.gppString), W(fv)) try {
            var n =
                f.gppString,
                p = f.applicableSections;
            l = {
                idpcApplies: g,
                supportTcfeu: !0,
                checkChildSignals: !0,
                supportUsfl: !0
            };
            let na = !(p.includes(2) && l ? .idpcApplies),
                xa = m = !1,
                Oa = !1;
            if (n && !n.startsWith("GPP_ERROR_STRING_")) {
                const Cb = AK(n.split("~")[0]),
                    Bj = vK(n),
                    ua = rh(Cb, 3);
                for (n = 0; n < ua.length; ++n) {
                    const ve = ua[n];
                    if (!p.includes(ve)) continue;
                    const we = Bj[n];
                    switch (ve) {
                        case 2:
                            if (l ? .supportTcfeu) {
                                const Ea = oM(we);
                                if (!Ea) throw Error("Cannot decode TCF V2 section string.");
                                na = pF(Ea);
                                !sF(Ea, ["3", "4"], 0) && (m = !0);
                                !sF(Ea, ["2", "7",
                                    "9", "10"
                                ], 3) && (xa = !0)
                            }
                            break;
                        case 7:
                            const sx = pL(we);
                            yP(sx) && (m = !0);
                            a: {
                                if (!l ? .checkChildSignals) {
                                    var t = !1;
                                    break a
                                }
                                const Ea = y(y(sx, jL, 1), hL, 12) ? .j();t = Ea === 1 || Ea === 2 ? !0 : !1
                            }
                            t && (Oa = !0);
                            break;
                        case 8:
                            const tx = KK(we);
                            uP(tx) && (m = !0);
                            a: {
                                if (!l ? .checkChildSignals) {
                                    var v = !1;
                                    break a
                                }
                                const Ea = y(y(tx, EK, 1), CK, 8);v = Ea ? .i() === 1 || Ea ? .i() === 2 || Ea ? .j() === 1 || Ea ? .j() === 2 ? !0 : !1
                            }
                            v && (Oa = !0);
                            break;
                        case 9:
                            const ux = uL(we);
                            zP(ux) && (m = !0);
                            a: {
                                if (!l ? .checkChildSignals) {
                                    var w = !1;
                                    break a
                                }
                                const Ea = I(ux, 8);w = Ea === 1 || Ea === 2 ? !0 : !1
                            }
                            w &&
                                (Oa = !0);
                            break;
                        case 10:
                            const vx = SK(we);
                            vP(vx) && (m = !0);
                            a: {
                                if (!l ? .checkChildSignals) {
                                    var B = !1;
                                    break a
                                }
                                const Ea = I(y(vx, MK, 1), 8);B = Ea === 1 || Ea === 2 ? !0 : !1
                            }
                            B && (Oa = !0);
                            break;
                        case 12:
                            const wx = aL(we);
                            wP(wx) && (m = !0);
                            a: {
                                if (!l ? .checkChildSignals) {
                                    var G = !1;
                                    break a
                                }
                                const Ea = y(y(wx, VK, 1), TK, 8);G = Ea ? .i() === 1 || Ea ? .i() === 2 ? !0 : !1
                            }
                            G && (Oa = !0);
                            break;
                        case 13:
                            const xx = gL(we);
                            l ? .supportUsfl && xP(xx) && (m = !0);
                            var L;
                            if (L = l ? .supportUsfl) a: {
                                if (!l ? .checkChildSignals) {
                                    L = !1;
                                    break a
                                }
                                const Ea = y(xx, bL, 8) ? .i();L = Ea === 1 || Ea === 2 ? !0 : !1
                            }
                            L &&
                                (Oa = !0)
                    }
                }
            }
            var A = na;
            var H = m;
            var K = xa;
            var ia = Oa;
            var Jb = jK(iK(k, A), H);
            var ma = yh(Jb, 16, ia);
            yh(ma, 8, K)
        } catch (na) {
            ny(1182, na), A = jK(iK(k, !g), !1), A = yh(A, 16, !1), yh(A, 8, !1)
        } else {
            A = !1;
            try {
                A = FP(f.gppString, f.applicableSections)
            } catch (na) {
                ny(1182, na)
            }
            jK(k, A)
        }
        a.g = TP(c, {
            Uk: b,
            al: h,
            Ij: k
        })
    };
    async function VP(a) {
        const b = gl(),
            c = a.ma,
            d = a.pageState.i();
        IE(g => {
            I(g, 1) === 0 && (g = J(g, 2, !(d.j() ? !E(d, 4) : !E(c, 6))), g = J(g, 6, !(Gh(d, 5) ? !E(d, 5) : !E(c, 20))), M(g, 1, 1))
        });
        WP(a.pubWin, y(d, eh, 10) || dh(c));
        XP(a.C.google_ad_client);
        IE(g => {
            I(g, 1) === 1 && M(g, 1, 2)
        });
        const e = new mF(a.pubWin);
        await (jF(e, (F(d, 8) || F(c, 8)) === ".google.cn") ? kF(e) : Promise.resolve(null));
        IE(g => {
            I(g, 1) === 2 && (g = J(g, 3, !0), M(g, 1, 3))
        });
        await UP(a, {
            Oa: d.j() ? E(d, 4) : E(c, 6),
            Vj: Gh(d, 7) ? E(d, 7) : E(c, 25)
        });
        const f = gl();
        IE(g => {
            I(g, 1) === 3 && (g = J(g, 3, f - b > 500),
                g = J(g, 4, !!a.g ? .B()), g = J(g, 5, !!a.g ? .i()), g = J(g, 7, !!a.g ? .j()), g = J(g, 8, !!a.g ? .l()), M(g, 1, 4))
        })
    }

    function WP(a, b) {
        var c = W(hv);
        a !== a.top || a.__uspapi || a.frames.__uspapiLocator || (a = new MM(a, b, c), HM(a), IM(a))
    }

    function XP(a) {
        var b = rd(q.top, "googlefcPresent");
        q.googlefc && !b && my("adsense_fc_has_namespace_but_no_iframes", {
            publisherId: a
        }, 1)
    };
    var YP = (a, b = !1) => {
        try {
            return b ? (new dk(a.innerWidth, a.innerHeight)).round() : tk(a || window).round()
        } catch (c) {
            return new dk(-12245933, -12245933)
        }
    };

    function ZP(a = q) {
        a = a.devicePixelRatio;
        return typeof a === "number" ? +a.toFixed(3) : null
    }

    function $P(a, b = q) {
        a = a.scrollingElement || (a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return new Zj(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
    }

    function aQ(a) {
        try {
            return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
        } catch (b) {
            return !1
        }
    };

    function bQ(a, b) {
        var c = oy(),
            d;
        var e;
        d = (e = (e = jk()) && (d = e.initialLayoutRect) && typeof d.top === "number" && typeof d.left === "number" && typeof d.width === "number" && typeof d.height === "number" ? new fk(d.left, d.top, d.width, d.height) : null) ? new Zj(e.left, e.top) : (d = mk()) && ra(d.rootBounds) ? new Zj(d.rootBounds.left + d.boundingClientRect.left, d.rootBounds.top + d.boundingClientRect.top) : null;
        if (d) return d;
        try {
            {
                const k = new Zj(0, 0);
                var f = sk(b);
                let l = f ? f.defaultView : window;
                if (Ub(l, "parent")) {
                    do {
                        if (l == a) var g = Mk(b);
                        else {
                            const m =
                                Lk(b);
                            g = new Zj(m.left, m.top)
                        }
                        f = g;
                        k.x += f.x;
                        k.y += f.y
                    } while (l && l != a && l != l.parent && (b = l.frameElement) && (l = l.parent))
                }
                var h = k
            }
            return h
        } catch (k) {
            return c.ia(888, k), new Zj(-12245933, -12245933)
        }
    }

    function cQ(a, b, c, d = !1) {
        a = bQ(a, c);
        c = nk() || YP(b.top);
        if (!a || a.y === -12245933 || c.width === -12245933 || c.height === -12245933 || !c.height) return 0;
        let e = 0;
        try {
            const f = b.top;
            e = $P(f.document, f).y
        } catch (f) {
            return 0
        }
        b = e + c.height;
        return a.y < e ? d ? 0 : (e - a.y) / c.height : a.y > b ? (a.y - b) / c.height : 0
    };

    function dQ(a, b, c) {
        var d = SN(a, "__gpi_opt_out", b);
        d && (d = Dh(Bh(Hj(d), 2, 2147483647), 3, "/"), c = Dh(d, 4, c), TN(a, "__gpi_opt_out", c, b))
    }

    function eQ(a, b, c, d) {
        const e = QM(a, "gpi-uoo", (f, g) => {
            if (g.source === c) {
                g = Dh(Bh(Hj(f.userOptOut ? "1" : "0"), 2, 2147483647), 3, "/");
                g = Dh(g, 4, a.location.hostname);
                var h = new WN(a);
                TN(h, "__gpi_opt_out", g, b);
                if (f.userOptOut || f.clearAdsData) UN(h, "__gads", b), UN(h, "__gpi", b)
            }
        });
        d.push(e)
    };

    function fQ(a, b) {
        const c = a.pubWin,
            d = a.C.google_ad_client,
            e = lE();
        let f = null;
        const g = QM(c, "pvt", (h, k) => {
            typeof h.token === "string" && k.source === b.contentWindow && (f = h.token, g(), e[d] = e[d] || [], e[d].push(f), e[d].length > 100 && e[d].shift())
        });
        a.j.push(g);
        return () => {
            f && Array.isArray(e[d]) && (Qa(e[d], f), e[d].length || delete e[d], f = null)
        }
    };

    function gQ(a) {
        return a.length ? a.join("~") : void 0
    };

    function hQ({
        K: a,
        mk: b,
        fk: c,
        Yi: d,
        Zo: e,
        ap: f,
        H: g
    }) {
        let h = 0;
        try {
            h |= yp(a, f);
            const m = Math.min(a.screen.width || 0, a.screen.height || 0);
            h |= m ? m < 320 ? 8192 : 0 : 2048;
            h |= a.navigator && iQ(a.navigator.userAgent) ? 1048576 : 0;
            if (b) {
                f = h;
                const n = a.innerHeight;
                var k = Kd(a) * n >= b;
                var l = f | (k ? 0 : 1024)
            } else l = h | (a.innerHeight >= a.innerWidth ? 0 : 8);
            h = l;
            h |= Bp(a, c, !0, e)
        } catch {
            h |= 32
        }
        switch (d) {
            case 2:
                jQ(a, g) && (h |= 16777216);
                break;
            case 1:
                kQ(a, g) && (h |= 16777216)
        }
        return h
    }

    function iQ(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    }

    function jQ(a, b = null) {
        const c = mC({
            qg: 0,
            uf: a.innerWidth,
            Uf: 3,
            rg: 0,
            vf: Math.min(Math.round(a.innerWidth / 320 * 50), lQ) + 15,
            Vf: 3
        });
        return qC(mQ(a, b), c) != null
    }

    function kQ(a, b = null) {
        const c = a.innerWidth,
            d = a.innerHeight,
            e = Math.min(Math.round(a.innerWidth / 320 * 50), lQ) + 15,
            f = mC({
                qg: 0,
                uf: c,
                Uf: 3,
                rg: d - e,
                vf: d,
                Vf: 3
            });
        e > 25 && f.push({
            x: c - 25,
            y: d - 25
        });
        return qC(mQ(a, b), f) != null
    }

    function mQ(a, b = null) {
        return new sC(a, {
            fh: nQ(a, b)
        })
    }

    function nQ(a, b = null) {
        if (b) return (c, d, e) => {
            wl(b, "ach_evt", {
                tn: c.tagName,
                id: c.getAttribute("id") ? ? "",
                cls: c.getAttribute("class") ? ? "",
                ign: String(e),
                pw: a.innerWidth,
                ph: a.innerHeight,
                x: d.x,
                y: d.y
            }, !0, 1)
        }
    }
    const lQ = 90 * 1.38;

    function oQ(a, b) {
        return hQ({
            K: a,
            fk: 3E3,
            mk: a.innerWidth > xp ? 650 : 0,
            H: fy,
            Yi: b
        })
    };

    function pQ(a) {
        let b = 0;
        try {
            b |= yp(a)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function qQ(a) {
        let b = 0;
        try {
            b |= yp(a), b |= Bp(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };
    var eh = class extends N {};
    var rQ = class extends N {
        i() {
            return F(this, 3)
        }
        j() {
            return Gh(this, 4)
        }
    };
    var sQ = class extends N {
            i() {
                return fh(this, rQ, 1)
            }
        },
        tQ = sj(sQ);

    function uQ() {
        var a = q.adsbygoogle;
        try {
            const b = a.pageState;
            Le(b, Qe);
            return tQ(b)
        } catch (b) {
            return new sQ
        }
    };

    function vQ() {
        const a = {};
        Lv(ot) && (a.bust = Lv(ot));
        return a
    };

    function wQ(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    }

    function xQ(a) {
        let b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function yQ(a) {
        return a.hidden != null ? a.hidden : a.mozHidden != null ? a.mozHidden : a.webkitHidden != null ? a.webkitHidden : null
    }

    function zQ(a, b) {
        if (wQ(b) == 3) var c = !1;
        else a(), c = !0;
        if (!c) {
            const d = () => {
                mb(b, "prerenderingchange", d);
                a()
            };
            lb(b, "prerenderingchange", d)
        }
    };

    function AQ(a, b = !1) {
        let c = 0;
        try {
            c |= yp(a);
            var d;
            if (!(d = !a.navigator)) {
                var e = a.navigator;
                d = "brave" in e && "isBrave" in e.brave || !1
            }
            c |= d || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            c |= Bp(a, b ? Number.MAX_SAFE_INTEGER : 2500, !0)
        } catch (f) {
            c |= 32
        }
        return c
    };
    const BQ = "body div footer header html main section".split(" ");

    function CQ(a, b = null, c = !1, d = !1, e = !1) {
        let f = yp(a);
        iQ(a.navigator ? .userAgent) && (f |= 1048576);
        const g = a.innerWidth;
        g < 1200 && (f |= 65536);
        const h = a.innerHeight;
        h < 650 && (f |= 2097152);
        b && f === 0 && (b = b === 3 ? "left" : "right", (c = DQ({
            K: a,
            Zj: !1,
            Qk: 1,
            position: b,
            T: g,
            W: h,
            Rb: new Set,
            minWidth: 120,
            minHeight: 500,
            Bf: c,
            Xf: d,
            Wf: e
        })) ? mA(a).sideRailPlasParam.set(b, `${c.width}x${c.height}_${String(b).charAt(0)}`) : f |= 16);
        return f
    }

    function EQ(a) {
        a = mA(a).sideRailPlasParam;
        return [...Array.from(a.values())].join("|")
    }

    function FQ(a, b) {
        return Ck(a, c => c.nodeType === Node.ELEMENT_NODE && b.has(c)) !== null
    }

    function GQ(a, b) {
        return Ck(a, c => c.nodeType === Node.ELEMENT_NODE && b.getComputedStyle(c, null).position === "fixed")
    }

    function HQ(a) {
        const b = [];
        for (const c of a.document.querySelectorAll("*")) {
            const d = a.getComputedStyle(c, null);
            d.position === "fixed" && d.display !== "none" && d.visibility !== "hidden" && b.push(c)
        }
        return b
    }

    function IQ(a, b) {
        const {
            top: c,
            left: d,
            bottom: e,
            right: f
        } = b.getBoundingClientRect();
        return c >= 0 && d >= 0 && e <= a.innerHeight && f <= a.innerWidth
    }

    function JQ(a) {
        return Math.round(Math.round(a / 10) * 10)
    }

    function KQ(a) {
        return `${a.position}-${JQ(a.T)}x${JQ(a.W)}-${JQ(a.scrollY+a.ic)}Y`
    }

    function LQ(a) {
        return `f-${KQ({position:a.position,ic:a.ic,scrollY:0,T:a.T,W:a.W})}`
    }

    function MQ(a, b) {
        a = Math.min(a ? ? Infinity, b ? ? Infinity);
        return a !== Infinity ? a : 0
    }

    function NQ(a, b, c) {
        const d = mA(c.K).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.max(e.top - 10, 0),
                    g = Math.min(e.bottom + 10, c.W),
                    h = Math.max(e.left - 10, 0);
                e = Math.min(e.right + 10, c.T);
                for (var k = c.T * .3; f <= g; f += 10) {
                    if (e > 0 && h < k) {
                        var l = LQ({
                            position: "left",
                            ic: f,
                            T: c.T,
                            W: c.W
                        });
                        b.set(l, MQ(b.get(l), h))
                    }
                    if (h < c.T && e > c.T - k) {
                        l = LQ({
                            position: "right",
                            ic: f,
                            T: c.T,
                            W: c.W
                        });
                        const m = c.T - e;
                        b.set(l, MQ(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    }

    function OQ(a, b) {
        const c = b.K,
            d = b.Bf,
            e = b.Wf;
        var f = `f-${JQ(b.T)}x${JQ(b.W)}`;
        a.has(f) || (a.set(f, 0), f = HQ(c), d || e ? (PQ(a, b, f.filter(g => IQ(c, g))), QQ(c, f.filter(g => !IQ(c, g)).concat(e ? Array.from(c.document.querySelectorAll("[google-side-rail-overlap=false]")) : []))) : PQ(a, b, f))
    }

    function PQ(a, b, c) {
        var d = b.Rb;
        const e = b.K;
        mA(e).sideRailProcessedFixedElements.clear();
        d = new Set([...Array.from(e.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]")), ...d]);
        for (const f of c) FQ(f, d) || NQ(f, a, b)
    }

    function RQ(a) {
        if (a.T < 1200 || a.W < 650) return null;
        var b = mA(a.K).sideRailAvailableSpace;
        a.Zj || OQ(b, {
            K: a.K,
            T: a.T,
            W: a.W,
            Rb: a.Rb,
            Bf: a.Bf,
            Wf: a.Wf
        });
        const c = [];
        var d = a.W * .9,
            e = Ip(a.K),
            f = (a.W - d) / 2,
            g = f,
            h = d / 7;
        for (var k = 0; k < 8; k++) {
            var l = c,
                m = l.push;
            a: {
                var n = g;
                var p = a.position,
                    t = b,
                    v = {
                        K: a.K,
                        T: a.T,
                        W: a.W,
                        Rb: a.Rb,
                        Xf: a.Xf
                    };
                const L = LQ({
                        position: p,
                        ic: n,
                        T: v.T,
                        W: v.W
                    }),
                    A = KQ({
                        position: p,
                        ic: n,
                        scrollY: e,
                        T: v.T,
                        W: v.W
                    });
                if (t.has(A)) {
                    n = MQ(t.get(L), t.get(A));
                    break a
                }
                const H = p === "left" ? 20 : v.T - 20;
                let K = H;p = v.T * .3 / 5 * (p === "left" ? 1 : -1);
                for (let ia = 0; ia < 6; ia++) {
                    var w = nC(v.K.document, {
                            x: Math.round(K),
                            y: Math.round(n)
                        }),
                        B = FQ(w, v.Rb),
                        G = GQ(w, v.K);
                    if (!B && G !== null) {
                        NQ(G, t, v);
                        t.delete(A);
                        break
                    }
                    B || (B = v, w.getAttribute("google-side-rail-overlap") === "true" ? B = !0 : w.getAttribute("google-side-rail-overlap") === "false" || B.Xf && !BQ.includes(w.tagName.toLowerCase()) ? B = !1 : (G = w.offsetHeight >= B.W * .25, B = w.offsetWidth >= B.T * .9 && G));
                    if (B) t.set(A, Math.round(Math.abs(K - H) + 20));
                    else if (K !== H) K -= p, p /= 2;
                    else {
                        t.set(A, 0);
                        break
                    }
                    K += p
                }
                n = MQ(t.get(L), t.get(A))
            }
            m.call(l,
                n);
            g += h
        }
        b = a.Qk;
        e = a.position;
        d = Math.round(d / 8);
        f = Math.round(f);
        g = a.minWidth;
        a = a.minHeight;
        m = [];
        h = Array(c.length).fill(0);
        for (l = 0; l < c.length; l++) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[l];) m.pop();
            h[l] = m.length === 0 ? 0 : m[m.length - 1] + 1;
            m.push(l)
        }
        m = [];
        k = c.length - 1;
        l = Array(c.length).fill(0);
        for (n = k; n >= 0; n--) {
            for (; m.length !== 0 && c[m[m.length - 1]] >= c[n];) m.pop();
            l[n] = m.length === 0 ? k : m[m.length - 1] - 1;
            m.push(n)
        }
        m = null;
        for (k = 0; k < c.length; k++)
            if (n = {
                    position: e,
                    width: Math.round(c[k]),
                    height: Math.round((l[k] - h[k] + 1) *
                        d),
                    offsetY: f + h[k] * d
                }, t = n.width >= g && n.height >= a, b === 0 && t) {
                m = n;
                break
            } else b === 1 && t && (!m || n.width * n.height > m.width * m.height) && (m = n);
        return m
    }

    function QQ(a, b) {
        const c = mA(a);
        if (b.length && !c.g) {
            var d = new MutationObserver(() => {
                setTimeout(() => {
                    SQ(a);
                    for (const e of c.sideRailMutationCallbacks) e()
                }, 500)
            });
            for (const e of b) d.observe(e, {
                attributes: !0
            });
            c.g = d
        }
    }

    function SQ(a) {
        ({
            sideRailAvailableSpace: a
        } = mA(a));
        const b = Array.from(a.keys()).filter(c => c.startsWith("f-"));
        for (const c of b) a.delete(c)
    }

    function DQ(a) {
        if (a.Aa) return a.Aa.Wa(1228, () => RQ(a)) || null;
        try {
            return RQ(a)
        } catch {}
        return null
    };
    const TQ = {
        [27]: 512,
        [26]: 128
    };
    var UQ = (a, b, c, d) => {
            d = cK(d);
            switch (c) {
                case 1:
                case 2:
                    return oQ(a, c) === 0;
                case 3:
                case 4:
                    return CQ(a, c, !0, W(Vt), !0) === 0;
                case 8:
                    return AQ(a, W(gt)) === 0;
                case 9:
                    return b = !(b.google_adtest === "on" || vN(a.location, "google_scr_debug")), !LG(a, b, d);
                case 30:
                    return BI(a) === 0;
                case 26:
                    return qQ(a) === 0;
                case 27:
                    return pQ(a) === 0;
                case 40:
                    return !0;
                default:
                    return !1
            }
        },
        VQ = (a, b, c, d) => {
            switch (c) {
                case 0:
                case 40:
                case 10:
                case 11:
                    return 0;
                case 1:
                case 2:
                    return oQ(a, c);
                case 3:
                case 4:
                    return CQ(a, c, !1, W(Vt));
                case 8:
                    return AQ(a, W(gt));
                case 9:
                    return LG(a, !(b.google_adtest === "on" || vN(a.location, "google_scr_debug")), d);
                case 16:
                    return Tv(b, a) ? 0 : 8388608;
                case 30:
                    return BI(a);
                case 26:
                    return qQ(a);
                case 27:
                    return pQ(a);
                default:
                    return 32
            }
        },
        WQ = (a, b, c) => {
            const d = b.google_reactive_ad_format;
            if (!Nb(d)) return !1;
            a = $c(a);
            if (!a || !UQ(a, b, d, c)) return !1;
            b = mA(a);
            if (Fp(b, d)) return !1;
            b.adCount[d] || (b.adCount[d] = 0);
            b.adCount[d]++;
            return !0
        },
        YQ = a => {
            const b = a.google_reactive_ad_format;
            return !a.google_reactive_ads_config && XQ(a) && b !== 16 && b !== 10 && b !== 11 && b !==
                40 && b !== 41
        },
        ZQ = a => {
            if (!a.hash) return null;
            let b = null;
            ed(sN, c => {
                !b && vN(a, c) && (b = tN[c] || null)
            });
            return b
        },
        aR = (a, b) => {
            const c = mA(a).tagSpecificState[1] || null;
            c !== null && c.debugCard == null && ed(uN, d => {
                !c.debugCardRequested && typeof d === "number" && yN(d, a.location) && (c.debugCardRequested = !0, $Q(a, b, e => {
                    c.debugCard = e.createDebugCard(d, a)
                }))
            })
        },
        cR = (a, b, c) => {
            if (!b) return null;
            const d = mA(b);
            let e = 0;
            ed(Ob, f => {
                const g = TQ[f];
                g && bR(a, b, f, c) === 0 && (e |= g)
            });
            d.wasPlaTagProcessed && (e |= 256);
            a.google_reactive_tag_first && (e |=
                1024);
            return e ? `${e}` : null
        },
        dR = (a, b, c) => {
            const d = [];
            ed(Ob, e => {
                const f = bR(b, a, e, c);
                f !== 0 && d.push(`${e}:${f}`)
            });
            return d.join(",") || null
        },
        eR = a => {
            const b = [],
                c = {};
            ed(a, (d, e) => {
                if ((e = vp[e]) && !c[e]) {
                    c[e] = !0;
                    if (d) d = 1;
                    else if (d === !1) d = 2;
                    else return;
                    b.push(`${e}:${d}`)
                }
            });
            return b.join(",")
        },
        fR = a => {
            a = a.overlays;
            if (!a) return "";
            a = a.bottom;
            return typeof a === "boolean" ? a ? "1" : "0" : ""
        },
        bR = (a, b, c, d) => {
            if (!b) return 256;
            let e = 0;
            const f = mA(b),
                g = Fp(f, c);
            if (a.google_reactive_ad_format === c || g) e |= 64;
            let h = !1;
            ed(f.reactiveTypeDisabledByPublisher,
                (k, l) => {
                    String(c) === String(l) && (h = !0)
                });
            return h && ZQ(b.location) !== c && (e |= 128, c === 2 || c === 1 || c === 3 || c === 4 || c === 8) ? e : e | VQ(b, a, c, d)
        },
        gR = (a, b) => {
            if (a) {
                var c = mA(a),
                    d = {};
                ed(b, (e, f) => {
                    (f = vp[f]) && (e === !1 || /^false$/i.test(e)) && (d[f] = !0)
                });
                ed(Ob, e => {
                    d[wp[e]] && (c.reactiveTypeDisabledByPublisher[e] = !0)
                })
            }
        },
        hR = (a, b, c) => {
            b = ky(b, c);
            c = { ...vQ()
            };
            const d = X(iv);
            [0, 1].includes(d) && (c.osttc = `${d}`);
            return qN(1, window, Vc(a, new Map(Object.entries(c)))).then(b)
        },
        $Q = (a, b, c) => {
            c = ky(212, c);
            qN(3, a, b).then(c)
        },
        iR = (a, b, c) => {
            a.dataset.adsbygoogleStatus =
                "reserved";
            a.className += " adsbygoogle-noablate";
            c.adsbygoogle || (c.adsbygoogle = [], ad(c.document, Uc `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`));
            c.adsbygoogle.push({
                element: a,
                params: b
            })
        },
        jR = a => {
            a = a.google_reactive_ad_format;
            return Nb(a) ? `${a}` : null
        },
        XQ = a => !!jR(a) || a.google_pgb_reactive != null,
        kR = a => {
            a = Number(jR(a));
            return a === 26 || a === 27 || a === 30 || a === 16 || a === 40 || a === 41
        };

    function lR(a) {
        return typeof a.google_reactive_sra_index === "number"
    }

    function mR(a, b, c) {
        const d = b.K || b.pubWin,
            e = b.C,
            f = cK(c);
        c = dR(d, e, f);
        e.google_reactive_plat = c;
        (c = eR(a)) && (e.google_reactive_plaf = c);
        (c = fR(a)) && (e.google_reactive_fba = c);
        (c = EQ(d)) && (e.google_plas = c);
        nR(a, e);
        c = ZQ(b.pubWin.location);
        oR(a, c, e);
        c ? (e.fra = c, e.google_pgb_reactive = 6) : e.google_pgb_reactive = 5;
        e.asro = W(Ju);
        e.aihb = W(bu);
        e.ailel = gQ(Mv(wu));
        e.aiael = gQ(Mv(du));
        e.aicel = gQ(Mv(hu));
        e.aifxl = gQ(Mv(qu));
        e.aiixl = gQ(Mv(tu));
        X(Ou) && (e.aiapm = X(Ou));
        X(Pu) && (e.aiapmi = X(Pu));
        X(cu) && (e.aiact = X(cu));
        X(fu) && (e.aicct =
            X(fu));
        X(vu) && (e.ailct = X(vu));
        W(nu) && (e.aiescf = !0);
        e.aiof = gQ(Mv(Fu));
        e.fsapi = !0;
        c !== 8 && (f && HG(f) ? (c = KG(f, 86400, "__lsv__"), c ? .length && (c = Math.floor((Date.now() - Math.max(...c)) / 6E4), c >= 0 && (e.vmsli = c))) : e.vmsli = -1);
        c = KG(f, 600, "__lsa__");
        c ? .length && Math.floor((Date.now() - Math.max(...c)) / 6E4) <= X(ft) && (e.dap = 3);
        nk() || YP(b.pubWin.top);
        c = ky(429, (h, k) => pR(b, d, e.google_ad_client, a, h, k, f));
        const g = ky(430, (h, k) => Lp(b.pubWin, "431", fy, k));
        c = RM(b.pubWin, "rsrai", c, g);
        b.j.push(c);
        mA(d).wasReactiveTagRequestSent = !0;
        qR(b, a, f)
    }

    function qR(a, b, c) {
        const d = a.C,
            e = ra(b.page_level_pubvars) ? b.page_level_pubvars : {};
        b = ky(353, (g, h) => {
            const k = Vc(a.ua.qc, new Map(Object.entries(vQ())));
            var l = a.pubWin,
                m = d.google_ad_client;
            return Bd(h.origin) ? bO(l, m, e, g.config, c, k, null) : !1
        });
        const f = ky(353, (g, h) => Lp(a.pubWin, "353", fy, h));
        b = RM(a.pubWin, "apcnf", b, f);
        a.j.push(b)
    }

    function pR(a, b, c, d, e, f, g) {
        if (!Bd(f.origin)) return !1;
        f = e.data;
        if (!Array.isArray(f)) return !1;
        if (!tE(b, 1)) return !0;
        f && Yj(6, [f]);
        e = e.amaConfig;
        const h = [],
            k = [],
            l = mA(b);
        let m = null;
        for (let n = 0; n < f.length; n++) {
            if (!f[n]) continue;
            const p = f[n],
                t = p.adFormat;
            l && p.enabledInAsfe && (l.reactiveTypeEnabledInAsfe[t] = !0);
            if (!p.noCreative) {
                p.google_reactive_sra_index = n;
                if (t === 9 && e) {
                    p.pubVars = Object.assign(p.pubVars || {}, rR(d, p));
                    const v = new MG;
                    if (FG(v, p) && v.G(p)) {
                        m = v;
                        continue
                    }
                }
                h.push(p);
                k.push(t)
            }
        }
        h.length && hR(a.ua.Sh,
            522, n => {
                sR(h, b, n, d, g)
            });
        e && bO(b, c, d, e, g, Vc(a.ua.qc, new Map(Object.entries(vQ()))), m);
        return !0
    }

    function rR(a, b) {
        const c = b.adFormat,
            d = b.adKey;
        delete b.adKey;
        const e = {};
        a = a.page_level_pubvars;
        ra(a) && Object.assign(e, a);
        e.google_ad_unit_key = d;
        e.google_reactive_sra_index = b.google_reactive_sra_index;
        c === 30 && (e.google_reactive_ad_format = 30);
        e.google_pgb_reactive = e.google_pgb_reactive || 5;
        return b.pubVars = e
    }

    function sR(a, b, c, d, e) {
        const f = [];
        for (let g = 0; g < a.length; g++) {
            const h = a[g],
                k = h.adFormat,
                l = h.adKey,
                m = c.configProcessorForAdFormat(k);
            k && m && l && (h.pubVars = rR(d, h), delete h.google_reactive_sra_index, f.push(k), jy(466, () => m.verifyAndProcessConfig(b, h, e)))
        }
    }

    function nR(a, b) {
        const c = [];
        let d = !1;
        ed(vp, (e, f) => {
            let g;
            a.hasOwnProperty(f) && (f = a[f], f ? .google_ad_channel && (g = String(f.google_ad_channel)));
            --e;
            c[e] && c[e] !== "+" || (c[e] = g ? g.replace(/,/g, "+") : "+", d || (d = !!g))
        });
        d && (b.google_reactive_sra_channels = c.join(","))
    }

    function oR(a, b, c) {
        if (!c.google_adtest) {
            var d = a.page_level_pubvars;
            if (a.google_adtest === "on" || d ? .google_adtest === "on" || b) c.google_adtest = "on"
        }
    };
    Tb("script");
    var tR = {
        "image-top": 0,
        "image-middle": 1,
        "image-side": 2,
        "text-only": 3,
        "in-article": 4
    };

    function uR(a, b) {
        if (!Tv(b, a)) return () => {};
        a = vR(b, a);
        if (!a) return () => {};
        const c = pE();
        b = Qb(b);
        const d = {
            Fb: a,
            C: b,
            offsetWidth: a.offsetWidth
        };
        c.push(d);
        return () => Qa(c, d)
    }

    function vR(a, b) {
        a = b.document.getElementById(a.google_async_iframe_id);
        if (!a) return null;
        for (a = a.parentElement; a && !Yv.test(a.className);) a = a.parentElement;
        return a
    }

    function wR(a, b) {
        for (let f = 0; f < a.childNodes.length; f++) {
            const g = {},
                h = a.childNodes[f];
            var c = h.style,
                d = ["width", "height"];
            for (let k = 0; k < d.length; k++) {
                const l = "google_ad_" + d[k];
                if (!g.hasOwnProperty(l)) {
                    var e = md(c[d[k]]);
                    e = e === null ? null : Math.round(e);
                    e != null && (g[l] = e)
                }
            }
            if (g.google_ad_width == b.google_ad_width && g.google_ad_height == b.google_ad_height) return h
        }
        return null
    }

    function xR(a, b) {
        a.style.display = b ? "inline-block" : "none";
        const c = a.parentElement;
        b ? c.dataset.adStatus = a.dataset.adStatus : (a.dataset.adStatus = c.dataset.adStatus, delete c.dataset.adStatus)
    }

    function yR(a, b) {
        const c = b.innerHeight >= b.innerWidth ? 1 : 2;
        if (a.g != c) {
            a.g = c;
            a = pE();
            for (const d of a)
                if (d.Fb.offsetWidth != d.offsetWidth || d.C.google_full_width_responsive_allowed) d.offsetWidth = d.Fb.offsetWidth, jy(467, () => {
                    var e = d.Fb,
                        f = d.C;
                    const g = wR(e, f);
                    f.google_full_width_responsive_allowed && (e.style.marginLeft = f.gfwroml || "", e.style.marginRight = f.gfwromr || "", e.style.height = f.gfwroh ? `${f.gfwroh}px` : "", e.style.width = f.gfwrow ? `${f.gfwrow}px` : "", e.style.zIndex = f.gfwroz || "", delete f.google_full_width_responsive_allowed);
                    delete f.google_ad_format;
                    delete f.google_ad_width;
                    delete f.google_ad_height;
                    delete f.google_content_recommendation_ui_type;
                    delete f.google_content_recommendation_rows_num;
                    delete f.google_content_recommendation_columns_num;
                    b.google_spfd(e, f, b);
                    const h = wR(e, f);
                    !h && g && e.childNodes.length == 1 ? (xR(g, !1), f.google_reactive_ad_format = 16, f.google_ad_section = "responsive_resize", iR(e, f, b)) : h && g && h != g && (xR(g, !1), xR(h, !0))
                })
        }
    }
    var zR = class extends S {
        constructor() {
            super(...arguments);
            this.g = null
        }
        L(a) {
            const b = dE();
            if (!iE(b, 27, !1)) {
                jE(b, 27, !0);
                this.g = a.innerHeight >= a.innerWidth ? 1 : 2;
                var c = () => {
                    yR(this, a)
                };
                lb(a, "resize", c);
                cq(this, () => {
                    mb(a, "resize", c)
                })
            }
        }
    };
    var AR = class {
        constructor(a, b) {
            this.K = a;
            this.Fb = b;
            this.g = null;
            this.j = 0
        }
        run() {
            this.g = q.setInterval(za(this.i, this), 500);
            this.i()
        }
        i() {
            ++this.j >= 10 && q.clearInterval(this.g);
            var a = Wv(this.K, this.Fb);
            Xv(this.K, this.Fb, a);
            a = Sv(this.Fb, this.K);
            a != null && a.x === 0 || q.clearInterval(this.g)
        }
    };
    var BR = class {
        constructor(a) {
            this.i = 0;
            this.g = this.M = null;
            this.I = 0;
            this.j = [];
            this.Fc = this.D = "";
            this.B = this.F = null;
            this.G = !1;
            this.K = a.K;
            this.pubWin = a.pubWin;
            this.C = a.C;
            this.ma = a.ma;
            this.ua = a.ua;
            this.gb = a.gb;
            this.X = a.X;
            this.pageState = a.pageState
        }
    };

    function CR(a, b, c = 1E5) {
        a -= b;
        return a >= c ? "M" : a >= 0 ? a : "-M"
    };
    var Te = {
        Ao: 0,
        wo: 1,
        xo: 9,
        to: 2,
        uo: 3,
        zo: 5,
        yo: 7,
        vo: 10
    };
    var DR = class extends N {},
        ER = sj(DR),
        FR = [1, 3];
    const GR = Uc `https://securepubads.g.doubleclick.net/static/topics/topics_frame.html`;

    function HR(a) {
        const b = a.google_tag_topics_state ? ? (a.google_tag_topics_state = {});
        return b.messageChannelSendRequestFn ? Promise.resolve(b.messageChannelSendRequestFn) : new Promise(c => {
            function d(h) {
                return g.g(h).then(({
                    data: k
                }) => k)
            }
            const e = bd("IFRAME");
            e.style.display = "none";
            e.name = "goog_topics_frame";
            e.src = ac(GR).toString();
            const f = (new URL(GR.toString())).origin,
                g = iN({
                    destination: a,
                    Ca: e,
                    origin: f,
                    We: "goog:gRpYw:doubleclick"
                });
            g.g("goog:topics:frame:handshake:ack").then(({
                data: h
            }) => {
                h === "goog:topics:frame:handshake:ack" &&
                    c(d)
            });
            b.messageChannelSendRequestFn = d;
            a.document.documentElement.appendChild(e)
        })
    }

    function IR(a, b, c) {
        var d = oy(),
            e = W(wv);
        const {
            ud: f,
            rd: g
        } = JR(c);
        b = b.google_tag_topics_state ? ? (b.google_tag_topics_state = {});
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e
        }).then(h => {
            var k = g;
            if (h instanceof Uint8Array) {
                if (!k) {
                    if (k = f instanceof Uint8Array) a: if (qa(h) && qa(f) && h.length == f.length) {
                        k = h.length;
                        for (let n = 0; n < k; n++)
                            if (h[n] !== f[n]) {
                                k = !1;
                                break a
                            }
                        k = !0
                    } else k = !1;
                    k = !k
                }
            } else if (Se()(h)) k || (k = h !== f);
            else return d.ia(989, Error(JSON.stringify(h))), 7;
            if (k && c) try {
                var l =
                    new DR;
                var m = Bh(l, 2, gl());
                h instanceof Uint8Array ? $g(m, 1, FR, Ee(h, !1)) : $g(m, 3, FR, h == null ? h : xf(h));
                c.setItem("goog:cached:topics", Hh(m))
            } catch {}
            return h
        }), b.getTopicsPromise = a);
        return f && !g ? Promise.resolve(f) : b.getTopicsPromise
    }

    function JR(a) {
        if (!a) return {
            ud: null,
            rd: !0
        };
        try {
            const e = a.getItem("goog:cached:topics");
            if (!e) return {
                ud: null,
                rd: !0
            };
            const f = ER(e);
            let g;
            const h = ch(f, FR);
            switch (h) {
                case 0:
                    g = null;
                    break;
                case 1:
                    a = f;
                    var b = Ng(f, FR, 1);
                    const l = a.R;
                    let m = l[x] | 0;
                    const n = Hg(l, m, b),
                        p = Ee(n, !0);
                    p != null && p !== n && Jg(l, m, b, p);
                    var c = p;
                    var d = c == null ? be() : c;
                    g = new Uint8Array(ee(d) || 0);
                    break;
                case 3:
                    g = I(f, Ng(f, FR, 3));
                    break;
                default:
                    mc(h, void 0)
            }
            const k = ph(f, 2) + 6048E5 < gl();
            return {
                ud: g,
                rd: k
            }
        } catch {
            return {
                ud: null,
                rd: !0
            }
        }
    };

    function KR(a) {
        return W(pv) && a ? !!a.match(Lv(nv)) : !1
    }

    function LR(a, b) {
        if (!W(uv) && b.i()) {
            b = JN("shared-storage", a.document);
            const c = JN("browsing-topics", a.document);
            if (b || c) try {
                return HR(a)
            } catch (d) {
                ny(984, d)
            }
        }
        return null
    }
    async function MR(a, b, c, d, e, f) {
        if (JN("browsing-topics", b.document) && e && !W(tv) && !KR(f ? .label))
            if (NR(c, d)) {
                a.B = 1;
                const g = cK(c, b);
                c = e.then(async h => {
                    await IR(h, b, g).then(k => {
                        a.B = k
                    })
                });
                W(vv) && (d = X(xv), d > 0 ? await Promise.race([c, Hd(d)]) : await c)
            } else a.B = 5
    }

    function NR(a, b) {
        return !b.google_restrict_data_processing && b.google_tag_for_under_age_of_consent !== 1 && b.google_tag_for_child_directed_treatment !== 1 && !!a.i() && !oE() && !E(a, 9) && !E(a, 13) && !E(a, 12) && (typeof b.google_privacy_treatments !== "string" || !b.google_privacy_treatments.split(",").includes("disablePersonalization")) && !E(a, 14) && !E(a, 16)
    };

    function OR(a, b, c) {
        const d = b.parentElement ? .classList.contains("adsbygoogle") ? b.parentElement : b;
        c.addEventListener("load", () => {
            PR(d)
        });
        return RM(a, "adpnt", (e, f) => {
            if (Hp(f, c.contentWindow)) {
                e = Kp(e).qid;
                try {
                    c.setAttribute("data-google-query-id", e), a.googletag ? ? (a.googletag = {
                        cmd: []
                    }), a.googletag.queryIds = a.googletag.queryIds ? ? [], a.googletag.queryIds.push(e), a.googletag.queryIds.length > 500 && a.googletag.queryIds.shift()
                } catch {}
                d.dataset.adStatus = "filled";
                e = !0
            } else e = !1;
            return e
        })
    }

    function PR(a) {
        setTimeout(() => {
            a.dataset.adStatus !== "filled" && (a.dataset.adStatus = "unfilled")
        }, 1E3)
    };

    function QR(a, b, {
        bg: c,
        cg: d
    }) {
        return E(b, 8) || (c || !b.i()) && d || !eK(a.g) ? !1 : !0
    }

    function RR(a, b, {
        bg: c,
        cg: d
    }) {
        if (QR(a, b, {
                bg: c,
                cg: d
            })) return gK("__eoi", a.g) ? ? void 0
    }
    var SR = class {
        constructor(a) {
            this.g = a
        }
    };

    function TR(a, b, c) {
        try {
            if (!Bd(c.origin) || !Hp(c, a.g.contentWindow)) return
        } catch (f) {
            return
        }
        const d = b.msg_type;
        let e;
        typeof d === "string" && (e = a.xa[d]) && a.Aa.Wa(168, () => {
            e.call(a, b, c)
        })
    }
    class UR extends S {
        constructor(a, b) {
            var c = oy(),
                d = fy;
            super();
            this.j = a;
            this.g = b;
            this.Aa = c;
            this.H = d;
            this.xa = {};
            this.Ma = this.Aa.Xa(168, (e, f) => void TR(this, e, f));
            this.Ag = this.Aa.Xa(169, (e, f) => Lp(this.j, "ras::xsf", this.H, f));
            this.Z = [];
            this.U(this.xa);
            this.Z.push(QM(this.j, "sth", this.Ma, this.Ag))
        }
        i() {
            for (const a of this.Z) a();
            this.Z.length = 0;
            super.i()
        }
    };
    var VR = class extends UR {};

    function WR(a, b, c = null) {
        return new YR(a, b, c)
    }
    var YR = class extends VR {
        constructor(a, b, c) {
            super(a, b);
            this.A = c;
            this.D = R(HE);
            this.l = () => {};
            lb(this.g, "load", this.l)
        }
        i() {
            mb(this.g, "load", this.l);
            super.i()
        }
        U(a) {
            a["adsense-labs"] = b => {
                if (b = Kp(b).settings)
                    if (b = Ih(Jj, JSON.parse(b)), D(b, 1) != null) {
                        if (gh(b, b.R[x] | 0, Ij, 4, 3, !0).length > 0) {
                            var c = hh(b, Ij, 4, Pg(Ke)),
                                d = c,
                                e = this.D;
                            const h = new $m;
                            for (var f of d) switch (f.getVersion()) {
                                case 1:
                                    yh(h, 1, !0);
                                    break;
                                case 2:
                                    yh(h, 2, !0)
                            }
                            f = new an;
                            f = C(f, 1, bn, h);
                            PE(e, f);
                            e = this.j;
                            f = this.A;
                            if (!iE(dE(), 37, !1)) {
                                e = new WN(e);
                                for (var g of c) switch (g.getVersion()) {
                                    case 1:
                                        TN(e,
                                            "__gads", g, f);
                                        break;
                                    case 2:
                                        TN(e, "__gpi", g, f)
                                }
                                jE(dE(), 37, !0)
                            }
                            Ig(b, 4)
                        }
                        if (g = y(b, Ij, 5)) c = this.j, iE(dE(), 40, !1) || (c = new SR(c), e = ph(g, 2) - Date.now() / 1E3, e = {
                            Ud: Math.max(e, 0),
                            path: F(g, 3),
                            domain: F(g, 4),
                            te: !1
                        }, hK("__eoi", g.getValue(), e, c.g), jE(dE(), 40, !0));
                        Ig(b, 5);
                        g = this.j;
                        c = F(b, 1) || "";
                        if (nK({
                                win: g,
                                Oa: FN()
                            }).g != null) {
                            e = nK({
                                win: g,
                                Oa: FN()
                            });
                            e = e.g != null ? GN(e.getValue()) : {};
                            b !== null && (e[c] = vg(b));
                            try {
                                g.localStorage.setItem("google_adsense_settings", JSON.stringify(e))
                            } catch (h) {}
                        }
                    }
            }
        }
    };

    function ZR(a) {
        a.l = a.A;
        a.D.style.transition = "height 500ms";
        a.sa.style.transition = "height 500ms";
        a.g.style.transition = "height 500ms";
        $R(a)
    }

    function aS(a, b) {
        a.g.contentWindow.postMessage(JSON.stringify({
            msg_type: "expand-on-scroll-result",
            eos_success: !0,
            eos_amount: b,
            googMsgType: "sth"
        }), "*")
    }

    function $R(a) {
        const b = `rect(0px, ${a.g.width}px, ${a.l}px, 0px)`;
        a.g.style.clip = b;
        a.sa.style.clip = b;
        a.g.setAttribute("height", a.l.toString());
        a.g.style.height = `${a.l}px`;
        a.sa.setAttribute("height", a.l.toString());
        a.sa.style.height = `${a.l}px`;
        a.D.style.height = `${a.l}px`
    }

    function bS(a, b) {
        b = ld(b.r_nh);
        a.A = b == null ? 0 : b;
        if (a.A <= 0) return "1";
        a.I = Mk(a.D).y;
        a.F = Ip(a.j);
        if (a.I + a.l < a.F) return "2";
        if (a.I > Dp(a.j) - a.j.innerHeight) return "3";
        b = a.F;
        a.g.setAttribute("height", a.A.toString());
        a.g.style.height = `${a.A}px`;
        a.sa.style.overflow = "hidden";
        a.D.style.position = "relative";
        a.D.style.transition = "height 100ms";
        a.sa.style.transition = "height 100ms";
        a.g.style.transition = "height 100ms";
        b = Math.min(b + a.j.innerHeight - a.I, a.l);
        Fk(a.sa, {
            position: "relative",
            top: "auto",
            bottom: "auto"
        });
        b = `rect(0px, ${a.g.width}px, ${b}px, 0px)`;
        Fk(a.g, {
            clip: b
        });
        Fk(a.sa, {
            clip: b
        });
        return "0"
    }
    var cS = class extends VR {
        constructor(a, b) {
            super(a.K, b);
            this.jd = this.zg = !1;
            this.pa = this.F = this.A = 0;
            this.sa = a.X;
            this.D = this.sa.parentElement && this.sa.parentElement.classList.contains("adsbygoogle") ? this.sa.parentElement : this.sa;
            this.l = parseInt(this.sa.style.height, 10);
            this.wi = this.l / 5;
            this.I = Mk(this.D).y;
            this.vi = hb(ky(651, () => {
                this.I = Mk(this.D).y;
                var c = this.F;
                this.F = Ip(this.j);
                this.l < this.A ? (c = this.F - c, c > 0 && (this.pa += c, this.pa >= this.wi ? (ZR(this), aS(this, this.A)) : (this.l = Math.min(this.A, this.l + c), aS(this,
                    c), $R(this)))) : mb(this.j, "scroll", this.M)
            }), this);
            this.M = () => {
                var c = this.vi;
                Qj.requestAnimationFrame ? Qj.requestAnimationFrame(c) : c()
            }
        }
        U(a) {
            a["expand-on-scroll"] = (b, c) => {
                b = Kp(b);
                this.zg || (this.zg = !0, b = bS(this, b), b === "0" && lb(this.j, "scroll", this.M, ib), c.target.postMessage(JSON.stringify({
                    msg_type: "expand-on-scroll-result",
                    eos_success: b === "0",
                    googMsgType: "sth"
                }), "*"))
            };
            a["expand-on-scroll-force-expand"] = () => {
                this.jd || (this.jd = !0, ZR(this), mb(this.j, "scroll", this.M))
            }
        }
        i() {
            this.M && mb(this.j, "scroll", this.M,
                ib);
            super.i()
        }
    };

    function dS(a) {
        const b = a.I.getBoundingClientRect(),
            c = b.top + b.height < 0;
        return !(b.top > a.g.innerHeight) && !c
    }
    var eS = class extends S {
        constructor(a, b, c) {
            super();
            this.g = a;
            this.A = b;
            this.I = c;
            this.D = 0;
            this.l = dS(this);
            const d = gb(this.F, this);
            this.j = ky(433, () => {
                Qj.requestAnimationFrame ? Qj.requestAnimationFrame(d) : d()
            });
            lb(this.g, "scroll", this.j, ib)
        }
        F() {
            const a = dS(this);
            if (a && !this.l) {
                var b = {
                    rr: "vis-bcr"
                };
                const c = this.A.contentWindow;
                c && (SM(c, "ig", b, "*", 2), ++this.D >= 10 && this.dispose())
            }
            this.l = a
        }
        dispose() {
            this.j && mb(this.g, "scroll", this.j, ib)
        }
    };

    function fS(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return typeof c === "string" ? c : c.property + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        Fk(a, "transition", b.join(","))
    }
    var gS = eb(function() {
        const a = vk(document, "DIV"),
            b = Ic ? "-webkit" : Hc ? "-moz" : null;
        let c = "transition:opacity 1s linear;";
        b && (c += b + "-transition:opacity 1s linear;");
        tc(a, Sc("div", {
            style: c
        }));
        return Ik(a.firstChild, "transition") != ""
    });

    function hS(a, b, c) {
        a.i[b].indexOf(c) < 0 && (a.i[b] += c)
    }

    function iS(a, b) {
        a.g.indexOf(b) >= 0 || (a.g = b + a.g)
    }

    function jS(a, b) {
        a.errors.indexOf(b) < 0 && (a.errors = b + a.errors)
    }

    function kS(a, b, c, d) {
        return a.errors != "" || b ? null : a.g.replace(lS, "") == "" ? c != null && a.i[0] || d != null && a.i[1] ? !1 : !0 : !1
    }

    function mS(a) {
        var b = kS(a, "", null, 0);
        if (b === null) return "XS";
        b = b ? "C" : "N";
        a = a.g;
        return a.indexOf("a") >= 0 ? b + "A" : a.indexOf("f") >= 0 ? b + "F" : b + "S"
    }
    var nS = class {
        constructor(a, b) {
            this.i = ["", ""];
            this.g = a || "";
            this.errors = b || ""
        }
        toString() {
            return [this.i[0], this.i[1], this.g, this.errors].join("|")
        }
    };

    function oS(a) {
        let b = a.Z;
        a.D = () => {};
        pS(a, a.A, b);
        let c = a.A.parentElement;
        if (!c) return a.g;
        let d = !0,
            e = null;
        for (; c;) {
            try {
                e = /^head|html$/i.test(c.nodeName) ? null : cd(c, b)
            } catch (g) {
                jS(a.g, "c")
            }
            const f = qS(a, b, c, e);
            c.classList.contains("adsbygoogle") && e && (/^\-.*/.test(e["margin-left"]) || /^\-.*/.test(e["margin-right"])) && (a.U = !0);
            if (d && !f && rS(e)) {
                iS(a.g, "l");
                a.F = c;
                break
            }
            d = d && f;
            if (e && sS(a, e)) break;
            c = c.parentElement;
            if (!c) {
                if (b === a.pubWin) break;
                try {
                    if (c = b.frameElement, b = b.parent, !Xc(b)) {
                        iS(a.g, "c");
                        break
                    }
                } catch (g) {
                    iS(a.g,
                        "c");
                    break
                }
            }
        }
        a.G && a.B && tS(a);
        return a.g
    }

    function uS(a) {
        function b(m) {
            for (let n = 0; n < m.length; n++) Fk(k, m[n], "0px")
        }

        function c() {
            vS(d, g, h);
            !k || l || h || (b(wS), b(xS))
        }
        const d = a.A;
        d.style.overflow = a.md ? "visible" : "hidden";
        a.G && (a.F ? (fS(d, yS()), fS(a.F, yS())) : fS(d, "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1) .3s, height .5s cubic-bezier(.4, 0, 1, 1)"));
        a.M !== null && (d.style.opacity = String(a.M));
        const e = a.width != null && a.j != null && (a.re || a.j > a.width) ? a.j : null,
            f = a.height != null && a.i != null && (a.re || a.i > a.height) ? a.i : null;
        if (a.I) {
            const m =
                a.I.length;
            for (let n = 0; n < m; n++) vS(a.I[n], e, f)
        }
        const g = a.j,
            h = a.i,
            k = a.F,
            l = a.U;
        a.G ? q.setTimeout(c, 1E3) : c()
    }

    function zS(a) {
        if (a.B && !a.pa || a.j == null && a.i == null && a.M == null && a.B) return a.g;
        var b = a.B;
        a.B = !1;
        oS(a);
        a.B = b;
        if (!b || a.check != null && !kS(a.g, a.check, a.j, a.i)) return a.g;
        a.g.g.indexOf("n") >= 0 && (a.width = null, a.height = null);
        if (a.width == null && a.j !== null || a.height == null && a.i !== null) a.G = !1;
        (a.j == 0 || a.i == 0) && a.g.g.indexOf("l") >= 0 && (a.j = 0, a.i = 0);
        b = a.g;
        b.i[0] = "";
        b.i[1] = "";
        b.g = "";
        b.errors = "";
        uS(a);
        return oS(a)
    }

    function sS(a, b) {
        let c = !1;
        b.display == "none" && (iS(a.g, "n"), a.B && (c = !0));
        b.visibility != "hidden" && b.visibility != "collapse" || iS(a.g, "v");
        b.overflow == "hidden" && iS(a.g, "o");
        b.position == "absolute" ? (iS(a.g, "a"), c = !0) : b.position == "fixed" && (iS(a.g, "f"), c = !0);
        return c
    }

    function pS(a, b, c) {
        let d = 0;
        if (!b || !b.parentElement) return !0;
        let e = !1,
            f = 0;
        const g = b.parentElement.childNodes;
        for (let k = 0; k < g.length; k++) {
            var h = g[k];
            h == b ? e = !0 : (h = AS(a, h, c), d |= h, e && (f |= h))
        }
        f & 1 && (d & 2 && hS(a.g, 0, "o"), d & 4 && hS(a.g, 1, "o"));
        return !(d & 1)
    }

    function qS(a, b, c, d) {
        let e = null;
        try {
            e = c.style
        } catch (w) {
            jS(a.g, "s")
        }
        var f = c.getAttribute("width"),
            g = ld(f),
            h = c.getAttribute("height"),
            k = ld(h),
            l = d && /^block$/.test(d.display) || e && /^block$/.test(e.display);
        b = pS(a, c, b);
        var m = d && d.width;
        const n = d && d.height;
        var p = e && e.width,
            t = e && e.height,
            v = md(m) == a.width && md(n) == a.height;
        m = v ? m : p;
        t = v ? n : t;
        p = md(m);
        v = md(t);
        g = a.width !== null && (p !== null && a.width >= p || g !== null && a.width >= g);
        v = a.height !== null && (v !== null && a.height >= v || k !== null && a.height >= k);
        k = !b && rS(d);
        v = b || v || k || !(f ||
            m || d && (!BS(String(d.minWidth)) || !CS(String(d.maxWidth))));
        l = b || g || k || l || !(h || t || d && (!BS(String(d.minHeight)) || !CS(String(d.maxHeight))));
        DS(a, 0, v, c, "width", f, a.width, a.j);
        ES(a, 0, "d", v, e, d, "width", m, a.width, a.j);
        ES(a, 0, "m", v, e, d, "minWidth", e && e.minWidth, a.width, a.j);
        ES(a, 0, "M", v, e, d, "maxWidth", e && e.maxWidth, a.width, a.j);
        a.eg ? (c = /^html|body$/i.test(c.nodeName), f = md(n), h = d ? d.overflowY === "auto" || d.overflowY === "scroll" : !1, h = a.i != null && d && f && Math.round(f) !== a.i && !h && d.minHeight !== "100%", a.B && !c && h && (e.setProperty("height",
            "auto", "important"), d && !BS(String(d.minHeight)) && e.setProperty("min-height", "0px", "important"), d && !CS(String(d.maxHeight)) && a.i && Math.round(f) < a.i && e.setProperty("max-height", "none", "important"))) : (DS(a, 1, l, c, "height", h, a.height, a.i), ES(a, 1, "d", l, e, d, "height", t, a.height, a.i), ES(a, 1, "m", l, e, d, "minHeight", e && e.minHeight, a.height, a.i), ES(a, 1, "M", l, e, d, "maxHeight", e && e.maxHeight, a.height, a.i));
        return b
    }

    function tS(a) {
        function b() {
            if (c > 0) {
                var l = cd(e, d) || {
                    width: 0,
                    height: 0
                };
                const m = md(l.width);
                l = md(l.height);
                m !== null && f !== null && h && h(0, f - m);
                l !== null && g !== null && h && h(1, g - l);
                --c
            } else q.clearInterval(k), h && (h(0, 0), h(1, 0))
        }
        let c = 31.25;
        const d = a.Z,
            e = a.A,
            f = a.j,
            g = a.i,
            h = a.D;
        let k;
        q.setTimeout(() => {
            k = q.setInterval(b, 16)
        }, 990)
    }

    function AS(a, b, c) {
        if (b.nodeType == 3) return /\S/.test(b.data) ? 1 : 0;
        if (b.nodeType == 1) {
            if (/^(head|script|style)$/i.test(b.nodeName)) return 0;
            let d = null;
            try {
                d = cd(b, c)
            } catch (e) {}
            if (d) {
                if (d.display == "none" || d.position == "fixed") return 0;
                if (d.position == "absolute") {
                    if (!a.l.boundingClientRect || d.visibility == "hidden" || d.visibility == "collapse") return 0;
                    c = null;
                    try {
                        c = b.getBoundingClientRect()
                    } catch (e) {
                        return 0
                    }
                    return (c.right > a.l.boundingClientRect.left ? 2 : 0) | (c.bottom > a.l.boundingClientRect.top ? 4 : 0)
                }
            }
            return 1
        }
        return 0
    }

    function DS(a, b, c, d, e, f, g, h) {
        if (h != null) {
            if (typeof f == "string") {
                if (f == "100%" || !f) return;
                f = ld(f);
                f == null && (jS(a.g, "n"), hS(a.g, b, "d"))
            }
            if (f != null)
                if (c) {
                    if (a.B)
                        if (a.G) {
                            const k = Math.max(f + h - (g || 0), 0),
                                l = a.D;
                            a.D = (m, n) => {
                                m == b && uc(d, e, String(k - n));
                                l && l(m, n)
                            }
                        } else uc(d, e, String(h))
                } else hS(a.g, b, "d")
        }
    }

    function ES(a, b, c, d, e, f, g, h, k, l) {
        if (l != null) {
            f = f && f[g];
            typeof f != "string" || (c == "m" ? BS(f) : CS(f)) || (f = md(f), f == null ? iS(a.g, "p") : k != null && iS(a.g, f == k ? "E" : "e"));
            if (typeof h == "string") {
                if (c == "m" ? BS(h) : CS(h)) return;
                h = md(h);
                h == null && (jS(a.g, "p"), hS(a.g, b, c))
            }
            if (h != null)
                if (d && e) {
                    if (a.B)
                        if (a.G) {
                            const m = Math.max(h + l - (k || 0), 0),
                                n = a.D;
                            a.D = (p, t) => {
                                p == b && (e[g] = m - t + "px");
                                n && n(p, t)
                            }
                        } else e[g] = l + "px"
                } else hS(a.g, b, c)
        }
    }
    var JS = class {
        constructor(a, b, c, d, e, f, g) {
            this.pubWin = a;
            this.A = b;
            this.I = c;
            this.F = this.D = null;
            this.U = !1;
            this.l = new FS(this.A);
            this.Z = (a = this.A.ownerDocument) && (a.defaultView || a.parentWindow);
            this.l = new FS(this.A);
            this.B = g;
            this.pa = GS(this.l, d.tg, d.height, d.bd);
            this.width = this.B ? this.l.boundingClientRect ? this.l.boundingClientRect.right - this.l.boundingClientRect.left : null : e;
            this.height = this.B ? this.l.boundingClientRect ? this.l.boundingClientRect.bottom - this.l.boundingClientRect.top : null : f;
            this.j = HS(d.width);
            this.i = HS(d.height);
            this.M = this.B ? HS(d.opacity) : null;
            this.check = d.check;
            this.bd = !!d.bd;
            this.G = d.tg == "animate" && !IS(this.l, this.i, this.bd) && gS();
            this.md = !!d.md;
            this.g = new nS;
            IS(this.l, this.i, this.bd) && iS(this.g, "r");
            e = this.l;
            e.g && e.i >= e.W && iS(this.g, "b");
            this.re = !!d.re;
            this.eg = !!d.eg
        }
    };

    function IS(a, b, c) {
        var d;
        (d = a.g) && !(d = !a.visible) && (c ? (b = a.i + Math.min(b, HS(a.getHeight())), a = a.g && b >= a.W) : a = a.g && a.i >= a.W, d = a);
        return d
    }
    var FS = class {
        constructor(a) {
            this.boundingClientRect = null;
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c && $c(c);
            this.g = !!c;
            if (a) try {
                this.boundingClientRect = a.getBoundingClientRect()
            } catch (g) {}
            var d = a;
            let e = 0,
                f = this.boundingClientRect;
            for (; d;) try {
                f && (e += f.top);
                const g = d.ownerDocument,
                    h = g && (g.defaultView || g.parentWindow);
                (d = h && h.frameElement) && (f = d.getBoundingClientRect())
            } catch (g) {
                break
            }
            this.i = e;
            c = c || q;
            this.W = (c.document.compatMode == "CSS1Compat" ? c.document.documentElement : c.document.body).clientHeight;
            b = b && wQ(b);
            this.visible = !!a && !(b == 2 || b == 3) && !(this.boundingClientRect && this.boundingClientRect.top >= this.boundingClientRect.bottom && this.boundingClientRect.left >= this.boundingClientRect.right)
        }
        isVisible() {
            return this.visible
        }
        getWidth() {
            return this.boundingClientRect ? this.boundingClientRect.right - this.boundingClientRect.left : null
        }
        getHeight() {
            return this.boundingClientRect ? this.boundingClientRect.bottom - this.boundingClientRect.top : null
        }
    };

    function GS(a, b, c, d) {
        switch (b) {
            case "no_rsz":
                return !1;
            case "force":
            case "animate":
                return !0;
            default:
                return IS(a, c, d)
        }
    }

    function rS(a) {
        return !!a && /^left|right$/.test(a.cssFloat || a.styleFloat)
    }

    function KS(a, b, c, d) {
        return zS(new JS(a, b, d, c, null, null, !0))
    }
    var LS = new nS("s", ""),
        lS = RegExp("[lonvafrbpEe]", "g");

    function CS(a) {
        return !a || /^(auto|none|100%)$/.test(a)
    }

    function BS(a) {
        return !a || /^(0px|auto|none|0%)$/.test(a)
    }

    function vS(a, b, c) {
        b !== null && ld(a.getAttribute("width")) !== null && a.setAttribute("width", String(b));
        c !== null && ld(a.getAttribute("height")) !== null && a.setAttribute("height", String(c));
        b !== null && (a.style.width = b + "px");
        c !== null && (a.style.height = c + "px")
    }
    var wS = "margin-left margin-right padding-left padding-right border-left-width border-right-width".split(" "),
        xS = "margin-top margin-bottom padding-top padding-bottom border-top-width border-bottom-width".split(" ");

    function yS() {
        let a = "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1), height .3s cubic-bezier(.4, 0, 1, 1) .2s",
            b = wS;
        for (var c = 0; c < b.length; c++) a += ", " + b[c] + " .2s cubic-bezier(.4, 0, 1, 1)";
        b = xS;
        for (c = 0; c < b.length; c++) a += ", " + b[c] + " .3s cubic-bezier(.4, 0, 1, 1) .2s";
        return a
    }

    function HS(a) {
        return typeof a === "string" ? ld(a) : typeof a === "number" && isFinite(a) ? a : null
    };
    var MS = class extends VR {
        constructor(a, b, c) {
            super(a, b);
            this.X = c
        }
        U(a) {
            a["resize-me"] = (b, c) => {
                b = Kp(b);
                var d = b.r_chk;
                if (d == null || d === "") {
                    var e = ld(b.r_nw),
                        f = ld(b.r_nh),
                        g = ld(b.r_no);
                    g != null || e !== 0 && f !== 0 || (g = 0);
                    var h = b.r_str;
                    h = h ? h : null; {
                        var k = /^true$/.test(b.r_ao),
                            l = /^true$/.test(b.r_ifr),
                            m = /^true$/.test(b.r_cab);
                        const t = window;
                        if (t)
                            if (h === "no_rsz") b.err = "7", e = !0;
                            else {
                                var n = new FS(this.g);
                                if (n.g) {
                                    var p = n.getWidth();
                                    p != null && (b.w = p);
                                    p = n.getHeight();
                                    p != null && (b.h = p);
                                    GS(n, h, f, m) ? (n = this.X, d = KS(t, n, {
                                        width: e,
                                        height: f,
                                        opacity: g,
                                        check: d,
                                        tg: h,
                                        md: k,
                                        re: l,
                                        bd: m
                                    }, [this.g]), b.r_cui && /^true$/.test(b.r_cui.toString()) && u(n, {
                                        height: `${f===null?0:f-48}px`,
                                        top: "24px"
                                    }), e != null && (b.nw = e), f != null && (b.nh = f), b.rsz = d.toString(), b.abl = mS(d), b.frsz = (h === "force").toString(), b.err = "0", e = !0) : (b.err = "1", e = !1)
                                } else b.err = "3", e = !1
                            }
                        else b.err = "2", e = !1
                    }
                    c.source.postMessage(JSON.stringify({
                        msg_type: "resize-result",
                        r_str: h,
                        r_status: e,
                        googMsgType: "sth"
                    }), "*");
                    this.g.dataset.googleQueryId || this.g.setAttribute("data-google-query-id",
                        b.qid)
                }
            }
        }
    };
    const NS = ["google_ad_client", "google_ad_format", "google_ad_height", "google_ad_width", "google_page_url"];

    function OS(a, b) {
        return new IntersectionObserver(b, a)
    }

    function PS(a, b, c) {
        lb(a, b, c);
        return () => mb(a, b, c)
    }
    let QS = null;

    function RS() {
        QS = gl()
    }

    function SS(a, b) {
        return b ? QS === null ? (lb(a, "mousemove", RS, {
            passive: !0
        }), lb(a, "scroll", RS, {
            passive: !0
        }), RS(), !1) : gl() - QS >= b * 1E3 : !1
    }

    function TS({
        win: a,
        element: b,
        gi: c,
        fi: d,
        ei: e = 0,
        Ta: f,
        ah: g,
        options: h = {},
        Dh: k = !0,
        Sj: l = OS
    }) {
        let m, n = !1,
            p = !1;
        const t = [],
            v = l(h, (w, B) => {
                try {
                    const G = () => {
                        t.length || (d && (t.push(PS(b, "mouseenter", () => {
                            n = !0;
                            G()
                        })), t.push(PS(b, "mouseleave", () => {
                            n = !1;
                            G()
                        }))), t.push(PS(a.document, "visibilitychange", () => G())));
                        const L = SS(a, e),
                            A = yQ(a.document);
                        if (p && !n && !L && !A) m = m || a.setTimeout(() => {
                            SS(a, e) ? G() : (f(), B.disconnect())
                        }, c * 1E3);
                        else if (k || n || L || A) a.clearTimeout(m), m = void 0
                    };
                    ({
                        isIntersecting: p
                    } = w[w.length - 1]);
                    G()
                } catch (G) {
                    g &&
                        g(G)
                }
            });
        v.observe(b);
        return () => {
            v.disconnect();
            for (const w of t) w();
            m != null && a.clearTimeout(m)
        }
    };

    function US(a, b, c, d = null) {
        return d ? (d = cK(d, a)) ? new VS(a, b, c, d) : null : null
    }

    function WS(a, b) {
        b = Kp(b);
        QE(a.l, bo(new eo, Yn(new Zn, Vn(Un(new Wn, ld(b.s_w) ? ? 0), ld(b.s_h) ? ? 0).g()).g()).g());
        a.A = TS({
            win: a.j,
            element: a.X,
            gi: 1,
            fi: !Gb(),
            ei: 0,
            Ta: () => {
                var c = a.l;
                var d = new eo;
                var e = (new ao).g();
                d = C(d, 4, co, e);
                return void QE(c, d.g())
            },
            ah: c => ny(1268, c),
            options: {
                threshold: .5
            },
            Dh: !0,
            Sj: void 0
        })
    }
    var VS = class extends VR {
        constructor(a, b, c, d) {
            super(a, b);
            this.X = c;
            this.storage = d;
            this.l = R(HE);
            this.A = null
        }
        U(a) {
            a["survey-submitted"] = b => {
                var c = gl() + X(Xt) * 1E3;
                this.storage.setItem("google_survey_fcap", String(c));
                c = this.l;
                var d = new eo;
                var e = (new $n).g();
                d = C(d, 2, co, e);
                QE(c, d.g());
                this.A ? .();
                W(au) && (b = Kp(b).s_a, this.storage.setItem("__ssiua__", b))
            };
            a["survey-rendered"] = b => void WS(this, b)
        }
        i() {
            this.A ? .();
            super.i()
        }
    };

    function XS(a, b, c, d, e) {
        return new YS(a, b, c, d, e)
    }

    function ZS(a, b, c) {
        const d = a.g,
            e = a.D;
        if (e != null && d != null && Hp(c, d.contentWindow) && (b = b.config, typeof b === "string")) {
            try {
                var f = JSON.parse(b);
                if (!Array.isArray(f)) return;
                a.l = Ih(Kj, f)
            } catch (g) {
                return
            }
            a.dispose();
            f = oh(a.l, 1);
            f <= 0 || (a.A = TS({
                win: a.j,
                element: e,
                gi: f - .2,
                fi: !Gb(),
                ei: oh(a.l, 3),
                Ta: () => void $S(a, e),
                ah: g => np.ia(1223, g, void 0, void 0),
                options: {
                    threshold: qh(a.l, 2, 1)
                },
                Dh: !0
            }))
        }
    }

    function $S(a, b) {
        a.F();
        setTimeout(np.Xa(1224, () => {
            var c = Number(a.C.rc);
            a.C.rc = c ? c + 1 : 1;
            c = b.parentElement || null;
            c && Yv.test(c.className) || (c = vk(document, "INS"), c.className = "adsbygoogle", b.parentNode && b.parentNode.insertBefore(c, b.nextSibling));
            W(Pt) ? (aT(a, c, b), a.C.no_resize = !0, nq(ZF(c), "filled", () => {
                wk(b)
            })) : wk(b);
            iR(c, a.C, a.j)
        }), 200)
    }

    function aT(a, b, c) {
        a.j.getComputedStyle(b).position === "static" && (b.style.position = "relative");
        c.style.position = "absolute";
        c.style.top = "0";
        c.style.left = "0";
        delete b.dataset.adsbygoogleStatus;
        delete b.dataset.adStatus;
        b.classList.remove("adsbygoogle-noablate")
    }
    var YS = class extends VR {
        constructor(a, b, c, d, e) {
            super(a, b);
            this.C = c;
            this.D = d;
            this.F = e;
            this.l = this.A = null;
            (b = (b = b.contentWindow) && b.parent) && a !== b && this.Z.push(QM(b, "sth", this.Ma, this.Ag))
        }
        U(a) {
            a.av_ref = (b, c) => {
                ZS(this, b, c)
            }
        }
        i() {
            super.i();
            this.D = null;
            this.A && this.A()
        }
    };

    function bT(a) {
        if (W(Qt)) {
            var b = a.X.parentElement || null;
            b && Yv.test(b.className) && nq(ZF(b), "unfilled", () => {
                var c;
                if (c = W(Qt))
                    if (c = !iE(dE(), 42, !1)) {
                        a: switch (a.C.google_reactive_ad_format) {
                            case 0:
                            case 27:
                            case 40:
                                c = !0;
                                break a;
                            default:
                                c = !1
                        }
                        if (c = c && a.C.google_ad_width >= X(Yt)) a.g ? (c = new WN(a.pubWin), c = a.g.i() ? !!eK(c.win) : !1) : c = !1;c && (c = (c = a.g ? cK(a.g, a.pubWin) : null) ? (c.getItem("google_survey_fcap") ? Number(c.getItem("google_survey_fcap")) : 0) <= gl() : !1);
                        if (c) a: if (W(st) || Db() || Bb()) c = !0;
                            else {
                                if (Eb() && a.l && a.l.label) switch (a.l.label) {
                                    case "treatment_1.1":
                                    case "treatment_1.2":
                                    case "treatment_1.3":
                                    case "control_2":
                                        c = !0;
                                        break a
                                }
                                c = !1
                            }
                        c && (c = (c = Ap(a.pubWin)) ? b.getBoundingClientRect().top > c : !1)
                    }
                if (c) {
                    c = a.pubWin.document.createElement("ins");
                    var d = b.getAttribute("style");
                    d && c.setAttribute("style", d);
                    a.C.google_ad_height && (c.style.height = `${a.C.google_ad_height}px`);
                    (d = b.getAttribute("class")) && c.setAttribute("class", d);
                    (d = b.getAttribute("id")) && c.setAttribute("id", d);
                    b.replaceWith(c);
                    d = a.C;
                    var e = {};
                    for (f of NS) d[f] && (e[f] = d[f]);
                    e.sso = !0;
                    iR(c, e, a.pubWin);
                    var f = c;
                    jE(dE(), 42, !0);
                    if (d = a.g ? cK(a.g, a.pubWin) : null) c = gl() +
                        X(Wt) * 1E3, d.setItem("google_survey_fcap", String(c));
                    var g = Jp(a.pubWin),
                        h = Ip(a.pubWin);
                    const l = f.getBoundingClientRect();
                    d = a.C.google_page_url;
                    f = R(HE);
                    c = new eo;
                    e = new Xn;
                    var k = new Tn;
                    h = Bh(k, 1, Math.round(l.top + h));
                    g = Bh(h, 2, Math.round(l.left + g)).g();
                    e = z(e, 1, g);
                    g = Vn(Un(new Wn, Math.round(a.C.google_ad_width ? ? 0)), Math.round(a.C.google_ad_height ? ? 0)).g();
                    e = z(e, 2, g);
                    g = W(st);
                    e = yh(e, 3, g);
                    d = Dh(e, 4, typeof d === "string" ? d : "").g();
                    c = C(c, 1, co, d);
                    QE(f, c.g())
                }
            })
        }
    };
    const cT = /^blogger$/,
        dT = /^wordpress(.|\s|$)/i,
        eT = /^joomla!/i,
        fT = /^drupal/i,
        gT = /\/wp-content\//,
        hT = /\/wp-content\/plugins\/advanced-ads/,
        iT = /\/wp-content\/themes\/genesis/,
        jT = /\/wp-content\/plugins\/genesis/;

    function kT(a) {
        var b = a.getElementsByTagName("script"),
            c = b.length;
        for (var d = 0; d < c; ++d) {
            var e = b[d];
            if (e.hasAttribute("src")) {
                e = e.getAttribute("src") || "";
                if (hT.test(e)) return 5;
                if (jT.test(e)) return 6
            }
        }
        b = a.getElementsByTagName("link");
        c = b.length;
        for (d = 0; d < c; ++d)
            if (e = b[d], e.hasAttribute("href") && (e = e.getAttribute("href") || "", iT.test(e) || jT.test(e))) return 6;
        a = a.getElementsByTagName("meta");
        d = a.length;
        for (e = 0; e < d; ++e) {
            var f = a[e];
            if (f.getAttribute("name") == "generator" && f.hasAttribute("content")) {
                f = f.getAttribute("content") ||
                    "";
                if (cT.test(f)) return 1;
                if (dT.test(f)) return 2;
                if (eT.test(f)) return 3;
                if (fT.test(f)) return 4
            }
        }
        for (a = 0; a < c; ++a)
            if (d = b[a], d.getAttribute("rel") == "stylesheet" && d.hasAttribute("href") && (d = d.getAttribute("href") || "", gT.test(d))) return 2;
        return 0
    };
    var lT = {
        google_ad_block: "ad_block",
        google_ad_client: "client",
        google_ad_intent_query: "ait_q",
        google_ad_output: "output",
        google_ad_callback: "callback",
        google_ad_height: "h",
        google_ad_resize: "twa",
        google_ad_slot: "slotname",
        google_ad_unit_key: "adk",
        google_ad_dom_fingerprint: "adf",
        google_ad_intent_qetid: "aiqeid",
        google_placement_id: "pi",
        google_daaos_ts: "daaos",
        google_erank: "epr",
        google_ad_width: "w",
        abgtt: "abgtt",
        google_captcha_token: "captok",
        google_content_recommendation_columns_num: "cr_col",
        google_content_recommendation_rows_num: "cr_row",
        google_ctr_threshold: "ctr_t",
        google_cust_criteria: "cust_params",
        gfwrnwer: "fwrn",
        gfwrnher: "fwrnh",
        google_image_size: "image_size",
        google_last_modified_time: "lmt",
        google_loeid: "loeid",
        google_max_num_ads: "num_ads",
        google_max_radlink_len: "max_radlink_len",
        google_mtl: "mtl",
        google_native_settings_key: "nsk",
        google_enable_content_recommendations: "ecr",
        google_num_radlinks: "num_radlinks",
        google_num_radlinks_per_unit: "num_radlinks_per_unit",
        google_pucrd: "pucrd",
        google_reactive_plaf: "plaf",
        google_reactive_plat: "plat",
        google_reactive_fba: "fba",
        google_reactive_sra_channels: "plach",
        google_responsive_auto_format: "rafmt",
        armr: "armr",
        google_plas: "plas",
        google_rl_dest_url: "rl_dest_url",
        google_rl_filtering: "rl_filtering",
        google_rl_mode: "rl_mode",
        google_rt: "rt",
        google_video_play_muted: "vpmute",
        google_source_type: "src_type",
        google_restrict_data_processing: "rdp",
        google_tag_for_child_directed_treatment: "tfcd",
        google_tag_for_under_age_of_consent: "tfua",
        google_tag_origin: "to",
        google_ad_semantic_area: "sem",
        google_tfs: "tfs",
        google_package: "pwprc",
        google_tag_partner: "tp",
        fra: "fpla",
        google_ml_rank: "mlr",
        google_apsail: "psa",
        google_ad_channel: "channel",
        google_ad_type: "ad_type",
        google_ad_format: "format",
        google_color_bg: "color_bg",
        google_color_border: "color_border",
        google_color_link: "color_link",
        google_color_text: "color_text",
        google_color_url: "color_url",
        google_page_url: "url",
        google_ad_section: "region",
        google_cpm: "cpm",
        google_encoding: "oe",
        google_safe: "adsafe",
        google_font_face: "f",
        google_font_size: "fs",
        google_hints: "hints",
        google_ad_host: "host",
        google_ad_host_channel: "h_ch",
        google_ad_host_tier_id: "ht_id",
        google_kw_type: "kw_type",
        google_kw: "kw",
        google_contents: "contents",
        google_targeting: "targeting",
        google_adtest: "adtest",
        google_alternate_color: "alt_color",
        google_alternate_ad_url: "alternate_ad_url",
        google_cust_age: "cust_age",
        google_cust_gender: "cust_gender",
        google_cust_l: "cust_l",
        google_cust_lh: "cust_lh",
        google_language: "hl",
        google_city: "gcs",
        google_country: "gl",
        google_region: "gr",
        google_content_recommendation_ad_positions: "ad_pos",
        google_content_recommendation_ui_type: "crui",
        google_content_recommendation_use_square_imgs: "cr_sq_img",
        sso: "sso",
        google_color_line: "color_line",
        google_disable_video_autoplay: "disable_video_autoplay",
        google_full_width_responsive_allowed: "fwr",
        google_full_width_responsive: "fwrattr",
        efwr: "efwr",
        google_pgb_reactive: "pra",
        rc: "rc",
        google_resizing_allowed: "rs",
        google_resizing_height: "rh",
        google_resizing_width: "rw",
        rpe: "rpe",
        google_responsive_formats: "resp_fmts",
        google_safe_for_responsive_override: "sfro",
        google_video_doc_id: "video_doc_id",
        google_video_product_type: "video_product_type",
        google_webgl_support: "wgl",
        aihb: "aihb",
        aiof: "aiof",
        asro: "asro",
        ailel: "ailel",
        aiael: "aiael",
        aicel: "aicel",
        aifxl: "aifxl",
        aiixl: "aiixl",
        vmsli: "itsi",
        dap: "dap",
        aiapm: "aiapm",
        aiapmi: "aiapmi",
        aiact: "aiact",
        aicct: "aicct",
        ailct: "ailct",
        aiescf: "aiescf"
    };

    function mT(a) {
        a.g === -1 && (a.g = a.data.reduce((b, c, d) => b + (c ? 2 ** d : 0), 0));
        return a.g
    }
    var nT = class {
        constructor() {
            this.data = [];
            this.g = -1
        }
        set(a, b = !0) {
            0 <= a && a < 52 && Number.isInteger(a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
        }
        get(a) {
            return !!this.data[a]
        }
    };

    function oT() {
        const a = new nT;
        "SVGElement" in q && "createElementNS" in q.document && a.set(0);
        const b = qd();
        b["allow-top-navigation-by-user-activation"] && a.set(1);
        b["allow-popups-to-escape-sandbox"] && a.set(2);
        q.crypto && q.crypto.subtle && a.set(3);
        "TextDecoder" in q && "TextEncoder" in q && a.set(4);
        return mT(a)
    };

    function pT(a = window, b = () => {}) {
        try {
            return a.localStorage.getItem("__ssiua__")
        } catch (c) {
            return b(c), null
        }
    }

    function qT(a, b = window, c = () => {}) {
        return a.i() ? pT(b, c) : null
    };
    var rT = rj(rK);

    function sT(a = document) {
        const b = [],
            c = [];
        for (const f of Array.from(a.querySelectorAll("meta[name=generator][content]"))) {
            if (!f) continue;
            var d = f.getAttribute("content") ? ? "";
            const [, g, h] = /^([^0-9]+)(?:\s([0-9]+(?:\.[0-9]+){0,2})[.0-9]*)?[^0-9]*$/.exec(d) ? ? [], k = g, l = h;
            a = new qK;
            l && Dh(a, 3, l.substring(0, 20));
            let m, n;
            if (k) {
                for (const [p, t] of (new Map([
                        [1, "WordPress"],
                        [2, "Drupal"],
                        [3, "MediaWiki"],
                        [4, "Blogger"],
                        [5, "SEOmatic"],
                        [7, "Flutter"],
                        [8, "Joomla! - Open Source Content Management"]
                    ])).entries()) {
                    var e = p;
                    if (t ===
                        k.trim()) {
                        m = e;
                        break
                    }
                }
                for (const [p, t] of (new Map([
                        [1, "All in One SEO (AIOSEO)"],
                        [2, "All in One SEO Pro (AIOSEO)"],
                        [3, "AMP for WP"],
                        [4, "Site Kit by Google"],
                        [5, "Elementor"],
                        [6, "Powered by WPBakery Page Builder - drag and drop page builder for WordPress."]
                    ])).entries())
                    if (e = p, t === k.trim()) {
                        n = e;
                        break
                    }
            }
            n ? (d = Fh(a, 1, 1), Fh(d, 2, n)) : m ? Fh(a, 1, m) : (e = Fh(a, 1, 0), Ig(e, 3), c.push({
                content: d,
                name: k,
                version: l
            }));
            b.push(a)
        }
        return {
            labels: b,
            Yo: c
        }
    };
    const tT = new Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        uT = new Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);

    function vT(a) {
        try {
            const b = a.performance ? .getEntriesByType("navigation") ? .[0];
            if (b ? .type) return tT.get(b.type) ? ? null
        } catch {}
        return uT.get(a.performance ? .navigation ? .type) ? ? null
    };
    var wT = class extends N {};
    var xT = class extends N {};

    function yT(a, b) {
        if (Eb()) {
            var c = a.document.documentElement.lang;
            zT(a) ? AT(b, Fd(a), !0, "", c) : (new MutationObserver((d, e) => {
                zT(a) && (AT(b, Fd(a), !1, c, a.document.documentElement.lang), e.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    }

    function zT(a) {
        a = a.document ? .documentElement ? .classList;
        return !(!a ? .contains("translated-rtl") && !a ? .contains("translated-ltr"))
    }

    function AT(a, b, c, d, e) {
        Oj({
            ptt: `${a}`,
            pvsid: `${b}`,
            ibatl: String(c),
            pl: d,
            nl: e
        }, "translate-event")
    };

    function BT(a) {
        if (a = a.navigator ? .userActivation) {
            var b = 0;
            a ? .hasBeenActive && (b |= 1);
            a ? .isActive && (b |= 2);
            return b
        }
    };
    const CT = /[+, ]/;

    function DT(a, b) {
        const c = a.C;
        var d = a.pubWin,
            e = {},
            f = d.document,
            g = Id(d),
            h = !1,
            k = "",
            l = 1;
        a: {
            l = c.google_ad_width || d.google_ad_width;
            var m = c.google_ad_height || d.google_ad_height;
            if (d && d.top === d) h = !1;
            else {
                h = d.document;
                k = h.documentElement;
                if (l && m) {
                    var n = 1;
                    let t = 1;
                    d.innerHeight ? (n = d.innerWidth, t = d.innerHeight) : k && k.clientHeight ? (n = k.clientWidth, t = k.clientHeight) : h.body && (n = h.body.clientWidth, t = h.body.clientHeight);
                    if (t > 2 * m || n > 2 * l) {
                        h = !1;
                        break a
                    }
                }
                h = !0
            }
        }
        k = h;
        l = aE(g).If;
        m = d.top == d ? 0 : Xc(d.top) ? 1 : 2;
        n = 4;
        k || m !== 1 ? k ||
            m !== 2 ? k && m === 1 ? n = 7 : k && m === 2 && (n = 8) : n = 6 : n = 5;
        l && (n |= 16);
        k = String(n);
        l = cE(d);
        m = !!c.google_page_url;
        e.google_iframing = k;
        l !== 0 && (e.google_iframing_environment = l);
        if (!m && f.domain === "ad.yieldmanager.com") {
            for (k = f.URL.substring(f.URL.lastIndexOf("http")); k.indexOf("%") > -1;) try {
                k = decodeURIComponent(k)
            } catch (t) {
                break
            }
            c.google_page_url = k;
            m = !!k
        }
        m ? (e.google_page_url = c.google_page_url, e.google_page_location = (h ? f.referrer : f.URL) || "EMPTY") : (h && Xc(d.top) && f.referrer && d.top.document.referrer === f.referrer ? e.google_page_url =
            d.top.document.URL : e.google_page_url = h ? f.referrer : f.URL, e.google_page_location = null);
        if (f.URL === e.google_page_url) try {
            var p = Math.round(Date.parse(f.lastModified) / 1E3) || null
        } catch {
            p = null
        } else p = null;
        e.google_last_modified_time = p;
        d = g === g.top ? g.document.referrer : (d = jk()) && d.referrer || "";
        e.google_referrer_url = d;
        bE(e, c);
        b.i() ? (e = c.google_page_location || c.google_page_url, "EMPTY" === e && (e = c.google_page_url), e ? (e = e.toString(), e.indexOf("http://") == 0 ? e = e.substring(7, e.length) : e.indexOf("https://") == 0 && (e = e.substring(8,
            e.length)), d = e.indexOf("/"), d === -1 && (d = e.length), e = e.substring(0, d).split("."), d = !1, e.length >= 3 && (d = e[e.length - 3] in pP), e.length >= 2 && (d = d || e[e.length - 2] in pP), e = d) : e = !1, e = e ? "pagead2.googlesyndication.com" : "googleads.g.doubleclick.net") : e = "pagead2.googlesyndication.com";
        b = ET(a, b);
        d = a.C;
        f = d.google_ad_channel;
        g = "/pagead/ads?";
        d.google_ad_client === "ca-pub-6219811747049371" && FT.test(f) && (g = "/pagead/lopri?");
        e = `https://${e}${g}`;
        a = (Gh(a.pageState.i(), 6) ? E(a.pageState.i(), 6) : E(a.ma, 9)) && c.google_debug_params ?
            c.google_debug_params : "";
        a = Rk(b, e + a);
        return c.google_ad_url = a
    }

    function GT(a) {
        try {
            if (a.parentNode) return a.parentNode
        } catch {
            return null
        }
        if (a.nodeType === 9) a: {
            try {
                const c = a ? a.defaultView : window;
                if (c) {
                    const d = c.frameElement;
                    if (d && Xc(c.parent)) {
                        var b = d;
                        break a
                    }
                }
            } catch {}
            b = null
        }
        else b = null;
        return b
    }

    function HT(a, b) {
        var c = ZN(a.pubWin);
        a.C.saaei && (c += (c === "" ? "" : ",") + a.C.saaei);
        a.C.google_ad_intent_eids && (c += `${c===""?"":","}${a.C.google_ad_intent_eids}`);
        b.eid = c;
        c = a.C.google_loeid;
        typeof c === "string" && (a.i |= 4096, b.loeid = c)
    }

    function IT(a, b) {
        a = (a = $c(a.pubWin)) && a.document ? $P(a.document, a) : new Zj(-12245933, -12245933);
        b.scr_x = Math.round(a.x);
        b.scr_y = Math.round(a.y)
    }

    function JT(a) {
        try {
            const b = q.top.location.hash;
            if (b) {
                const c = b.match(a);
                return c && c[1] || ""
            }
        } catch {}
        return ""
    }

    function KT(a, b, c) {
        const d = a.C;
        var e = a.pubWin,
            f = a.K,
            g = Id(window);
        d.fsapi && (b.fsapi = !0);
        b.ref = d.google_referrer_url;
        b.loc = d.google_page_location;
        var h;
        (h = jk(e)) && ra(h.data) && typeof h.data.type === "string" ? (h = h.data.type.toLowerCase(), h = h == "doubleclick" || h == "adsense" ? null : h) : h = null;
        h && (b.apn = h.substr(0, 10));
        g = aE(g);
        b.url || b.loc || !g.url || (b.url = g.url, g.If || (b.usrc = 1));
        g.url != (b.loc || b.url) && (b.top = g.url);
        a.Fc && (b.etu = a.Fc);
        (c = cR(d, f, f ? cK(c, f) : null)) && (b.fc = c);
        if (!Wk(d)) {
            c = a.pubWin.document;
            g = "";
            if (c.documentMode &&
                (h = Dk(new rk(c), "IFRAME"), h.frameBorder = "0", h.style.height = 0, h.style.width = 0, h.style.position = "absolute", c.body)) {
                c.body.appendChild(h);
                try {
                    const ua = h.contentWindow.document;
                    ua.open();
                    var k = oc("<!DOCTYPE html>");
                    ua.write(pc(k));
                    ua.close();
                    g += ua.documentMode
                } catch (ua) {}
                c.body.removeChild(h)
            }
            b.docm = g
        }
        let l, m, n, p, t, v, w, B, G, L;
        try {
            l = e.screenX, m = e.screenY
        } catch (ua) {}
        try {
            n = e.outerWidth, p = e.outerHeight
        } catch (ua) {}
        try {
            t = e.innerWidth, v = e.innerHeight
        } catch (ua) {}
        try {
            w = e.screenLeft, B = e.screenTop
        } catch (ua) {}
        try {
            t =
                e.innerWidth, v = e.innerHeight
        } catch (ua) {}
        try {
            G = e.screen.availWidth, L = e.screen.availTop
        } catch (ua) {}
        b.brdim = [w, B, l, m, G, L, n, p, t, v].join();
        k = 0;
        q.postMessage === void 0 && (k |= 1);
        k > 0 && (b.osd = k);
        b.vis = wQ(e.document);
        k = a.X;
        e = XQ(d) ? LS : zS(new JS(e, k, null, {
            width: 0,
            height: 0
        }, d.google_ad_width, d.google_ad_height, !1));
        b.rsz = e.toString();
        b.abl = mS(e);
        if (!XQ(d) && (e = Xk(d), e != null)) {
            k = 0;
            a: {
                try {
                    {
                        var A = d.google_async_iframe_id;
                        const ua = window.document;
                        if (A) var H = ua.getElementById(A);
                        else {
                            var K = ua.getElementsByTagName("script"),
                                ia = K[K.length - 1];
                            H = ia && ia.parentNode || null
                        }
                    }
                    if (A = H) {
                        H = [];
                        K = 0;
                        for (var Jb = Date.now(); ++K <= 100 && Date.now() - Jb < 50 && (A = GT(A));) A.nodeType === 1 && H.push(A);
                        var ma = H;
                        b: {
                            for (Jb = 0; Jb < ma.length; Jb++) {
                                c: {
                                    var na = ma[Jb];
                                    try {
                                        if (na.parentNode && na.offsetWidth > 0 && na.offsetHeight > 0 && na.style && na.style.display !== "none" && na.style.visibility !== "hidden" && (!na.style.opacity || Number(na.style.opacity) !== 0)) {
                                            const ua = na.getBoundingClientRect();
                                            var xa = ua.right > 0 && ua.bottom > 0;
                                            break c
                                        }
                                    } catch (ua) {}
                                    xa = !1
                                }
                                if (!xa) {
                                    var Oa = !1;
                                    break b
                                }
                            }
                            Oa = !0
                        }
                        if (Oa) {
                            b: {
                                const ua = Date.now();Oa = /^html|body$/i;xa = /^fixed/i;
                                for (na = 0; na < ma.length && Date.now() - ua < 50; na++) {
                                    const ve = ma[na];
                                    if (!Oa.test(ve.tagName) && xa.test(ve.style.position || Kk(ve, "position"))) {
                                        var Cb = ve;
                                        break b
                                    }
                                }
                                Cb = null
                            }
                            break a
                        }
                    }
                } catch {}
                Cb = null
            }
            Cb && Cb.offsetWidth * Cb.offsetHeight <= e.width * e.height * 4 && (k = 1);
            b.pfx = k
        }
        a: {
            if (Math.random() < .05 && f) try {
                const ua = f.document.getElementsByTagName("head")[0];
                var Bj = ua ? kT(ua) : 0;
                break a
            } catch (ua) {}
            Bj = 0
        }
        f = Bj;
        f !== 0 && (b.cms = f);
        d.google_lrv !== a.gb && (b.alvm = d.google_lrv ||
            "none")
    }

    function LT(a, b) {
        let c = 0;
        a.location && a.location.ancestorOrigins ? c = a.location.ancestorOrigins.length : Yc(() => {
            c++;
            return !1
        }, a);
        c && (b.nhd = c)
    }

    function MT(a, b) {
        const c = iE(b, 8, {});
        b = iE(b, 9, {});
        const d = a.google_ad_section,
            e = a.google_ad_format;
        a = a.google_ad_slot;
        e ? c[d] = c[d] ? c[d] + `,${e}` : e : a && (b[d] = b[d] ? b[d] + `,${a}` : a)
    }

    function NT(a, b, c) {
        const d = a.C;
        var e = a.C;
        b.dt = pp;
        e.google_async_iframe_id && e.google_bpp && (b.bpp = e.google_bpp);
        a: {
            try {
                var f = q.performance;
                if (f && f.timing && f.now) {
                    var g = f.timing.navigationStart + Math.round(f.now()) - f.timing.domLoading;
                    break a
                }
            } catch (m) {}
            g = null
        }(e = (e = g) ? CR(e, q.Date.now() - pp, 1E6) : null) && (b.bdt = e);
        b.idt = CR(a.I, pp);
        e = a.C;
        b.shv = a.pageState.i().i() || F(a.ma, 2);
        a.gb && (b.mjsv = a.gb);
        e.google_loader_used == "sd" ? b.ptt = 5 : e.google_loader_used == "aa" && (b.ptt = 9);
        /^\w{1,3}$/.test(e.google_loader_used) &&
            (b.saldr = e.google_loader_used);
        if (e = jk(a.pubWin)) b.is_amp = 1, b.amp_v = kk(e), (e = lk(e)) && (b.act = e);
        e = a.pubWin;
        e == e.top && (b.abxe = 1);
        e = new WN(a.pubWin);
        (g = SN(e, "__gads", c)) ? b.cookie = g: c.i() && eK(e.win) && (b.cookie_enabled = "1");
        (g = SN(e, "__gpi", c)) && !g.includes("&") && (b.gpic = g);
        SN(e, "__gpi_opt_out", c) === "1" && (b.pdopt = "1");
        e = new SR(a.pubWin);
        g = {
            bg: !1,
            cg: !a.G
        };
        (f = RR(e, c, g)) ? b.eo_id_str = f: QR(e, c, g) && (b.eoidce = "1");
        c = dE();
        g = iE(c, 8, {});
        e = d.google_ad_section;
        g[e] && (b.prev_fmts = g[e]);
        g = iE(c, 9, {});
        g[e] && (b.prev_slotnames =
            g[e].toLowerCase());
        MT(d, c);
        e = iE(c, 15, 0);
        e > 0 && (b.nras = String(e));
        (g = jk(window)) ? (g ? (e = g.pageViewId, g = g.clientId, typeof g === "string" && (e += g.replace(/\D/g, "").substr(0, 6))) : e = null, e = +e) : (e = Id(window), g = e.google_global_correlator, g || (e.google_global_correlator = g = 1 + Math.floor(Math.random() * 8796093022208)), e = g);
        b.correlator = iE(c, 7, e);
        W(Dv) && (b.rume = 1);
        if (d.google_ad_channel) {
            e = iE(c, 10, {});
            g = "";
            f = d.google_ad_channel.split(CT);
            for (var h = 0; h < f.length; h++) {
                var k = f[h];
                e[k] ? g += k + "+" : e[k] = !0
            }
            b.pv_ch = g
        }
        if (d.google_ad_host_channel) {
            e =
                d.google_ad_host_channel;
            g = iE(c, 11, []);
            f = e.split("|");
            c = -1;
            e = [];
            for (h = 0; h < f.length; h++) {
                k = f[h].split(CT);
                g[h] || (g[h] = {});
                let m = "";
                for (let n = 0; n < k.length; n++) {
                    const p = k[n];
                    p !== "" && (g[h][p] ? m += "+" + p : g[h][p] = !0)
                }
                m = m.slice(1);
                e[h] = m;
                m !== "" && (c = h)
            }
            g = "";
            if (c > -1) {
                for (f = 0; f < c; f++) g += e[f] + "|";
                g += e[c]
            }
            b.pv_h_ch = g
        }
        b.frm = d.google_iframing;
        b.ife = d.google_iframing_environment;
        a: {
            c = d.google_ad_client;
            try {
                const m = Id(window);
                let n = m.google_prev_clients;
                n || (n = m.google_prev_clients = {});
                if (c in n) {
                    var l = 1;
                    break a
                }
                n[c] = !0;
                l = 2;
                break a
            } catch {
                l = 0;
                break a
            }
            l = void 0
        }
        b.pv = l;
        a.K && W(Tt) && (l = a.K, l = Eb() && zT(l) ? l.document.documentElement.lang : void 0, l && (b.tl = l));
        W(Ut) && a.pubWin.location.host.endsWith("h5games.usercontent.goog") && (b.cdm = a.pubWin.location.host);
        LT(a.pubWin, b);
        (a = d.google_ad_layout) && tR[a] >= 0 && (b.rplot = tR[a])
    }

    function OT(a, b) {
        a = a.g;
        oE() && (b.npa = 1);
        if (a) {
            Gh(a, 3) && (b.gdpr = a.B() ? "1" : "0");
            var c = D(a, 1);
            c && (b.us_privacy = c);
            (c = D(a, 2)) && (b.gdpr_consent = c);
            (c = D(a, 4)) && (b.addtl_consent = c);
            (c = nh(a, 7)) && (b.tcfe = c);
            (c = F(a, 11)) && (b.gpp = c);
            (a = Qg(a, 10, Qf, Pg(), void 0, 0)) && a.length > 0 && (b.gpp_sid = a.join(","))
        }
    }

    function PT(a, b) {
        const c = a.C;
        OT(a, b);
        ed(lT, (d, e) => {
            b[d] = c[e]
        });
        XQ(c) && (a = jR(c), b.fa = a);
        b.pi || c.google_ad_slot == null || (a = kx(c), a.g != null && (a = Br(a.getValue()), b.pi = a))
    }

    function QT(a, b) {
        var c = nk() || YP(a.pubWin.top);
        c && (b.biw = c.width, b.bih = c.height);
        c = a.pubWin;
        c !== c.top && (a = YP(a.pubWin)) && (b.isw = a.width, b.ish = a.height)
    }

    function RT(a, b) {
        var c = a.pubWin;
        c !== null && c != c.top ? (a = [c.document.URL], c.name && a.push(c.name), c = YP(c, !1), a.push(c.width.toString()), a.push(c.height.toString()), a = gd(a.join(""))) : a = 0;
        a !== 0 && (b.ifk = a)
    }

    function ST(a, b) {
        (a = lE()[a.C.google_ad_client]) && (b.psts = a.join())
    }

    function TT(a, b) {
        (a = oh(a.pageState.i(), 2)) && a >= 0 && (b.tmod = a)
    }

    function UT(a, b) {
        (a = a.pubWin.google_user_agent_client_hint) && (b.uach = Sd(a))
    }

    function VT(a, b) {
        try {
            const e = a.pubWin && a.pubWin.external && a.pubWin.external.getHostEnvironmentValue && a.pubWin.external.getHostEnvironmentValue.bind(a.pubWin.external);
            if (e) {
                var c = JSON.parse(e("os-mode")),
                    d = parseInt(c["os-mode"], 10);
                d >= 0 && (b.wsm = d + 1)
            }
        } catch {}
    }

    function WT(a, b) {
        a.C.google_ad_public_floor >= 0 && (b.pubf = a.C.google_ad_public_floor);
        a.C.google_ad_private_floor >= 0 && (b.pvtf = a.C.google_ad_private_floor)
    }

    function XT(a, b) {
        const c = Number(a.C.google_traffic_source);
        c && Object.values(Fa).includes(c) && (b.trt = a.C.google_traffic_source)
    }

    function YT(a, b) {
        var c;
        if (c = !W(Jv)) c = a.l ? .label, c = !(W(pv) && c && c.match(Lv(nv)));
        c && ("runAdAuction" in a.pubWin.navigator && "joinAdInterestGroup" in a.pubWin.navigator && (b.td = 1), c = a.pubWin.navigator, a.pubWin.isSecureContext && "runAdAuction" in c && c.runAdAuction instanceof Function && JN("run-ad-auction", a.pubWin.document) && (c = new nT, c.set(1, KN(a.pubWin.navigator)), b.tdf = mT(c)))
    }

    function ZT(a, b) {
        if (W(lv) && navigator.deprecatedRunAdAuctionEnforcesKAnonymity) {
            var c = new xT;
            var d = new wT;
            d = Eh(d, 4, "deprecated_kanon");
            c = z(c, 2, d)
        }
        a.l != null && Eb() && (c ? ? (c = new xT), d = Eh(c, 3, a.l.label), M(d, 4, a.l.status));
        c && (b.psd = Sd(Hh(c)))
    }

    function $T(a, b) {
        W(Av) || JN("attribution-reporting", a.pubWin.document) && (b.nt = 1)
    }

    function aU(a, b, c) {
        (a = qT(c, a.K || void 0, () => {})) && (b.ssiua = a)
    }

    function bU(a, b) {
        if (typeof a.C.google_privacy_treatments === "string") {
            var c = new Map([
                ["disablePersonalization", 1]
            ]);
            a = a.C.google_privacy_treatments.split(",");
            var d = [];
            for (const [e, f] of c.entries()) c = f, a.includes(e) && d.push(c);
            d.length && (b.ppt = d.join("~"))
        }
    }

    function cU(a, b) {
        if (a.A) {
            a.A.Uj && (b.xatf = 1);
            try {
                a.A.Af ? .disconnect(), a.A.Af = void 0
            } catch {}
        }
    }

    function dU(a, b = document) {
        if (W(jt)) try {
            const {
                labels: c
            } = sT(b);
            c.length && (a.pgls = c.map(d => Qd(rT(d))).join("~"))
        } catch (c) {
            oy().ia(1278, c)
        }
    }

    function ET(a, b) {
        const c = {};
        PT(a, c);
        UT(a, c);
        NT(a, c, b);
        c.u_tz = -(new Date).getTimezoneOffset();
        try {
            var d = Qj.history.length
        } catch (e) {
            d = 0
        }
        c.u_his = d;
        c.u_h = Qj.screen ? .height;
        c.u_w = Qj.screen ? .width;
        c.u_ah = Qj.screen ? .availHeight;
        c.u_aw = Qj.screen ? .availWidth;
        c.u_cd = Qj.screen ? .colorDepth;
        c.u_sd = ZP(a.pubWin);
        c.dmc = a.pubWin.navigator ? .deviceMemory;
        jy(889, () => {
            if (a.K == null) c.adx = -12245933, c.ady = -12245933;
            else {
                var e = bQ(a.K, a.X);
                c.adx && c.adx != -12245933 && c.ady && c.ady != -12245933 || (c.adx = Math.round(e.x), c.ady = Math.round(e.y));
                aQ(a.X) || (c.adx = -12245933, c.ady = -12245933, a.i |= 32768)
            }
        });
        QT(a, c);
        RT(a, c);
        IT(a, c);
        HT(a, c);
        c.oid = 2;
        ST(a, c);
        c.pvsid = Fd(a.pubWin, oy());
        TT(a, c);
        VT(a, c);
        c.uas = BT(a.pubWin);
        (d = vT(a.pubWin)) && (c.nvt = d);
        a.D && (c.scar = a.D);
        a.B instanceof Uint8Array ? c.topics = Qd(a.B) : a.B && (c.topics = a.B, c.tps = a.B);
        cU(a, c);
        KT(a, c, b);
        c.fu = a.i;
        c.bc = oT();
        if (Gh(a.pageState.i(), 6) ? E(a.pageState.i(), 6) : E(a.ma, 9))
            if ($N(c), c.creatives = JT(/\b(?:creatives)=([\d,]+)/), c.adgroups = JT(/\b(?:adgroups)=([\d,]+)/), c.adgroups || c.sso) c.adtest = "on",
                c.disable_budget_throttling = !0, c.use_budget_filtering = !1, c.retrieve_only = !0, c.disable_fcap = !0;
        Wj() && (c.atl = !0);
        c.bz = Jd(a.pubWin);
        WT(a, c);
        XT(a, c);
        YT(a, c);
        ZT(a, c);
        $T(a, c);
        bU(a, c);
        String(a.C.google_special_category_data) === "true" && (c.scd = 1);
        dU(c, a.pubWin.document);
        W(au) && aU(a, c, b);
        return c
    }
    const FT = /YtLoPri/;
    var eU = class extends N {};

    function fU(a) {
        return hh(a, eU, 15, Pg())
    }
    var gU = class extends N {},
        hU = sj(gU);

    function iU() {
        var a = new jU;
        var b = new qs;
        b = Fh(b, 2, 4);
        b = Fh(b, 8, 1);
        var c = new xr;
        c = Dh(c, 7, "#dpId");
        b = z(b, 1, c);
        return kh(a, 3, qs, b)
    }
    var jU = class extends N {},
        kU = sj(jU);
    var lU = class {
        constructor(a) {
            this.Bb = a.Bb ? ? [];
            this.mf = !!a.mf;
            this.pf = !!a.pf;
            this.nf = !!a.nf;
            this.fe = a.fe ? ? 250;
            this.ee = a.ee ? ? 300;
            this.Le = a.Le ? ? 15E3;
            this.Ie = a.Ie ? ? "#FFFFFF";
            this.Mb = a.Mb ? ? "#1A73E8";
            this.Ke = a.Ke ? ? 15E3;
            this.Me = a.Me ? ? 0;
            this.Xd = a.Xd ? ? 0;
            this.Ye = a.Ye || "#0B57D0";
            this.wd = a.wd || "#FFFFFF";
            this.ae = a.ae ? ? 670;
            this.ed = !!a.ed;
            this.Jd = a.Jd ? ? [];
            this.jg = a.jg || "450px";
            this.Ef = !!a.Ef;
            this.Zd = a.Zd ? ? 0;
            this.qe = a.qe ? ? !0;
            this.Zc = !!a.Zc;
            this.Vd = a.Vd ? ? 0;
            this.sf = !!a.sf;
            this.Qh = !!a.Qh;
            this.kf = !!a.kf;
            this.sg = !!a.sg;
            this.Sf = !!a.Sf;
            this.de = a.de ? ? 0;
            this.dc = a.dc ? ? 0;
            this.Pf = new Set(a.Pf ? ? []);
            this.we = !!a.we
        }
    };

    function mU(a, b, c, d, e, f, g, h, k) {
        const l = k(999, a.top, m => {
            m.data.action === "init" && m.data.adChannel === "ShoppingVariant" && nU(a, b, d, c, e, f, g, h)
        });
        g(() => {
            a.top.removeEventListener("message", l)
        })
    }

    function nU(a, b, c, d, e, f, g, h) {
        E(f, 13) || kA(c, d, e);
        const k = b.contentDocument.documentElement,
            l = new ResizeObserver(() => {
                b.height = `${Math.ceil(k.offsetHeight+26)}px`
            });
        l.observe(k);
        const m = h(1066, a, () => {
            const n = k.offsetHeight;
            n && (b.height = `${n+26}px`)
        }, 1E3);
        g(() => {
            l.disconnect();
            a.clearInterval(m)
        })
    }
    var oU = class {
        constructor(a) {
            this.Ra = a
        }
        pd(a) {
            const b = a.win.document.createElement("iframe"),
                c = a.P,
                d = new lA({
                    Ca: b,
                    Ia: F(c, 16),
                    Pb: "anno-cse",
                    Sa: this.Ra.replace("ca", "partner"),
                    hd: "ShoppingVariant",
                    location: a.win.location,
                    language: F(c, 7),
                    Xb: F(c, 10).replace("TERM", a.na),
                    Na: a.J.Bb.filter(e => e !== 42),
                    Qa: !1,
                    Eb: void 0,
                    Wc: !0,
                    ng: void 0,
                    Pa: !0,
                    sb: this.Ra
                });
            d.L();
            mU(a.win, b, a.na, d, a.gg, c, a.kc, a.Hb, a.rb);
            return b
        }
    };
    var pU = class {
        constructor(a, b, c) {
            this.Ra = a;
            this.g = b;
            this.eb = c
        }
        pd(a) {
            var b = a.win;
            b = a.qa ? .95 * b.innerHeight - 30 : b.innerHeight;
            var c = {};
            var d = a.na;
            const e = a.tf || "",
                f = this.Ra,
                g = a.Cc,
                h = a.J.Sf,
                k = a.aa,
                l = !!E(a.P, 13),
                m = a.J.Jd.join(","),
                n = a.J.qe,
                p = this.g,
                t = a.J.we ? this.eb : null,
                v = c && c.Qb;
            c = c && c.Ug;
            d = Bz('<link href="https://fonts.googleapis.com/css?family=Google+Sans:500" rel="stylesheet"' + (v ? ' nonce="' + Y(cA(v)) + '"' : "") + "><style" + (v ? ' nonce="' + Y(cA(v)) + '"' : "") + ">#gda-search-term {height: 24px; font-size: 18px; font-weight: 500; color: #202124; font-family: 'Google Sans'; padding-bottom: 6px;" +
                (k ? "padding-right: 16px;" : "padding-left: 16px;") + "}" + (h ? ".adsbygoogle {display: inline-block;}.adsbygoogle {width: calc(100% - 2.5px); height: max(280px, calc(50vh - 25px));}@media (min-width: 488px) {.adsbygoogle {width: calc(50% - 2.5px); height: max(280px, calc(50vh - 50px));}}" : "") + '</style><div id="gda-search-term">' + zz(d) + "</div>" + (p !== -1 ? "<script" + (c ? ' nonce="' + Y(cA(c)) + '"' : "") + ">window[" + Lz(Mz("goog_pvsid")) + "] = " + Lz(Mz(p)) + ";\x3c/script>" : "") + (l ? "" : '<script data-ad-intent-query="' + Y(d) +
                    '" data-ad-intent-qetid="' + Y(e) + '" data-ad-intent-eids="' + Y(m) + '"' + (t ? ' data-page-url="' + Y(Rz(t)) + '"' : "") + ' async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + Qz(f) + '" crossorigin="anonymous"' + (c ? ' nonce="' + Y(cA(c)) + '"' : "") + ">\x3c/script>") + (h ? '<ins class="adsbygoogle" data-ad-client="' + Y(f) + '"> </ins><ins class="adsbygoogle" data-ad-client="' + Y(f) + '"> </ins>' + (g >= 488 ? '<ins class="adsbygoogle" data-ad-client="' + Y(f) + '"> </ins><ins class="adsbygoogle" data-ad-client="' +
                    Y(f) + '"> </ins>' : "") + "<script" + (c ? ' nonce="' + Y(cA(c)) + '"' : "") + ">for (let slot = document.getElementsByClassName('adsbygoogle').length; slot; slot--) (adsbygoogle=window.adsbygoogle||[]).push({});\x3c/script>" : '<ins class="adsbygoogle" style="display:inline-block;width:' + Y(Z(g)) + "px;height:" + Y(Z(b - 30)) + 'px" data-ad-client="' + Y(f) + '"></ins>') + (n ? "<script" + (c ? ' nonce="' + Y(cA(c)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;\x3c/script>" : "") + (l ? "<script" + (c ? ' nonce="' + Y(cA(c)) +
                    '"' : "") + ">const el = document.querySelector('ins.adsbygoogle'); el.dir = 'ltr'; el.style.backgroundColor = 'lightblue'; el.style.fontSize = '25px'; el.style.textDecoration = 'none'; el.textContent = \"Loading display ads inside this slot for query = " + Nz(d) + ' and " + "property code = ' + Nz(f) + '";\x3c/script>' : ""));
            d = Sc("body", {
                dir: a.aa ? "rtl" : "ltr",
                lang: F(a.P, 7),
                style: "margin:0px;height:100%;padding-top: 0px;overflow: hidden;"
            }, wz(d));
            a = a.win.document.createElement("IFRAME");
            u(a, {
                border: "0",
                width: "100%",
                height: b + "px"
            });
            a.srcdoc = pc(d);
            return a
        }
    };

    function qU(a) {
        var b = {};
        const c = a.na,
            d = a.uj,
            e = a.Ra,
            f = a.Cc,
            g = a.xi,
            h = a.ak,
            k = a.Yk,
            l = a.eids,
            m = a.Lk,
            n = a.sk,
            p = a.tk;
        a = a.vk;
        const t = b && b.Qb;
        b = b && b.Ug;
        return Bz('<link href="https://fonts.googleapis.com/css?family=Google+Sans:500" rel="stylesheet"' + (t ? ' nonce="' + Y(cA(t)) + '"' : "") + "><style" + (t ? ' nonce="' + Y(cA(t)) + '"' : "") + ">#gda-search-term {height: 24px; font-size: 18px; font-weight: 500; color: #202124; font-family: 'Google Sans'; padding-bottom: 6px;" + (h ? "padding-right: 16px;" : "padding-left: 16px;") + '}</style><div id="gda-search-term">' +
            zz(c) + "</div>" + (p !== -1 ? "<script" + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + ">window[" + Lz(Mz(n)) + "] = " + Lz(Mz(p)) + ";\x3c/script>" : "") + '<ins id="display-slot" class="adsbygoogle" style="display:inline-block;width:' + Y(Z(f)) + "px;height:calc(" + Y(Z(g)) + ')" data-ad-client="' + Y(e) + '"></ins>' + (m ? "<script" + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + ">(adsbygoogle=window.adsbygoogle||[]).requestNonPersonalizedAds=1;\x3c/script>" : "") + (k ? "<script" + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + ">const el = document.querySelector('ins.adsbygoogle'); el.dir = 'ltr'; el.style.backgroundColor = 'lightblue'; el.style.fontSize = '25px'; el.style.textDecoration = 'none'; el.textContent = \"Loading display ads inside this slot for query = " +
                Nz(c) + ' and " + "property code = ' + Nz(e) + '";\x3c/script>' : "") + "<script" + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + ">top.postMessage({'action':'sgda-ready'}, top.location.origin);\x3c/script>" + (k ? "" : '<script data-ad-intent-query="' + Y(c) + '" data-ad-intent-qetid="' + Y(d) + '" data-ad-intent-eids="' + Y(l) + '"' + (a ? ' data-page-url="' + Y(Rz(a)) + '"' : "") + ' async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + Qz(e) + '" crossorigin="anonymous"' + (b ? ' nonce="' + Y(cA(b)) + '"' : "") + ">\x3c/script>"))
    };
    var uU = class {
        constructor(a, b, c) {
            this.Ra = a;
            this.g = b;
            this.eb = c
        }
        pd(a) {
            var b = qU({
                na: a.na,
                uj: a.tf || "",
                Ra: this.Ra,
                Cc: a.Cc,
                xi: a.J.jg,
                ak: a.aa,
                Yk: !!E(a.P, 13),
                eids: a.J.Jd.join(","),
                Lk: a.J.qe,
                sk: "goog_pvsid",
                tk: this.g,
                vk: a.J.we ? this.eb : null
            });
            b = Sc("body", {
                dir: a.aa ? "rtl" : "ltr",
                lang: F(a.P, 7),
                style: "margin:0;height:100%;padding-top:0;overflow:hidden"
            }, wz(b));
            const c = a.win.document.createElement("iframe");
            u(c, {
                border: "0",
                width: "100%"
            });
            c.height = "24px";
            const d = a.rb(999, a.win, e => {
                if (e.data.action === "sgda-ready" &&
                    (e = c.contentDocument, e ? .body)) {
                    var f = e.getElementById("display-slot");
                    if (f) {
                        var g = e.createElement("iframe"),
                            h = new MutationObserver((k, l) => {
                                if (f.getAttribute("data-ad-status") === "unfilled") wk(f);
                                else if (f.getAttribute("data-ad-status") !== "filled") return;
                                rU(g, c);
                                sU(a.win, g, c, a.kc, a.Hb);
                                l.disconnect()
                            });
                        h.observe(f, {
                            attributes: !0,
                            attributeFilter: ["data-ad-status"]
                        });
                        a.kc(() => void h.disconnect());
                        tU(this.Ra, g, a);
                        e.body.append(g)
                    }
                }
            });
            a.kc(() => {
                a.win.removeEventListener("message", d)
            });
            c.srcdoc = pc(b);
            return c
        }
    };

    function tU(a, b, c) {
        const d = new lA({
                Ca: b,
                Ia: F(c.P, 16),
                Pb: "anno-cse",
                Sa: a.replace("ca", "partner"),
                hd: "ShoppingVariant",
                location: c.win.location,
                language: F(c.P, 7),
                Xb: F(c.P, 10).replace("TERM", c.na),
                Na: c.J.Bb.filter(f => f !== 42),
                Qa: !1,
                Eb: void 0,
                Wc: !0,
                ng: void 0,
                Pa: !0,
                sb: a,
                og: !0
            }),
            e = c.rb(999, c.win, f => {
                f.data.action === "init" && f.data.adChannel === "ShoppingVariant" && (E(c.P, 13) || kA(d, c.na, c.gg))
            });
        d.L();
        c.kc(() => {
            c.win.removeEventListener("message", e)
        })
    }

    function sU(a, b, c, d, e) {
        const f = b.contentDocument.documentElement,
            g = new ResizeObserver(() => void rU(b, c));
        g.observe(f);
        const h = e(1066, a, () => void rU(b, c), 1E3);
        d(() => {
            g.disconnect();
            a.clearInterval(h)
        })
    }

    function rU(a, b) {
        const c = a.contentDocument ? .documentElement ? .offsetHeight;
        if (c) {
            var d = b.contentDocument ? .getElementById("display-slot") ? .offsetHeight ? ? 0;
            a.height = Math.ceil(c + 26) + "px";
            b.height = Math.ceil(c + 26 + d) + "px"
        }
    };

    function vU(a, b) {
        a = rx(Kw([...b], a), a);
        if (a.length !== 0) return a.reduce((c, d) => c.la.g > d.la.g ? c : d)
    };
    async function wU(a, b) {
        await new Promise(c => void a.win.setTimeout(c, 0));
        a.i = a.g.ka(b) + a.j
    }
    var xU = class {
        constructor(a, b) {
            var c = X(Uu);
            this.win = a;
            this.g = b;
            this.j = c;
            this.i = b.ka(2) + c
        }
    };
    var yU = class {
            constructor(a) {
                this.performance = a
            }
            ka() {
                return this.performance.now()
            }
        },
        zU = class {
            ka() {
                return Date.now()
            }
        };
    const AU = [255, 255, 255];

    function BU(a) {
        function b(d) {
            return [Number(d[1]), Number(d[2]), Number(d[3]), d.length > 4 ? Number(d[4]) : 1]
        }
        var c = a.match(/rgb\(([0-9]+),\s*([0-9]+),\s*([0-9]+)\)/);
        if (c || (c = a.match(/rgba\(([0-9]+),\s*([0-9]+),\s*([0-9]+),\s*([0-9\\.]+)\)/))) return b(c);
        if (a === "transparent" || a === "") return [0, 0, 0, 0];
        throw Error(`Invalid color: ${a}`);
    }

    function CU(a) {
        var b = getComputedStyle(a);
        if (b.backgroundImage !== "none") return null;
        b = BU(b.backgroundColor);
        var c = DU(b);
        if (c) return c;
        a = (a = a.parentElement) ? CU(a) : AU;
        if (!a) return null;
        c = b[3];
        return [Math.round(c * b[0] + (1 - c) * a[0]), Math.round(c * b[1] + (1 - c) * a[1]), Math.round(c * b[2] + (1 - c) * a[2])]
    }

    function DU(a) {
        return a[3] === 1 ? [a[0], a[1], a[2]] : null
    };

    function EU(a) {
        return a.Yd > 0 && a.i.j >= a.Yd
    }
    var GU = class {
        constructor(a, b, c, d) {
            this.hg = b;
            this.Te = c;
            this.Yd = d;
            this.g = 0;
            this.i = new FU(a)
        }
    };

    function HU(a, b) {
        b -= a.l;
        for (const c of a.g.keys()) {
            const d = a.g.get(c);
            let e = 0;
            for (; e < d.length && d[e] < b;) e++;
            a.i -= e;
            e > 0 && a.g.set(c, d.slice(e))
        }
    }

    function IU(a, b, c) {
        let d = [];
        a.g.has(b) && (d = a.g.get(b));
        d.push(c);
        a.i++;
        a.g.set(b, d)
    }
    class FU {
        constructor(a) {
            this.l = a;
            this.g = new Map;
            this.i = 0
        }
        get j() {
            return this.i
        }
    };

    function JU(a) {
        u(a, {
            border: "0",
            "box-shadow": "none",
            display: "inline",
            "float": "none",
            margin: "0",
            outline: "0",
            padding: "0"
        })
    }

    function KU(a, b) {
        b = a.document.createElement(b);
        u(b, Us(a));
        u(b, {
            color: "inherit",
            cursor: "inherit",
            direction: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-weight": "inherit",
            "text-align": "inherit",
            "text-orientation": "inherit",
            visibility: "inherit",
            "writing-mode": "inherit"
        });
        return b
    }

    function LU(a) {
        a.dataset.googleVignette = "false";
        a.dataset.googleInterstitial = "false"
    };

    function MU(a, b, c) {
        a = NU(a, "100 -1000 840 840", `calc(${b} - 2px)`, b, OU[c]);
        u(a, {
            color: "inherit",
            cursor: "inherit",
            fill: "currentcolor"
        });
        return a
    }

    function PU(a, b, c) {
        a = QU(a, "20px", b.Mb, c);
        a.classList.add("google-anno-sa-intent-icon");
        return a
    }

    function RU(a, b, c) {
        a = NU(a, "0 -960 960 960", "20px", "20px", "m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z");
        u(a, {
            left: "13px",
            right: "",
            "pointer-events": "initial",
            position: "absolute",
            top: "15px",
            transform: "none",
            fill: b.Mb
        });
        a.role = "button";
        a.ariaLabel = c;
        a.tabIndex = 0;
        return a
    }
    const OU = {
        [0]: "M503-104q-24 24-57 24t-57-24L103-390q-23-23-23-56.5t23-56.5l352-353q11-11 26-17.5t32-6.5h286q33 0 56.5 23.5T879-800v286q0 17-6.5 32T855-456L503-104Zm196-536q25 0 42.5-17.5T759-700q0-25-17.5-42.5T699-760q-25 0-42.5 17.5T639-700q0 25 17.5 42.5T699-640ZM446-160l353-354v-286H513L160-446l286 286Zm353-640Z",
        [1]: "m274-274-128-70 42-42 100 14 156-156-312-170 56-56 382 98 157-155q17-17 42.5-17t42.5 17q17 17 17 42.5T812-726L656-570l98 382-56 56-170-312-156 156 14 100-42 42-70-128Z",
        [2]: "M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z",
        [3]: "M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm200-500 54-18 16-54q-32-48-77-82.5T574-786l-54 38v56l160 112Zm-400 0 160-112v-56l-54-38q-54 17-99 51.5T210-652l16 54 54 18Zm-42 308 46-4 30-54-58-174-56-20-40 30q0 65 18 118.5T238-272Zm242 112q26 0 51-4t49-12l28-60-26-44H378l-26 44 28 60q24 8 49 12t51 4Zm-90-200h180l56-160-146-102-144 102 54 160Zm332 88q42-50 60-103.5T800-494l-40-28-56 18-58 174 30 54 46 4Z",
        [4]: "M120-680v-160l160 80-160 80Zm600 0v-160l160 80-160 80Zm-280-40v-160l160 80-160 80Zm0 640q-76-2-141.5-12.5t-114-26.5Q136-135 108-156t-28-44v-360q0-25 31.5-46.5t85.5-38q54-16.5 127-26t156-9.5q83 0 156 9.5t127 26q54 16.5 85.5 38T880-560v360q0 23-28 44t-76.5 37q-48.5 16-114 26.5T520-80v-160h-80v160Zm40-440q97 0 167.5-11.5T760-558q0-5-76-23.5T480-600q-128 0-204 18.5T200-558q42 15 112.5 26.5T480-520ZM360-166v-154h240v154q80-8 131-23.5t69-27.5v-271q-55 22-138 35t-182 13q-99 0-182-13t-138-35v271q18 12 69 27.5T360-166Zm120-161Z",
        [5]: "M200-80q-33 0-56.5-23.5T120-160v-480q0-33 23.5-56.5T200-720h80q0-83 58.5-141.5T480-920q83 0 141.5 58.5T680-720h80q33 0 56.5 23.5T840-640v480q0 33-23.5 56.5T760-80H200Zm0-80h560v-480H200v480Zm280-240q83 0 141.5-58.5T680-600h-80q0 50-35 85t-85 35q-50 0-85-35t-35-85h-80q0 83 58.5 141.5T480-400ZM360-720h240q0-50-35-85t-85-35q-50 0-85 35t-35 85ZM200-160v-480 480Z",
        [6]: "M80-160v-120h80v-440q0-33 23.5-56.5T240-800h600v80H240v440h240v120H80Zm520 0q-17 0-28.5-11.5T560-200v-400q0-17 11.5-28.5T600-640h240q17 0 28.5 11.5T880-600v400q0 17-11.5 28.5T840-160H600Zm40-120h160v-280H640v280Zm0 0h160-160Z",
        [7]: "M400-40v-80H200q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h200v-80h80v880h-80ZM200-240h200v-240L200-240Zm360 120v-360l200 240v-520H560v-80h200q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H560Z",
        [8]: "M300-240q25 0 42.5-17.5T360-300q0-25-17.5-42.5T300-360q-25 0-42.5 17.5T240-300q0 25 17.5 42.5T300-240Zm0-360q25 0 42.5-17.5T360-660q0-25-17.5-42.5T300-720q-25 0-42.5 17.5T240-660q0 25 17.5 42.5T300-600Zm180 180q25 0 42.5-17.5T540-480q0-25-17.5-42.5T480-540q-25 0-42.5 17.5T420-480q0 25 17.5 42.5T480-420Zm180 180q25 0 42.5-17.5T720-300q0-25-17.5-42.5T660-360q-25 0-42.5 17.5T600-300q0 25 17.5 42.5T660-240Zm0-360q25 0 42.5-17.5T720-660q0-25-17.5-42.5T660-720q-25 0-42.5 17.5T600-660q0 25 17.5 42.5T660-600ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z",
        [9]: "M160-80v-440H80v-240h208q-5-9-6.5-19t-1.5-21q0-50 35-85t85-35q23 0 43 8.5t37 23.5q17-16 37-24t43-8q50 0 85 35t35 85q0 11-2 20.5t-6 19.5h208v240h-80v440H160Zm400-760q-17 0-28.5 11.5T520-800q0 17 11.5 28.5T560-760q17 0 28.5-11.5T600-800q0-17-11.5-28.5T560-840Zm-200 40q0 17 11.5 28.5T400-760q17 0 28.5-11.5T440-800q0-17-11.5-28.5T400-840q-17 0-28.5 11.5T360-800ZM160-680v80h280v-80H160Zm280 520v-360H240v360h200Zm80 0h200v-360H520v360Zm280-440v-80H520v80h280Z",
        [10]: "m456-200 174-340H510v-220L330-420h126v220Zm24 120q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"
    };

    function QU(a, b, c, d) {
        a = NU(a, "0 -960 960 960", b, b, OU[d]);
        u(a, {
            fill: c,
            cursor: "inherit"
        });
        return a
    }

    function NU(a, b, c, d, e) {
        const f = a.document.createElementNS("http://www.w3.org/2000/svg", "path");
        f.setAttribute("d", e);
        e = a.document.createElementNS("http://www.w3.org/2000/svg", "svg");
        u(e, Us(a));
        e.setAttribute("viewBox", b);
        e.setAttribute("width", c);
        e.setAttribute("height", d);
        JU(e);
        e.appendChild(f);
        return e
    };

    function SU(a, b, c, d) {
        const e = KU(a, "div");
        e.classList.add("google-anno-skip", "google-anno-sc");
        d = a.getComputedStyle(d).fontSize || "16px";
        var f = e.appendChild;
        var g = b.J;
        var h = b.g.get(c) || 0;
        g = QU(a, d, g.wd, h);
        u(g, {
            position: "relative",
            top: "3px"
        });
        h = KU(a, "span");
        u(h, {
            display: "inline-block",
            "padding-left": b.aa() ? "" : "3px",
            "padding-right": b.aa() ? "3px" : ""
        });
        h.appendChild(g);
        f.call(e, h);
        f = e.appendChild;
        g = KU(a, "span");
        g.appendChild(a.document.createTextNode(c));
        u(g, {
            position: "relative",
            left: b.aa() ? "" : "3px",
            right: b.aa() ?
                "3px" : "",
            "padding-left": b.aa() ? "6px" : "",
            "padding-right": b.aa() ? "" : "6px"
        });
        f.call(e, g);
        u(e, {
            display: "inline-block",
            "border-radius": "20px",
            "padding-left": b.aa() ? "7px" : "6px",
            "padding-right": b.aa() ? "6px" : "7px",
            "padding-top": "3px",
            "padding-bottom": "3px",
            "border-width": "1px",
            "border-style": "solid",
            color: b.J.wd,
            "font-family": "Roboto",
            "font-weight": "500",
            "font-size": d,
            "border-color": "#D7D7D7",
            background: b.J.Ye,
            cursor: "pointer",
            "margin-top": "-3px"
        });
        e.tabIndex = 0;
        e.role = "link";
        e.ariaLabel = c;
        return e
    };
    const TU = [{
        ig: "1907259590",
        ge: 480,
        He: 220
    }, {
        ig: "2837189651",
        ge: 400,
        He: 180
    }, {
        ig: "9211025045",
        ge: 360,
        He: 160
    }, {
        ig: "6584860439",
        ge: -Infinity,
        He: 150
    }];

    function UU(a) {
        TU.find(b => b.ge <= a)
    };
    const VU = new class {
        constructor() {
            this.g = []
        }
    };
    let WU = !1;

    function XU(a) {
        YU(a.config, 1065, a.win, () => {
            if (!a.g) {
                var b = new Pn;
                b = Ch(b, 1, a.i);
                var c = new On;
                b = C(b, 2, Qn, c);
                a.config.V.pe(b)
            }
        }, 1E4)
    }
    class ZU {
        constructor(a, b, c) {
            this.win = a;
            this.config = b;
            this.i = c;
            this.g = !1
        }
        cancel(a) {
            this.win.clearTimeout(a)
        }
    }

    function $U(a) {
        VU.g.push(a)
    }

    function aV(a, b, c, d, e, f = null) {
        UU(a.document.body.clientWidth);
        d = b.qa ? bV(a, b, d, e, f) : cV(a, b, d, e, f);
        oq(d.isVisible(), !1, () => {
            WU = !1;
            for (const h of VU.g) h();
            VU.g.length = 0
        });
        d.show({
            Wg: !0
        });
        WU = !0;
        const g = new ZU(a, b, c);
        XU(g);
        VU.g.push(() => {
            var h = b.V,
                k = h.pe;
            var l = new Pn;
            l = Ch(l, 1, c);
            var m = new Nn;
            l = C(l, 3, Qn, m);
            k.call(h, l);
            g.g = !0
        })
    }

    function bV(a, b, c, d, e) {
        d = b.Bd.pd({
            win: a,
            na: c,
            gg: d,
            J: b.J,
            qa: b.qa,
            aa: b.aa(),
            P: b.P,
            tf: e,
            Cc: b.qa ? a.innerWidth : Math.min(a.document.body.clientWidth, b.J.ae),
            rb: b.rb.bind(b),
            Hb: b.Hb.bind(b),
            kc: $U
        });
        return QB(a, d, {
            Nh: .95,
            hh: .95,
            zIndex: 2147483647,
            Ec: !0,
            jf: "adpub-drawer-root",
            hf: !1,
            Ua: !0,
            rf: new T(F(b.P, 10).replace("TERM", c))
        })
    }

    function cV(a, b, c, d, e) {
        const f = b.qa ? a.innerWidth : Math.min(a.document.body.clientWidth, b.J.ae);
        d = b.Bd.pd({
            win: a,
            na: c,
            gg: d,
            J: b.J,
            qa: b.qa,
            aa: b.aa(),
            P: b.P,
            tf: e,
            Cc: f,
            rb: b.rb.bind(b),
            Hb: b.Hb.bind(b),
            kc: $U
        });
        return ZA(a, d, {
            Hd: `${f}px`,
            Ed: b.aa(),
            xd: F(b.P, 14),
            zIndex: 2147483647,
            Ec: !0,
            Yg: !0,
            jf: "adpub-drawer-root",
            hf: !1,
            Ua: !0,
            rf: new T(F(b.P, 10).replace("TERM", c))
        })
    };
    const dV = ["BTN", "BUTTON"];

    function eV(a, b) {
        switch (a.tagName ? .toUpperCase ? .()) {
            case "IFRAME":
            case "A":
            case "AUDIO":
            case "BUTTON":
            case "CANVAS":
            case "CITE":
            case "CODE":
            case "EMBED":
            case "FOOTER":
            case "FORM":
            case "KBD":
            case "LABEL":
            case "OBJECT":
            case "PRE":
            case "SAMP":
            case "SCRIPT":
            case "SELECT":
            case "STYLE":
            case "SUB":
            case "SUPER":
            case "SVG":
            case "TEXTAREA":
            case "TIME":
            case "VAR":
            case "VIDEO":
            case null:
                return !1
        }
        return !((a.className.toUpperCase ? .() ? .includes("CRUMB") || a.id.toUpperCase ? .() ? .includes("CRUMB")) && a.offsetHeight <=
            50) && (!b.kf || !fV(a))
    }

    function fV(a) {
        return dV.some(b => a.className.toUpperCase ? .() ? .includes(b) || a.id.toUpperCase ? .() ? .includes(b))
    };

    function gV(a, b, c) {
        b = b.getBoundingClientRect();
        a = An(zn(new Bn, a), 3);
        c = Eh(a, 4, c);
        c = Ah(c, 6, Math.round(b.x));
        return Ah(c, 7, Math.round(b.y))
    }

    function hV(a) {
        a = BU(a);
        var b = new xn;
        b = Ah(b, 1, a[0]);
        b = Ah(b, 2, a[1]);
        b = Ah(b, 3, a[2]);
        return Zg(b, 4, rf(a[3]), 0)
    };
    const iV = /[\s!'",:;\\(\\)\\?\\.\u00bf\u00a1\u30a0\uff1d\u037e\u061f\u3002\uff1f\uff1b\uff1a\u2014\u2014\uff5e\u300a\u300b\u3008\u3009\uff08\uff09\u300c\u300d\u3001\u00b7\u2026\u2025\uff01\uff0c\u00b7\u2019\u060c\u061b\u060d\u06d4\u0648]/;

    function jV(a, b) {
        switch (b) {
            case 1:
                return !0;
            default:
                return a === "" || iV.test(a)
        }
    };

    function kV(a, b) {
        const c = new lV(b);
        for (const d of a) F(d, 5) && sh(d, 3).forEach(e => {
            mV(c, e, e)
        });
        nV(c);
        return new oV(c)
    }

    function pV(a, b, c) {
        b = a.match(b);
        a = new Map;
        for (const d of b)
            if (b = d.j, a.has(b)) {
                const e = a.get(b);
                d.length > e.length && a.set(b, d)
            } else a.set(b, d);
        return c ? [...a.values()] : Array.from(a.values())
    }
    var oV = class {
        constructor(a) {
            this.g = a
        }
        isEmpty() {
            return this.g.isEmpty()
        }
        match(a) {
            return this.g.match(a)
        }
    };

    function mV(a, b, c) {
        const d = a.i.has(c) ? a.i.get(c) : a.l++;
        a.i.set(c, d);
        a.B.set(d, c);
        c = 0;
        for (let e = 0; e < b.length; e++) {
            const f = b.charCodeAt(e);
            a.g[c].contains(f) || (a.g.push(new qV), a.g[a.size].B = c, a.g[a.size].G = f, a.g[c].j.set(f, a.size), a.size++);
            c = a.g[c].j.get(f)
        }
        a.g[c].l = !0;
        a.g[c].A = d;
        a.g[c].D = a.j.length;
        a.j.push(b.length)
    }

    function nV(a) {
        const b = [];
        for (b.push(0); b.length > 0;) {
            const f = b.shift();
            var c = a,
                d = c.g[f];
            if (f === 0) d.g = 0, d.i = 0;
            else if (d.B === 0) d.g = 0, d.i = d.l ? f : c.g[c.g[f].g].i;
            else {
                d = c.g[c.g[f].B].g;
                for (var e = c.g[f].G;;) {
                    if (c.g[d].contains(e)) {
                        c.g[f].g = c.g[d].j.get(e);
                        break
                    }
                    if (d === 0) {
                        c.g[f].g = 0;
                        break
                    }
                    d = c.g[d].g
                }
                c.g[f].i = c.g[f].l ? f : c.g[c.g[f].g].i
            }
            for (const g of a.g[f].Ma) b.push(g)
        }
    }
    class lV {
        constructor(a) {
            this.A = a;
            this.size = 1;
            this.g = [new qV];
            this.j = [];
            this.i = new Map;
            this.B = new Map;
            this.l = 0
        }
        isEmpty() {
            return this.l === 0
        }
        match(a) {
            let b = 0;
            const c = [];
            for (let g = 0; g < a.length; g++) {
                for (;;) {
                    var d = a.charCodeAt(g),
                        e = this.g[b];
                    if (e.contains(d)) {
                        b = e.j.get(d);
                        break
                    }
                    if (b === 0) break;
                    b = e.g
                }
                let h = b;
                for (;;) {
                    h = this.g[h].i;
                    if (h === 0) break;
                    const k = g + 1 - this.j[this.g[h].D],
                        l = g;
                    d = a;
                    e = l;
                    var f = this.A;
                    jV(d.charAt(k - 1), f) && jV(d.charAt(e + 1), f) && c.push(new rV(k, l, this.B.get(this.g[h].A)));
                    h = this.g[h].g
                }
            }
            return c
        }
    }
    class qV {
        constructor() {
            this.j = new Map;
            this.M = !1;
            this.xa = this.I = this.F = this.pa = this.U = this.Z = -1
        }
        contains(a) {
            return this.j.has(a)
        }
        set B(a) {
            this.Z = a
        }
        get B() {
            return this.Z
        }
        set G(a) {
            this.U = a
        }
        get G() {
            return this.U
        }
        set l(a) {
            this.M = a
        }
        get l() {
            return this.M
        }
        set A(a) {
            this.I = a
        }
        get A() {
            return this.I
        }
        set g(a) {
            this.pa = a
        }
        get g() {
            return this.pa
        }
        set i(a) {
            this.F = a
        }
        get i() {
            return this.F
        }
        set D(a) {
            this.xa = a
        }
        get D() {
            return this.xa
        }
        get Ma() {
            return this.j.values()
        }
    }
    var rV = class {
        constructor(a, b, c) {
            this.i = a;
            this.g = b;
            this.B = c
        }
        get j() {
            return this.i
        }
        get l() {
            return this.g
        }
        get na() {
            return this.B
        }
        get length() {
            return this.g - this.i
        }
    };
    async function sV(a, b, c, d, e) {
        const f = kV(fU(b.P), b.i);
        if (!f.isEmpty()) {
            var g = new Map;
            for (const h of fU(b.P).filter(k => F(k, 5))) sh(h, 3).forEach(k => {
                g.set(k, F(h, 1))
            });
            await tV(a, a.document.body, b, f, g, new Set, c, d, b.J.Zd ? new GU(0, 0, 0, b.J.Zd) : null, b.J.de ? new uV(b.J.de) : null, e)
        }
    }
    async function tV(a, b, c, d, e, f, g, h, k, l, m) {
        g.g.ka(9) >= g.i && await wU(g, 10);
        if (b.nodeType !== Node.ELEMENT_NODE || !(b.classList ? .contains("google-anno-skip") || c.J.sf && !eV(b, c.J)))
            if (c.J.Ef && f.size && b.nodeType === Node.ELEMENT_NODE && vV(a, b) && b.parentElement && !wV(a, c, b.parentElement) && xV(a, l, b.getBoundingClientRect().top) && yV(a, f, c, h, b.parentElement, b, k, l), b.nodeType === Node.TEXT_NODE && b.textContent) pV(d, b.textContent, c.J.Zc).map(n => e.get(n.na)).filter(n => !!n).forEach(n => void f.add(n));
            else {
                for (const n of b.childNodes) await tV(a,
                    n, c, d, e, f, g, h, k, l, m);
                f.size && b.nodeType === Node.ELEMENT_NODE && ["block", "table-cell"].includes(a.getComputedStyle(b).display) && !wV(a, c, b) && xV(a, l, b.getBoundingClientRect().bottom) && yV(a, f, c, h, b, null, k, l)
            }
    }

    function yV(a, b, c, d, e, f, g, h) {
        for (const [l, m] of [...b].entries()) {
            var k = l;
            const n = m;
            if (g && EU(g) || c.J.dc && k === c.J.dc) return;
            c.J.dc && b.delete(n);
            const p = gV(c.V.nd(), f ? ? e, n);
            d.entries.push(Eg(p));
            g && IU(g.i, n, g.g);
            if (E(c.P, 17)) continue;
            k = SU(a, c, n, e);
            const t = zV(k, c, Uf(Gg(p, 10)) ? ? "0");
            LU(k);
            AV(c, 999, k, v => {
                try {
                    var w = In(Gn(n), Uf(Gg(p, 10)) ? ? "0");
                    var B = Bh(w, 7, t.i);
                    const G = c.V.tc(B);
                    aV(a, c, G, n, c.B.get(n) || "");
                    return !1
                } finally {
                    v.preventDefault(), c.J.sg && v.stopImmediatePropagation()
                }
            });
            e.insertBefore(k, f);
            h && BV(h,
                k.getBoundingClientRect().bottom + window.scrollY)
        }
        c.J.dc || b.clear()
    }

    function vV(a, b) {
        return ["BR", "IMG", "TABLE"].includes(b.tagName) || a.getComputedStyle(b).display === "block"
    }

    function wV(a, b, c) {
        if (!b.J.Vd) return !1;
        a = md(a.getComputedStyle(c).fontSize);
        return a !== null && a > b.J.Vd
    }

    function xV(a, b, c) {
        return b ? b.g === void 0 || c + a.scrollY - b.g > b.i : !0
    }
    class CV {
        constructor() {
            this.g = null
        }
        get i() {
            return this.g
        }
    }

    function zV(a, b, c) {
        const d = new CV;
        DV(b, e => {
            for (const k of e)
                if (k.isIntersecting) {
                    var f = c;
                    e = b.V;
                    var g = e.af,
                        h = new fn;
                    f = Zg(h, 1, Tf(f), "0");
                    d.g = g.call(e, f)
                } else d.g && (e = b.V, g = e.Ze, f = new en, f = Ch(f, 1, d.g), g.call(e, f), d.g = null)
        }).observe(a);
        return d
    }

    function BV(a, b) {
        a.g = b
    }
    class uV {
        constructor(a) {
            this.i = a;
            this.g = void 0
        }
    };

    function EV(a, b, c, d, e, f, g) {
        if (!a.g) {
            var h = b.document.createElement("span");
            h.appendChild(MU(b, "12px", f));
            h.appendChild(b.document.createTextNode(d));
            HD(b, c || null, {
                informationText: h
            }, e, g ? k => {
                g.qf(k)
            } : g);
            a.g = !0
        }
    }
    var FV = class {
        constructor() {
            this.g = !1
        }
    };

    function GV(a, b) {
        const c = b.qa === b.aa;
        var d = HV(a, b, c);
        if (!d) return null;
        d = d.position.Kd();
        a = IV(a, d, b, function(f) {
            f = f.getBoundingClientRect();
            return c ? b.T - f.right : f.left
        });
        if (!a || a - 16 < 200) return null;
        const e = b.T;
        return {
            Da: c ? e - a : 16,
            La: c ? 16 : e - a,
            ga: d
        }
    }

    function JV(a, b) {
        const c = zp(a),
            d = Ap(a);
        return oC(new sC(a), new ak(d - b.ga - 50, c - b.La, d - b.ga, b.Da)).size > 0
    }

    function HV(a, b, c) {
        b = Math.floor(b.W * .3);
        return b < 66 ? null : vC(a, {
            jc: c ? BC({
                ga: 16,
                La: 16
            }) : zC({
                ga: 16,
                Da: 16
            }),
            Kf: b - 66,
            Kb: 200,
            Qf: 50,
            Wd: b,
            vb: 16
        }, [a.document.body]).Ue
    }

    function IV(a, b, c, d) {
        a = c.qa ? KV(a, b, c) : LV(a, b, c);
        b = c.T;
        let e = c.qa ? b : b * .35;
        a.forEach(f => {
            e = Math.min(e, d(f))
        });
        return e < 16 ? null : e - 16
    }

    function KV(a, b, c) {
        const d = c.W;
        return oC(new sC(a), new ak(d - b - 50, c.T - 16, d - b, 16))
    }

    function LV(a, b, c) {
        const d = c.W,
            e = c.T;
        c = c.aa;
        return oC(new sC(a), new ak(d - b - 50, (c ? e * .35 : e) - 16, d - b, (c ? 16 : e * .65) + 16))
    }

    function MV(a, b, c) {
        const d = a.aa;
        return {
            Da: d ? NV(a, b, c) : c,
            La: d ? c : NV(a, b, c),
            ga: 16
        }
    }

    function NV(a, b, c) {
        const d = a.T;
        return a.qa ? d - b + 16 : Math.max(d - c - d * .35, d - b + 16)
    }

    function OV(a, b, c) {
        const d = c.aa,
            e = c.T;
        a = c.qa ? KV(a, 16, c) : LV(a, 16, c);
        return (b.Zc ? [...a] : Array.from(a)).map(f => new uC(d ? e - f.getBoundingClientRect().right : f.getBoundingClientRect().left, d ? e - f.getBoundingClientRect().left : f.getBoundingClientRect().right)).sort((f, g) => f.start - g.start)
    };

    function PV(a, b, c, d) {
        const e = document.createElement("SPAN");
        u(e, Us(a));
        e.id = "gda";
        e.appendChild(RU(a, b.J, F(b.P, 18)));
        LU(e);
        AV(b, 1064, e, f => {
            d ? .();
            wk(c);
            f.preventDefault();
            f.stopImmediatePropagation();
            return !1
        });
        return e
    }

    function QV(a, b, c, d) {
        const e = document.createElement("SPAN");
        u(e, Us(a));
        JU(e);
        u(e, {
            position: "absolute",
            top: "2.5px",
            bottom: "2.5px",
            left: (b.aa(), "50px"),
            right: b.aa() ? "24px" : "12px",
            display: "flex",
            "flex-direction": "row",
            color: b.J.Mb,
            cursor: "pointer",
            transition: "width 5s"
        });
        b.qa || u(e, {
            "justify-content": ""
        });
        const f = PU(a, b.J, b.g.get(d.za) || 0),
            g = document.createElement("SPAN");
        u(g, {
            display: "inline-block",
            cursor: "inherit"
        });
        u(g, {
            "margin-left": b.aa() ? "6px" : "4px",
            "margin-right": b.aa() ? "4px" : "6px",
            "margin-top": "12px"
        });
        e.appendChild(g);
        g.appendChild(f);
        c.classList ? .add("google-anno-sa-qtx", "google-anno-skip");
        c.tabIndex = 0;
        c.role = "link";
        c.ariaLive = "polite";
        c.ariaLabel = F(b.P, 19).replace("TERM", d.za);
        u(c, {
            height: "40px",
            "align-items": "center",
            "line-height": "44px",
            "font-size": "16px",
            "font-weight": "400",
            "font-style": "normal",
            "font-family": "Roboto",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
            overflow: "hidden",
            "-webkit-tap-highlight-color": "transparent",
            color: b.J.Mb
        });
        LU(e);
        AV(b, 999, e, h => {
            h.preventDefault();
            if ((d.Ig ? ?
                    0) + 800 <= b.ka(26)) {
                h = d.za;
                const l = b.l.get(h) || "";
                var k = In(Gn(h), d.Qc);
                k = Bh(k, 3, d.Rd);
                k = b.V.tc(k);
                aV(a, b, k, h, l, b.J.ed ? b.j.get(h) || "" : null)
            }
            return !1
        });
        e.appendChild(c);
        return e
    }

    function RV(a, b, c, d, e) {
        const f = document.createElement("div");
        u(f, Us(a));
        f.id = "google-anno-sa";
        f.dir = b.aa() ? "rtl" : "ltr";
        f.tabIndex = 0;
        u(f, {
            background: b.J.Ie,
            "border-style": "solid",
            bottom: d.ga + "px",
            "border-radius": "16px",
            height: "50px",
            position: "fixed",
            "text-align": "center",
            border: "0px",
            left: d.Da + "px",
            right: d.La + "px",
            "box-shadow": "0px 1px 2px rgba(0, 0, 0, 0.3), 0px 1px 3px 1px rgba(0, 0, 0, 0.15)",
            "z-index": "1000"
        });
        u(f, {
            fill: "white"
        });
        d = document.createElement("SPAN");
        u(d, Us(a));
        u(d, {
            cursor: "inherit"
        });
        f.appendChild(QV(a, b, d, c));
        f.appendChild(PV(a, b, f, e));
        return f
    }

    function SV(a, b, c, d, e) {
        var f = c.getElementsByClassName("google-anno-sa-qtx")[0];
        f instanceof HTMLElement && (f.innerText = a.za);
        if ((d.g.get(e) || 0) !== (d.g.get(a.za) || 0)) {
            b = PU(b, d.J, d.g.get(a.za) || 0);
            for (const g of c.getElementsByClassName("google-anno-sa-intent-icon")) g.replaceWith(b)
        }
        f.ariaLabel = F(d.P, 19).replace("TERM", a.za);
        c = d.V;
        d = c.Oe;
        f = new jn;
        f = Ig(f, 2, Tf(a.Qc));
        a = Eh(f, 4, a.za);
        return d.call(c, a)
    }

    function TV(a, b, c, d) {
        if (JV(b, d)) return null;
        a.Ig = c.ka(25);
        d = RV(b, c, a, d, () => {
            a.g = !0;
            var f = c.V,
                g = f.Je;
            var h = new gn;
            h = Zg(h, 3, Tf(a.Qc), "0");
            h = Eh(h, 2, a.za);
            g.call(f, h)
        });
        const e = SV(a, b, d, c, a.za);
        b.document.body.appendChild(d);
        return e
    }

    function UV(a, b, c, d, e, f, g) {
        if (!(a.g || a.za === e && a.Qc === d && a.i === f)) {
            if (a.Rd !== null) {
                var h = a.Rd,
                    k = c.V,
                    l = k.Ne,
                    m = new hn;
                h = Ch(m, 1, h);
                l.call(k, h)
            }
            k = a.za;
            a.za = e;
            a.Qc = d;
            a.i = f;
            E(c.P, 17) || (d = b.document.getElementById("google-anno-sa"), a.Rd = d ? SV(a, b, d, c, k) : TV(a, b, c, g))
        }
    }
    var VV = class {
        constructor() {
            this.za = "";
            this.Qc = null;
            this.i = "";
            this.Rd = null;
            this.g = !1;
            this.Ig = null
        }
    };

    function WV(a, b) {
        a.g >= a.i.length && (a.g = 0, a.l++);
        if (!(a.config.J.Xd && a.l >= a.config.J.Xd))
            if (WU) VU.g.push(() => void WV(a, b));
            else {
                var c = a.i[a.g++];
                a.j = !1;
                UV(a.A, a.win, a.config, c.g, c.na, c.i, a.B);
                YU(a.config, 898, a.win, () => void WV(a, b), a.ug)
            }
    }
    var XV = class {
        constructor(a, b, c) {
            var d = new VV;
            this.win = a;
            this.config = b;
            this.A = d;
            this.B = c;
            this.i = [];
            this.j = !0;
            this.l = this.g = 0;
            this.ug = b.params.ug
        }
    };
    class YV {
        constructor(a, b, c) {
            this.g = a;
            this.na = b;
            this.i = c
        }
    };
    const ZV = ["block", "inline", "inline-block", "list-item", "table-cell"];
    async function $V(a, b, c, d, e) {
        d.g.ka(5) >= d.i && await wU(d, 6);
        c.J.mf || aW(a, b, c, e, fU(c.P));
        c.J.nf && !bW(a) || await c.Fa(898, sV(a, c, d, e, b));
        c.J.pf || await cW(a, c, () => new FV, d, e)
    }

    function bW(a) {
        try {
            const b = a.location ? .href ? .match(/goog_fac=1/);
            return b !== null && b !== void 0
        } catch (b) {
            return !1
        }
    }
    async function cW(a, b, c, d, e) {
        var f = fU(b.P);
        var g = new lV(b.i);
        for (const h of f) F(h, 6) !== "" && (f = F(h, 1), mV(g, f, f));
        nV(g);
        g = new oV(g);
        g.isEmpty() || await b.Fa(898, dW(a, b, d, e, g, new GU(b.params.bl, b.params.hg, b.params.Te, b.params.Yd), c()))
    }
    async function dW(a, b, c, d, e, f, g) {
        var h = a.document.body;
        if (E(b.P, 17) || y(b.P, is, 21))
            for (; h;) {
                c.g.ka(7) >= c.i && await wU(c, 8);
                if (h.nodeType === Node.TEXT_NODE && h.textContent !== "" && h.parentElement) {
                    var k = h.parentElement;
                    a: {
                        var l = a;
                        var m = b,
                            n = k,
                            p = h.textContent,
                            t = d,
                            v = e,
                            w = f;
                        const Oa = [];b: {
                            var B = p;
                            switch (m.i) {
                                case 1:
                                    var G = Array(B.length),
                                        L = 0;
                                    for (var A = 0; A < B.length; A++) iV.test(B[A]) || L++, G[A] = L;
                                    B = G;
                                    break b;
                                default:
                                    G = Array(B.length);
                                    for (A = L = 0; A < B.length;) {
                                        for (;
                                            /\s/.test(B[A]);) G[A] = L, A++;
                                        for (var H = !1; A < B.length &&
                                            !/\s/.test(B[A]);) H = !0, G[A] = L, A++;
                                        H && (L++, G[A - 1] = L)
                                    }
                                    B = G
                            }
                        }
                        v = p.includes("\u00bb") ? [] : pV(v, p, m.J.Zc);L = -1;
                        for (const Cb of v)
                            if (v = Cb.j, G = Cb.l, !(v < L)) {
                                A = w;
                                var K = Cb.na;
                                HU(A.i, A.g + B[v]);
                                H = A;
                                var ia = H.i;
                                if ((ia.g.has(K) ? ia.g.get(K).length : 0) < H.hg && A.i.j < A.Te) {
                                    A = l.getComputedStyle(n);
                                    H = A.fontSize.match(/\d+/);
                                    if (!(H && Number(H[0]) >= 12 && Number(H[0]) <= 22 && Pa(ZV, A.display))) {
                                        w.g += B[B.length - 1];
                                        l = [];
                                        break a
                                    }
                                    L += 1;
                                    L < v && Oa.push(l.document.createTextNode(p.substring(L, v)));
                                    L = p.substring(v, G + 1);
                                    A = p;
                                    H = v;
                                    ia = G + 1;
                                    ia = A.substring(Math.max(H -
                                        30, 0), H) + "~~" + A.substring(ia, Math.min(ia + 30, A.length));
                                    H = l;
                                    var Jb = m.V.nd();
                                    A = n;
                                    var ma = L,
                                        na = ia,
                                        xa = Cb.na;
                                    K = B[v];
                                    ia = A.getBoundingClientRect();
                                    Jb = An(zn(new Bn, Jb), 2);
                                    ma = Eh(Jb, 2, ma);
                                    ma = Eh(ma, 3, na);
                                    xa = Eh(ma, 4, xa);
                                    K = Ah(xa, 5, K);
                                    K = Ah(K, 6, Math.round(ia.x));
                                    ia = Ah(K, 7, Math.round(ia.y));
                                    H = H.getComputedStyle(A);
                                    K = new yn;
                                    K = Eh(K, 1, H.fontFamily);
                                    xa = hV(H.color);
                                    K = z(K, 7, xa);
                                    xa = hV(H.backgroundColor);
                                    K = z(K, 8, xa);
                                    xa = H.fontSize.match(/^(\d+(\.\d+)?)px$/);
                                    K = Ah(K, 4, xa ? Math.round(Number(xa[1])) : 0);
                                    xa = Math.round(Number(H.fontWeight));
                                    isNaN(xa) || xa === 400 || Ah(K, 5, xa);
                                    H.textDecorationLine !== "none" && Eh(K, 6, H.textDecorationLine);
                                    H = z(ia, 8, K);
                                    ia = [];
                                    for (ma = A; ma && ia.length < 20;) {
                                        A = ia;
                                        K = A.push;
                                        xa = ma;
                                        na = new wn;
                                        na = Eh(na, 1, xa.tagName);
                                        xa.className !== "" && Yg(na, 2, xa.className.split(" "), Xf);
                                        K.call(A, na);
                                        if (ma.tagName === "BODY") break;
                                        ma = ma.parentElement
                                    }
                                    A = ia.reverse();
                                    A = ih(H, 9, A);
                                    t.entries.push(Eg(A));
                                    Oa.push(eW(l, m, Uf(Gg(A, 10)) ? ? "0", Cb.na, L, n));
                                    IU(w.i, Cb.na, w.g + B[v]);
                                    L = G;
                                    if (EU(w)) break
                                }
                            }
                        m = L + 1;m !== 0 && m < p.length && Oa.push(l.document.createTextNode(p.substring(m)));
                        w.g += B[B.length - 1];l = Oa
                    }
                    if (l.length && !E(b.P, 17)) {
                        !b.J.ed && EV(g, a, b.params.Vg ? vU(a, b.params.Vg) : void 0, F(b.P, 3), y(b.P, is, 21).g(), b.params.Ah, b.V);
                        for (const Oa of l) k.insertBefore(Oa, h), fW(Oa);
                        k.removeChild(h);
                        for (h = l[l.length - 1]; h.lastChild;) h = h.lastChild;
                        if (EU(f)) break
                    }
                }
                a: {
                    k = a;p = f;l = b.i;w = b.J;
                    if (h.firstChild && (h.nodeType !== Node.ELEMENT_NODE ? 0 : !h.classList ? .contains("google-anno-skip") && (h.offsetHeight || k.getComputedStyle(h).display === "contents"))) {
                        if (eV(h, w)) {
                            h = h.firstChild;
                            break a
                        }
                        if (h.textContent ? .length) {
                            k =
                                p;
                            b: switch (p = h.textContent, l) {
                                case 1:
                                    l = p;
                                    p = 0;
                                    for (w = l.length - 1; w >= 0; w--) iV.test(l[w]) || p++;
                                    l = p;
                                    break b;
                                default:
                                    l = p.trim(), l = l === "" ? 0 : l.split(/\s+/).length
                            }
                            HU(k.i, k.g + l)
                        }
                    }
                    for (;;) {
                        if (h.nextSibling) {
                            h = h.nextSibling;
                            break a
                        }
                        if (!h.parentNode) {
                            h = null;
                            break a
                        }
                        h = h.parentNode
                    }
                    h = void 0
                }
            }
    }

    function gW(a, b) {
        var c = b.J;
        b = {
            aa: b.aa(),
            qa: b.qa,
            T: zp(a),
            W: Ap(a)
        };
        if (b.W >= 400) {
            var d;
            if ((d = GV(a, b)) != null) var e = d;
            else a: {
                d = b.T;c = OV(a, c, b);a = 16;
                for (e of c) {
                    c = e.start;
                    const f = e.end;
                    if (c > a) {
                        if (c - a - 16 >= 200) {
                            e = MV(b, c, a);
                            break a
                        }
                        a = f + 16
                    } else f >= a && (a = f + 16)
                }
                e = d - a - 16 >= 200 ? MV(b, d, a) : null
            }
        } else e = null;
        return e
    }

    function aW(a, b, c, d, e) {
        function f() {
            return h ? ? (h = c.Hb(898, a, () => {
                if (!g) {
                    var l = c.ka(12);
                    a.clearInterval(h);
                    g = !0;
                    var m = gW(a, c);
                    m && hW(a, b, c, d, l, e, m)
                }
            }, c.J.Le))
        }
        if (e.filter(l => F(l, 7).length).length) {
            var g = !1,
                h = void 0,
                k = iW(c, a, () => {
                    if (!(a.scrollY <= c.J.Me || g)) {
                        var l = c.ka(12),
                            m = gW(a, c);
                        m ? (g = !0, a.removeEventListener("scroll", k), hW(a, b, c, d, l, e, m)) : h = f()
                    }
                });
            YU(c, 898, a, () => {
                if (!g) {
                    var l = c.ka(12),
                        m = gW(a, c);
                    m ? (g = !0, hW(a, b, c, d, l, e, m)) : h = f()
                }
            }, c.J.Ke)
        }
    }

    function hW(a, b, c, d, e, f, g) {
        const h = new XV(a, c, g);
        f.filter(k => F(k, 7).length).forEach(k => {
            var l = c.V.nd(),
                m = F(k, 1);
            var n = wh(k, 4);
            l = An(zn(new Bn, l), 1);
            m = Eh(l, 4, m);
            n = zh(m, 12, n);
            d.entries.push(Eg(n));
            n = Uf(Gg(n, 10)) ? ? "0";
            h.i.push(new YV(n, F(k, 1), F(k, 1)));
            h.j && WV(h, b)
        });
        c.V.Jf(jW(d, c.ka(13) - e))
    }

    function fW(a) {
        if (a.nodeType === Node.ELEMENT_NODE) {
            if (a.tagName === "A") {
                var b = DU(BU(getComputedStyle(a.parentElement).color)),
                    c = DU(BU(getComputedStyle(a).color));
                var d = CU(a);
                if (d = b && c && d ? PM(c, d) < Math.min(PM(b, d), 2.5) ? b : null : b) {
                    b = d[0];
                    c = d[1];
                    d = d[2];
                    b = Number(b);
                    c = Number(c);
                    d = Number(d);
                    if (b != (b & 255) || c != (c & 255) || d != (d & 255)) throw Error('"(' + b + "," + c + "," + d + '") is not a valid RGB color');
                    c = b << 16 | c << 8 | d;
                    b = b < 16 ? "#" + (16777216 | c).toString(16).slice(1) : "#" + c.toString(16);
                    u(a, {
                        color: b
                    })
                }
            }
            for (b = 0; b < a.childElementCount; b++) fW(a.children[b])
        }
    }
    class kW {
        constructor() {
            this.g = null
        }
        get i() {
            return this.g
        }
    }

    function eW(a, b, c, d, e, f) {
        const g = a.document.createElement("SPAN");
        g.className = "google-anno-t";
        JU(g);
        u(g, {
            "text-decoration": "underline"
        });
        u(g, {
            "text-decoration-style": "dotted"
        });
        u(g, {
            "-webkit-text-decoration-line": "underline",
            "-webkit-text-decoration-style": "dotted"
        });
        u(g, {
            color: "inherit",
            "font-family": "inherit",
            "font-size": "inherit",
            "font-style": "inherit",
            "font-weight": "inherit"
        });
        g.appendChild(a.document.createTextNode(e));
        e = a.document.createElement("A");
        JU(e);
        u(e, {
            "text-decoration": "none",
            fill: "currentColor"
        });
        lc(e);
        e.className = "google-anno";
        LU(e);
        e.appendChild(lW(a, b, f));
        e.appendChild(a.document.createTextNode("\u00a0"));
        e.appendChild(g);
        const h = mW(b, c, e);
        AV(b, 999, e, k => {
            try {
                var l = In(Gn(d), c);
                var m = Bh(l, 2, h.i);
                const n = b.V.tc(m);
                aV(a, b, n, d, b.A.get(d) || "", b.J.ed ? b.j.get(d) || "" : null);
                return !1
            } finally {
                k.preventDefault(), k.stopImmediatePropagation()
            }
        });
        return e
    }

    function lW(a, b, c) {
        return MU(a, a.getComputedStyle(c).fontSize, b.params.Ah)
    }

    function mW(a, b, c) {
        const d = new kW;
        DV(a, e => {
            for (const k of e)
                if (k.isIntersecting) {
                    var f = b;
                    e = a.V;
                    var g = e.Mf,
                        h = new Mn;
                    f = Zg(h, 2, Tf(f), "0");
                    d.g = g.call(e, f)
                } else d.g && (e = a.V, g = e.Lf, f = new Ln, f = Ch(f, 1, d.g), g.call(e, f), d.g = null)
        }).observe(c);
        return d
    };

    function jW(a, b) {
        const c = a.g;
        a.g = a.entries.length;
        var d = new Kn,
            e = new Cn;
        a = ih(e, 2, a.entries.slice(c));
        d = z(d, 1, a);
        b !== 0 && Ch(d, 2, Math.round(b));
        return d
    }
    var nW = class {
        constructor() {
            this.entries = [];
            this.language = null;
            this.g = 0
        }
    };

    function oW(a, b, c) {
        pW(a);
        var d = new Map;
        for (const e of b) b = qW(e), d.set(b, (d.get(b) ? ? 0) + 1);
        for (const [e, f] of d) d = e, rW(a, f, d, c), sW(a, d)
    }

    function tW(a, b, c, d) {
        a.i.forEach(e => {
            uW(e, { ...a.g,
                outcome: b,
                Mc: c,
                xf: d
            })
        })
    }

    function vW(a, b, c, d, e) {
        a.i.forEach(f => {
            f.Qe(b, { ...a.g,
                outcome: c,
                Mc: d,
                xf: e
            })
        })
    }

    function pW(a) {
        a.l || (a.l = !0, a.i.forEach(b => {
            wW(b, a.g)
        }))
    }

    function rW(a, b, c, d) {
        a.i.forEach(e => {
            e.Se(b, { ...a.g,
                format: c,
                Mc: d
            })
        })
    }

    function sW(a, b) {
        a.A.has(b) || (a.A.add(b), a.i.forEach(c => {
            xW(c, { ...a.g,
                format: b
            })
        }))
    }

    function yW(a, b) {
        a.i.forEach(c => {
            zW(c, { ...a.g,
                reason: AW(b)
            })
        })
    }
    var IW = class {
        constructor(a, b, c) {
            this.G = this.j = 1;
            this.B = this.l = !1;
            this.g = {
                language: a.Pf.has(b) ? b : "other",
                ya: Eb() ? 2 : Bb() ? 4 : Db() ? 7 : 10
            };
            this.A = new Set;
            this.i = [...c]
        }
        nd() {
            return this.G++
        }
        Re(a) {
            a: switch (ch(a, En)) {
                case 4:
                    var b = 1;
                    break a;
                case 5:
                    b = 2;
                    break a;
                default:
                    b = 0
            }
            const c = BW(a);
            var d = ph(a, 3),
                e = c.length > 0;tW(this, b, !1, e);vW(this, d, b, !1, e);a.i() && c.length > 0 && oW(this, c, !1);
            if (Mg(a, vn, 5, En)) {
                a = uh(a, vn, 5, En);
                for (const f of hh(a, qn, 1, Pg())) yW(this, f)
            }
            this.j++
        }
        Jf(a) {
            const b = a.i() ? 1 : 0,
                c = BW(a);
            var d = ph(a, 2),
                e =
                c.length > 0;
            tW(this, b, !0, e);
            vW(this, d, b, !0, e);
            a.i() && c.length > 0 && oW(this, c, !0);
            this.j++
        }
        Mf() {
            this.i.forEach(a => {
                CW(a, { ...this.g,
                    format: 2
                })
            });
            return this.j++
        }
        Lf() {
            this.i.forEach(a => {
                DW(a, { ...this.g,
                    format: 2
                })
            });
            this.j++
        }
        Oe() {
            this.i.forEach(a => {
                CW(a, { ...this.g,
                    format: 1
                })
            });
            return this.j++
        }
        Ne() {
            this.i.forEach(a => {
                DW(a, { ...this.g,
                    format: 1
                })
            });
            this.j++
        }
        af() {
            this.i.forEach(a => {
                CW(a, { ...this.g,
                    format: 3
                })
            });
            return this.j++
        }
        Ze() {
            this.i.forEach(a => {
                DW(a, { ...this.g,
                    format: 3
                })
            });
            this.j++
        }
        tc(a) {
            let b = 0;
            Qf(Gg(a,
                2)) != null ? b = 2 : Qf(Gg(a, 3)) != null ? b = 1 : Qf(Gg(a, 7)) != null && (b = 3);
            this.i.forEach(c => {
                c.click({ ...this.g,
                    format: b
                })
            });
            return this.j++
        }
        pe(a) {
            let b = 0;
            Mg(a, On, 2, Qn) ? b = 1 : Mg(a, Nn, 3, Qn) && (b = 2);
            this.i.forEach(c => {
                EW(c, { ...this.g,
                    type: b
                })
            });
            this.j++
        }
        qf(a) {
            a: switch (I(a, 1)) {
                case 1:
                    a = 1;
                    break a;
                case 2:
                    a = 2;
                    break a;
                default:
                    a = 0
            }
            const b = a;this.i.forEach(c => {
                FW(c, { ...this.g,
                    type: b
                })
            });this.B || (this.B = !0, this.i.forEach(c => {
                GW(c, this.g)
            }));this.j++
        }
        Je() {
            this.i.forEach(a => {
                HW(a, this.g)
            });
            this.j++
        }
    };

    function BW(a) {
        a.i() ? (a = a.j(), a = [...hh(a, Bn, 2, Pg())]) : a = [];
        return a
    }

    function AW(a) {
        switch (ch(a, rn)) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            case 9:
                return 4;
            case 11:
                return 5;
            case 12:
                return 6;
            case 13:
                return 7;
            default:
                return 0
        }
    }

    function qW(a) {
        switch (I(a, 1)) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            default:
                return 0
        }
    };

    function JW(a, b) {
        var c = new Rn;
        var d = a.j++;
        c = Ch(c, 1, d);
        b = Ch(c, 2, Math.round(a.l.ka(b) - a.A));
        b = z(b, 10, a.G);
        return yh(b, 15, a.D ? !0 : void 0)
    }
    var KW = class {
        constructor(a, b, c, d, e, f, g, h) {
            this.l = b;
            this.A = c;
            this.G = d;
            this.D = f;
            this.i = this.j = 1;
            this.B = [...g];
            this.g = h.length ? new IW(e, a, h) : null
        }
        nd() {
            return this.i++
        }
        Re(a) {
            this.g ? .Re(a);
            var b = this.handle,
                c = JW(this, 11);
            a = C(c, 3, Sn, a);
            b.call(this, a)
        }
        Jf(a) {
            this.g ? .Jf(a);
            var b = this.handle,
                c = JW(this, 11);
            a = C(c, 14, Sn, a);
            b.call(this, a)
        }
        Mf(a) {
            this.g ? .Mf(a);
            var b = this.handle,
                c = JW(this, 15);
            a = C(c, 4, Sn, a);
            return b.call(this, a)
        }
        Lf(a) {
            this.g ? .Lf(a);
            var b = this.handle,
                c = JW(this, 16);
            a = C(c, 5, Sn, a);
            b.call(this, a)
        }
        Oe(a) {
            this.g ? .Oe(a);
            var b = this.handle,
                c = JW(this, 17);
            a = C(c, 6, Sn, a);
            return b.call(this, a)
        }
        Ne(a) {
            this.g ? .Ne(a);
            var b = this.handle,
                c = JW(this, 18);
            a = C(c, 7, Sn, a);
            b.call(this, a)
        }
        af(a) {
            this.g ? .af(a);
            var b = this.handle,
                c = JW(this, 19);
            a = C(c, 16, Sn, a);
            return b.call(this, a)
        }
        Ze(a) {
            this.g ? .Ze(a);
            var b = this.handle,
                c = JW(this, 20);
            a = C(c, 17, Sn, a);
            b.call(this, a)
        }
        tc(a) {
            this.g ? .tc(a);
            var b = this.handle,
                c = JW(this, 14);
            a = C(c, 8, Sn, a);
            return b.call(this, a)
        }
        pe(a) {
            this.g ? .pe(a);
            var b = this.handle,
                c = JW(this, 21);
            a = C(c, 9, Sn, a);
            b.call(this, a)
        }
        qf(a) {
            this.g ? .qf(a);
            var b = this.handle,
                c = JW(this, 22);
            a = C(c, 11, Sn, a);
            b.call(this, a)
        }
        Je(a) {
            this.g ? .Je(a);
            var b = this.handle,
                c = JW(this, 24);
            a = C(c, 12, Sn, a);
            b.call(this, a)
        }
        handle(a) {
            for (const b of this.B) b(a);
            return ph(a, 1)
        }
    };

    function YU(a, b, c, d, e) {
        c.setTimeout(LW(a, b, d), e)
    }

    function AV(a, b, c, d) {
        c.addEventListener("click", LW(a, b, d))
    }

    function DV(a, b) {
        return new IntersectionObserver(LW(a, 1065, b), {
            threshold: .98
        })
    }

    function iW(a, b, c) {
        a = LW(a, 898, c);
        b.addEventListener("scroll", a, {
            passive: !0
        });
        return a
    }

    function LW(a, b, c) {
        return a.Aa.Xa(b, c, void 0, d => {
            d.es = a.J.Bb.join(",")
        })
    }
    var NW = class {
        constructor(a, b, c, d, e, f, g, h) {
            this.qa = a;
            this.P = b;
            this.Aa = c;
            this.V = d;
            this.G = e;
            this.params = f;
            this.J = g;
            this.Bd = h;
            this.A = new Map;
            this.l = new Map;
            this.B = new Map;
            this.g = new Map;
            this.j = new Map;
            this.i = Pa(MW, F(b, 7)) ? 1 : 0;
            for (const k of fU(this.P)) D(k, 6) != null && this.A.set(F(k, 1), F(k, 6)), D(k, 7) != null && this.l.set(F(k, 1), F(k, 7)), D(k, 5) != null && this.B.set(F(k, 1), F(k, 5)), nh(k, 10) != null && this.g.set(F(k, 1), I(k, 10)), D(k, 11) != null && this.j.set(F(k, 1), F(k, 11))
        }
        rb(a, b, c) {
            a = LW(this, a, c);
            b.addEventListener("message",
                a);
            return a
        }
        Hb(a, b, c, d) {
            return b.setInterval(LW(this, a, c), d)
        }
        Fa(a, b) {
            this.Aa.Fa(a, b, c => {
                c.es = this.J.Bb.join(",")
            });
            return b
        }
        ka(a) {
            return this.G.ka(a)
        }
        aa() {
            return I(this.P, 12) === 2
        }
    };
    const MW = ["ja", "zh_CN", "zh_TW"];
    const OW = new Map([
        [1, 1],
        [2, 2]
    ]);
    async function PW(a, b, c, d, e, f, g, h, k) {
        k = a ? (k = SN(new WN(a), "__gads", k)) ? gd(k + "t2Z7mVic") % 20 : null : null;
        var l = k ? ? Math.floor(dd() * 20),
            m = g.ka(0),
            n = !!a && zp(a) < 488;
        k = c.P;
        var p;
        p = (p = F(k, 7)) ? (p = p.match(/^[a-z]{2,3}/i)) ? p[0].toLowerCase() : "" : "";
        var t = c.J,
            v = new Jn;
        l = Ah(v, 2, l);
        l = jh(l, 3, Df, t.Bb, Qf, void 0, !0);
        e = new KW(p, g, m, l, t, E(k, 17), e, f);
        f = new NW(n, k, d, e, g, c.params, c.J, c.Bd);
        d = new nW;
        d.language = p;
        h = await QW(a, b, f, h, d);
        b = e.Re;
        f = c.eb;
        a = a ? .location ? .hostname || "";
        c = c.Hj;
        g = g.ka(11) - m;
        m = new Fn;
        p = new kn;
        f = Eh(p, 1, f);
        a = Eh(f, 2, a);
        n = J(a, 3, n);
        n = z(m, 1, n);
        a = new ln;
        a = Eh(a, 2, d.language);
        c = Eh(a, 3, c);
        n = z(n, 2, c);
        n = Ch(n, 3, Math.round(g));
        f = fU(k);
        k = g = c = a = m = 0;
        for (w of f) m += (F(w, 6) !== "" ? 1 : 0) + (F(w, 7) !== "" ? 1 : 0) + (F(w, 5) !== "" ? 1 : 0), a += (F(w, 6) !== "" ? 1 : 0) + (F(w, 7) !== "" ? 1 : 0) + (F(w, 5) !== "" ? 1 : 0), c += F(w, 6) !== "" ? 1 : 0, g += F(w, 7) !== "" ? 1 : 0, k += F(w, 5) !== "" ? 1 : 0;
        var w = new Dn;
        w = zh(w, 1, f.length);
        w = zh(w, 2, m);
        w = Ig(w, 3, a == null ? a : Bf(a));
        w = Ig(w, 4, c == null ? c : Bf(c));
        w = Ig(w, 5, g == null ? g : Bf(g));
        w = zh(w, 6, k);
        w = z(n, 6, w);
        if (h.length) {
            var B = new vn;
            B = ih(B, 1, h);
            C(w, 5,
                En, B)
        } else {
            d.g = d.entries.length;
            k = new Cn;
            g = d.entries;
            d = k.R[x] | 0;
            He(d);
            d = gh(k, d, Bn, 2, 2, !0);
            n = h = 0;
            if (Array.isArray(g))
                for (B = g.length, c = 0; c < B; c++) a = g[c], d.push(a), (a = !!((a.R[x] | 0) & 2)) && !h++ && te(d, 8), a || n++ || te(d, 16);
            else
                for (B of g) g = B, d.push(g), (g = !!((g.R[x] | 0) & 2)) && !h++ && te(d, 8), g || n++ || te(d, 16);
            C(w, 4, En, k)
        }
        b.call(e, w)
    }
    async function QW(a, b, c, d, e) {
        if (!a) return [sn()];
        var f = a.document.body;
        if (!f || !RW(f)) return [pn()];
        d.g.ka(3) >= d.i && await wU(d, 4);
        f = [];
        (c.J.fe && zp(a) < c.J.fe || c.J.ee && Ap(a) < c.J.ee) && f.push(pn());
        if (th(c.P, 1).length) {
            const g = th(c.P, 1).map(h => OW.get(h) ? ? 0);
            f.push(un(new qn, mn(g)))
        }
        id() && f.push(tn());
        f.length || await $V(a, b, c, d, e);
        return f
    }

    function RW(a) {
        try {
            (new ResizeObserver(() => {})).disconnect()
        } catch {
            return !1
        }
        return a.classList && a.classList.contains !== void 0 && a.attachShadow !== void 0
    };
    async function SW(a, b, c, d, e, f, g) {
        const h = a.performance ? .now ? new yU(a.performance) : new zU,
            k = new xU(a, h);
        if (typeof e !== "string") throw Error(`Invalid config string ${e}`);
        e = kU(e);
        var l = fh(e, gU, 1),
            m = c.google_ad_client;
        if (typeof m !== "string") throw new ey(`Invalid property code ${m}`);
        c = c.google_page_url;
        c = typeof c === "string" ? c : "";
        m = I(e, 4) === 2 ? W(Gu) ? new uU(m, Fd(a), c) : new pU(m, Fd(a), c) : new oU(m);
        a = R(HE);
        l = TW(l);
        a: {
            try {
                const t = b ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/);
                if (!t) {
                    var n = null;
                    break a
                }
                var p =
                    decodeURIComponent(t[1]);
                n = hU(p);
                break a
            } catch (t) {
                n = null;
                break a
            }
            n = void 0
        }
        n = n || fh(e, gU, 1);
        p = gh(e, e.R[x] | 0, qs, 3, 1);
        p = {
            bl: X(Tu),
            hg: X(Xu),
            Te: X(Vu),
            Yd: X(Wu),
            Vg: p,
            ug: X($u),
            Ah: 2
        };
        g = {
            P: n,
            eb: c,
            Hj: g,
            params: p,
            J: new lU({
                Bb: l,
                mf: W(ju),
                pf: W(lu),
                fe: X(Zu),
                ee: X(Yu),
                Le: X(Ru),
                Ie: Lv(ou),
                Mb: Lv(pu),
                Ke: X(Qu),
                Me: X(Su),
                Xd: X(xu),
                nf: W(ku),
                Ye: Lv(eu),
                wd: Lv(gu),
                ae: X(zu),
                ed: I(e, 4) === 2,
                Jd: Mv(su),
                jg: Lv(ru),
                Ef: W(uu),
                Zd: X(yu),
                qe: W(Ku),
                Vd: X(Bu),
                sf: W(mu),
                Qh: W(Hu),
                kf: W(iu),
                sg: W(Mu),
                Sf: W(Eu),
                de: X(Du),
                dc: X(Au),
                Zc: W(Iu),
                Pf: R(Kv).g(Cu.g,
                    Cu.defaultValue),
                we: W(Lu)
            }),
            Bd: m
        };
        await UW(b, d, a, g, h, k, f)
    }

    function TW(a) {
        const b = R(ip).g();
        a && b.push(...rh(a, 24));
        b.push(...Mv(Nu).map(Number));
        b.push(42);
        b.sort((c, d) => c - d);
        return b
    }
    async function UW(a, b, c, d, e, f, g) {
        if (a) {
            var h = mA(a);
            if (h.wasReactiveAdConfigReceived[42]) return;
            h.wasReactiveAdConfigReceived[42] = !0
        }
        h = [new VW(c, oy(), d.P)];
        await PW(a, b, d, oy(), [k => {
            WW(c, k, e.ka(23), d.P)
        }], h, e, f, g)
    }

    function WW(a, b, c, d) {
        a && oy().Fa(1214, LE(a, b, c), e => void XW(e, d))
    }

    function wW(a, b) {
        YW(a, c => c.Bi, {
            da: 1,
            ...b
        })
    }

    function xW(a, b) {
        YW(a, c => c.Cj, {
            da: 1,
            ...b
        })
    }

    function uW(a, b) {
        YW(a, c => c.Ci, {
            da: 1,
            ...b
        })
    }

    function zW(a, b) {
        YW(a, c => c.Di, {
            da: 1,
            ...b
        })
    }

    function CW(a, b) {
        YW(a, c => c.Fi, {
            da: 1,
            ...b
        })
    }

    function DW(a, b) {
        YW(a, c => c.Ei, {
            da: 1,
            ...b
        })
    }

    function EW(a, b) {
        YW(a, c => c.Dk, {
            da: 1,
            ...b
        })
    }

    function FW(a, b) {
        YW(a, c => c.mj, {
            da: 1,
            ...b
        })
    }

    function GW(a, b) {
        YW(a, c => c.lj, {
            da: 1,
            ...b
        })
    }

    function HW(a, b) {
        YW(a, c => c.Ai, {
            da: 1,
            ...b
        })
    }

    function YW(a, b, c) {
        a.g && a.Aa.Fa(1214, ME(a.g, b, c), d => void XW(d, a.i))
    }

    function ZW(a, b, c) {
        a.g && a.Aa.Fa(1214, NE(a.g, b, c), d => void XW(d, a.i))
    }
    class VW {
        constructor(a, b, c) {
            this.g = a;
            this.Aa = b;
            this.i = c
        }
        Qe(a, b) {
            ZW(this, c => c.Qe, {
                cd: a,
                ...b
            })
        }
        Se(a, b) {
            YW(this, c => c.Se, {
                da: a,
                ...b
            })
        }
        click(a) {
            YW(this, b => b.Zi, {
                da: 1,
                ...a
            })
        }
    }

    function XW(a, b) {
        a.es = TW(b).join(",")
    };

    function $W(a, b) {
        const c = bd("STYLE", a);
        c.textContent = xc(Jc `* { pointer-events: none; }`);
        a ? .head.appendChild(c);
        setTimeout(() => {
            a ? .head.removeChild(c)
        }, b)
    }

    function aX(a, b, c) {
        if (!a.body) return null;
        const d = new bX;
        d.apply(a, b);
        return () => {
            var e = c || 0;
            e > 0 && $W(b.document, e);
            Fk(a.body, {
                filter: d.g,
                webkitFilter: d.g,
                overflow: d.j,
                position: d.l,
                top: d.B
            });
            b.scrollTo(0, d.i)
        }
    }
    class bX {
        constructor() {
            this.g = this.B = this.l = this.j = null;
            this.i = 0
        }
        apply(a, b) {
            this.j = a.body.style.overflow;
            this.l = a.body.style.position;
            this.B = a.body.style.top;
            this.g = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
            this.i = Ip(b);
            Fk(a.body, "top", `${-this.i}px`)
        }
    };

    function cX(a, b) {
        var c;
        if (!a.j)
            for (a.j = [], c = a.g.parentElement; c;) {
                a.j.push(c);
                if (a.I(c)) break;
                c = c.parentNode && c.parentNode.nodeType === 1 ? c.parentNode : null
            }
        c = a.j.slice();
        let d, e;
        for (d = 0; d < c.length; ++d)(e = c[d]) && b.call(a, e, d, c)
    }
    var dX = class extends S {
        constructor(a, b, c) {
            super();
            this.g = a;
            this.U = b;
            this.D = c;
            this.j = null;
            cq(this, () => this.j = null)
        }
        I(a) {
            return this.D === a
        }
    };

    function eX(a, b) {
        const c = a.D;
        c && (b ? (vA(a.F), u(c, {
            display: "block"
        }), a.A.body && !a.l && (a.l = aX(a.A, a.U, a.Z)), c.setAttribute("tabindex", "0"), c.setAttribute("aria-hidden", "false"), a.A.body.setAttribute("aria-hidden", "true")) : (wA(a.F), u(c, {
            display: "none"
        }), a.l && (a.l(), a.l = null), a.A.body.setAttribute("aria-hidden", "false"), c.setAttribute("aria-hidden", "true")))
    }

    function fX(a) {
        eX(a, !1);
        const b = a.D;
        if (b) {
            var c = gX(a.M);
            cX(a, d => {
                u(d, c);
                Mp(d)
            });
            a.g.setAttribute("width", "");
            a.g.setAttribute("height", "");
            Fk(a.g, c);
            Fk(a.g, hX);
            Fk(b, iX);
            Fk(b, {
                background: "transparent"
            });
            u(b, {
                display: "none",
                position: "fixed"
            });
            Mp(b);
            Mp(a.g);
            Kd(a.M) <= 1 || (Fk(b, {
                overflow: "scroll",
                "max-width": "100vw"
            }), wd(b))
        }
    }
    class jX extends dX {
        constructor(a, b, c) {
            var d = X(yv);
            super(a, b, c);
            this.l = null;
            this.A = b.document;
            this.Z = d;
            this.F = pA(new uA(b), 2147483646);
            this.M = b
        }
    }

    function gX(a) {
        a = Kd(a);
        a = 100 * (a < 1 ? 1 : a);
        return {
            width: `${a}vw`,
            height: `${a}vh`
        }
    }
    var iX = {
            backgroundColor: "white",
            opacity: "1",
            position: "fixed",
            left: "0px",
            top: "0px",
            margin: "0px",
            padding: "0px",
            display: "none",
            zIndex: "2147483647"
        },
        hX = {
            left: "0",
            position: "absolute",
            top: "0"
        };
    var kX = class extends jX {
        constructor(a, b, c) {
            super(b, a, c);
            fX(this)
        }
        I(a) {
            return a.classList ? a.classList.contains("adsbygoogle") : Pa(a.classList ? a.classList : (typeof a.className == "string" ? a.className : a.getAttribute && a.getAttribute("class") || "").match(/\S+/g) || [], "adsbygoogle")
        }
    };
    const lX = {
        [1]: "closed",
        [2]: "viewed",
        [3]: "dismissed"
    };
    async function mX(a, b, c, d, e) {
        a = new nX(a, b, c, d, e);
        await a.L();
        return a
    }

    function oX(a) {
        return setTimeout(ky(728, () => {
            pX(() => {
                a.A.reject()
            });
            a.dispose()
        }), X(qv) * 1E3)
    }

    function qX(a, b) {
        var c = VM(a.g).then(() => {
            clearTimeout(b);
            a.A.resolve()
        });
        ly(1005, c);
        c = WM(a.g).then(d => {
            rX(a, lX[d.status], d.payload)
        });
        ly(1006, c);
        c = XM(a.g).then(() => {
            rX(a, "error")
        });
        ly(1004, c)
    }

    function sX(a) {
        if (W(rv)) {
            a.win.location.hash !== "" && my("pub_hash", {
                o_url: a.win.location.href
            }, .1);
            a.win.location.hash = "goog_fullscreen_ad";
            var b = ky(950, c => {
                c.oldURL.endsWith("#goog_fullscreen_ad") && (a.j === 10 ? rX(a, "closed") : a.g.df.postMessage(JSON.stringify({
                    eventType: "backButton",
                    googMsgType: "fullscreen"
                }), "*"), a.win.removeEventListener("hashchange", b))
            });
            a.win.addEventListener("hashchange", b);
            cq(a, () => {
                a.win.removeEventListener("hashchange", b);
                a.win.location.hash === "#goog_fullscreen_ad" && a.win.history.back()
            })
        }
    }

    function pX(a) {
        try {
            a()
        } catch (b) {}
    }

    function rX(a, b, c) {
        eX(a.F, !1);
        a.l && (c && b === "viewed" ? pX(() => {
            a.l({
                status: b,
                reward: c
            })
        }) : pX(() => {
            a.l({
                status: b
            })
        }));
        a.j === 11 && my("fs_ad", {
            tgorigin: a.C.google_tag_origin,
            client: a.C.google_ad_client,
            url: a.C.google_page_url ? ? "",
            slot: a.C.google_ad_slot ? ? "0",
            ratype: a.j,
            clostat: b
        }, 1);
        a.dispose()
    }
    var nX = class extends S {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.D = b;
            this.I = c;
            this.j = d;
            this.C = e;
            this.l = null;
            this.F = new kX(a, c, b);
            a = this.j === 10 ? 1 : 2;
            b = this.win;
            c = this.I.contentWindow;
            d = {
                Tk: 2,
                version: to()
            };
            e = oy();
            a = new ZM(a, b, c, e, d);
            a.L();
            this.g = a;
            this.A = new UM;
            this.D.dataset["slotcar" + (this.j === 10 ? "Interstitial" : "Rewarded")] = "true"
        }
        async L() {
            const a = oX(this);
            qX(this, a);
            cq(this, () => {
                this.g.dispose();
                clearTimeout(a);
                wk(this.D)
            });
            await this.A.promise
        }
        show(a) {
            this.B || (this.l = a, eX(this.F, !0), q.IntersectionObserver ||
                this.g.df.postMessage(JSON.stringify({
                    eventType: "visible",
                    googMsgType: "fullscreen"
                }), "*"), sX(this))
        }
        disposeAd() {
            this.dispose()
        }
    };

    function tX({
        Pg: a,
        Zh: b
    }) {
        return a || (b === "dev" ? "dev" : "")
    };

    function uX(a) {
        oy().lg(b => {
            b.shv = String(a);
            b.mjsv = tX({
                Pg: to(),
                Zh: a
            });
            b.eid = ZN(q)
        })
    }

    function vX(a, b) {
        b = b ? .i();
        const c = b ? .j() ? E(b, 4) : E(a, 6);
        uX(b ? .i() || F(a, 2));
        Le(EN, Re);
        EN = c
    };
    var wX = class extends N {
        i() {
            return E(this, 10)
        }
    };
    var xX = class extends N {
        i() {
            return F(this, 4)
        }
    };
    var yX = class extends N {
        i() {
            return E(this, 1)
        }
        j() {
            return y(this, rs, 2)
        }
    };
    var zX = class extends N {},
        AX = [13, 14],
        BX = [27, 28];
    var CX = typeof sttc === "undefined" ? void 0 : sttc;

    function DX(a) {
        var b = oy();
        try {
            if (Le(a, Qe), a.length > 0) return new zX(JSON.parse(a))
        } catch (c) {
            b.ia(838, c instanceof Error ? c : Error(String(c)))
        }
        return new zX
    };

    function EX(a, b, c, d) {
        const e = new UM;
        let f = "";
        const g = k => {
            try {
                const l = typeof k.data === "object" ? k.data : JSON.parse(k.data);
                f === l.paw_id && (mb(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
            } catch (l) {}
        };
        var h = typeof a.gmaSdk ? .getQueryInfo === "function" ? a.gmaSdk : void 0;
        if (h) return lb(a, "message", g), f = c(h), e.promise;
        c = typeof a.webkit ? .messageHandlers ? .getGmaQueryInfo ? .postMessage === "function" || typeof a.webkit ? .messageHandlers ? .getGmaSig ? .postMessage === "function" ? a.webkit.messageHandlers :
            void 0;
        return c ? (f = String(Math.floor(dd() * 2147483647)), lb(a, "message", g), b(c, f), e.promise) : null
    }

    function FX(a) {
        return EX(a, (b, c) => void(b.getGmaQueryInfo ? ? b.getGmaSig) ? .postMessage(c), b => b.getQueryInfo(), b => b.signal)
    }(function(a) {
        return Ne(b => {
            if (!Ue(b)) return !1;
            for (const [c, d] of Object.entries(a)) {
                const e = c,
                    f = d;
                if (!(e in b)) {
                    if (f.Yj === !0) continue;
                    return !1
                }
                if (!f(b[e])) return !1
            }
            return !0
        })
    })({
        vc: Qe,
        pn: Qe,
        eid: Ve(),
        vnm: Ve(),
        js: Qe
    }, "RawGmaSdkStaticSignalObject");
    const GX = (a, b) => {
        try {
            const k = E(b, 6) === void 0 ? !0 : E(b, 6);
            var c = Ej(I(b, 2)),
                d = F(b, 3);
            a: switch (I(b, 4)) {
                case 1:
                    var e = "pt";
                    break a;
                case 2:
                    e = "cr";
                    break a;
                default:
                    e = ""
            }
            var f = new Gj(c, d, e),
                g = y(b, yj, 5) ? .i() ? ? "";
            f.Nc = g;
            f.g = k;
            f.Za = !!E(b, 7);
            f.win = a;
            var h = f.build();
            wj(h)
        } catch {}
    };

    function HX(a, b) {
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), a.document.readyState === "complete" ? GX(a, b) : lb(a, "load", () => void GX(a, b)))
    };

    function IX(a) {
        const b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    }

    function JX(a) {
        if (a === a.top || Xc(a.top)) return Promise.resolve({
            status: 4
        });
        a: {
            try {
                var b = (a.top ? .frames ? ? {}).google_ads_top_frame;
                break a
            } catch (d) {}
            b = null
        }
        if (!b) return Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && IX(a.document.referrer)) return Promise.resolve({
            status: 3
        });
        const c = new UM;
        a = new MessageChannel;
        a.port1.onmessage = d => {
            d.data.msgType === "__goog_top_url_resp" && c.resolve({
                Fc: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };

    function rE() {
        return navigator.cookieDeprecationLabel ? Promise.race([navigator.cookieDeprecationLabel.getValue().then(a => ({
            status: 1,
            label: a
        })).catch(() => ({
            status: 2
        })), Hd(X(ov), {
            status: 5
        })]) : Promise.resolve({
            status: 3
        })
    }

    function KX(a) {
        a = a.innerInsElement;
        if (!a) throw Error("no_wrapper_element_in_loader_provided_slot");
        return a
    }
    async function LX({
        ma: a,
        ua: b,
        gb: c,
        slot: d,
        pageState: e
    }) {
        const f = d.vars,
            g = $c(d.pubWin),
            h = KX(d),
            k = new BR({
                K: g,
                pubWin: d.pubWin,
                C: f,
                ma: a,
                ua: b,
                gb: c,
                X: h,
                pageState: e
            });
        k.I = Date.now();
        Yj(1, [k.C]);
        jy(1032, () => {
            if (g && W(Hv)) {
                var l = k.C;
                iE(dE(), 32, !1) || (jE(dE(), 32, !0), yT(g, l.google_loader_used === "sd" ? 5 : 9))
            }
        });
        try {
            await MX(k)
        } catch (l) {
            if (!ny(159, l)) throw l;
        }
        jy(639, () => {
            var l;
            var m = k.C;
            (l = k.K) && m.google_responsive_auto_format === 1 && m.google_full_width_responsive_allowed === !0 ? (m = (m = l.document.getElementById(m.google_async_iframe_id)) ?
                Bk(m, "INS", "adsbygoogle") : null) ? ((new AR(l, m)).run(), l = !0) : l = !1 : l = !1;
            return l
        });
        g ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/) ? ly(1008, NX(d.pubWin, g, f, k.j, Hh(iU()), k.g, F(e.i(), 8) || F(a, 8)), l => void XW(l, null)) : RM(k.pubWin, "affa", l => {
            ly(1008, NX(d.pubWin, g, f, k.j, l.config, k.g, F(e.i(), 8) || F(a, 8)), m => void XW(m, null));
            return !0
        });
        OX(k);
        return k
    }
    async function NX(a, b, c, d, e, f, g) {
        await SW(a, b, c, d, e, f, g)
    }

    function MX(a) {
        if (/_sdo/.test(a.C.google_ad_format)) return Promise.resolve();
        var b = a.pubWin;
        XN(13, b);
        XN(11, b);
        W(kv) ? a.G = uh(a.ma, yX, 28, BX) ? .i() ? ? !0 : a.G = uh(a.ma, wX, 13, AX) ? .i() ? ? !0;
        b = dE();
        var c = iE(b, 23, !1);
        c || jE(b, 23, !0);
        c || (b = a.C.google_ad_client, c = a.ma, b = Mg(c, wX, 13, AX) ? y(uh(c, wX, 13, AX), oK, 2) : Mg(c, xX, 14, AX) && uh(c, xX, 14, AX) ? .i() === b ? y(y(uh(c, xX, 14, AX), wX, 2), oK, 2) : new oK, c = uh(a.ma, yX, 28, BX) ? .j() ? ? null, b = new pK(a.pubWin, a.C.google_ad_client, b, c, E(a.ma, 6), E(a.ma, 20)), b.i = !0, b.run());
        W(Rt) && (a.pubWin.googFloatingToolbarManagerAsyncPositionUpdate = !0, a.K && a.K !== a.pubWin && (a.K.googFloatingToolbarManagerAsyncPositionUpdate = !0));
        b = !jk() && !Ab();
        return !b || b && !PX(a) ? QX(a) : Promise.resolve()
    }

    function PX(a) {
        return RX(a) || SX(a)
    }

    function RX(a) {
        const b = a.C;
        if (!b.google_pause_ad_requests) return !1;
        const c = q.setTimeout(() => {
                my("abg:cmppar", {
                    client: a.C.google_ad_client,
                    url: a.C.google_page_url
                })
            }, 1E4),
            d = ky(450, () => {
                b.google_pause_ad_requests = !1;
                q.clearTimeout(c);
                a.pubWin.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
                if (!PX(a)) {
                    const e = QX(a);
                    ly(1222, e)
                }
            });
        a.pubWin.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
        return !0
    }

    function SX(a) {
        const b = a.pubWin.document,
            c = a.X;
        if (wQ(b) === 3) return zQ(ky(332, () => {
            if (!TX(a, UX().visible, c)) {
                const g = QX(a);
                ly(1222, g)
            }
        }), b), !0;
        const d = UX();
        if (d.hidden < 0 && d.visible < 0) return !1;
        const e = xQ(b);
        if (!e) return !1;
        if (!yQ(b)) return TX(a, d.visible, c);
        if (cQ(a.K, a.pubWin, c) <= d.hidden) return !1;
        let f = ky(332, () => {
            if (!yQ(b) && f) {
                mb(b, e, f);
                if (!TX(a, d.visible, c)) {
                    const g = QX(a);
                    ly(1222, g)
                }
                f = null
            }
        });
        return lb(b, e, f)
    }

    function UX() {
        var a = X(qt);
        const b = X(rt);
        return b === 3 && a === 6 ? (a = {
            hidden: 0,
            visible: 3
        }, q.IntersectionObserver || (a.visible = -1), Gb() && (a.visible *= 2), a) : {
            hidden: 0,
            visible: q.IntersectionObserver ? Gb() ? a : b : -1
        }
    }

    function TX(a, b, c) {
        if (!c || b < 0) return !1;
        var d = a.C;
        if (!Gp(d.google_reactive_ad_format) && (XQ(d) || d.google_reactive_ads_config) || !aQ(c) || cQ(a.K, a.pubWin, c) <= b) return !1;
        var e = dE(),
            f = iE(e, 8, {});
        e = iE(e, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        const g = !!a.pubWin.google_apltlad;
        if (!f[d] && !e[d] && !g) return !1;
        f = new Promise(h => {
            const k = new q.IntersectionObserver((l, m) => {
                Ia(l, n => {
                    n.intersectionRatio <= 0 || (m.unobserve(n.target), h(void 0))
                })
            }, {
                rootMargin: `${b*100}%`
            });
            a.M = k;
            k.observe(c)
        });
        e = new Promise(h => {
            c.addEventListener("adsbygoogle-close-to-visible-event", () => {
                h(void 0)
            })
        });
        ha(Promise, "any").call(Promise, [f, e]).then(() => {
            jy(294, () => {
                const h = QX(a);
                ly(1222, h)
            })
        });
        return !0
    }

    function QX(a) {
        jy(326, () => {
            var c = a.pubWin,
                d = a.K,
                e = a.ma,
                f = a.pageState,
                g = a.ua;
            if (Uk(a.C) === 1) {
                var h = W(Iv);
                if ((h || W(Gv)) && c === d) {
                    var k = new Sj;
                    d = new Tj;
                    var l = k.setCorrelator(Fd(c));
                    var m = ZN(c);
                    l = Eh(l, 5, m);
                    M(l, 2, 1);
                    k = z(d, 1, k);
                    l = new Rj;
                    l = J(l, 10, !0);
                    m = W(Bv);
                    l = J(l, 8, m);
                    m = W(Cv);
                    l = J(l, 12, m);
                    m = W(Fv);
                    l = J(l, 7, m);
                    m = W(Ev);
                    l = J(l, 13, m);
                    z(k, 2, l);
                    c.google_rum_config = vg(d);
                    e = (Gh(f.i(), 6) ? E(f.i(), 6) : E(e, 9)) && h ? g.Ek : g.Fk;
                    ad(c.document, e)
                } else nl(iy)
            }
        });
        a.C.google_ad_channel = VX(a, a.C.google_ad_channel);
        a.C.google_tag_partner =
            WX(a, a.C.google_tag_partner);
        aO(a.K, a.C);
        const b = a.C.google_start_time;
        typeof b === "number" && (pp = b, a.C.google_start_time = null);
        oP(a);
        a.K && aR(a.K, Vc(a.ua.gj, new Map(Object.entries(vQ()))));
        mE() && Vc(a.ua.qc, new Map(Object.entries(vQ())));
        XQ(a.C) && (xN() && (a.C.google_adtest = a.C.google_adtest || "on"), a.C.google_pgb_reactive = a.C.google_pgb_reactive || 3);
        return XX(a)
    }

    function VX(a, b) {
        return (b ? [b] : []).concat(sE(a.pubWin).ad_channels || []).join("+")
    }

    function WX(a, b) {
        return (b ? [b] : []).concat(sE(a.pubWin).tag_partners || []).join("+")
    }

    function YX(a) {
        const b = bd("IFRAME");
        ed(a, (c, d) => {
            c != null && b.setAttribute(d, c)
        });
        return b
    }

    function ZX(a, b, c) {
        return a.C.google_reactive_ad_format === 9 && Bk(a.X, null, "fsi_container") ? (a.X.appendChild(b), Promise.resolve(b)) : hR(a.ua.Sh, 525, d => {
            a.X.appendChild(b);
            d.createAdSlot(a.K, a.C, b, a.X.parentElement, c, a.pubWin);
            return b
        })
    }

    function $X(a, b, c, d) {
        GE();
        R(HE).eb = a.C.google_page_url;
        d = Cj(Aj(M(M(zj(new Dj, xj(new yj, String(Fd(a.pubWin)))), 4, 1), 2, 1), a.pageState.i().i() || F(a.ma, 2)), d.i());
        W(it) && J(d, 7, !0);
        HX(a.pubWin, d);
        const e = a.K;
        if (a.C.google_acr)
            if (a.C.google_wrap_fullscreen_ad) {
                const h = a.C.google_acr;
                mX(a.pubWin, a.X.parentElement, b, a.C.google_reactive_ad_format, a.C).then(h).catch(() => {
                    h(null)
                })
            } else a.C.google_acr(b);
        lb(b, "load", () => {
            b && b.setAttribute("data-load-complete", !0);
            const h = e ? sE(e).enable_overlap_observer || !1 :
                !1;
            (a.C.ovlp || h) && e && e === a.pubWin && aY(e, a, a.X, b)
        });
        d = h => {
            h && a.j.push(() => {
                h.dispose()
            })
        };
        const f = fQ(a, b);
        eQ(a.pubWin, a.g, b.contentWindow, a.j);
        !e || XQ(a.C) && !kR(a.C) || (a.C.no_resize || d(new MS(e, b, a.X)), d(new cS(a, b)), d(e.IntersectionObserver ? null : new eS(e, b, a.X)), e.IntersectionObserver && d(XS(e, b, a.C, a.X, ky(1225, () => {
            f();
            for (const h of a.j) h();
            a.j.length = 0
        }))));
        if (e) {
            d(WR(e, b, a.g));
            if (W(Qt)) {
                var g = US(e, b, a.X, a.g);
                g && d(g)
            }
            a.j.push(uR(e, a.C));
            R(zR).L(e);
            a.j.push(OR(e, a.X, b))
        }
        b && b.setAttribute("data-google-container-id",
            c);
        c = a.C.iaaso;
        c != null && (d = a.X, g = d.parentElement, (g && Yv.test(g.className) ? g : d).setAttribute("data-auto-ad-size", c));
        b.setAttribute("tabindex", "0");
        b.setAttribute("title", "Advertisement");
        b.setAttribute("aria-label", "Advertisement");
        bY(a);
        bT(a);
        W(ht) && jP(a, b)
    }

    function bY(a) {
        const b = jk(a.pubWin);
        if (b)
            if (b.container === "AMP-STICKY-AD") {
                const c = e => {
                        e.data === "fill_sticky" && b.renderStart && b.renderStart()
                    },
                    d = ky(616, c);
                lb(a.pubWin, "message", d);
                a.j.push(() => {
                    mb(a.pubWin, "message", c)
                })
            } else b.renderStart && b.renderStart()
    }

    function aY(a, b, c, d) {
        hO(new rO(a), c).then(e => {
            Yj(8, [e]);
            return e
        }).then(e => {
            const f = c.parentElement;
            (f && Yv.test(f.className) ? f : c).setAttribute("data-overlap-observer-io", String(e.xh));
            return e
        }).then(e => {
            const f = b.C.armr || "",
                g = e.vj || "",
                h = b.C.iaaso == null ? "" : Number(b.C.iaaso),
                k = Number(e.xh),
                l = La(e.entries, B => `${B.Db}:${B.Yf}:${B.Mh}`),
                m = Number(e.rk.toFixed(2)),
                n = d.dataset.googleQueryId || "",
                p = m * e.mc.width * e.mc.height,
                t = `${e.Xh.scrollX},${e.Xh.scrollY}`,
                v = Vk(e.target),
                w = [e.mc.left, e.mc.top, e.mc.right,
                    e.mc.bottom
                ].join();
            e = `${e.ki.width}x${e.ki.height}`;
            my("ovlp", {
                adf: b.C.google_ad_dom_fingerprint,
                armr: f,
                client: b.C.google_ad_client,
                eid: ZN(b.C),
                et: g,
                fwrattr: b.C.google_full_width_responsive,
                iaaso: h,
                io: k,
                saldr: b.C.google_loader_used,
                oa: m,
                oe: l.join(","),
                qid: n,
                rafmt: b.C.google_responsive_auto_format,
                roa: p,
                slot: b.C.google_ad_slot,
                sp: t,
                tgt: v,
                tr: w,
                url: b.C.google_page_url,
                vp: e,
                pvc: Fd(a)
            }, 1)
        }).catch(e => {
            Yj(8, ["Error:", e.message, c]);
            my("ovlp-err", {
                err: e.message
            }, 1)
        })
    }

    function cY(a, b) {
        b.allow = b.allow && b.allow.length > 0 ? b.allow + ("; " + a) : a
    }

    function dY(a, b, c) {
        var d = a.C,
            e = d.google_async_iframe_id;
        const f = d.google_ad_width,
            g = d.google_ad_height,
            h = lR(d);
        e = {
            id: e,
            name: e
        };
        var k = a.C,
            l = a.l;
        JN("browsing-topics", a.pubWin.document) && NR(c, k) && !W(sv) && !KR(l ? .label) && (e.browsingTopics = "true");
        e.style = h ? [`width:${f}px !IMPORTANT`, `height:${g}px !IMPORTANT`].join(";") : "left:0;position:absolute;top:0;border:0;" + `width:${f}px;` + `height:${g}px;`;
        k = qd();
        if (k["allow-top-navigation-by-user-activation"] && k["allow-popups-to-escape-sandbox"]) {
            if (!h)
                if (k = b, b =
                    "fsb=" + encodeURIComponent("1")) {
                    l = k.indexOf("#");
                    l < 0 && (l = k.length);
                    let m = k.indexOf("?"),
                        n;
                    m < 0 || m > l ? (m = l, n = "") : n = k.substring(m + 1, l);
                    k = [k.slice(0, m), n, k.slice(l)];
                    l = k[1];
                    k[1] = b ? l ? l + "&" + b : b : l;
                    b = k[0] + (k[1] ? "?" + k[1] : "") + k[2]
                } else b = k;
            e.sandbox = pd().join(" ")
        }
        d.google_video_play_muted === !1 && cY("autoplay", e);
        k = b;
        k.length > 61440 && (k = k.substring(0, 61432), k = k.replace(/%\w?$/, ""), k = k.replace(/&[^=]*=?$/, ""), k += "&trunc=1");
        k !== b && (l = b.lastIndexOf("&", 61432), l === -1 && (l = b.lastIndexOf("?", 61432)), my("trn", {
            ol: b.length,
            tr: l === -1 ? "" : b.substring(l + 1),
            url: b
        }, .01));
        b = k;
        f != null && (e.width = String(f));
        g != null && (e.height = String(g));
        e.frameborder = "0";
        e.marginwidth = "0";
        e.marginheight = "0";
        e.vspace = "0";
        e.hspace = "0";
        e.allowtransparency = "true";
        e.scrolling = "no";
        d.dash && (e.srcdoc = d.dash);
        IN("attribution-reporting", a.pubWin.document) && cY("attribution-reporting", e);
        IN("run-ad-auction", a.pubWin.document) && cY("run-ad-auction", e);
        W(cv) && (d = a.pubWin, d.credentialless !== void 0 && (W(dv) || d.crossOriginIsolated) && (e.credentialless = "true"));
        if (h) e.src = b, e = YX(e), a = ZX(a, e, c);
        else {
            c = {};
            c.dtd = CR((new Date).getTime(), pp);
            c = Rk(c, b);
            e.src = c;
            c = a.pubWin;
            c = c == c.top;
            e = YX(e);
            c && a.j.push(pk(a.pubWin, e));
            a.X.style.visibility = "visible";
            for (a = a.X; c = a.firstChild;) a.removeChild(c);
            a.appendChild(e);
            a = Promise.resolve(e)
        }
        return a
    }
    async function eY(a) {
        var b = a.C,
            c = a.pubWin;
        const d = a.g;
        fY(a);
        d.i() && dQ(new WN(a.pubWin), a.g, a.pubWin.location.hostname);
        if (!d.i() && !a.G) return my("afc_noc_req", {
            client: a.C.google_ad_client,
            isGdprCountry: (a.pageState.i().j() ? E(a.pageState.i(), 4) : E(a.ma, 6)).toString()
        }, X(pt)), Promise.resolve();
        var e = gY(a.ua, d);
        e && document.documentElement.appendChild(e);
        W(mv) && d.i() && (a.l = await qE());
        a.F = LR(a.pubWin, d);
        YN(a.pubWin, d);
        if (e = a.C.google_reactive_ads_config) gR(a.K, e), mR(e, a, d), e = e.page_level_pubvars, ra(e) &&
            Sb(a.C, e);
        e = JN("shared-storage", a.pubWin.document);
        W(bv) ? tP(a.pubWin, a.G) : a.F && d.i() && e && !W(av) && !iE(dE(), 34, !1) && (jE(dE(), 34, !0), e = a.F.then(g => {
            g({
                message: "goog:spam:client_age",
                pvsid: Fd(a.pubWin)
            })
        }), ly(1069, e));
        await MR(a, a.pubWin, d, a.C, a.F, a.l);
        await a.A ? .jj;
        e = "";
        lR(b) ? (e = (d.i() ? a.ua.ri : a.ua.oi).toString() + "#" + (encodeURIComponent("RS-" + b.google_reactive_sra_index + "-") + "&" + Qk({
            adk: b.google_ad_unit_key,
            client: b.google_ad_client,
            fa: b.google_reactive_ad_format
        })), MT(b, dE()), hY(b)) : (b.google_pgb_reactive ===
            5 && b.google_reactive_ads_config || !YQ(b) || WQ(c, b, d)) && hY(b) && (e = DT(a, d));
        Yj(2, [b, e]);
        if (!e) return Promise.resolve();
        b.google_async_iframe_id || Tk(c);
        var f = Uk(b);
        b = a.pubWin === a.K ? "a!" + f.toString(36) : `${f.toString(36)}.${Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)}`;
        c = cQ(a.K, a.pubWin, a.X, !0) > 0;
        f = {
            ifi: f,
            uci: b
        };
        c && (c = dE(), f.btvi = iE(c, 21, 1), kE(c, 21));
        e = Rk(f, e);
        c = dY(a, e, d);
        a.C.rpe && KS(a.pubWin, a.X, {
            height: a.C.google_ad_height,
            tg: "force",
            md: !0,
            eg: !0,
            Ee: a.C.google_ad_client
        });
        c = await c;
        try {
            $X(a, c, b, d)
        } catch (g) {
            ny(223, g)
        }
    }

    function iY(a) {
        const b = X(nt);
        if (b <= 0) return null;
        const c = gl(),
            d = FX(a.pubWin);
        if (!d) return null;
        a.D = "0";
        return Promise.race([d, Hd(b, "0")]).then(e => {
            my("adsense_paw", {
                time: gl() - c
            });
            e ? .length > 1E4 ? ny(809, Error(`ML:${e.length}`)) : a.D = e
        }).catch(e => {
            ny(809, e)
        })
    }

    function fY(a) {
        var b = a.pubWin;
        const c = a.X;
        var d = a.C;
        const e = a.gb,
            f = X(zv);
        d = !Gp(d.google_reactive_ad_format) && (XQ(d) || d.google_reactive_ads_config);
        if (!(a.A ? .Af || f <= 0 || $c(b) || !q.IntersectionObserver || d)) {
            a.A = {};
            var g = new bp(e),
                h = gl();
            b = new Promise(k => {
                let l = 0;
                const m = a.A,
                    n = new q.IntersectionObserver(ky(1236, p => {
                        if (p = p.find(t => t.target === c)) g.ce.ze.ld.g.g.Xc({
                            cd: gl() - h,
                            Vk: ++l
                        }), m.Uj = p.isIntersecting && p.intersectionRatio >= .8, k()
                    }), {
                        threshold: [.8]
                    });
                n.observe(c);
                m.Af = n
            });
            a.A.jj = Promise.race([b, Hd(f, null)]).then(k => {
                g.ce.ze.ld.g.i.Xc({
                    cd: gl() - h,
                    status: k === null ? "TIMEOUT" : "OK"
                })
            })
        }
    }

    function jY(a) {
        const b = gl();
        return Promise.race([jy(832, () => JX(a)), Hd(200)]).then(c => {
            my("afc_etu", {
                etus: c ? .status ? ? 100,
                sig: gl() - b,
                tms: 200
            });
            return c ? .Fc
        })
    }
    async function kY(a) {
        const b = iY(a),
            c = jy(868, () => jY(a.pubWin));
        await VP(a);
        await b;
        a.Fc = await c || "";
        await eY(a)
    }

    function XX(a) {
        Id(a.pubWin) !== a.pubWin && (a.i |= 4);
        wQ(a.pubWin.document) === 3 && (a.i |= 32);
        var b;
        if (b = a.K) {
            b = a.K;
            const c = zp(b);
            b = !(Ep(b).scrollWidth <= c)
        }
        b && (a.i |= 1024);
        a.pubWin.Prototype ? .Version && (a.i |= 16384);
        a.C.google_loader_features_used && (a.i |= a.C.google_loader_features_used);
        return kY(a)
    }

    function hY(a) {
        const b = dE(),
            c = a.google_ad_section;
        XQ(a) && kE(b, 15);
        if (Wk(a)) {
            if (kE(b, 5) > 100) return !1
        } else if (kE(b, 6) - iE(b, 15, 0) > 100 && c === "") return !1;
        return !0
    }

    function gY(a, b) {
        a: {
            var c = [q.top];
            var d = [];
            let f = 0,
                g;
            for (; g = c[f++];) {
                d.push(g);
                try {
                    if (g.frames)
                        for (let h = 0; h < g.frames.length && c.length < 1024; ++h) c.push(g.frames[h])
                } catch {}
            }
            c = d;
            for (d = 0; d < c.length; d++) try {
                var e = c[d].frames.google_esf;
                if (e) {
                    Pj = e;
                    break a
                }
            } catch (h) {}
            Pj = null
        }
        if (Pj) return null;e = bd("IFRAME");e.id = "google_esf";e.name = "google_esf";e.src = ac(b.i() ? a.ri : a.oi).toString();e.style.display = "none";
        return e
    }

    function OX(a) {
        if (nE()) {
            const b = ky(1244, () => void WO(a.K || a.pubWin, {
                Oa: a.pageState.i().j() ? E(a.pageState.i(), 4) : E(a.ma, 6)
            }));
            q.setTimeout(b, 1E3)
        }
    };
    (function(a, b, c) {
        jy(843, () => {
            if (!q.google_sa_impl) {
                var d = new fp(b);
                try {
                    ie(l => {
                        Xx(d, 1192, l)
                    })
                } catch (l) {}
                var e = uQ(),
                    f = e.i(),
                    g = DX(a);
                vX(g, e);
                Yj(16, [3, vg(g)]);
                var h = tX({
                        Pg: b,
                        Zh: f.i() || F(g, 2)
                    }),
                    k = c(h, g, oh(f, 1), f.i(), F(f, 9));
                q.google_sa_impl = l => LX({
                    ma: g,
                    ua: k,
                    gb: h,
                    slot: l,
                    pageState: e
                });
                QN(HN(q));
                q.google_process_slots ? .();
                f = (q.Prototype || {}).Version;
                f != null && my("prtpjs", {
                    version: f
                })
            }
        })
    })(CX, to(), function(a, b, c, d, e) {
        c = c > 2012 ? `_fy${c}` : "";
        e || (e = F(b, 3));
        d || (d = F(b, 2));
        return {
            Fk: Uc `https://pagead2.googlesyndication.com/pagead/js/${d}/${e}/rum${c}.js`,
            Ek: Uc `https://pagead2.googlesyndication.com/pagead/js/${d}/${e}/rum_debug${c}.js`,
            Sh: Uc `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/reactive_library${c}.js`,
            gj: Uc `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/debug_card_library${c}.js`,
            Wo: Uc `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${c}.js`,
            Qo: Uc `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/gallerify${c}.js`,
            qc: Uc `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/autogames${c}.js`,
            ri: Uc `https://googleads.g.doubleclick.net/pagead/html/${d}/${e}/zrt_lookup${c}.html`,
            oi: Uc `https://pagead2.googlesyndication.com/pagead/html/${d}/${e}/zrt_lookup${c}.html`
        }
    });
}).call(this, "");