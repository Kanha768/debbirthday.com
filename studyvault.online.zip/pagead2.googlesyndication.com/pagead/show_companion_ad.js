(function() {
    var p, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        q = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ba = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        ca = ba(this),
        u = function(a, b) {
            if (b) a: {
                var c = ca;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && q(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
    u("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.fa = f;
            q(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.fa
        };
        a = Math.random() * 1E9 >>> 0;
        var c = "jscomp_symbol_" + a + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6", "es3");
    u("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = ca[b[c]];
            typeof d === "function" && typeof d.prototype[a] != "function" && q(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return da(aa(this))
                }
            })
        }
        return a
    }, "es6", "es3");
    var da = function(a) {
            a = {
                next: a
            };
            a[Symbol.iterator] = function() {
                return this
            };
            return a
        },
        ea = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        fa = function() {
            function a() {
                function e() {}

                function f() {}
                new e;
                Reflect.construct(e, [], f);
                return new e instanceof e
            }

            function b(e, f, g) {
                g === void 0 && (g = e);
                g = g.prototype || Object.prototype;
                g = ea(g);
                var m = Function.prototype.apply;
                return (e = m.call(e, g, f)) || g
            }
            if (typeof Reflect != "undefined" && Reflect.construct) {
                if (a()) return Reflect.construct;
                var c = Reflect.construct,
                    d = function(e, f, g) {
                        e = c(e, f);
                        g && Reflect.setPrototypeOf(e, g.prototype);
                        return e
                    };
                return d
            }
            return b
        },
        ha = {
            valueOf: fa
        }.valueOf(),
        ma;
    if (typeof Object.setPrototypeOf == "function") ma = Object.setPrototypeOf;
    else {
        var na;
        a: {
            var oa = {
                    a: !0
                },
                pa = {};
            try {
                pa.__proto__ = oa;
                na = pa.a;
                break a
            } catch (a) {}
            na = !1
        }
        ma = na ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var v = ma,
        w = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: aa(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        qa = function(a) {
            if (!(a instanceof Array)) {
                a = w(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        };
    u("globalThis", function(a) {
        return a || ca
    }, "es_2020", "es3");
    u("Reflect", function(a) {
        return a ? a : {}
    }, "es6", "es3");
    u("Reflect.construct", function() {
        return ha
    }, "es6", "es3");
    u("Reflect.setPrototypeOf", function(a) {
        return a ? a : v ? a = function(b, c) {
            try {
                return v(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    }, "es6", "es5");
    u("Object.setPrototypeOf", function(a) {
        return a || v
    }, "es6", "es5");
    var y = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    u("WeakMap", function(a) {
        function b() {
            if (!a || !Object.seal) return !1;
            try {
                var l = Object.seal({}),
                    k = Object.seal({}),
                    n = new a([
                        [l, 2],
                        [k, 3]
                    ]);
                if (n.get(l) != 2 || n.get(k) != 3) return !1;
                n.delete(l);
                n.set(k, 4);
                return !n.has(l) && n.get(k) == 4
            } catch (r) {
                return !1
            }
        }

        function c() {}

        function d(l) {
            var k = typeof l;
            return k === "object" && l !== null || k === "function"
        }

        function e(l) {
            if (!y(l, g)) {
                var k = new c;
                q(l, g, {
                    value: k
                })
            }
        }

        function f(l) {
            var k = Object[l];
            k && (Object[l] = function(n) {
                if (n instanceof c) return n;
                Object.isExtensible(n) && e(n);
                return k(n)
            })
        }
        if (b()) return a;
        var g = "$jscomp_hidden_" + Math.random();
        f("freeze");
        f("preventExtensions");
        f("seal");
        var m = 0,
            h = function(l) {
                this.C = (m += Math.random() + 1).toString();
                if (l) {
                    l = w(l);
                    for (var k; !(k = l.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        h.prototype.set = function(l, k) {
            if (!d(l)) throw Error("Invalid WeakMap key");
            e(l);
            if (!y(l, g)) throw Error("WeakMap key fail: " + l);
            l[g][this.C] = k;
            return this
        };
        h.prototype.get = function(l) {
            return d(l) && y(l, g) ? l[g][this.C] : void 0
        };
        h.prototype.has = function(l) {
            return d(l) && y(l,
                g) && y(l[g], this.C)
        };
        h.prototype.delete = function(l) {
            return d(l) && y(l, g) && y(l[g], this.C) ? delete l[g][this.C] : !1
        };
        return h
    }, "es6", "es3");
    u("Map", function(a) {
        function b() {
            if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
            try {
                var h = Object.seal({
                        x: 4
                    }),
                    l = new a(w([
                        [h, "s"]
                    ]));
                if (l.get(h) != "s" || l.size != 1 || l.get({
                        x: 4
                    }) || l.set({
                        x: 4
                    }, "t") != l || l.size != 2) return !1;
                var k = l.entries(),
                    n = k.next();
                if (n.done || n.value[0] != h || n.value[1] != "s") return !1;
                n = k.next();
                return n.done || n.value[0].x != 4 || n.value[1] != "t" || !k.next().done ? !1 : !0
            } catch (r) {
                return !1
            }
        }
        if (b()) return a;
        var c = new WeakMap,
            d = function(h) {
                this[0] = {};
                this[1] =
                    g();
                this.size = 0;
                if (h) {
                    h = w(h);
                    for (var l; !(l = h.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        d.prototype.set = function(h, l) {
            h = h === 0 ? 0 : h;
            var k = e(this, h);
            k.list || (k.list = this[0][k.id] = []);
            k.j ? k.j.value = l : (k.j = {
                next: this[1],
                s: this[1].s,
                head: this[1],
                key: h,
                value: l
            }, k.list.push(k.j), this[1].s.next = k.j, this[1].s = k.j, this.size++);
            return this
        };
        d.prototype.delete = function(h) {
            h = e(this, h);
            return h.j && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.j.s.next = h.j.next, h.j.next.s = h.j.s, h.j.head =
                null, this.size--, !0) : !1
        };
        d.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].s = g();
            this.size = 0
        };
        d.prototype.has = function(h) {
            return !!e(this, h).j
        };
        d.prototype.get = function(h) {
            return (h = e(this, h).j) && h.value
        };
        d.prototype.entries = function() {
            return f(this, function(h) {
                return [h.key, h.value]
            })
        };
        d.prototype.keys = function() {
            return f(this, function(h) {
                return h.key
            })
        };
        d.prototype.values = function() {
            return f(this, function(h) {
                return h.value
            })
        };
        d.prototype.forEach = function(h, l) {
            for (var k = this.entries(), n; !(n = k.next()).done;) n =
                n.value, h.call(l, n[1], n[0], this)
        };
        d.prototype[Symbol.iterator] = d.prototype.entries;
        var e = function(h, l) {
                var k;
                var n = (k = l) && typeof k;
                n == "object" || n == "function" ? c.has(k) ? k = c.get(k) : (n = "" + ++m, c.set(k, n), k = n) : k = "p_" + k;
                if ((n = h[0][k]) && y(h[0], k))
                    for (h = 0; h < n.length; h++) {
                        var r = n[h];
                        if (l !== l && r.key !== r.key || l === r.key) return {
                            id: k,
                            list: n,
                            index: h,
                            j: r
                        }
                    }
                return {
                    id: k,
                    list: n,
                    index: -1,
                    j: void 0
                }
            },
            f = function(h, l) {
                var k = h[1];
                return da(function() {
                    if (k) {
                        for (; k.head != h[1];) k = k.s;
                        for (; k.next != k.head;) return k = k.next, {
                            done: !1,
                            value: l(k)
                        };
                        k = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            g = function() {
                var h = {};
                return h.s = h.next = h.head = h
            },
            m = 0;
        return d
    }, "es6", "es3");
    u("Set", function(a) {
        function b() {
            if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
            try {
                var d = Object.seal({
                        x: 4
                    }),
                    e = new a(w([d]));
                if (!e.has(d) || e.size != 1 || e.add(d) != e || e.size != 1 || e.add({
                        x: 4
                    }) != e || e.size != 2) return !1;
                var f = e.entries(),
                    g = f.next();
                if (g.done || g.value[0] != d || g.value[1] != d) return !1;
                g = f.next();
                return g.done || g.value[0] == d || g.value[0].x != 4 || g.value[1] != g.value[0] ? !1 : f.next().done
            } catch (m) {
                return !1
            }
        }
        if (b()) return a;
        var c = function(d) {
            this.m = new Map;
            if (d) {
                d =
                    w(d);
                for (var e; !(e = d.next()).done;) e = e.value, this.add(e)
            }
            this.size = this.m.size
        };
        c.prototype.add = function(d) {
            d = d === 0 ? 0 : d;
            this.m.set(d, d);
            this.size = this.m.size;
            return this
        };
        c.prototype.delete = function(d) {
            d = this.m.delete(d);
            this.size = this.m.size;
            return d
        };
        c.prototype.clear = function() {
            this.m.clear();
            this.size = 0
        };
        c.prototype.has = function(d) {
            return this.m.has(d)
        };
        c.prototype.entries = function() {
            return this.m.entries()
        };
        c.prototype.values = function() {
            return this.m.values()
        };
        c.prototype.keys = c.prototype.values;
        c.prototype[Symbol.iterator] = c.prototype.values;
        c.prototype.forEach = function(d, e) {
            var f = this;
            this.m.forEach(function(g) {
                return d.call(e, g, g, f)
            })
        };
        return c
    }, "es6", "es3");
    u("Object.values", function(a) {
        return a ? a : a = function(b) {
            var c = [],
                d;
            for (d in b) y(b, d) && c.push(b[d]);
            return c
        }
    }, "es8", "es3");
    u("Object.entries", function(a) {
        return a ? a : a = function(b) {
            var c = [],
                d;
            for (d in b) y(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8", "es3");
    u("Number.isFinite", function(a) {
        return a ? a : a = function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    }, "es6", "es3");
    u("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6", "es3");
    u("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    }, "es6", "es3");
    u("Number.isInteger", function(a) {
        return a ? a : a = function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    }, "es6", "es3");
    u("Number.isSafeInteger", function(a) {
        return a ? a : a = function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    }, "es6", "es3");
    var ra = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[Symbol.iterator] = function() {
            return e
        };
        return e
    };
    u("Array.prototype.entries", function(a) {
        return a ? a : a = function() {
            return ra(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6", "es3");
    u("Math.imul", function(a) {
        return a ? a : a = function(b, c) {
            b = Number(b);
            c = Number(c);
            var d = b >>> 16 & 65535;
            b &= 65535;
            var e = c >>> 16 & 65535;
            c &= 65535;
            d = d * c + b * e << 16 >>> 0;
            return b * c + d | 0
        }
    }, "es6", "es3");
    u("Array.prototype.values", function(a) {
        return a ? a : a = function() {
            return ra(this, function(b, c) {
                return c
            })
        }
    }, "es8", "es3");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var A = this || self,
        ta = function(a, b, c, d) {
            a = a.split(".");
            d = d || A;
            for (var e; a.length && (e = a.shift());)
                if (a.length || b === void 0) d = d[e] && d[e] !== Object.prototype[e] ? d[e] : d[e] = {};
                else if (!c && sa(b) && sa(d[e]))
                for (var f in b) b.hasOwnProperty(f) && (d[e][f] = b[f]);
            else d[e] = b
        },
        sa = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        };
    var ua, va;
    a: {
        for (var wa = ["CLOSURE_FLAGS"], xa = A, ya = 0; ya < wa.length; ya++)
            if (xa = xa[wa[ya]], xa == null) {
                va = null;
                break a
            }
        va = xa
    }
    var za = va && va[610401301],
        Aa = ua = za != null ? za : !1;
    var Ba = !1;

    function Ca() {
        var a = A.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Da = null,
        Ea, Fa = A.navigator;
    Ea = Fa ? Fa.userAgentData || null : null;

    function Ga(a) {
        if (!Aa && !Ba) return !1;
        var b = Ea;
        return b ? b.brands.some(function(c) {
            return (c = c.brand) && c.indexOf(a) != -1
        }) : !1
    }

    function B(a) {
        var b = Da == null ? Ca() : Da;
        return b.indexOf(a) != -1
    };

    function C(a) {
        a = a === void 0 ? !1 : a;
        if (!a && !Aa && !Ba) return !1;
        a = Ea;
        return !!a && a.brands.length > 0
    }

    function Ha() {
        return C() ? Ga("Chromium") : (B("Chrome") || B("CriOS")) && !(C() ? 0 : B("Edge")) || B("Silk")
    };
    var Ia = Array.prototype.indexOf ? function(a, b, c) {
            return Array.prototype.indexOf.call(a, b, c)
        } : function(a, b, c) {
            c = c == null ? 0 : c < 0 ? Math.max(0, a.length + c) : c;
            if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, c);
            for (; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        Ja = Array.prototype.forEach ? function(a, b, c) {
            Array.prototype.forEach.call(a, b, c)
        } : function(a, b, c) {
            for (var d = a.length, e = typeof a === "string" ? a.split("") : a, f = 0; f < d; f++) f in e && b.call(c, e[f], f, a)
        };
    var Ka = C() ? !1 : B("Trident") || B("MSIE"),
        La;
    if (La = B("Gecko")) {
        var Ma, Na = Da == null ? Ca() : Da;
        Ma = Na.toLowerCase().indexOf("webkit") != -1;
        La = !(Ma && !B("Edge"))
    }
    var Oa = La && !(B("Trident") || B("MSIE")) && !B("Edge");
    !B("Android") || Ha();
    Ha();
    !B("Safari") || Ha() || (C() ? 0 : B("Coast")) || (C() ? 0 : B("Opera")) || (C() ? 0 : B("Edge")) || (C() ? Ga("Microsoft Edge") : B("Edg/")) || C() && Ga("Opera");

    function D(a) {
        a.Da = !0;
        return a
    }
    D(function(a) {
        return a !== null && a !== void 0
    }, "exists");
    D(function(a) {
        return typeof a === "number"
    }, "number");
    Pa(0);
    D(function(a) {
        return Number.isSafeInteger(a)
    }, "isSafeInteger");
    D(function(a) {
        return Number.isInteger(a)
    }, "isInteger");
    D(function(a) {
        return Number.isFinite(a)
    }, "isFinite");
    var Qa = D(function(a) {
        return typeof a === "string"
    }, "string");
    Pa("");
    D(function(a) {
        return a.trim() !== ""
    }, "isNotBlank");
    D(function(a) {
        return a.trim() === ""
    }, "isBlank");
    D(function(a) {
        return typeof a === "boolean"
    }, "boolean");
    var Ra = D(function(a) {
        return typeof a === "bigint"
    }, "bigint");
    D(function(a) {
        return a === null
    }, "null");
    D(function(a) {
        return a === void 0
    }, "undefined");
    D(function(a) {
        return a == null
    }, "null | undefined");

    function Pa(a) {
        return D(function(b) {
            return b === a
        }, function() {
            throw Error("basicPrettyPrint should only be used in DEBUG mode");
        })
    }
    D(function(a) {
        return a != null && typeof a === "object" && typeof a.then === "function"
    }, "Thenable");
    var Sa = D(function(a) {
        return typeof a === "function"
    }, "Function");
    D(function(a) {
        return Sa(a) ? a.Da === !0 : !1
    }, "isGuard");
    Ta(Date);
    D(function(a) {
        return !isNaN(a)
    }, "isValidDate");
    D(function(a) {
        return a.global
    }, "isGlobalRegExp");
    D(function(a) {
        return a.sticky
    }, "isStickyRegExp");
    D(function(a) {
        return !!a && (typeof a === "object" || typeof a === "function")
    }, "object");

    function Ta(a) {
        return D(function(b) {
            return b instanceof a
        }, function() {
            var b = a.displayName;
            b && typeof b === "string" || (b = a.name, b && typeof b === "string" || (b = String(a), b = (b = /function\s+([^\(]+)/m.exec(b)) ? b[1] : "(Anonymous)"));
            return b
        })
    }
    D(function() {
        return !0
    }, "unknown");
    Ua();
    Ua();

    function Ua() {
        return D(function(a) {
            return Array.isArray(a)
        }, "Array<unknown>")
    }
    Va();
    Va();

    function Va() {
        return D(function(a) {
            return a instanceof Set
        }, "Set<unknown>")
    }
    Wa();
    Wa();

    function Wa() {
        return D(function(a) {
            return a instanceof Map
        }, "Map<unknown, unknown>")
    };
    var E = typeof A.BigInt === "function" && typeof A.BigInt(0) === "bigint";
    var Xa = function(a) {
        this.da = a
    };
    Xa.prototype.toString = function(a) {
        return this.da.toString(a)
    };
    Xa.prototype.valueOf = function() {
        throw Error("Convert JSBI instances to native numbers using `toNumber`.");
    };
    Xa.prototype[Symbol.toPrimitive] = function() {
        return this.da
    };
    /* 
     
     Copyright 2018 Google Inc 
     SPDX-License-Identifier: Apache-2.0 
    */
    var F = function(a, b) {
            var c = ha(Array, [a], this.constructor);
            c.sign = b;
            Object.setPrototypeOf(c, F.prototype);
            if (a > Ya) throw new RangeError("Maximum BigInt size exceeded");
            return c
        },
        G = F,
        H = Array;
    G.prototype = ea(H.prototype);
    G.prototype.constructor = G;
    if (v) v(G, H);
    else
        for (var K in H)
            if (K != "prototype")
                if (Object.defineProperties) {
                    var Za = Object.getOwnPropertyDescriptor(H, K);
                    Za && Object.defineProperty(G, K, Za)
                } else G[K] = H[K];
    G.cb = H.prototype;
    F.prototype.toString = function(a) {
        a = a === void 0 ? 10 : a;
        if (a < 2 || a > 36) throw new RangeError("toString() radix argument must be between 2 and 36");
        if (this.length === 0) var b = "0";
        else if ((a & a - 1) === 0) {
            b = this.length;
            var c = a - 1;
            c = (c >>> 1 & 85) + (c & 85);
            c = (c >>> 2 & 51) + (c & 51);
            c = (c >>> 4 & 15) + (c & 15);
            --a;
            var d = this.g(b - 1),
                e = $a(d);
            e = b * 30 - e;
            var f = (e + c - 1) / c | 0;
            this.sign && f++;
            if (f > 268435456) throw Error("string too long");
            e = Array(f);
            --f;
            for (var g = 0, m = 0, h = 0; h < b - 1; h++) {
                var l = this.g(h);
                g = (g | l << m) & a;
                e[f--] = ab[g];
                m = c - m;
                g = l >>> m;
                for (m = 30 -
                    m; m >= c;) e[f--] = ab[g & a], g >>>= c, m -= c
            }
            b = (g | d << m) & a;
            e[f--] = ab[b];
            for (g = d >>> c - m; g !== 0;) e[f--] = ab[g & a], g >>>= c;
            this.sign && (e[f--] = "-");
            if (f !== -1) throw Error("implementation bug");
            b = e.join("")
        } else b = bb(this, a, !1);
        return b
    };
    F.prototype.valueOf = function() {
        throw Error("Convert JSBI instances to native numbers using `toNumber`.");
    };
    var fb = function(a, b) {
            if (b.sign) throw new RangeError("Exponent must be positive");
            if (b.length === 0) return cb(1, !1);
            if (a.length === 0) return a;
            if (a.length === 1 && a.g(0) === 1) return a.sign && (b.g(0) & 1) === 0 ? (b = a, b.length !== 0 && (a = b.ga(), a.sign = !b.sign, b = a)) : b = a, b;
            if (b.length > 1) throw new RangeError("BigInt too big");
            b = b.D(0);
            if (b === 1) return a;
            if (b >= db) throw new RangeError("BigInt too big");
            if (a.length === 1 && a.g(0) === 2) {
                var c = 1 + (b / 30 | 0);
                a = a.sign && (b & 1) !== 0;
                a = new F(c, a);
                a.v();
                b = 1 << b % 30;
                a.h(c - 1, b);
                return a
            }
            c = null;
            var d = a;
            (b & 1) !== 0 && (c = a);
            for (b >>= 1; b !== 0; b >>= 1) d = eb(d, d), (b & 1) !== 0 && (c = c === null ? d : eb(c, d));
            return c
        },
        eb = function(a, b) {
            if (a.length === 0) return a;
            if (b.length === 0) return b;
            var c = a.length + b.length;
            a.P() + b.P() >= 30 && c--;
            c = new F(c, a.sign !== b.sign);
            c.v();
            for (var d = 0; d < a.length; d++) {
                var e = b,
                    f = a.g(d),
                    g = c,
                    m = d;
                if (f !== 0) {
                    for (var h = f & 32767, l = f >>> 15, k = f = 0, n = 0; n < e.length; n++, m++) {
                        var r = g.g(m),
                            I = e.g(n),
                            x = I & 32767,
                            t = I >>> 15;
                        I = L(x, h);
                        x = L(x, l);
                        var J = L(t, h);
                        t = L(t, l);
                        r += k + I + f;
                        f = r >>> 30;
                        r &= 1073741823;
                        r += ((x & 32767) << 15) + ((J &
                            32767) << 15);
                        f += r >>> 30;
                        k = t + (x >>> 15) + (J >>> 15);
                        g.h(m, r & 1073741823)
                    }
                    for (; f !== 0 || k !== 0; m++) e = g.g(m), e += f + k, k = 0, f = e >>> 30, g.h(m, e & 1073741823)
                }
            }
            return c.J()
        },
        cb = function(a, b) {
            b = new F(1, b);
            b.h(0, a);
            return b
        };
    F.prototype.ga = function() {
        for (var a = new F(this.length, this.sign), b = 0; b < this.length; b++) a[b] = this[b];
        return a
    };
    F.prototype.J = function() {
        for (var a = this.length, b = this[a - 1]; b === 0;) a--, b = this[a - 1], this.pop();
        a === 0 && (this.sign = !1);
        return this
    };
    F.prototype.v = function() {
        for (var a = 0; a < this.length; a++) this[a] = 0
    };
    var bb = function(a, b, c) {
        var d = a.length;
        if (d === 0) return "";
        if (d === 1) return b = a.D(0).toString(b), c === !1 && a.sign && (b = "-" + b), b;
        d = d * 30 - $a(a.g(d - 1));
        var e = gb[b];
        --e;
        d *= hb;
        d += e - 1;
        d = d / e | 0;
        d = d + 1 >> 1;
        e = fb(cb(b, !1), cb(d, !1));
        var f = e.D(0);
        if (e.length === 1 && f <= 32767) {
            e = new F(a.length, !1);
            e.v();
            for (var g = 0, m = a.length * 2 - 1; m >= 0; m--) g = g << 15 | a.l(m), e.I(m, g / f | 0), g = g % f | 0;
            f = g.toString(b)
        } else {
            var h = a;
            f = e.R();
            m = e.length;
            var l = h.R() - f;
            g = new F(l + 2 >>> 1, !1);
            g.v();
            var k = new F(f + 2 >>> 1, !1);
            k.v();
            var n = $a(e.l(f - 1)) - 15;
            n > 0 && (e = ib(e,
                n, 0));
            h = ib(h, n, 1);
            for (var r = e.l(f - 1), I = 0; l >= 0; l--) {
                var x = 32767,
                    t = h.l(l + f);
                if (t !== r) {
                    t = (t << 15 | h.l(l + f - 1)) >>> 0;
                    x = t / r | 0;
                    t = t % r | 0;
                    for (var J = e.l(f - 2), z = h.l(l + f - 2); L(x, J) >>> 0 > (t << 16 | z) >>> 0 && !(x--, t += r, t > 32767););
                }
                t = e;
                J = x;
                var ia = 0;
                z = m;
                for (var ja = 0, ka = 0; ka < z; ka++) {
                    var S = t.g(ka),
                        la = L(S & 32767, J);
                    S = L(S >>> 15, J);
                    la = la + ((S & 32767) << 15) + ja + ia;
                    ia = la >>> 30;
                    ja = S >>> 15;
                    k.h(ka, la & 1073741823)
                }
                if (k.length > z)
                    for (k.h(z++, ia + ja); z < k.length;) k.h(z++, 0);
                else if (ia + ja !== 0) throw Error("implementation bug");
                t = h.ja(k, l, f + 1);
                t !== 0 &&
                    (t = h.ha(e, l, f), h.I(l + f, h.l(l + f) + t & 32767), x--);
                l & 1 ? I = x << 15 : g.h(l >>> 1, I | x)
            }
            h.ia(n);
            e = {
                Ma: g,
                Oa: h
            };
            f = e;
            e = f.Ma;
            f = f.Oa.J();
            f = bb(f, b, !0)
        }
        e.J();
        for (b = bb(e, b, !0); f.length < d;) f = "0" + f;
        c === !1 && a.sign && (b = "-" + b);
        return b + f
    };
    p = F.prototype;
    p.P = function() {
        return $a(this.g(this.length - 1))
    };
    p.Ya = function(a, b, c) {
        c > this.length && (c = this.length);
        var d = a & 32767;
        a >>>= 15;
        for (var e = 0, f = 0; f < c; f++) {
            var g = this.g(f),
                m = g & 32767,
                h = g >>> 15;
            g = L(m, d);
            m = L(m, a);
            var l = L(h, d);
            h = L(h, a);
            g = b + g + e;
            e = g >>> 30;
            g &= 1073741823;
            g += ((m & 32767) << 15) + ((l & 32767) << 15);
            e += g >>> 30;
            b = h + (m >>> 15) + (l >>> 15);
            this.h(f, g & 1073741823)
        }
        if (e !== 0 || b !== 0) throw Error("implementation bug");
    };
    p.ha = function(a, b, c) {
        for (var d = 0, e = 0; e < c; e++) {
            var f = this.l(b + e) + a.l(e) + d;
            d = f >>> 15;
            this.I(b + e, f & 32767)
        }
        return d
    };
    p.ja = function(a, b, c) {
        var d = c - 1 >>> 1,
            e = 0;
        if (b & 1) {
            b >>= 1;
            for (var f = this.g(b), g = f & 32767, m = 0; m < d; m++) {
                var h = a.g(m);
                f = (f >>> 15) - (h & 32767) - e;
                e = f >>> 15 & 1;
                this.h(b + m, (f & 32767) << 15 | g & 32767);
                f = this.g(b + m + 1);
                g = (f & 32767) - (h >>> 15) - e;
                e = g >>> 15 & 1
            }
            d = a.g(m);
            f = (f >>> 15) - (d & 32767) - e;
            e = f >>> 15 & 1;
            this.h(b + m, (f & 32767) << 15 | g & 32767);
            g = d >>> 15;
            if (b + m + 1 >= this.length) throw new RangeError("out of bounds");
            (c & 1) === 0 && (f = this.g(b + m + 1), g = (f & 32767) - g - e, e = g >>> 15 & 1, this.h(b + a.length, f & 1073709056 | g & 32767))
        } else {
            b >>= 1;
            for (m = 0; m < a.length - 1; m++) f =
                this.g(b + m), d = a.g(m), g = (f & 32767) - (d & 32767) - e, e = g >>> 15 & 1, f = (f >>> 15) - (d >>> 15) - e, e = f >>> 15 & 1, this.h(b + m, (f & 32767) << 15 | g & 32767);
            g = this.g(b + m);
            a = a.g(m);
            f = (g & 32767) - (a & 32767) - e;
            e = f >>> 15 & 1;
            d = 0;
            (c & 1) === 0 && (d = (g >>> 15) - (a >>> 15) - e, e = d >>> 15 & 1);
            this.h(b + m, (d & 32767) << 15 | f & 32767)
        }
        return e
    };
    p.ia = function(a) {
        if (a !== 0) {
            for (var b = this.g(0) >>> a, c = this.length - 1, d = 0; d < c; d++) {
                var e = this.g(d + 1);
                this.h(d, e << 30 - a & 1073741823 | b);
                b = e >>> a
            }
            this.h(c, b)
        }
    };
    var ib = function(a, b, c) {
        var d = a.length,
            e = d + c;
        e = new F(e, !1);
        if (b === 0) {
            for (b = 0; b < d; b++) e.h(b, a.g(b));
            c > 0 && e.h(d, 0);
            return e
        }
        for (var f = 0, g = 0; g < d; g++) {
            var m = a.g(g);
            e.h(g, m << b & 1073741823 | f);
            f = m >>> 30 - b
        }
        c > 0 && e.h(d, f);
        return e
    };
    p = F.prototype;
    p.g = function(a) {
        return this[a]
    };
    p.D = function(a) {
        return this[a] >>> 0
    };
    p.h = function(a, b) {
        this[a] = b | 0
    };
    p.Za = function(a, b) {
        this[a] = b | 0
    };
    p.R = function() {
        var a = this.length;
        return this.D(a - 1) <= 32767 ? a * 2 - 1 : a * 2
    };
    p.l = function(a) {
        return this[a >>> 1] >>> (a & 1) * 15 & 32767
    };
    p.I = function(a, b) {
        var c = a >>> 1,
            d = this.g(c);
        a = a & 1 ? d & 32767 | b << 15 : d & 1073709056 | b & 32767;
        this.h(c, a)
    };
    var Ya = 33554432,
        db = Ya << 5,
        gb = [0, 0, 32, 51, 64, 75, 83, 90, 96, 102, 107, 111, 115, 119, 122, 126, 128, 131, 134, 136, 139, 141, 143, 145, 147, 149, 151, 153, 154, 156, 158, 159, 160, 162, 163, 165, 166],
        jb = 5,
        hb = 1 << jb,
        ab = "0123456789abcdefghijklmnopqrstuvwxyz".split(""),
        $a = Math.clz32 ? function(a) {
            return Math.clz32(a) - 2
        } : function(a) {
            return a === 0 ? 30 : 29 - (Math.log(a >>> 0) / Math.LN2 | 0) | 0
        },
        L = Math.imul || function(a, b) {
            return a * b | 0
        };
    D(function(a) {
        return typeof a === "bigint"
    }, "bigint");
    Ta(F);
    Ta(Xa);
    D(function(a) {
        return E ? Ra(a) : Qa(a) && /^(?:-?[1-9]\d*|0)$/.test(a)
    }, "gbigint");
    D(function(a) {
        return E ? a >= kb && a <= lb : a[0] === "-" ? M(a, mb) : M(a, nb)
    }, "isSafeInt52");
    var mb = Number.MIN_SAFE_INTEGER.toString(),
        kb = E ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        nb = Number.MAX_SAFE_INTEGER.toString(),
        lb = E ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
    D(function(a) {
        return E ? a >= ob && a <= pb : a[0] === "-" ? M(a, "-9223372036854775808") : M(a, "9223372036854775807")
    }, "isValidSignedInt64");
    var ob = E ? BigInt("-9223372036854775808") : void 0,
        pb = E ? BigInt("9223372036854775807") : void 0;
    D(function(a) {
        return E ? a >= qb && a <= rb : a[0] === "-" ? !1 : M(a, "18446744073709551615")
    }, "isValidUnsignedInt64");
    var qb = E ? BigInt(0) : void 0,
        rb = E ? BigInt("18446744073709551615") : void 0;

    function M(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    var sb = !1;
    if (sb && typeof Proxy !== "undefined") {
        var N = tb;
        new Proxy({}, {
            getPrototypeOf: N,
            setPrototypeOf: N,
            isExtensible: N,
            preventExtensions: N,
            getOwnPropertyDescriptor: N,
            defineProperty: N,
            has: N,
            get: N,
            set: N,
            deleteProperty: N,
            apply: N,
            construct: N
        })
    }

    function tb() {
        throw Error();
    };
    var ub = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var vb = ub(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            A.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });

    function wb(a) {
        return a ? a.passive && vb() ? a : a.capture || !1 : !1
    }
    var xb = function(a, b, c, d) {
            return a.addEventListener ? (a.addEventListener(b, c, wb(d)), !0) : !1
        },
        yb = function(a, b, c, d) {
            return a.removeEventListener ? (a.removeEventListener(b, c, wb(d)), !0) : !1
        };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    function O(a) {
        return {
            valueOf: a
        }.valueOf()
    };
    var P = {};
    var zb = "goog#html",
        Ab = globalThis.trustedTypes,
        Bb = Ab,
        Cb;

    function Db() {
        var a = null;
        if (zb === "" || !Bb) return a;
        try {
            var b = function(c) {
                return c
            };
            a = Bb.createPolicy(zb, {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {}
        return a
    };
    var Eb = function(a, b) {
        this.Ka = b
    };
    Eb.prototype.toString = function() {
        return this.Ka
    };
    new Eb(P, "about:blank");
    new Eb(P, "about:invalid#zClosurez");
    var Fb = O(function() {
            return typeof URL === "function"
        }),
        Gb = ["data:", "http:", "https:", "mailto:", "ftp:"];
    var Hb = function(a, b) {
        this.W = b
    };
    Hb.prototype.toString = function() {
        return this.W + ""
    };

    function Ib(a) {
        Cb === void 0 && (Cb = Db());
        var b = Cb;
        return new Hb(P, b ? b.createHTML(a) : a)
    }

    function Jb(a) {
        if (a instanceof Hb) return a.W;
        a = "";
        throw Error(a);
    };

    function Kb(a, b) {
        if (a.nodeType === 1) {
            var c = "",
                d = a.tagName;
            if (/^(script|style)$/i.test(d)) throw Error(c);
        }
        a.innerHTML = Jb(b)
    };

    function Lb(a) {
        try {
            return new URL(a, window.document.baseURI)
        } catch (b) {
            return new URL("about:invalid")
        }
    };

    function Mb(a, b) {
        var c = b.createRange();
        c.selectNode(b.body);
        a = Ib(a);
        return c.createContextualFragment(Jb(a))
    };

    function Nb(a) {
        a = a.nodeName;
        return typeof a === "string" ? a : "FORM"
    }

    function Ob(a) {
        a = a.nodeType;
        return a === 1 || typeof a !== "number"
    };
    var Q = function(a, b, c, d, e) {
        this.oa = a;
        this.S = b;
        this.pa = c;
        this.Aa = d;
        this.T = e
    };
    Q.prototype.Ca = function(a) {
        return a !== "FORM" && (this.oa.has(a) || this.S.has(a))
    };
    Q.prototype.wa = function(a, b) {
        b = this.S.get(b);
        var c;
        return ((c = b) == null ? 0 : c.has(a)) ? b.get(a) : this.pa.has(a) ? {
            i: 1
        } : (c = this.Aa.get(a)) ? c : this.T && [].concat(qa(this.T)).some(function(d) {
            return a.indexOf(d) === 0
        }) ? {
            i: 1
        } : {
            i: 0
        }
    };
    var Pb = "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" "),
        Qb = [
            ["A", new Map([
                ["href", {
                    i: 2
                }]
            ])],
            ["AREA", new Map([
                ["href", {
                    i: 2
                }]
            ])],
            ["LINK", new Map([
                ["href", {
                    i: 5,
                    conditions: new Map([
                        ["rel", new Set("alternate author bookmark canonical cite help icon license next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" "))]
                    ])
                }]
            ])],
            ["SOURCE", new Map([
                ["src", {
                    i: 5
                }],
                ["srcset", {
                    i: 6
                }]
            ])],
            ["IMG", new Map([
                ["src", {
                    i: 5
                }],
                ["srcset", {
                    i: 6
                }]
            ])],
            ["VIDEO", new Map([
                ["src", {
                    i: 5
                }]
            ])],
            ["AUDIO", new Map([
                ["src", {
                    i: 5
                }]
            ])]
        ],
        Rb = "title aria-atomic aria-autocomplete aria-busy aria-checked aria-current aria-disabled aria-dropeffect aria-expanded aria-haspopup aria-hidden aria-invalid aria-label aria-level aria-live aria-multiline aria-multiselectable aria-orientation aria-posinset aria-pressed aria-readonly aria-relevant aria-required aria-selected aria-setsize aria-sort aria-valuemax aria-valuemin aria-valuenow aria-valuetext alt align autocapitalize autocomplete autocorrect autofocus autoplay bgcolor border cellpadding cellspacing checked cite color cols colspan controls controlslist datetime disabled download draggable enctype face formenctype frameborder height hreflang hidden ismap label lang loop max maxlength media minlength min multiple muted nonce open placeholder poster preload rel required reversed role rows rowspan selected shape size sizes slot span spellcheck start step summary translate type valign value width wrap itemscope itemtype itemid itemprop itemref".split(" "),
        Sb = [
            ["dir", {
                i: 3,
                conditions: O(function() {
                    return new Map([
                        ["dir", new Set(["auto", "ltr", "rtl"])]
                    ])
                })
            }],
            ["async", {
                i: 3,
                conditions: O(function() {
                    return new Map([
                        ["async", new Set(["async"])]
                    ])
                })
            }],
            ["loading", {
                i: 3,
                conditions: O(function() {
                    return new Map([
                        ["loading", new Set(["eager", "lazy"])]
                    ])
                })
            }],
            ["target", {
                i: 3,
                conditions: O(function() {
                    return new Map([
                        ["target", new Set(["_self", "_blank"])]
                    ])
                })
            }]
        ],
        Tb = new Q(new Set(Pb), new Map(Qb), new Set(Rb), new Map(Sb), void 0),
        Ub = new Q(new Set(Pb.concat(["BUTTON", "INPUT"])),
            new Map(Qb), new Set(O(function() {
                return Rb.concat(["class", "id", "name"])
            })), new Map(O(function() {
                return Sb.concat([
                    ["style", {
                        i: 1
                    }]
                ])
            })), void 0),
        Vb = new Q(new Set(O(function() {
            return Pb.concat("STYLE TITLE INPUT TEXTAREA BUTTON LABEL".split(" "))
        })), new Map(Qb), new Set(O(function() {
            return Rb.concat(["class", "id", "tabindex", "contenteditable", "name"])
        })), new Map(O(function() {
            return Sb.concat([
                ["style", {
                    i: 1
                }]
            ])
        })), new Set(["data-", "aria-"]));
    var Wb = function(a, b, c, d, e) {
        this.Y = a;
        this.ba = c;
        this.aa = d;
        this.H = e
    };
    p = Wb.prototype;
    p.O = function(a) {
        return a = this.Pa(a)
    };
    p.Pa = function(a) {
        var b = document.implementation.createHTMLDocument("");
        a = this.Sa(a, b);
        b = b.body;
        b.appendChild(a);
        b = (new XMLSerializer).serializeToString(b);
        b = b.slice(b.indexOf(">") + 1, b.lastIndexOf("</"));
        return b = Ib(b)
    };
    p.Sa = function(a, b) {
        var c = this;
        a = Mb(a, b);
        a = document.createTreeWalker(a, 5, function(m) {
            return c.Ha(m)
        });
        for (var d = a.nextNode(), e = b.createDocumentFragment(), f = e; d !== null;) {
            var g = void 0;
            if (d.nodeType === 3) this.ba && f.nodeName === "STYLE" ? (d = this.ba(d.data), g = this.createTextNode(d)) : g = this.Ra(d);
            else if (Ob(d)) g = this.Qa(d, b);
            else throw b = "", Error(b);
            f.appendChild(g);
            if (d = a.firstChild()) f = g;
            else
                for (; !(d = a.nextSibling()) && (d = a.parentNode());) f = f.parentNode
        }
        return e
    };
    p.createTextNode = function(a) {
        return document.createTextNode(a)
    };
    p.Ra = function(a) {
        return this.createTextNode(a.data)
    };
    p.Qa = function(a, b) {
        var c = Nb(a);
        b = b.createElement(c);
        a = a.attributes;
        for (var d = w(a), e = d.next(); !e.done; e = d.next()) {
            var f = e = e.value;
            e = f.name;
            var g = f.value;
            f = this.Y.wa(e, c);
            if (this.Ta(f.conditions, a)) switch (f.i) {
                case 1:
                    R(b, e, g);
                    break;
                case 2:
                    a: if (f = void 0, Fb) {
                        try {
                            f = new URL(g)
                        } catch (k) {
                            f = "https:";
                            break a
                        }
                        f = f.protocol
                    } else b: {
                        f = document.createElement("a");
                        try {
                            f.href = g
                        } catch (k) {
                            f = void 0;
                            break b
                        }
                        f = f.protocol;f = f === ":" || f === "" ? "https:" : f
                    }
                    f = f !== void 0 && Gb.indexOf(f.toLowerCase()) !== -1 ? g : "about:invalid#zClosurez";
                    R(b, e, f);
                    break;
                case 3:
                    R(b, e, g.toLowerCase());
                    break;
                case 4:
                    this.aa ? (f = this.aa(g), R(b, e, f)) : R(b, e, g);
                    break;
                case 5:
                    if (this.H) {
                        f = {
                            type: 2,
                            attributeName: e,
                            ua: c
                        };
                        var m = Lb(g);
                        (f = this.H(m, f)) && R(b, e, f.toString())
                    } else R(b, e, g);
                    break;
                case 6:
                    if (this.H) {
                        f = {
                            type: 2,
                            attributeName: e,
                            ua: c
                        };
                        m = [];
                        g = w(g.split(","));
                        for (var h = g.next(); !h.done; h = g.next()) {
                            h = h.value;
                            var l = w(h.trim().split(/\s+/, 2));
                            h = l.next().value;
                            l = l.next().value;
                            m.push({
                                url: h,
                                L: l
                            })
                        }
                        g = m = {
                            G: m
                        };
                        m = {
                            G: []
                        };
                        g = w(g.G);
                        for (h = g.next(); !h.done; h = g.next()) h = h.value,
                            l = Lb(h.url), (l = this.H(l, f)) && m.G.push({
                                url: l.toString(),
                                L: h.L
                            });
                        R(b, e, Xb(m))
                    } else R(b, e, g)
            }
        }
        return b
    };
    p.Ha = function(a) {
        if (a.nodeType === 3) return 1;
        if (!Ob(a)) return 2;
        a = Nb(a);
        return a === null ? 2 : this.Y.Ca(a) ? 1 : 2
    };
    p.Ta = function(a, b) {
        if (!a) return !0;
        a = w(a);
        for (var c = a.next(); !c.done; c = a.next()) {
            c = c.value;
            var d = w(c);
            c = d.next().value;
            d = d.next().value;
            var e = void 0;
            if ((c = (e = b.getNamedItem(c)) == null ? void 0 : e.value) && !d.has(c)) return !1
        }
        return !0
    };

    function R(a, b, c) {
        a.setAttribute(b, c)
    }

    function Xb(a) {
        return a.G.map(function(b) {
            var c = b;
            b = c.url;
            c = c.L;
            return "" + b + (c ? " " + c : "")
        }).join(" , ")
    }
    var Yb = O(function() {
            return new Wb(Tb, P)
        }),
        Zb = O(function() {
            return new Wb(Ub, P)
        }),
        $b = O(function() {
            return new Wb(Vb, P)
        });
    var ac = {
            0: 1,
            1: 1
        },
        bc = {
            0: .1,
            1: .1
        };

    function cc(a, b) {
        try {
            $b.O(a)
        } catch (c) {
            return T(b, "H_SLSANITIZE"), !0
        }
        try {
            Zb.O(a)
        } catch (c) {
            return T(b, "H_RSANITIZE"), !0
        }
        try {
            Yb.O(a)
        } catch (c) {
            return T(b, "H_SANITIZE"), !0
        }
        return !1
    }

    function T(a, b, c) {
        var d = dc ? dc : typeof window !== "undefined" && window.navigator && window.navigator.sendBeacon !== void 0 ? navigator.sendBeacon.bind(navigator) : ec;
        b = {
            host: window.location.hostname,
            type: b,
            additionalData: c
        };
        d("https://csp.withgoogle.com/csp/lcreport/" + a.X, JSON.stringify(b))
    }

    function ec(a, b) {
        var c = new XMLHttpRequest;
        c.open("POST", a);
        c.setRequestHeader("Content-Type", "application/json");
        c.send(b)
    }
    var dc;
    var fc = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        },
        gc = function(a, b) {
            b = b === void 0 ? document : b;
            return b.createElement(String(a).toLowerCase())
        };
    var ic = function(a, b, c, d, e) {
        c = c === void 0 ? null : c;
        d = d === void 0 ? !1 : d;
        e = e === void 0 ? !1 : e;
        return hc(a, b, c, !1, d, e)
    };

    function hc(a, b, c, d, e, f) {
        f = f === void 0 ? !1 : f;
        a.google_image_requests || (a.google_image_requests = []);
        var g = gc("IMG", a.document);
        if (c || e) {
            var m = function(h) {
                c && c(h);
                if (e) {
                    h = a.google_image_requests;
                    var l = Ia(h, g);
                    l >= 0 && Array.prototype.splice.call(h, l, 1)
                }
                yb(g, "load", m);
                yb(g, "error", m)
            };
            xb(g, "load", m);
            xb(g, "error", m)
        }
        d && (g.referrerPolicy = "no-referrer");
        f && (g.attributionSrc = "");
        g.src = b;
        a.google_image_requests.push(g);
        return g
    }

    function jc(a, b, c) {
        c = c === void 0 ? !1 : c;
        var d;
        if (d = a.navigator) d = a.navigator.userAgent, d = /Chrome/.test(d) && !/Edge/.test(d) ? !0 : !1;
        d && a.navigator.sendBeacon ? a.navigator.sendBeacon(b) : ic(a, b, void 0, c)
    };
    var kc = document,
        U = window;
    var lc = function(a, b) {
        return typeof b === "string" ? a.getElementById(b) : b
    };
    var mc = null;

    function nc(a) {
        a = a === void 0 ? A : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function oc(a) {
        a = a === void 0 ? A : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    var pc = function(a, b, c, d, e, f) {
        d = d === void 0 ? 0 : d;
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = d;
        this.slotId = e;
        this.taskId = f;
        this.uniqueId = Math.random()
    };
    var V = A.performance,
        qc = !!(V && V.mark && V.measure && V.clearMarks),
        W = ub(function() {
            var a;
            if (a = qc) {
                var b;
                a = void 0;
                a = a === void 0 ? window : a;
                if (mc === null) {
                    mc = "";
                    try {
                        var c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (mc = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (d) {}
                }
                b = mc;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        }),
        X = function(a, b) {
            this.u = [];
            this.Ba = b || A;
            var c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.u = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.B = W() || (c != null ? c : Math.random() < a)
        };
    X.prototype.disable = function() {
        this.B = !1;
        this.u !== this.Ba.google_js_reporting_queue && (W() && Ja(this.u, rc), this.u.length = 0)
    };
    X.prototype.Na = function(a) {
        !this.B || this.u.length > 2048 || this.u.push(a)
    };
    var rc = function(a) {
        a && V && W() && (V.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), V.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    X.prototype.start = function(a, b) {
        if (!this.B) return null;
        var c = oc() || nc();
        a = new pc(a, b, c);
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        V && W() && V.mark(b);
        return a
    };
    X.prototype.end = function(a) {
        if (this.B && typeof a.value === "number") {
            var b = oc() || nc();
            a.duration = b - a.value;
            b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            V && W() && V.mark(b);
            this.Na(a)
        }
    };
    var Y = function(a, b) {
            a = a === void 0 ? 4E3 : a;
            b = b === void 0 ? "&" : b;
            this.Ea = a;
            this.N = b;
            this.K = {};
            this.Ga = 0;
            this.F = []
        },
        tc = function(a, b, c, d, e) {
            var f = [];
            fc(a, function(g, m) {
                (g = sc(g, b, c, d, e)) && f.push(m + "=" + g)
            });
            return f.join(b)
        },
        sc = function(a, b, c, d, e) {
            if (a == null) return "";
            b = b || "&";
            c = c || ",$";
            typeof c === "string" && (c = c.split(""));
            if (a instanceof Array) {
                if (d || (d = 0), d < c.length) {
                    for (var f = [], g = 0; g < a.length; g++) f.push(sc(a[g], b, c, d + 1, e));
                    return f.join(c[d])
                }
            } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(tc(a,
                b, c, d, e + 1)) : "...";
            return encodeURIComponent(String(a))
        };
    Y.prototype.ma = function(a, b) {
        this.F.push(a);
        this.K[a] = b
    };
    Y.prototype.la = function(a, b) {
        var c = this.Ga++,
            d = {};
        d[a] = b;
        a = [d];
        this.ma(c, a)
    };
    Y.prototype.za = function(a, b, c) {
        a = a + "//" + b + c;
        var d = this.xa() - c.length;
        if (d < 0) return "";
        this.F.sort(function(l, k) {
            return l - k
        });
        c = null;
        b = "";
        for (var e = 0; e < this.F.length; e++)
            for (var f = this.F[e], g = this.K[f], m = 0; m < g.length; m++) {
                if (!d) {
                    c = c == null ? f : c;
                    break
                }
                var h = tc(g[m], this.N, ",$");
                if (h) {
                    h = b + h;
                    if (d >= h.length) {
                        d -= h.length;
                        a += h;
                        b = this.N;
                        break
                    }
                    c = c == null ? f : c
                }
            }
        d = "";
        c != null && (d = "" + b + "trn=" + c);
        return a + d
    };
    Y.prototype.xa = function() {
        var a = 1,
            b;
        for (b in this.K) b.length > a && (a = b.length);
        return this.Ea - 3 - a - this.N.length - 1
    };
    var uc = function() {};
    var vc = function(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        this.ta = a;
        this.Ja = b;
        this.sa = c;
        this.na = d;
        this.La = "https:";
        this.Z = Math.random()
    };
    vc.prototype.Ua = function(a) {
        a >= 0 && a <= 1 && (this.Z = a)
    };
    vc.prototype.Fa = function(a, b, c, d, e) {
        c = c === void 0 ? !1 : c;
        if (this.Va(c, d)) try {
            if (b instanceof Y) var f = b;
            else f = new Y, fc(b, function(m, h) {
                f.la(h, m)
            });
            var g = f.za(this.La, this.ta, this.Ja + a + "&");
            g && (typeof e !== "undefined" ? ic(A, g, e) : this.na ? jc(A, g) : ic(A, g))
        } catch (m) {}
    };
    vc.prototype.Va = function(a, b) {
        b = b || this.sa;
        a = a ? this.Z : Math.random();
        return a < b
    };
    var wc, xc = new X(1, window),
        yc = function(a) {
            var b = window;
            a != null && (b.google_measure_js_timing = a);
            b.google_measure_js_timing || xc.disable()
        },
        zc = function(a) {
            var b;
            wc = (b = a) != null ? b : new vc("pagead2.googlesyndication.com", "/pagead/gen_204?id=", .01);
            typeof window.google_srt !== "number" && (window.google_srt = Math.random());
            wc.Ua(window.google_srt);
            window.document.readyState == "complete" ? yc() : xc.B && xb(window, "load", function() {
                yc()
            })
        };
    zc();

    function Z(a, b) {
        a = a === null ? "null" : a === void 0 ? "undefined" : a;
        var c;
        if (c = b) {
            var d, e;
            c = Math.random() < ((e = (d = b.bb) != null ? d : ac[b.X[0]]) != null ? e : 0)
        }
        if (c && window.SAFEVALUES_REPORTING !== !1 && "DocumentFragment" in window) {
            var f, g;
            Math.random() < ((g = (f = b.ab) != null ? f : bc[b.X[0]]) != null ? g : 0) && T(b, "HEARTBEAT");
            d = cc(a, b);
            d || (d = a, d instanceof Hb ? e = d : (e = String(d).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"), e = Ib(e)), e.toString() !== d && T(b, "H_ESCAPE"))
        }
        return Ib(a)
    };
    var Ac = function(a, b) {
        b = b === void 0 ? null : b;
        this.o = null;
        this.V = !1;
        this.A = null;
        this.ca = b || "gam";
        this.ea = a + "_" + this.ca
    };
    p = Ac.prototype;
    p.ya = function() {
        var a = (new Date).valueOf();
        this.A == null && (U.gdbg_offset ? this.A = U.gdbg_offset : (this.A = a, U.gdbg_offset = this.A));
        return a - this.A
    };
    p.va = function(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")
    };
    p.ra = function() {
        if (this.o == null && !this.V)
            if (this.o = U.open("", "GoogleDebug_" + this.ea, "width=1100, height=600, status=no,resizable=yes, scrollbars=yes")) {
                var a = "Google Ad Manager Debug Output";
                this.ca != "gam" && (a = "Google Debug Output");
                var b = this.o.document,
                    c = "";
                c += "<html>";
                c += "<head><title>" + a + "</title><style>";
                c += "h2 {font-size: 1em;margin: 0 0 0.5em 0;color: #353C43}";
                c += "th {background: #e5e5e5;font-weight: normal;color: #444444;";
                c += "text-align: left;}";
                c += "td {border-bottom: 1px solid #dddddd}";
                c += "tbody tr:hover {background: #ffffcc}";
                c += ".dn {display: none;} .lightText {color: #a0a0a0;}";
                c += "</style>";
                c += "</head>";
                c += "<body><h2>" + a + "</h2><br/>";
                c += 'Page URL: <span id="pageUrl"></span><br/><br/>';
                c += '<form action="" method="post">';
                c += '<table id="google_slot_table" width="100%" class="dn" ';
                c += 'cellspacing="0">';
                c += "<thead><tr><th>&nbsp;";
                c += '<span id="numSlots">0</span> slots on page</th>';
                c += "<th>&nbsp;</th>";
                c += "<th>&nbsp;</th>";
                c += "</tr><tr>";
                c += "<th>&nbsp;&nbsp;Ad Slot Name</th>";
                c += "<th>Ad Request URL</th>";
                c += "<th>Delivery Analysis ";
                c += '<span class="lightText">(login required)</span></th>';
                c += "</tr></thead>";
                c += "<tbody>";
                c += '<tr class="dn"><td></td>';
                c += "<td></td></tr>";
                c += "</tbody></table><br/>";
                c += '<table id="google_msg_table" width="100%" cellspacing="0">';
                c += "<thead><tr><th>Offset (msec)</th><th>Type</th>";
                c += "<th>Message</th></tr></thead>";
                c += '<tbody id="google_msg_body">';
                c += '<tr class="dn"><td></td><td></td><td></td></tr>';
                c += "</tbody></table></form></body></html>";
                a = b;
                c = Z(c);
                a.write(Jb(c));
                b.getElementById("pageUrl").textContent = kc.URL;
                b.close();
                b.getElementById("google_slot_table")
            } else this.V = !0
    };
    p.M = function(a, b) {
        return '<font color="' + Bc[a] + '">' + b + "</font>"
    };
    p.Xa = function(a, b, c) {
        var d = this.o;
        if (d)
            if (d = this.o.document.getElementById("google_msg_table"), d != null) {
                d = d.insertRow(-1);
                var e = d.insertCell(0);
                Kb(e, Z(this.M(a, "" + this.ya())));
                e = d.insertCell(1);
                Kb(e, Z(this.M(a, a + "&nbsp;&nbsp;")));
                d = d.insertCell(2);
                c || (b = this.va(b));
                Kb(d, Z(this.M(a, b)))
            } else alert("fails to add to console: " + a + ", " + b)
    };
    p.ka = function() {
        if (this.o == null) {
            var a = "gdbg_console_" + this.ea;
            U[a] ? this.o = U[a] : (this.ra(), U[a] = this.o)
        }
    };
    p.Wa = function(a) {
        this.Xa("Error", a, !1)
    };
    var Bc = {
        Information: "black",
        Warning: "orange",
        Error: "red",
        Internal: "green"
    };
    var Cc = null;

    function Dc(a) {
        if (!Cc) {
            var b = "showcompanionads",
                c = void 0;
            c = c === void 0 ? null : c;
            b = b || "default";
            var d = c || "gam";
            c = "gdbg_logger_" + b + "_" + d;
            if (!U[c]) {
                U[c] = new Ac(b, d);
                b = kc.URL;
                if (d = !!b) {
                    a: {
                        if (b) {
                            d = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
                            try {
                                var e = d.exec(decodeURIComponent(b));
                                if (e) {
                                    var f = e[1] && e[1].length > 1 ? e[1].substring(1) : "true";
                                    break a
                                }
                            } catch (g) {}
                        }
                        f = ""
                    }
                    d = f.length > 0
                }(f = d) && U[c].ka()
            }
            Cc = U[c]
        }
        Cc.Wa(a)
    }
    var Ec = function() {
            var a = [],
                b = document.getElementsByTagName("base");
            if (b)
                for (var c = b.length, d = 0; d < c; ++d) {
                    var e = b[d],
                        f = e.getAttribute("target");
                    f && (a.push({
                        qa: e,
                        Ia: f
                    }), e.removeAttribute("target"))
                }
            return a
        },
        Fc = function(a) {
            if (a)
                for (var b = a.length, c = 0; c < b; ++c) {
                    var d = a[c];
                    d.qa.setAttribute("target", d.Ia)
                }
        };

    function Gc() {
        return !0
    }

    function Hc() {
        var a = [],
            b = Ic();
        if (b && (b = b.getSlots())) {
            b = w(b);
            for (var c = b.next(); !c.done; c = b.next()) {
                var d = c.value;
                c = {};
                if (d) {
                    c.slotId = d.getSlotId().getId();
                    c.adType = d.get("ad_type");
                    d = d.getSizes();
                    var e = [];
                    if (d && Array.isArray(d))
                        for (var f = 0, g = d.length; f < g; f++) {
                            var m = {};
                            typeof d[f] !== "string" && (m.adWidth = d[f].getWidth(), m.adHeight = d[f].getHeight(), e.push(m))
                        }
                    d = e;
                    c.adSizes = d
                }
                a.push(c)
            }
        }
        return a
    }

    function Jc(a, b, c) {
        b = {
            method: "gscac",
            caller: c
        };
        var d = uc;
        c = d;
        var e = "U";
        c.U && c.hasOwnProperty(e) || (d = new d, c.U = d);
        c = [];
        !b.eid && c.length && (b.eid = c.toString());
        wc.Fa("gpt_sca", b, !0, .001, void 0);
        if ((b = Ic()) && a && Array.isArray(a) && (c = b.getSlotIdMap()))
            for (d = 0, e = a.length; d < e; d++) {
                var f = a[d],
                    g = f.slotId;
                if (g in c) {
                    g = c[g];
                    var m = (m = Ic()) && m.isSlotAPersistentRoadblock != null ? m.isSlotAPersistentRoadblock(g) : !1;
                    if (!m && f.adContent) {
                        m = g.getSlotId().getDomId();
                        if (m = lc(document, m)) m.style.display = "";
                        if (f.friendlyIframeRendering) {
                            var h =
                                g;
                            m = f.adContent;
                            var l = f.adWidth,
                                k = f.adHeight,
                                n = h.getSlotId().getDomId(),
                                r = lc(document, n);
                            if (r) {
                                if (n = lc(document, n)) n.textContent = "";
                                n = "google_companion_" + h.getSlotId().getId();
                                l = l ? l : h.getSizes()[0].getWidth();
                                h = k ? k : h.getSizes()[0].getHeight();
                                k = document;
                                k = k.createElement("iframe");
                                k.id = n;
                                k.name = n;
                                l != null && h != null && (k.width = String(l), k.height = String(h));
                                k.vspace = "0";
                                k.hspace = "0";
                                k.allowTransparency = "true";
                                k.scrolling = "no";
                                k.marginWidth = "0";
                                k.marginHeight = "0";
                                k.frameBorder = "0";
                                k.style.border = "0";
                                k.style.verticalAlign =
                                    "bottom";
                                k.src = "about:blank";
                                r.appendChild(k);
                                h = k;
                                if (Ka) {
                                    try {
                                        var I = !!h.contentWindow.document
                                    } catch (z) {
                                        I = !1
                                    }
                                    if (I) {
                                        k = Ec();
                                        try {
                                            window.frames[h.name].contents = m, h.src = 'javascript:window["contents"]'
                                        } catch (z) {
                                            Dc("Could not write third party content into IE iframe: " + z.message)
                                        } finally {
                                            Fc(k)
                                        }
                                    } else {
                                        k = Ec();
                                        r = "google-ad-content-" + (Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36));
                                        try {
                                            window[r] = m;
                                            var x = 'document.domain = "' + document.domain +
                                                '";var adContent = window.parent["' + (r + '"];window.parent["') + (r + '"] = null;document.write(adContent);document.close();');
                                            h.src = 'javascript:\'<script type="text/javascript">' + x + "\x3c/script>'"
                                        } catch (z) {
                                            window[r] = null, Dc("Could not write third party content into IE iframe with modified document.domain: " + z.message)
                                        } finally {
                                            Fc(k)
                                        }
                                    }
                                } else try {
                                    var t = h.contentWindow ? h.contentWindow.document : h.contentDocument;
                                    Oa && t.open("text/html", "replace");
                                    h = t;
                                    var J = Z(m);
                                    h.write(Jb(J));
                                    t.close()
                                } catch (z) {
                                    Dc("Could not write content into iframe using the DOM standards method. " +
                                        z.message)
                                }
                            }
                            b.slotRenderEnded(g, f.adWidth, f.adHeight)
                        }
                        if (f.onAdContentSet != null) f.onAdContentSet(lc(document, g.getSlotId().getDomId()))
                    }
                }
            }
    }

    function Ic() {
        if (typeof googletag != "undefined" && googletag && typeof googletag.companionAds == "function") {
            var a = googletag.companionAds();
            return a
        }
        return null
    }

    function Kc(a) {
        a && (a += "&label=elementview&value=0", ic(U, a))
    }
    ta("googleCompanionsServicePresent", Gc, !0, void 0);
    ta("googleGetCompanionAdSlots", Hc, !0, void 0);
    ta("googleSetCompanionAdContents", Jc, !0, void 0);
    ta("google_companion_error", Kc, !0, void 0);
    var Lc = Ic();
    if (Lc && Lc.onImplementationLoaded) Lc.onImplementationLoaded();
}).call(this);