(function(sttc) {
    'use strict';
    var aa = Object.defineProperty,
        ba = globalThis,
        ca = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        da = {},
        ea = {};

    function fa(a, b, c) {
        if (!c || a != null) {
            c = ea[b];
            if (c == null) return a[b];
            c = a[c];
            return c !== void 0 ? c : a[b]
        }
    }

    function ha(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = d.length === 1;
            var e = d[0],
                f;!a && e in da ? f = da : f = ba;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ca && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? aa(da, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (ea[d] === void 0 && (a = Math.random() * 1E9 >>> 0, ea[d] = ca ? ba.Symbol(d) : "$jscp$" + a + "$" + d), aa(f, ea[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    ha("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    }, "es_next");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var p = this || self;

    function ia(a) {
        a = a.split(".");
        for (var b = p, c = 0; c < a.length; c++)
            if (b = b[a[c]], b == null) return null;
        return b
    }

    function ja(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function ka(a) {
        return Object.prototype.hasOwnProperty.call(a, la) && a[la] || (a[la] = ++ma)
    }
    var la = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        ma = 0;

    function na(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function oa(a, b, c) {
        if (!a) throw Error();
        if (arguments.length > 2) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function pa(a, b, c) {
        pa = Function.prototype.bind && Function.prototype.bind.toString().indexOf("native code") != -1 ? na : oa;
        return pa.apply(null, arguments)
    }

    function qa(a, b, c) {
        a = a.split(".");
        c = c || p;
        for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function ra(a) {
        return a
    };

    function sa(a) {
        p.setTimeout(() => {
            throw a;
        }, 0)
    };

    function ta(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function ua(a, b) {
        let c = 0;
        a = ta(String(a)).split(".");
        b = ta(String(b)).split(".");
        const d = Math.max(a.length, b.length);
        for (let g = 0; c == 0 && g < d; g++) {
            var e = a[g] || "",
                f = b[g] || "";
            do {
                e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                if (e[0].length == 0 && f[0].length == 0) break;
                c = va(e[1].length == 0 ? 0 : parseInt(e[1], 10), f[1].length == 0 ? 0 : parseInt(f[1], 10)) || va(e[2].length == 0, f[2].length == 0) || va(e[2], f[2]);
                e = e[3];
                f = f[3]
            } while (c == 0)
        }
        return c
    }

    function va(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var xa, ya = ia("CLOSURE_FLAGS"),
        za = ya && ya[610401301];
    xa = za != null ? za : !1;

    function Aa() {
        var a = p.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var Ba;
    const Ca = p.navigator;
    Ba = Ca ? Ca.userAgentData || null : null;

    function Da(a) {
        return xa ? Ba ? Ba.brands.some(({
            brand: b
        }) => b && b.indexOf(a) != -1) : !1 : !1
    }

    function q(a) {
        return Aa().indexOf(a) != -1
    };

    function Ea() {
        return xa ? !!Ba && Ba.brands.length > 0 : !1
    }

    function Fa() {
        return Ea() ? !1 : q("Trident") || q("MSIE")
    }

    function Ga() {
        return Ea() ? Da("Microsoft Edge") : q("Edg/")
    }

    function Ha() {
        !q("Safari") || Ia() || (Ea() ? 0 : q("Coast")) || (Ea() ? 0 : q("Opera")) || (Ea() ? 0 : q("Edge")) || Ga() || Ea() && Da("Opera")
    }

    function Ia() {
        return Ea() ? Da("Chromium") : (q("Chrome") || q("CriOS")) && !(Ea() ? 0 : q("Edge")) || q("Silk")
    }

    function Ja(a) {
        const b = {};
        a.forEach(c => {
            b[c[0]] = c[1]
        });
        return c => b[c.find(d => d in b)] || ""
    }

    function Ka() {
        var a = Aa();
        if (Fa()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), c[1] == "7.0")
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        let d;
        for (; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
        a = Ja(b);
        return (Ea() ? 0 : q("Opera")) ? a(["Version",
            "Opera"
        ]) : (Ea() ? 0 : q("Edge")) ? a(["Edge"]) : Ga() ? a(["Edg"]) : q("Silk") ? a(["Silk"]) : Ia() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    };

    function La(a, b) {
        if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Ma(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = typeof a === "string" ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Na(a, b) {
        const c = a.length,
            d = Array(c),
            e = typeof a === "string" ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Oa(a, b) {
        const c = a.length,
            d = typeof a === "string" ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function Pa(a, b) {
        a: {
            var c = a.length;
            const d = typeof a === "string" ? a.split("") : a;
            for (--c; c >= 0; c--)
                if (c in d && b.call(void 0, d[c], c, a)) {
                    b = c;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    }

    function Qa(a, b) {
        return La(a, b) >= 0
    }

    function u(a) {
        const b = a.length;
        if (b > 0) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Ra(a) {
        Ra[" "](a);
        return a
    }
    Ra[" "] = function() {};
    var Sa = Fa();
    !q("Android") || Ia();
    Ia();
    Ha();
    var Ta = null;

    function Ua(a) {
        const b = [];
        Va(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Va(a, b) {
        function c(e) {
            for (; d < a.length;) {
                const f = a.charAt(d++),
                    g = Ta[f];
                if (g != null) return g;
                if (!/^[\s\xa0]*$/.test(f)) throw Error("Unknown base64 encoding at char: " + f);
            }
            return e
        }
        Wa();
        let d = 0;
        for (;;) {
            const e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (h === 64 && e === -1) break;
            b(e << 2 | f >> 4);
            g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
        }
    }

    function Wa() {
        if (!Ta) {
            Ta = {};
            var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                b = ["+/=", "+/", "-_=", "-_.", "-_"];
            for (let c = 0; c < 5; c++) {
                const d = a.concat(b[c].split(""));
                for (let e = 0; e < d.length; e++) {
                    const f = d[e];
                    Ta[f] === void 0 && (Ta[f] = e)
                }
            }
        }
    };

    function Xa(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    let Ya = void 0,
        Za;

    function $a(a) {
        if (Za) throw Error("");
        Za = b => {
            p.setTimeout(() => {
                a(b)
            }, 0)
        }
    }

    function bb(a) {
        if (Za) try {
            Za(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function cb(a) {
        a = Error(a);
        Xa(a, "warning");
        bb(a);
        return a
    };
    var db = new Set;

    function eb(a, b = !1, c = !1) {
        a = c && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol();
        b && db.add(a);
        return a
    }
    var fb = eb(),
        gb = eb(void 0, !0),
        hb = eb(void 0, !0),
        ib = eb();
    const w = eb("jas", !0, !0);

    function jb(a, b) {
        a[w] |= b
    }

    function kb(a) {
        if (4 & a) return 4096 & a ? 4096 : 8192 & a ? 8192 : 0
    }

    function lb(a) {
        jb(a, 32);
        return a
    }

    function mb(a, b) {
        b[w] = (a | 0) & -30975
    }

    function nb(a, b) {
        b[w] = (a | 34) & -30941
    };

    function ob(a) {
        return Array.prototype.slice.call(a)
    };
    var pb = {};

    function qb(a) {
        return a !== null && typeof a === "object" && !Array.isArray(a) && a.constructor === Object
    }
    var rb;
    const sb = [];
    sb[w] = 55;
    rb = Object.freeze(sb);

    function tb(a) {
        if (a & 2) throw Error();
    }

    function ub(a, b) {
        const c = ra(hb);
        (b = c ? b[c] : void 0) && (a[hb] = ob(b))
    }
    var vb = Object.freeze({});

    function wb(a, b) {
        const c = xb;
        if (!b(a)) throw b = (typeof c === "function" ? c() : c) ? .concat("\n") ? ? "", Error(b + String(a));
    }

    function yb(a) {
        a.wc = !0;
        return a
    }
    let xb = void 0;
    const zb = yb(a => a !== null && a !== void 0);
    var Ab = yb(a => typeof a === "number"),
        Bb = yb(a => typeof a === "string"),
        Cb = yb(a => a === void 0),
        Db = yb(a => Array.isArray(a));

    function Eb() {
        return yb(a => Db(a) ? a.every(b => Ab(b)) : !1)
    };

    function Fb(a) {
        if (Bb(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (Ab(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var Ib = yb(a => a >= Gb && a <= Hb);
    const Gb = BigInt(Number.MIN_SAFE_INTEGER),
        Hb = BigInt(Number.MAX_SAFE_INTEGER);
    let Jb = 0,
        Kb = 0;

    function Lb(a) {
        const b = a >>> 0;
        Jb = b;
        Kb = (a - b) / 4294967296 >>> 0
    }

    function Mb(a) {
        if (a < 0) {
            Lb(-a);
            a = Jb;
            var b = Kb;
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            const [c, d] = [a, b];
            Jb = c >>> 0;
            Kb = d >>> 0
        } else Lb(a)
    }

    function Nb(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function Ob() {
        var a = Jb,
            b = Kb,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = Nb(a, b);
        return c
    };

    function Pb(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const Qb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Rb = Number.isSafeInteger,
        Sb = Number.isFinite,
        Tb = Math.trunc;

    function Ub(a) {
        if (a != null && typeof a !== "boolean") {
            var b = typeof a;
            throw Error(`Expected boolean but got ${b!="object"?b:a?Array.isArray(a)?"array":b:"null"}: ${a}`);
        }
        return a
    }

    function Vb(a) {
        if (a == null || typeof a === "boolean") return a;
        if (typeof a === "number") return !!a
    }
    const Wb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Xb(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Sb(a);
            case "string":
                return Wb.test(a);
            default:
                return !1
        }
    }

    function Yb(a) {
        if (!Sb(a)) throw cb("enum");
        return a | 0
    }

    function y(a) {
        return a == null ? a : Yb(a)
    }

    function Zb(a) {
        return a == null ? a : Sb(a) ? a | 0 : void 0
    }

    function $b(a) {
        if (typeof a !== "number") throw cb("int32");
        if (!Sb(a)) throw cb("int32");
        return a | 0
    }

    function ac(a) {
        return a == null ? a : $b(a)
    }

    function bc(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Sb(a) ? a | 0 : void 0
    }

    function cc(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Sb(a) ? a >>> 0 : void 0
    }

    function dc(a) {
        if (!Xb(a)) throw cb("int64");
        switch (typeof a) {
            case "string":
                return ec(a);
            case "bigint":
                return Fb(Qb(64, a));
            default:
                return fc(a)
        }
    }

    function gc(a) {
        const b = a.length;
        return a[0] === "-" ? b < 20 ? !0 : b === 20 && Number(a.substring(0, 7)) > -922337 : b < 19 ? !0 : b === 19 && Number(a.substring(0, 6)) < 922337
    }

    function fc(a) {
        a = Tb(a);
        if (!Rb(a)) {
            Mb(a);
            var b = Jb,
                c = Kb;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            const d = c * 4294967296 + (b >>> 0);
            b = Number.isSafeInteger(d) ? d : Nb(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function hc(a) {
        a = Tb(a);
        if (Rb(a)) a = String(a);
        else {
            {
                const b = String(a);
                gc(b) ? a = b : (Mb(a), a = Ob())
            }
        }
        return a
    }

    function ec(a) {
        var b = Tb(Number(a));
        if (Rb(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        gc(a) || (a.length < 16 ? Mb(Number(a)) : (a = BigInt(a), Jb = Number(a & BigInt(4294967295)) >>> 0, Kb = Number(a >> BigInt(32) & BigInt(4294967295))), a = Ob());
        return a
    }

    function jc(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Fb(Qb(64, a));
        if (Xb(a)) return b === "string" ? (b = Tb(Number(a)), Rb(b) ? a = Fb(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = Fb(Qb(64, BigInt(a))))) : a = Rb(a) ? Fb(fc(a)) : Fb(hc(a)), a
    }

    function kc(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function lc(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function mc(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function nc(a, b, c, d) {
        if (a != null && typeof a === "object" && a.Aa === pb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? ((a = b[fb]) || (a = new b, jb(a.C, 34), a = b[fb] = a), b = a) : b = new b : b = void 0, b;
        let e = c = a[w] | 0;
        e === 0 && (e |= d & 32);
        e |= d & 2;
        e !== c && (a[w] = e);
        return new b(a)
    };

    function oc(a) {
        return a
    };

    function pc(a, b, c) {
        const d = ob(a);
        var e = d.length;
        const f = b & 256 ? d[e - 1] : void 0;
        e += f ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < e; b++) d[b] = c(d[b]);
        if (f) {
            b = d[b] = {};
            for (const g in f) Object.prototype.hasOwnProperty.call(f, g) && (b[g] = c(f[g]))
        }
        ub(d, a);
        return d
    }

    function qc(a, b, c, d, e) {
        if (a != null) {
            if (Array.isArray(a)) {
                const f = a[w] | 0;
                return a.length === 0 && f & 1 ? void 0 : e && f & 2 ? a : rc(a, b, c, d !== void 0, e)
            }
            return b(a, d)
        }
    }

    function rc(a, b, c, d, e) {
        const f = d || c ? a[w] | 0 : 0;
        d = d ? !!(f & 32) : void 0;
        const g = ob(a);
        let h = 0;
        const k = g.length;
        for (let t = 0; t < k; t++) {
            var l = g[t];
            if (t === k - 1 && qb(l)) {
                var n = b,
                    m = c,
                    r = d,
                    x = e;
                let v = void 0;
                for (let I in l) {
                    if (!Object.prototype.hasOwnProperty.call(l, I)) continue;
                    const P = qc(l[I], n, m, r, x);
                    P != null && ((v ? ? (v = {}))[I] = P)
                }
                l = v
            } else l = qc(g[t], b, c, d, e);
            g[t] = l;
            l != null && (h = t + 1)
        }
        h < k && (g.length = h);
        c && (ub(g, a), c(f, g));
        return g
    }

    function sc(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return Ib(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a != null && a instanceof Uint8Array) {
                    let b = "",
                        c = 0;
                    const d = a.length - 10240;
                    for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                    b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                    return btoa(b)
                }
                if (a.Aa === pb) return tc(a);
                return
        }
        return a
    }
    var uc = typeof structuredClone != "undefined" ? structuredClone : a => rc(a, sc, void 0, void 0, !1);
    let vc;

    function wc(a) {
        try {
            return tc(a)
        } finally {
            vc = void 0
        }
    }

    function tc(a) {
        var b = a.C;
        a = rc(b, sc, void 0, void 0, !1);
        var c = b[w] | 0;
        if ((b = a.length) && !(c & 512)) {
            var d = a[b - 1],
                e = !1;
            qb(d) ? (b--, e = !0) : d = void 0;
            c = c & 512 ? 0 : -1;
            var f = b - c,
                g = (vc ? ? oc)(f, c, a, d);
            d && (a[b] = void 0);
            if (f < g && d) {
                f = !0;
                for (var h in d) {
                    if (!Object.prototype.hasOwnProperty.call(d, h)) continue;
                    const k = +h;
                    if (k <= g) e = k + c, a[e] = d[h], b = Math.max(e + 1, b), e = !1, delete d[h];
                    else {
                        f = !1;
                        break
                    }
                }
                f && (d = void 0)
            }
            for (f = b - 1; b > 0; f = b - 1)
                if (h = a[f], h == null) b--, e = !0;
                else if (f -= c, f >= g)(d ? ? (d = {}))[f] = h, b--, e = !0;
            else break;
            e && (a.length = b);
            d && a.push(d)
        }
        return a
    };

    function xc() {
        if (ib != null) {
            var a = Ya ? ? (Ya = {});
            var b = a[ib] || 0;
            b >= 5 || (a[ib] = b + 1, a = Error(), Xa(a, "incident"), Za ? bb(a) : sa(a))
        }
    };

    function yc(a, b, c = nb) {
        if (a != null) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[w] | 0;
                if (d & 2) return a;
                b && (b = d === 0 || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[w] = d | 34, d & 4 && Object.freeze(a), a) : rc(a, yc, d & 4 ? nb : c, !0, !0)
            }
            a.Aa === pb && (c = a.C, d = c[w] | 0, a = d & 2 ? a : new a.constructor(zc(c, d, !0)));
            return a
        }
    }

    function zc(a, b, c) {
        const d = c || b & 2 ? nb : mb,
            e = !!(b & 32);
        a = pc(a, b, f => yc(f, e, d));
        jb(a, 32 | (c ? 2 : 0));
        return a
    }

    function Ac(a) {
        const b = a.C,
            c = b[w] | 0;
        return c & 2 ? new a.constructor(zc(b, c, !1)) : a
    }

    function Bc(a) {
        const b = a.C,
            c = b[w] | 0;
        return c & 2 ? a : new a.constructor(zc(b, c, !0))
    };
    const Cc = Fb(0);

    function z(a, b) {
        a = a.C;
        return Dc(a, a[w] | 0, b)
    }

    function Dc(a, b, c) {
        if (c === -1) return null;
        const d = c + (b & 512 ? 0 : -1),
            e = a.length - 1;
        if (d >= e && b & 256) return a[e][c];
        if (d <= e) return a[d]
    }

    function A(a, b, c) {
        const d = a.C;
        let e = d[w] | 0;
        tb(e);
        B(d, e, b, c);
        return a
    }

    function B(a, b, c, d) {
        const e = b & 512 ? 0 : -1,
            f = c + e;
        var g = a.length - 1;
        if (f >= g && b & 256) return a[g][c] = d, b;
        if (f <= g) return a[f] = d, b;
        d !== void 0 && (g = b >> 15 & 1023 || 536870912, c >= g ? d != null && (a[g + e] = {
            [c]: d
        }, b |= 256, a[w] = b) : a[f] = d);
        return b
    }

    function Ec(a, b, c) {
        return Fc(a, b, c) !== void 0
    }

    function C(a) {
        return a === vb ? 2 : 4
    }

    function Gc(a, b, c, d, e) {
        const f = a.C;
        a = f[w] | 0;
        const g = 2 & a ? 1 : d;
        e = !!e;
        d = Hc(f, a, b);
        let h = d[w] | 0;
        if (!(4 & h)) {
            4 & h && (d = ob(d), h = Ic(h, a), a = B(f, a, b, d));
            let k = 0,
                l = 0;
            for (; k < d.length; k++) {
                const n = c(d[k]);
                n != null && (d[l++] = n)
            }
            l < k && (d.length = l);
            h = Jc(h, a);
            c = (h | 20) & -4097;
            h = c &= -8193;
            d[w] = h;
            2 & h && Object.freeze(d)
        }
        g === 1 || g === 4 && 32 & h ? Kc(h) || (e = h, h |= 2, h !== e && (d[w] = h), Object.freeze(d)) : (g === 2 && Kc(h) && (d = ob(d), h = Ic(h, a), h = Lc(h, a, e), d[w] = h, a = B(f, a, b, d)), Kc(h) || (b = h, h = Lc(h, a, e), h !== b && (d[w] = h)));
        return d
    }

    function Hc(a, b, c) {
        a = Dc(a, b, c);
        return Array.isArray(a) ? a : rb
    }

    function Jc(a, b) {
        a === 0 && (a = Ic(a, b));
        return a | 1
    }

    function Kc(a) {
        return !!(2 & a) && !!(4 & a) || !!(2048 & a)
    }

    function Mc(a, b, c, d) {
        const e = a.C;
        let f = e[w] | 0;
        tb(f);
        if (c == null) return B(e, f, b), a;
        let g = c[w] | 0,
            h = g;
        var k = Kc(g);
        let l = k || Object.isFrozen(c);
        k || (g = 0);
        l || (c = ob(c), h = 0, g = Ic(g, f), g = Lc(g, f, !0), l = !1);
        g |= 21;
        k = kb(g) ? ? 0;
        for (let n = 0; n < c.length; n++) {
            const m = c[n],
                r = d(m, k);
            Object.is(m, r) || (l && (c = ob(c), h = 0, g = Ic(g, f), g = Lc(g, f, !0), l = !1), c[n] = r)
        }
        g !== h && (l && (c = ob(c), g = Ic(g, f), g = Lc(g, f, !0)), c[w] = g);
        B(e, f, b, c);
        return a
    }

    function D(a, b, c, d) {
        const e = a.C;
        let f = e[w] | 0;
        tb(f);
        B(e, f, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function Nc(a, b, c, d) {
        const e = a.C;
        var f = e[w] | 0;
        tb(f);
        if (d == null) {
            var g = Oc(e);
            if (Pc(g, e, f, c) === b) g.set(c, 0);
            else return a
        } else {
            g = Oc(e);
            const h = Pc(g, e, f, c);
            h !== b && (h && (f = B(e, f, h)), g.set(c, b))
        }
        B(e, f, b, d);
        return a
    }

    function Qc(a, b, c) {
        return Rc(a, b) === c ? c : -1
    }

    function Rc(a, b) {
        a = a.C;
        return Pc(Oc(a), a, a[w] | 0, b)
    }

    function Oc(a) {
        return a[gb] ? ? (a[gb] = new Map)
    }

    function Pc(a, b, c, d) {
        let e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            const g = d[f];
            Dc(b, c, g) != null && (e !== 0 && (c = B(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function Sc(a, b, c) {
        a = a.C;
        let d = a[w] | 0;
        tb(d);
        const e = Dc(a, d, c);
        b = Ac(nc(e, b, !0, d));
        e !== b && B(a, d, c, b);
        return b
    }

    function Fc(a, b, c) {
        a = a.C;
        let d = a[w] | 0;
        const e = Dc(a, d, c);
        b = nc(e, b, !1, d);
        b !== e && b != null && B(a, d, c, b);
        return b
    }

    function Tc(a, b, c) {
        (a = Fc(a, b, c)) || (a = b[fb]) || (a = new b, jb(a.C, 34), a = b[fb] = a);
        return a
    }

    function E(a, b, c) {
        b = Fc(a, b, c);
        if (b == null) return b;
        a = a.C;
        let d = a[w] | 0;
        if (!(d & 2)) {
            const e = Ac(b);
            e !== b && (b = e, B(a, d, c, b))
        }
        return b
    }

    function F(a, b, c, d) {
        var e = a.C[w] | 0,
            f = e,
            g = !(2 & e);
        a = a.C;
        var h = !!(2 & f);
        e = h ? 1 : d;
        g && (g = !h);
        d = Hc(a, f, c);
        var k = d[w] | 0;
        h = !!(4 & k);
        if (!h) {
            k = Jc(k, f);
            var l = d,
                n = f;
            const m = !!(2 & k);
            m && (n |= 2);
            let r = !m,
                x = !0,
                t = 0,
                v = 0;
            for (; t < l.length; t++) {
                const I = nc(l[t], b, !1, n);
                if (I instanceof b) {
                    if (!m) {
                        const P = !!((I.C[w] | 0) & 2);
                        r && (r = !P);
                        x && (x = P)
                    }
                    l[v++] = I
                }
            }
            v < t && (l.length = v);
            k |= 4;
            k = x ? k | 16 : k & -17;
            k = r ? k | 8 : k & -9;
            l[w] = k;
            m && Object.freeze(l)
        }
        if (g && !(8 & k || !d.length && (e === 1 || e === 4 && 32 & k))) {
            Kc(k) && (d = ob(d), k = Ic(k, f), f = B(a, f, c, d));
            b = d;
            g = k;
            for (l =
                0; l < b.length; l++) k = b[l], n = Ac(k), k !== n && (b[l] = n);
            g |= 8;
            g = b.length ? g & -17 : g | 16;
            k = b[w] = g
        }
        e === 1 || e === 4 && 32 & k ? Kc(k) || (f = k, k |= !d.length || 16 & k && (!h || 32 & k) ? 2 : 2048, k !== f && (d[w] = k), Object.freeze(d)) : (e === 2 && Kc(k) && (d = ob(d), k = Ic(k, f), k = Lc(k, f, !1), d[w] = k, f = B(a, f, c, d)), Kc(k) || (c = k, k = Lc(k, f, !1), k !== c && (d[w] = k)));
        return d
    }

    function Uc(a, b, c) {
        c == null && (c = void 0);
        return A(a, b, c)
    }

    function Vc(a, b, c, d) {
        d == null && (d = void 0);
        return Nc(a, b, c, d)
    }

    function Wc(a, b, c) {
        const d = a.C;
        let e = d[w] | 0;
        tb(e);
        if (c == null) return B(d, e, b), a;
        let f = c[w] | 0,
            g = f;
        const h = Kc(f),
            k = h || Object.isFrozen(c);
        let l = !0,
            n = !0;
        for (let r = 0; r < c.length; r++) {
            var m = c[r];
            h || (m = !!((m.C[w] | 0) & 2), l && (l = !m), n && (n = m))
        }
        h || (f = l ? 13 : 5, f = n ? f | 16 : f & -17);
        k && f === g || (c = ob(c), g = 0, f = Ic(f, e), f = Lc(f, e, !0));
        f !== g && (c[w] = f);
        B(d, e, b, c);
        return a
    }

    function Ic(a, b) {
        a = (2 & b ? a | 2 : a & -3) | 32;
        return a &= -2049
    }

    function Lc(a, b, c) {
        32 & b && c || (a &= -33);
        return a
    }

    function Xc(a, b) {
        tb(a.C[w] | 0);
        a = Gc(a, 4, mc, 2, !0);
        const c = kb(a[w] | 0) ? ? 0;
        if (Array.isArray(b)) {
            var d = b.length;
            for (let e = 0; e < d; e++) a.push(kc(b[e], c))
        } else
            for (d of b) a.push(kc(d, c))
    }

    function Yc(a, b) {
        a = z(a, b);
        a != null && (typeof a === "bigint" ? Ib(a) ? a = Number(a) : (a = Qb(64, a), a = Ib(a) ? Number(a) : String(a)) : a = Xb(a) ? typeof a === "number" ? fc(a) : ec(a) : void 0);
        return a
    }

    function ad(a, b) {
        return bc(z(a, b))
    }

    function G(a, b) {
        return mc(z(a, b))
    }

    function H(a, b) {
        return Zb(z(a, b))
    }

    function J(a, b) {
        return Vb(z(a, b)) ? ? !1
    }

    function bd(a, b) {
        return ad(a, b) ? ? 0
    }

    function cd(a, b) {
        a = a.C;
        let c = a[w] | 0;
        const d = Dc(a, c, b);
        var e = d == null || typeof d === "number" ? d : d === "NaN" || d === "Infinity" || d === "-Infinity" ? Number(d) : void 0;
        e != null && e !== d && B(a, c, b, e);
        return e ? ? 0
    }

    function K(a, b) {
        return G(a, b) ? ? ""
    }

    function L(a, b) {
        return H(a, b) ? ? 0
    }

    function dd(a, b) {
        return Gc(a, b, mc, C())
    }

    function ed(a, b) {
        return Gc(a, b, Zb, C())
    }

    function fd(a, b, c) {
        return L(a, Qc(a, c, b))
    }

    function gd(a, b, c, d) {
        return E(a, b, Qc(a, d, c))
    }

    function hd(a, b, c) {
        return D(a, b, c == null ? c : dc(c), "0")
    }

    function id(a, b) {
        var c = performance.now();
        if (c != null && typeof c !== "number") throw Error(`Value of float/double field must be a number, found ${typeof c}: ${c}`);
        D(a, b, c, 0)
    }

    function jd(a, b, c) {
        return A(a, b, lc(c))
    }

    function kd(a, b, c) {
        return D(a, b, lc(c), "")
    };
    var M = class {
        constructor(a) {
            a: {
                if (a == null) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error("narr");
                    b = a[w] | 0;
                    16384 & b || !(64 & b) || 2 & b || xc();
                    if (b & 2048) throw Error("farr");
                    if (b & 64) {
                        var c = a;
                        break a
                    }
                    var d = a;
                    b |= 64;
                    var e = d.length;
                    if (e) {
                        var f = e - 1;
                        e = d[f];
                        if (qb(e)) {
                            b |= 256;
                            const g = b & 512 ? 0 : -1;
                            f -= g;
                            if (f >= 1024) throw Error("pvtlmt");
                            for (c in e) {
                                if (!Object.prototype.hasOwnProperty.call(e, c)) continue;
                                const h = +c;
                                if (h < f) d[h + g] = e[c], delete e[c];
                                else break
                            }
                            b = b & -33521665 | (f & 1023) << 15
                        }
                    }
                }
                a[w] = b;c = a
            }
            this.C = c
        }
        toJSON() {
            return wc(this)
        }
    };
    M.prototype.Aa = pb;

    function ld(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        jb(b, 128);
        return new a(lb(b))
    };

    function md(a) {
        return () => {
            var b;
            (b = a[fb]) || (b = new a, jb(b.C, 34), b = a[fb] = b);
            return b
        }
    }

    function nd(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(lb(b))
            }
            return b
        }
    };
    var od = class extends M {};
    var pd = class extends M {};

    function qd(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function rd(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function sd(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    };

    function td(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    }

    function ud(a, b, c) {
        return a.removeEventListener ? (a.removeEventListener(b, c, !1), !0) : !1
    };

    function vd() {
        return xa && Ba ? Ba.mobile : !wd() && (q("iPod") || q("iPhone") || q("Android") || q("IEMobile"))
    }

    function wd() {
        return xa && Ba ? !Ba.mobile && (q("iPad") || q("Android") || q("Silk")) : q("iPad") || q("Android") && !q("Mobile") || q("Silk")
    };

    function xd(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function yd(a, b) {
        for (const c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function zd(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function Ad(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    let Bd = globalThis.trustedTypes,
        Cd;

    function Dd() {
        let a = null;
        if (!Bd) return a;
        try {
            const b = c => c;
            a = Bd.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    };
    var Ed = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Fd(a) {
        Cd === void 0 && (Cd = Dd());
        var b = Cd;
        return new Ed(b ? b.createScriptURL(a) : a)
    }

    function Gd(a) {
        if (a instanceof Ed) return a.g;
        throw Error("");
    };
    var Hd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Id(a = document) {
        a = a.querySelector ? .("script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };
    const Jd = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Kd(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    var Ld = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Md = /#|$/;

    function Nd(a, b) {
        const c = a.search(Md);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    };

    function Od(a, ...b) {
        if (b.length === 0) return Fd(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Fd(c)
    }

    function Pd(a, b) {
        a = Gd(a).toString();
        const c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return Qd(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function Qd(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(k => e(k, h)) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        let f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(g => e(g[1], g[0])) : d.forEach(e);
        return Fd(a + b + c)
    };

    function Rd(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    Ra(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch {
            return !1
        }
    }

    function Sd(a) {
        return Rd(a.top) ? a.top : null
    }

    function Td(a, b) {
        const c = Ud("SCRIPT", a);
        c.src = Gd(b);
        (b = Id(c.ownerDocument)) && c.setAttribute("nonce", b);
        (a = a.getElementsByTagName("script")[0]) && a.parentNode && a.parentNode.insertBefore(c, a)
    }

    function Vd(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function Wd() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function Xd(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function Yd(a) {
        const b = a.length;
        if (b == 0) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    }
    var Zd = /^([0-9.]+)px$/,
        $d = /^(-?[0-9.]{1,30})$/;

    function ae(a) {
        if (!$d.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function be(a) {
        return (a = Zd.exec(a)) ? +a[1] : null
    }
    var ce = rd(() => vd() ? 2 : wd() ? 1 : 0),
        de = a => {
            Xd({
                display: "none"
            }, (b, c) => {
                a.style.setProperty(c, b, "important")
            })
        };
    let ee = [];
    const fe = () => {
        const a = ee;
        ee = [];
        for (const b of a) try {
            b()
        } catch {}
    };

    function ge() {
        var a = N(he).A(ie.g, ie.defaultValue),
            b = O.document;
        if (a.length && b.head)
            for (const c of a) c && b.head && (a = Ud("META"), b.head.appendChild(a), a.httpEquiv = "origin-trial", a.content = c)
    }
    var je = () => {
            var a = Math.random;
            return Math.floor(a() * 2 ** 52)
        },
        ke = a => {
            if (typeof a.goog_pvsid !== "number") try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: je(),
                    configurable: !1
                })
            } catch (b) {}
            return Number(a.goog_pvsid) || -1
        },
        me = a => {
            var b = le;
            b.readyState === "complete" || b.readyState === "interactive" ? (ee.push(a), ee.length == 1 && (window.Promise ? Promise.resolve().then(fe) : window.setImmediate ? setImmediate(fe) : setTimeout(fe, 0))) : b.addEventListener("DOMContentLoaded", a)
        };

    function Ud(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function ne(a, b, c = null, d = !1, e = !1) {
        oe(a, b, c, d, e)
    }

    function oe(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = Ud("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    const k = La(h, f);
                    k >= 0 && Array.prototype.splice.call(h, k, 1)
                }
                ud(f, "load", g);
                ud(f, "error", g)
            };
            td(f, "load", g);
            td(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var qe = (a, b) => {
            let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
            Xd(a, (d, e) => {
                if (d || d === 0) c += `&${e}=${encodeURIComponent(""+d)}`
            });
            pe(c)
        },
        pe = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : ne(b, a, void 0, !1, !1)
        };
    var le = document,
        O = window;
    let re = null;
    var se = (a, b = []) => {
        let c = !1;
        p.google_logging_queue || (c = !0, p.google_logging_queue = []);
        p.google_logging_queue.push([a, b]);
        if (a = c) {
            if (re == null) {
                re = !1;
                try {
                    const d = Sd(p);
                    d && d.location.hash.indexOf("google_logging") !== -1 && (re = !0)
                } catch (d) {}
            }
            a = re
        }
        a && Td(p.document, Od `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function te(a, b) {
        this.width = a;
        this.height = b
    }
    te.prototype.aspectRatio = function() {
        return this.width / this.height
    };
    te.prototype.isEmpty = function() {
        return !(this.width * this.height)
    };
    te.prototype.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    te.prototype.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    te.prototype.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    te.prototype.scale = function(a, b) {
        this.width *= a;
        this.height *= typeof b === "number" ? b : a;
        return this
    };

    function ue(a = p) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function ve(a = ue()) {
        return a ? Rd(a.master) ? a.master : null : null
    };

    function we(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function xe(a) {
        this.g = a || p.document || document
    }
    xe.prototype.contains = function(a, b) {
        return a && b ? a == b || a.contains(b) : !1
    };
    var ye = a => {
            a = ve(ue(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1;
            return a.google_unique_id
        },
        ze = a => {
            a = a.google_unique_id;
            return typeof a === "number" ? a : 0
        },
        Ae = a => {
            if (!a) return "";
            a = a.toLowerCase();
            a.substring(0, 3) != "ca-" && (a = "ca-" + a);
            return a
        };
    var Ce = class {
            constructor(a, b) {
                this.error = a;
                this.context = b.context;
                this.msg = b.message || "";
                this.id = b.id || "jserror";
                this.meta = {}
            }
        },
        De = a => !!(a.error && a.meta && a.id);

    function Ee(a) {
        return new Ce(a, {
            message: Fe(a)
        })
    }

    function Fe(a) {
        let b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    const Ge = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var He = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        Ie = class {
            constructor(a, b, c) {
                this.url = a;
                this.l = b;
                this.Xa = !!c;
                this.depth = null
            }
        };
    let Je = null;

    function Ke() {
        var a = window;
        if (Je === null) {
            Je = "";
            try {
                let b = "";
                try {
                    b = a.top.location.hash
                } catch (c) {
                    b = a.location.hash
                }
                if (b) {
                    const c = b.match(/\bdeid=([\d,]+)/);
                    Je = c ? c[1] : ""
                }
            } catch (b) {}
        }
        return Je
    };

    function Le() {
        const a = p.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Me() {
        const a = p.performance;
        return a && a.now ? a.now() : null
    };
    var Ne = class {
        constructor(a, b) {
            var c = Me() || Le();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const Oe = p.performance,
        Pe = !!(Oe && Oe.mark && Oe.measure && Oe.clearMarks),
        Qe = rd(() => {
            var a;
            if (a = Pe) a = Ke(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });

    function Re(a) {
        a && Oe && Qe() && (Oe.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Oe.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function Se(a) {
        a.g = !1;
        if (a.i !== a.j.google_js_reporting_queue) {
            if (Qe()) {
                var b = a.i;
                const c = b.length;
                b = typeof b === "string" ? b.split("") : b;
                for (let d = 0; d < c; d++) d in b && Re.call(void 0, b[d])
            }
            a.i.length = 0
        }
    }
    var Te = class {
        constructor(a) {
            this.i = [];
            this.j = a || p;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = Qe() || (b != null ? b : Math.random() < 1)
        }
        start(a, b) {
            if (!this.g) return null;
            a = new Ne(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Oe && Qe() && Oe.mark(b);
            return a
        }
        end(a) {
            if (this.g && typeof a.value === "number") {
                a.duration = (Me() || Le()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Oe && Qe() && Oe.mark(b);
                !this.g || this.i.length >
                    2048 || this.i.push(a)
            }
        }
    };

    function Ue(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function Ve(a, b, c, d, e) {
        const f = [];
        Xd(a, (g, h) => {
            (g = We(g, b, c, d, e)) && f.push(`${h}=${g}`)
        });
        return f.join(b)
    }

    function We(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        typeof c === "string" && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(We(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Ve(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Xe(a) {
        let b = 1;
        for (const c in a.i) c.length > b && (b = c.length);
        return 3997 - b - a.j.length - 1
    }

    function Ye(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = Xe(a) - b.length;
        if (d < 0) return "";
        a.g.sort((f, g) => f - g);
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.i[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = b == null ? g : b;
                    break
                }
                let l = Ve(h[k], a.j, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.j;
                        break
                    }
                    b = b == null ? g : b
                }
            }
        }
        a = "";
        b != null && (a = `${e}${"trn"}=${b}`);
        return c + a
    }
    var Ze = class {
        constructor() {
            this.j = "&";
            this.i = {};
            this.u = 0;
            this.g = []
        }
    };
    var af = class {
        constructor(a, b, c = null) {
            this.B = a;
            this.F = b;
            this.i = c;
            this.g = null;
            this.u = !1;
            this.A = this.G
        }
        fb(a) {
            this.A = a
        }
        Ca(a) {
            this.g = a
        }
        j(a) {
            this.u = a
        }
        Z(a, b, c) {
            let d, e;
            try {
                this.i && this.i.g ? (e = this.i.start(a.toString(), 3), d = b(), this.i.end(e)) : d = b()
            } catch (f) {
                b = this.F;
                try {
                    Re(e), b = this.A(a, Ee(f), void 0, c)
                } catch (g) {
                    this.G(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        na(a, b) {
            return (...c) => this.Z(a, () => b.apply(void 0, c))
        }
        G(a, b, c, d, e) {
            e = e || "jserror";
            let f = void 0;
            try {
                const ab = new Ze;
                var g = ab;
                g.g.push(1);
                g.i[1] = Ue("context", a);
                De(b) || (b = Ee(b));
                g = b;
                if (g.msg) {
                    b = ab;
                    var h = g.msg.substring(0, 512);
                    b.g.push(2);
                    b.i[2] = Ue("msg", h)
                }
                var k = g.meta || {};
                h = k;
                if (this.g) try {
                    this.g(h)
                } catch (wa) {}
                if (d) try {
                    d(h)
                } catch (wa) {}
                d = ab;
                k = [k];
                d.g.push(3);
                d.i[3] = k;
                d = p;
                k = [];
                h = null;
                do {
                    var l = d;
                    if (Rd(l)) {
                        var n = l.location.href;
                        h = l.document && l.document.referrer || null
                    } else n = h, h = null;
                    k.push(new Ie(n || "", l));
                    try {
                        d = l.parent
                    } catch (wa) {
                        d = null
                    }
                } while (d && l != d);
                for (let wa = 0, Rg = k.length - 1; wa <= Rg; ++wa) k[wa].depth = Rg - wa;
                l = p;
                if (l.location && l.location.ancestorOrigins &&
                    l.location.ancestorOrigins.length == k.length - 1)
                    for (n = 1; n < k.length; ++n) {
                        var m = k[n];
                        m.url || (m.url = l.location.ancestorOrigins[n - 1] || "", m.Xa = !0)
                    }
                var r = k;
                let Zc = new Ie(p.location.href, p, !1);
                l = null;
                const Be = r.length - 1;
                for (m = Be; m >= 0; --m) {
                    var x = r[m];
                    !l && Ge.test(x.url) && (l = x);
                    if (x.url && !x.Xa) {
                        Zc = x;
                        break
                    }
                }
                x = null;
                const Kk = r.length && r[Be].url;
                Zc.depth != 0 && Kk && (x = r[Be]);
                f = new He(Zc, x);
                if (f.i) {
                    r = ab;
                    var t = f.i.url || "";
                    r.g.push(4);
                    r.i[4] = Ue("top", t)
                }
                var v = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    const wa = f.g.url.match(Ld);
                    var I =
                        wa[1],
                        P = wa[3],
                        $c = wa[4];
                    t = "";
                    I && (t += I + ":");
                    P && (t += "//", t += P, $c && (t += ":" + $c));
                    var ic = t
                } else ic = "";
                I = ab;
                v = [v, {
                    url: ic
                }];
                I.g.push(5);
                I.i[5] = v;
                $e(this.B, e, ab, this.u, c)
            } catch (ab) {
                try {
                    $e(this.B, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Fe(ab),
                        url: f ? .g.url ? ? ""
                    }, this.u, c)
                } catch (Zc) {}
            }
            return this.F
        }
        ea(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.G(a, c instanceof Error ? c : Error(c), void 0, this.g || void 0)
            })
        }
    };
    var bf = class extends M {},
        cf = [2, 3, 4];
    var df = class extends M {},
        ef = [3, 4, 5],
        ff = [6, 7];
    var gf = class extends M {},
        hf = [4, 5];

    function jf(a, b) {
        var c = F(a, df, 2, C());
        if (!c.length) return kf(a, b);
        a = L(a, 1);
        if (a === 1) return c = jf(c[0], b), c.success ? {
            success: !0,
            value: !c.value
        } : c;
        c = Na(c, d => jf(d, b));
        switch (a) {
            case 2:
                return c.find(d => d.success && !d.value) ? ? c.find(d => !d.success) ? ? {
                    success: !0,
                    value: !0
                };
            case 3:
                return c.find(d => d.success && d.value) ? ? c.find(d => !d.success) ? ? {
                    success: !0,
                    value: !1
                };
            default:
                return {
                    success: !1,
                    errorType: 3
                }
        }
    }

    function kf(a, b) {
        var c = Rc(a, ef);
        a: {
            switch (c) {
                case 3:
                    var d = fd(a, 3, ef);
                    break a;
                case 4:
                    d = fd(a, 4, ef);
                    break a;
                case 5:
                    d = fd(a, 5, ef);
                    break a
            }
            d = void 0
        }
        if (!d) return {
            success: !1,
            errorType: 2
        };
        b = (b = b[c]) && b[d];
        if (!b) return {
            success: !1,
            property: d,
            da: c,
            errorType: 1
        };
        let e;
        try {
            var f = dd(a, 8);
            e = b(...f)
        } catch (g) {
            return {
                success: !1,
                property: d,
                da: c,
                errorType: 2
            }
        }
        f = L(a, 1);
        if (f === 4) return {
            success: !0,
            value: !!e
        };
        if (f === 5) return {
            success: !0,
            value: e != null
        };
        if (f === 12) a = K(a, Qc(a, ff, 7));
        else a: {
            switch (c) {
                case 4:
                    a = cd(a, Qc(a, ff, 6));
                    break a;
                case 5:
                    a = K(a, Qc(a, ff, 7));
                    break a
            }
            a = void 0
        }
        if (a == null) return {
            success: !1,
            property: d,
            da: c,
            errorType: 3
        };
        if (f === 6) return {
            success: !0,
            value: e === a
        };
        if (f === 9) return {
            success: !0,
            value: e != null && ua(String(e), a) === 0
        };
        if (e == null) return {
            success: !1,
            property: d,
            da: c,
            errorType: 4
        };
        switch (f) {
            case 7:
                c = e < a;
                break;
            case 8:
                c = e > a;
                break;
            case 12:
                c = Bb(a) && Bb(e) && (new RegExp(a)).test(e);
                break;
            case 10:
                c = e != null && ua(String(e), a) === -1;
                break;
            case 11:
                c = e != null && ua(String(e), a) === 1;
                break;
            default:
                return {
                    success: !1,
                    errorType: 3
                }
        }
        return {
            success: !0,
            value: c
        }
    }

    function lf(a, b) {
        return a ? b ? jf(a, b) : {
            success: !1,
            errorType: 1
        } : {
            success: !0,
            value: !0
        }
    };
    var mf = class extends M {};
    var nf = class extends M {
        getValue() {
            return E(this, mf, 2)
        }
    };
    var of = class extends M {}, pf = nd( of ), qf = [1, 2, 3, 6, 7, 8];
    var rf = class extends M {};

    function sf(a, b) {
        try {
            const c = d => [{
                [d.Da]: d.za
            }];
            return JSON.stringify([a.filter(d => d.la).map(c), wc(b), a.filter(d => !d.la).map(c)])
        } catch (c) {
            return tf(c, b), ""
        }
    }

    function tf(a, b) {
        try {
            qe({
                m: Fe(a instanceof Error ? a : Error(String(a))),
                b: L(b, 1) || null,
                v: K(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }
    var uf = class {
        constructor(a, b) {
            var c = new rf;
            a = D(c, 1, y(a), 0);
            b = kd(a, 2, b);
            this.j = Bc(b)
        }
    };
    var vf = class extends M {
        getWidth() {
            return bd(this, 3)
        }
        getHeight() {
            return bd(this, 4)
        }
    };
    var wf = class extends M {};

    function xf(a, b) {
        return A(a, 1, b == null ? b : dc(b))
    }

    function yf(a, b) {
        return A(a, 2, b == null ? b : dc(b))
    }
    var zf = class extends M {
        getWidth() {
            return jc(z(this, 1)) ? ? Cc
        }
        getHeight() {
            return jc(z(this, 2)) ? ? Cc
        }
    };
    var Af = class extends M {};
    var Bf = class extends M {};
    var Cf = class extends M {
        getValue() {
            return L(this, 1)
        }
    };
    var Df = class extends M {
        getContentUrl() {
            return K(this, 4)
        }
    };
    var Ef = class extends M {};

    function Ff(a) {
        return Sc(a, Ef, 3)
    }
    var Gf = class extends M {};
    var Hf = class extends M {
        getContentUrl() {
            return K(this, 1)
        }
    };
    var If = class extends M {};

    function Jf(a) {
        var b = new Kf;
        return D(b, 1, y(a), 0)
    }
    var Kf = class extends M {};
    var Lf = class extends M {},
        Mf = [4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17];
    var Nf = class extends M {};

    function Of(a, b) {
        return D(a, 1, y(b), 0)
    }

    function Pf(a, b) {
        return D(a, 2, y(b), 0)
    }
    var Qf = class extends M {};
    var Rf = class extends M {},
        Sf = [1, 2];

    function Tf(a, b) {
        return Uc(a, 1, b)
    }

    function Uf(a, b) {
        return Wc(a, 2, b)
    }

    function Vf(a, b) {
        return Mc(a, 4, b, $b)
    }

    function Wf(a, b) {
        return Wc(a, 5, b)
    }

    function Xf(a, b) {
        return D(a, 6, y(b), 0)
    }
    var Yf = class extends M {};
    var Zf = class extends M {},
        $f = [1, 2, 3, 4, 6];
    var ag = class extends M {};

    function bg(a) {
        var b = new cg;
        return Vc(b, 4, dg, a)
    }
    var cg = class extends M {
            getTagSessionCorrelator() {
                return jc(z(this, 2)) ? ? Cc
            }
        },
        dg = [4, 5, 7, 8, 9];
    var eg = class extends M {};

    function fg() {
        var a = Ac(gg());
        return kd(a, 1, hg())
    }
    var ig = class extends M {};
    var jg = class extends M {};
    var kg = class extends M {
        getTagSessionCorrelator() {
            return jc(z(this, 1)) ? ? Cc
        }
    };
    var lg = class extends M {},
        mg = [1, 7],
        ng = [4, 6, 8];
    class og extends uf {
        constructor() {
            super(...arguments)
        }
    }

    function pg(a, ...b) {
        qg(a, ...b.map(c => ({
            la: !0,
            Da: 3,
            za: wc(c)
        })))
    }

    function rg(a, ...b) {
        qg(a, ...b.map(c => ({
            la: !0,
            Da: 4,
            za: wc(c)
        })))
    }

    function sg(a, ...b) {
        qg(a, ...b.map(c => ({
            la: !0,
            Da: 7,
            za: wc(c)
        })))
    }
    var tg = class extends og {};
    var ug = (a, b) => {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function qg(a, ...b) {
        try {
            a.F && sf(a.g.concat(b), a.j).length >= 65536 && vg(a), a.u && !a.A && (a.A = !0, wg(a.u, () => {
                vg(a)
            })), a.g.push(...b), a.g.length >= a.B && vg(a), a.g.length && a.i === null && (a.i = setTimeout(() => {
                vg(a)
            }, a.P))
        } catch (c) {
            tf(c, a.j)
        }
    }

    function vg(a) {
        a.i !== null && (clearTimeout(a.i), a.i = null);
        if (a.g.length) {
            var b = sf(a.g, a.j);
            a.I("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.g = []
        }
    }
    var xg = class extends tg {
            constructor(a, b, c, d, e, f) {
                super(a, b);
                this.I = ug;
                this.P = c;
                this.B = d;
                this.F = e;
                this.u = f;
                this.g = [];
                this.i = null;
                this.A = !1
            }
        },
        yg = class extends xg {
            constructor(a, b, c = 1E3, d = 100, e = !1, f) {
                super(a, b, c, d, e && !0, f)
            }
        };

    function zg(a, b) {
        var c = Date.now();
        c = Number.isFinite(c) ? Math.round(c) : 0;
        b = hd(b, 1, c);
        c = ke(window);
        b = hd(b, 2, c);
        return hd(b, 6, a.A)
    }

    function Ag(a, b, c, d, e, f) {
        if (a.j) {
            var g = Pf(Of(new Qf, b), c);
            b = Xf(Uf(Tf(Wf(Vf(new Yf, d), e), g), a.g.slice()), f);
            b = bg(b);
            rg(a.i, zg(a, b));
            if (f === 1 || f === 3 || f === 4 && !a.g.some(h => L(h, 1) === L(g, 1) && L(h, 2) === c)) a.g.push(g), a.g.length > 100 && a.g.shift()
        }
    }

    function Bg(a, b, c, d) {
        if (a.j) {
            var e = new Nf;
            b = A(e, 1, ac(b));
            c = A(b, 2, ac(c));
            d = A(c, 3, y(d));
            c = new cg;
            d = Vc(c, 8, dg, d);
            rg(a.i, zg(a, d))
        }
    }

    function Cg(a, b, c, d, e) {
        if (a.j) {
            var f = new gf;
            b = Uc(f, 1, b);
            c = A(b, 2, y(c));
            d = A(c, 3, ac(d));
            if (e.da === void 0) Nc(d, 4, hf, y(e.errorType));
            else switch (e.da) {
                case 3:
                    c = new bf;
                    c = Nc(c, 2, cf, y(e.property));
                    e = A(c, 1, y(e.errorType));
                    Vc(d, 5, hf, e);
                    break;
                case 4:
                    c = new bf;
                    c = Nc(c, 3, cf, y(e.property));
                    e = A(c, 1, y(e.errorType));
                    Vc(d, 5, hf, e);
                    break;
                case 5:
                    c = new bf, c = Nc(c, 4, cf, y(e.property)), e = A(c, 1, y(e.errorType)), Vc(d, 5, hf, e)
            }
            e = new cg;
            e = Vc(e, 9, dg, d);
            rg(a.i, zg(a, e))
        }
    }
    var Dg = class {
        constructor(a, b, c, d = new yg(6, "unknown", b)) {
            this.A = a;
            this.u = c;
            this.i = d;
            this.g = [];
            this.j = a > 0 && Wd() < 1 / a
        }
    };
    var N = a => {
        var b = "ya";
        if (a.ya && a.hasOwnProperty(b)) return a.ya;
        b = new a;
        return a.ya = b
    };
    var Eg = class {
        constructor() {
            this.M = {
                [3]: {},
                [4]: {},
                [5]: {}
            }
        }
    };
    var Fg = /^true$/.test("false");

    function Gg(a, b) {
        switch (b) {
            case 1:
                return fd(a, 1, qf);
            case 2:
                return fd(a, 2, qf);
            case 3:
                return fd(a, 3, qf);
            case 6:
                return fd(a, 6, qf);
            case 8:
                return fd(a, 8, qf);
            default:
                return null
        }
    }

    function Hg(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return J(a, 1);
            case 7:
                return K(a, 3);
            case 2:
                return cd(a, 2);
            case 3:
                return K(a, 3);
            case 6:
                return dd(a, 4);
            case 8:
                return dd(a, 4);
            default:
                return null
        }
    }
    const Ig = rd(() => {
        if (!Fg) return {};
        try {
            var a = window;
            try {
                var b = a.sessionStorage.getItem("GGDFSSK")
            } catch {
                b = null
            }
            if (b) return JSON.parse(b)
        } catch {}
        return {}
    });

    function Jg(a, b, c, d = 0) {
        N(Kg).j[d] = N(Kg).j[d] ? .add(b) ? ? (new Set).add(b);
        const e = Ig();
        if (e[b] != null) return e[b];
        b = Lg(d)[b];
        if (!b) return c;
        b = pf(JSON.stringify(b));
        b = Mg(b);
        a = Hg(b, a);
        return a != null ? a : c
    }

    function Mg(a) {
        const b = N(Eg).M;
        if (b && Rc(a, qf) !== 8) {
            const c = Pa(F(a, nf, 5, C()), d => {
                d = lf(E(d, df, 1), b);
                return d.success && d.value
            });
            if (c) return c.getValue() ? ? null
        }
        return E(a, mf, 4) ? ? null
    }
    class Kg {
        constructor() {
            this.i = {};
            this.u = [];
            this.j = {};
            this.g = new Map
        }
    }

    function Ng(a, b = !1, c) {
        return !!Jg(1, a, b, c)
    }

    function Og(a, b = 0, c) {
        a = Number(Jg(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function Pg(a, b = "", c) {
        a = Jg(3, a, b, c);
        return typeof a === "string" ? a : b
    }

    function Qg(a, b = [], c) {
        a = Jg(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Sg(a, b = [], c) {
        a = Jg(8, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Lg(a) {
        return N(Kg).i[a] || (N(Kg).i[a] = {})
    }

    function Tg(a, b) {
        const c = Lg(b);
        Xd(a, (d, e) => {
            if (c[e]) {
                const g = pf(JSON.stringify(d));
                if (H(g, Qc(g, qf, 8)) != null) {
                    var f = pf(JSON.stringify(c[e]));
                    d = Sc(g, mf, 4);
                    f = dd(Tc(f, mf, 4), 4);
                    Xc(d, f)
                }
                c[e] = wc(g)
            } else c[e] = d
        })
    }

    function Ug(a, b, c, d, e = !1) {
        var f = [],
            g = [];
        for (const m of b) {
            b = Lg(m);
            for (const r of a) {
                var h = Rc(r, qf);
                const x = Gg(r, h);
                if (x) {
                    a: {
                        var k = x;
                        var l = h,
                            n = N(Kg).g.get(m) ? .get(x) ? .slice(0) ? ? [];
                        const t = new Zf;
                        switch (l) {
                            case 1:
                                Nc(t, 1, $f, y(k));
                                break;
                            case 2:
                                Nc(t, 2, $f, y(k));
                                break;
                            case 3:
                                Nc(t, 3, $f, y(k));
                                break;
                            case 6:
                                Nc(t, 4, $f, y(k));
                                break;
                            case 8:
                                Nc(t, 6, $f, y(k));
                                break;
                            default:
                                k = void 0;
                                break a
                        }
                        Mc(t, 5, n, $b);k = t
                    }
                    k && N(Kg).j[m] ? .has(x) && f.push(k);h === 8 && b[x] ? (k = pf(JSON.stringify(b[x])), h = Sc(r, mf, 4), k = dd(Tc(k, mf, 4), 4), Xc(h,
                        k)) : k && N(Kg).g.get(m) ? .has(x) && g.push(k);e || (h = x, k = m, l = d, n = N(Kg), n.g.has(k) || n.g.set(k, new Map), n.g.get(k).has(h) || n.g.get(k).set(h, []), l && n.g.get(k).get(h).push(l));b[x] = wc(r)
                }
            }
        }
        if (f.length || g.length) a = d ? ? void 0, c.j && c.u && (d = new ag, f = Wc(d, 2, f), g = Wc(f, 3, g), a && D(g, 1, ac(a), 0), f = new cg, g = Vc(f, 7, dg, g), rg(c.i, zg(c, g)))
    }

    function Vg(a, b) {
        b = Lg(b);
        for (const c of a) {
            a = pf(JSON.stringify(c));
            const d = Rc(a, qf);
            (a = Gg(a, d)) && (b[a] || (b[a] = c))
        }
    }

    function Wg() {
        return Object.keys(N(Kg).i).map(a => Number(a))
    }

    function Xg(a) {
        N(Kg).u.includes(a) || Tg(Lg(4), a)
    };

    function Q(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function Yg(a, b, c) {
        return b[a] || c
    }

    function Zg(a) {
        Q(5, Ng, a);
        Q(6, Og, a);
        Q(7, Pg, a);
        Q(8, Qg, a);
        Q(17, Sg, a);
        Q(13, Vg, a);
        Q(15, Xg, a)
    }

    function $g(a) {
        Q(4, b => {
            N(Eg).M = b
        }, a);
        Q(9, (b, c) => {
            var d = N(Eg);
            d.M[3][b] == null && (d.M[3][b] = c)
        }, a);
        Q(10, (b, c) => {
            var d = N(Eg);
            d.M[4][b] == null && (d.M[4][b] = c)
        }, a);
        Q(11, (b, c) => {
            var d = N(Eg);
            d.M[5][b] == null && (d.M[5][b] = c)
        }, a);
        Q(14, b => {
            var c = N(Eg);
            for (const d of [3, 4, 5]) Object.assign(c.M[d], b[d])
        }, a)
    }

    function ah(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };

    function bh(a, b, c) {
        a.j = Yg(1, b, () => {});
        a.u = (d, e) => Yg(2, b, () => [])(d, c, e);
        a.g = () => Yg(3, b, () => [])(c);
        a.i = d => {
            Yg(16, b, () => {})(d, c)
        }
    }
    class ch {
        j() {}
        i() {}
        u() {
            return []
        }
        g() {
            return []
        }
    };

    function $e(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Ze ? f = c : (f = new Ze, Xd(c, (h, k) => {
                var l = f;
                const n = l.u++;
                h = Ue(k, h);
                l.g.push(n);
                l.i[n] = h
            }));
            const g = Ye(f, "/pagead/gen_204?id=" + b + "&");
            g && ne(p, g)
        } catch (f) {}
    }

    function dh(a, b) {
        b >= 0 && b <= 1 && (a.g = b)
    }
    class eh {
        constructor() {
            this.g = Math.random()
        }
    };
    let fh, gh;
    const hh = new Te(window);
    (a => {
        fh = a ? ? new eh;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        dh(fh, window.google_srt);
        gh = new af(fh, !0, hh);
        gh.Ca(() => {});
        gh.j(!0);
        window.document.readyState == "complete" ? window.google_measure_js_timing || Se(hh) : hh.g && td(window, "load", () => {
            window.google_measure_js_timing || Se(hh)
        })
    })();
    let ih = (new Date).getTime();
    var jh = {
        ac: 0,
        Zb: 1,
        Wb: 2,
        Rb: 3,
        Xb: 4,
        Sb: 5,
        Yb: 6,
        Ub: 7,
        Vb: 8,
        Qb: 9,
        Tb: 10,
        bc: 11
    };
    var kh = {
        ec: 0,
        fc: 1,
        dc: 2
    };

    function lh(a) {
        if (a.g != 0) throw Error("Already resolved/rejected.");
    }
    var oh = class {
        constructor() {
            this.i = new mh(this);
            this.g = 0
        }
        resolve(a) {
            lh(this);
            this.g = 1;
            this.u = a;
            nh(this.i)
        }
        reject(a) {
            lh(this);
            this.g = 2;
            this.j = a;
            nh(this.i)
        }
    };

    function nh(a) {
        switch (a.g.g) {
            case 0:
                break;
            case 1:
                a.i && a.i(a.g.u);
                break;
            case 2:
                a.j && a.j(a.g.j);
                break;
            default:
                throw Error("Unhandled deferred state.");
        }
    }
    var mh = class {
        constructor(a) {
            this.g = a
        }
        then(a, b) {
            if (this.i) throw Error("Then functions already set.");
            this.i = a;
            this.j = b;
            nh(this)
        }
    };
    var ph = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new ph(Ma(this.g, a))
        }
        apply(a) {
            return new ph(a(this.g.slice(0)))
        }
        sort(a) {
            return new ph(this.g.slice(0).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = this.g.slice(0);
            b.push(a);
            return new ph(b)
        }
    };

    function qh(a, b) {
        const c = [],
            d = a.length;
        for (let e = 0; e < d; e++) c.push(a[e]);
        c.forEach(b, void 0)
    };
    var sh = class {
        constructor() {
            this.g = {};
            this.i = {}
        }
        set(a, b) {
            const c = rh(a);
            this.g[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = rh(a);
            return this.g[a] !== void 0 ? this.g[a] : b
        }
        clear() {
            this.g = {};
            this.i = {}
        }
    };

    function rh(a) {
        return a instanceof Object ? String(ka(a)) : a + ""
    };

    function th(a) {
        return new uh({
            value: a
        }, null)
    }

    function vh(a) {
        return new uh(null, a)
    }

    function wh(a) {
        try {
            return th(a())
        } catch (b) {
            return vh(b)
        }
    }

    function xh(a) {
        return a.g != null ? a.getValue() : null
    }

    function yh(a, b) {
        a.g != null && b(a.getValue());
        return a
    }

    function zh(a, b) {
        a.g != null || b(a.i);
        return a
    }
    var uh = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return this.g != null ? (a = a(this.getValue()), a instanceof uh ? a : th(a)) : this
        }
    };
    var Ah = class {
        constructor(a) {
            this.g = new sh;
            if (a)
                for (let b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return this.g.g[rh(a)] !== void 0
        }
    };
    var Bh = class {
        constructor() {
            this.g = new sh
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new Ah, this.g.set(a, c));
            c.add(b)
        }
    };
    var Ch = class extends M {
        getId() {
            return G(this, 3)
        }
    };
    var Dh = class {
        constructor({
            ob: a,
            ic: b,
            vc: c,
            Hb: d
        }) {
            this.g = b;
            this.u = new ph(a || []);
            this.j = d;
            this.i = c
        }
    };
    const Fh = a => {
            const b = [],
                c = a.u;
            c && c.g.length && b.push({
                aa: "a",
                ca: Eh(c)
            });
            a.g != null && b.push({
                aa: "as",
                ca: a.g
            });
            a.i != null && b.push({
                aa: "i",
                ca: String(a.i)
            });
            a.j != null && b.push({
                aa: "rp",
                ca: String(a.j)
            });
            b.sort(function(d, e) {
                return d.aa.localeCompare(e.aa)
            });
            b.unshift({
                aa: "t",
                ca: "aa"
            });
            return b
        },
        Eh = a => {
            a = a.g.slice(0).map(Gh);
            a = JSON.stringify(a);
            return Yd(a)
        },
        Gh = a => {
            const b = {};
            G(a, 7) != null && (b.q = G(a, 7));
            ad(a, 2) != null && (b.o = ad(a, 2));
            ad(a, 5) != null && (b.p = ad(a, 5));
            return b
        };
    var Hh = class extends M {
        setLocation(a) {
            return A(this, 1, y(a))
        }
    };

    function Ih(a) {
        const b = [].slice.call(arguments).filter(qd(e => e === null));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Ua || []);
            d = Object.assign(d, e.eb)
        });
        return new Jh(c, d)
    }

    function Kh(a) {
        switch (a) {
            case 1:
                return new Jh(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new Jh(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new Jh(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new Jh(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function Lh(a) {
        if (a == null) var b = null;
        else {
            b = Jh;
            var c = Fh(a);
            a = [];
            for (let d of c) c = String(d.ca), a.push(d.aa + "." + (c.length <= 20 ? c : c.slice(0, 19) + "_"));
            b = new b(null, {
                google_placement_id: a.join("~")
            })
        }
        return b
    }
    var Jh = class {
        constructor(a, b) {
            this.Ua = a;
            this.eb = b
        }
    };
    var Mh = new Jh(["google-auto-placed"], {
        google_reactive_ad_format: 40,
        google_tag_origin: "qs"
    });
    var Nh = nd(class extends M {});
    var Oh = class extends M {};
    var Ph = class extends M {};
    var Qh = class extends M {};
    var Rh = class extends M {};

    function Sh(a) {
        if (a.nodeType != 1) var b = !1;
        else if (b = a.tagName == "INS") a: {
            b = ["adsbygoogle-placeholder"];
            var c = a.className ? a.className.split(/\s+/) : [];a = {};
            for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
            for (c = 0; c < b.length; ++c)
                if (!a[b[c]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    };

    function Th(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && d.nodeType == 8;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        Sh(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    };
    var R = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        S = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Uh = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var Vh = new R(1333),
        Wh = new S(1359),
        Xh = new S(1358),
        Yh = new R(1360),
        Zh = new S(1357),
        $h = new R(1345),
        ai = new R(1332),
        bi = new R(1381),
        ci = new S(1130, 100),
        di = new S(1340, .2),
        ei = new S(1338, .3),
        fi = new S(1336, 1.2),
        gi = new S(1339, .3),
        hi = new R(1337),
        ii = new class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        }(14),
        ji = new R(1342),
        ki = new R(1344),
        li = new S(1343, 300),
        mi = new R(316),
        ni = new R(313),
        oi = new R(369),
        pi = new R(1318, !0),
        qi = new R(626390500),
        ri = new S(717888910),
        si = new Uh(627094447, "1 2 3 4 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 24 29 30 34".split(" ")),
        ti = new S(717888911),
        ui = new Uh(641845510, ["33", "38"]),
        vi = new R(717888913),
        wi = new Uh(635821288, ["29_18", "30_19"]),
        xi = new Uh(636146137, ["29_5", "30_6"]),
        yi = new S(717888912),
        zi = new Uh(627094446, "1 2 4 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 24 29 30 34".split(" ")),
        Ai = new Uh(683929765),
        Bi = new R(506914611),
        Ci = new R(723484983),
        Di = new S(643258048, .15),
        Ei = new S(643258049, .33938),
        Fi = new R(711741274),
        Gi = new R(45650663),
        Hi = new S(684147711, -1),
        Ii = new S(684147712, -1),
        Ji = new R(662101537),
        Ki = new R(45675667),
        Li =
        new R(45674084, !0),
        Mi = new S(1079, 5),
        Ni = new R(10013),
        ie = new class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        }(1934, ["AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "Amm8/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
            "A9wSqI5i0iwGdf6L1CERNdmsTPgVu44ewj8QxTBYgsv1LCPUVF7YmWOvTappqB1139jAymxUW/RO8zmMqo4zlAAAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MzY4MTI4MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A+d7vJfYtay4OUbdtRPZA3y7bKQLsxaMEPmxgfhBGqKXNrdkCQeJlUwqa6EBbSfjwFtJWTrWIioXeMW+y8bWAgQAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MzY4MTI4MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"
        ]),
        Oi = new R(84);
    var he = class {
        constructor() {
            const a = {};
            this.i = (b, c) => a[b] != null ? a[b] : c;
            this.u = (b, c) => a[b] != null ? a[b] : c;
            this.g = (b, c) => a[b] != null ? a[b] : c;
            this.A = (b, c) => a[b] != null ? a[b] : c;
            this.j = (b, c) => a[b] != null ? c.concat(a[b]) : c;
            this.B = () => {}
        }
    };

    function T(a) {
        return N(he).i(a.g, a.defaultValue)
    }

    function U(a) {
        return N(he).u(a.g, a.defaultValue)
    }

    function Pi(a) {
        return N(he).j(a.g, a.defaultValue)
    };

    function Qi(a, b) {
        const c = e => {
                e = Ri(e);
                return e == null ? !1 : 0 < e
            },
            d = e => {
                e = Ri(e);
                return e == null ? !1 : 0 > e
            };
        switch (b) {
            case 0:
                return {
                    init: Si(a.previousSibling, c),
                    ha: e => Si(e.previousSibling, c),
                    ma: 0
                };
            case 2:
                return {
                    init: Si(a.lastChild, c),
                    ha: e => Si(e.previousSibling, c),
                    ma: 0
                };
            case 3:
                return {
                    init: Si(a.nextSibling, d),
                    ha: e => Si(e.nextSibling, d),
                    ma: 3
                };
            case 1:
                return {
                    init: Si(a.firstChild, d),
                    ha: e => Si(e.nextSibling, d),
                    ma: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function Ri(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function Si(a, b) {
        return a && b(a) ? a : null
    };
    var Ti = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };
    var Ui = {
        overlays: 1,
        interstitials: 2,
        vignettes: 2,
        inserts: 3,
        immersives: 4,
        list_view: 5,
        full_page: 6,
        side_rails: 7
    };

    function Vi(a) {
        a = a.document;
        let b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    }

    function V(a) {
        return Vi(a).clientWidth ? ? void 0
    };

    function Wi(a, b) {
        do {
            const c = Vd(a, b);
            if (c && c.position == "fixed") return !1
        } while (a = a.parentElement);
        return !0
    };

    function Xi(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            const f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = be(a[c[e]]);
                d = d === null ? null : Math.round(d);
                d != null && (b[f] = d)
            }
        }
    }

    function Yi(a, b) {
        return !(($d.test(b.google_ad_width) || Zd.test(a.style.width)) && ($d.test(b.google_ad_height) || Zd.test(a.style.height)))
    }

    function Zi(a, b) {
        return (a = $i(a, b)) ? a.y : 0
    }

    function $i(a, b) {
        try {
            const c = b.document.documentElement.getBoundingClientRect(),
                d = a.getBoundingClientRect();
            return {
                x: d.left - c.left,
                y: d.top - c.top
            }
        } catch (c) {
            return null
        }
    }

    function aj(a, b, c, d, e) {
        if (a !== a.top) return Sd(a) ? 3 : 16;
        if (!(V(a) < 488)) return 4;
        if (!(a.innerHeight >= a.innerWidth)) return 5;
        const f = V(a);
        if (!f || (f - c) / f > d) a = 6;
        else {
            if (c = e.google_full_width_responsive !== "true") a: {
                c = b.parentElement;
                for (b = V(a); c; c = c.parentElement)
                    if ((d = Vd(c, a)) && (e = be(d.width)) && !(e >= b) && d.overflow !== "visible") {
                        c = !0;
                        break a
                    }
                c = !1
            }
            a = c ? 7 : !0
        }
        return a
    }

    function bj(a, b, c, d) {
        const e = aj(b, c, a, U(gi), d);
        e !== !0 ? a = e : d.google_full_width_responsive === "true" || Wi(c, b) ? (b = V(b), a = b - a, a = b && a >= 0 ? !0 : b ? a < -10 ? 11 : a < 0 ? 14 : 12 : 10) : a = 9;
        return a
    }

    function cj(a, b, c) {
        a = a.style;
        b === "rtl" ? a.marginRight = c : a.marginLeft = c
    }

    function dj(a, b) {
        if (b.nodeType === 3) return /\S/.test(b.data);
        if (b.nodeType === 1) {
            if (/^(script|style)$/i.test(b.nodeName)) return !1;
            let c;
            try {
                c = Vd(b, a)
            } catch (d) {}
            return !c || c.display !== "none" && !(c.position === "absolute" && (c.visibility === "hidden" || c.visibility === "collapse"))
        }
        return !1
    }

    function ej(a, b, c) {
        a = $i(b, a);
        return c === "rtl" ? -a.x : a.x
    }

    function fj(a, b) {
        var c;
        c = (c = b.parentElement) ? (c = Vd(c, a)) ? c.direction : "" : "";
        if (c) {
            var d = b.style;
            d.border = d.borderStyle = d.outline = d.outlineStyle = d.transition = "none";
            d.borderSpacing = d.padding = "0";
            cj(b, c, "0px");
            d.width = `${V(a)}px`;
            if (ej(a, b, c) !== 0) {
                cj(b, c, "0px");
                var e = ej(a, b, c);
                cj(b, c, `${-1*e}px`);
                a = ej(a, b, c);
                a !== 0 && a !== e && cj(b, c, `${e/(a-e)*e}px`)
            }
            d.zIndex = "30"
        }
    };

    function gj(a, b, c) {
        let d;
        return a.style && !!a.style[c] && be(a.style[c]) || (d = Vd(a, b)) && !!d[c] && be(d[c]) || null
    }

    function hj(a, b) {
        const c = ze(a) === 0;
        return b && c ? Math.max(250, 2 * Vi(a).clientHeight / 3) : 250
    }

    function ij(a, b) {
        let c;
        return a.style && a.style.zIndex || (c = Vd(a, b)) && c.zIndex || null
    }

    function jj(a) {
        return b => b.g <= a
    }

    function kj(a, b, c, d) {
        const e = a && lj(c, b),
            f = hj(b, d);
        return g => !(e && g.height() >= f)
    }

    function mj(a) {
        return b => b.height() <= a
    }

    function lj(a, b) {
        return Zi(a, b) < Vi(b).clientHeight - 100
    }

    function nj(a, b) {
        var c = gj(b, a, "height");
        if (c) return c;
        var d = b.style.height;
        b.style.height = "inherit";
        c = gj(b, a, "height");
        b.style.height = d;
        if (c) return c;
        c = Infinity;
        do(d = b.style && be(b.style.height)) && (c = Math.min(c, d)), (d = gj(b, a, "maxHeight")) && (c = Math.min(c, d)); while (b.parentElement && (b = b.parentElement) && b.tagName !== "HTML");
        return c
    };
    var oj = {
        google_ad_channel: !0,
        google_ad_client: !0,
        google_ad_host: !0,
        google_ad_host_channel: !0,
        google_adtest: !0,
        google_tag_for_child_directed_treatment: !0,
        google_tag_for_under_age_of_consent: !0,
        google_tag_partner: !0,
        google_restrict_data_processing: !0,
        google_page_url: !0,
        google_debug_params: !0,
        google_adbreak_test: !0,
        google_ad_frequency_hint: !0,
        google_admob_interstitial_slot: !0,
        google_admob_rewarded_slot: !0,
        google_admob_ads_only: !0,
        google_ad_start_delay_hint: !0,
        google_max_ad_content_rating: !0,
        google_traffic_source: !0,
        google_overlays: !0,
        google_privacy_treatments: !0,
        google_special_category_data: !0,
        google_ad_intent_query: !0,
        google_ad_intent_qetid: !0,
        google_ad_intent_eids: !0
    };
    const pj = RegExp("(^| )adsbygoogle($| )");

    function qj(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = Kd(d.property);
            a[e] = d.value
        }
    };
    var rj = class extends M {
        g() {
            return Vb(z(this, 23))
        }
    };
    var sj = class extends M {
        g() {
            return Yc(this, 1) ? ? void 0
        }
    };
    var tj = class extends M {};
    var uj = class extends M {};
    var vj = class extends M {};
    var wj = class extends M {};
    var xj = class extends M {
            getName() {
                return G(this, 4)
            }
        },
        yj = [1, 2, 3];
    var zj = class extends M {};
    var Aj = class extends M {};
    var Cj = class extends M {
            g() {
                return gd(this, Aj, 2, Bj)
            }
        },
        Bj = [1, 2];
    var Dj = class extends M {
        g() {
            return E(this, Cj, 3)
        }
    };
    var Ej = class extends M {},
        Fj = nd(Ej);

    function Gj(a) {
        const b = [];
        qh(a.getElementsByTagName("p"), function(c) {
            Hj(c) >= 100 && b.push(c)
        });
        return b
    }

    function Hj(a) {
        if (a.nodeType == 3) return a.length;
        if (a.nodeType != 1 || a.tagName == "SCRIPT") return 0;
        let b = 0;
        qh(a.childNodes, function(c) {
            b += Hj(c)
        });
        return b
    }

    function Ij(a) {
        return a.length == 0 || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Jj(a, b) {
        if (a.g == null) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }

    function Kj(a, b) {
        var c = [];
        try {
            c = b.querySelectorAll(a.u)
        } catch (d) {}
        if (!c.length) return [];
        b = u(c);
        b = Jj(a, b);
        typeof a.i === "number" && (c = a.i, c < 0 && (c += b.length), b = c >= 0 && c < b.length ? [b[c]] : []);
        if (typeof a.j === "number") {
            c = [];
            for (let d = 0; d < b.length; d++) {
                const e = Gj(b[d]);
                let f = a.j;
                f < 0 && (f += e.length);
                f >= 0 && f < e.length && c.push(e[f])
            }
            b = c
        }
        return b
    }
    var Lj = class {
        constructor(a, b, c, d) {
            this.u = a;
            this.i = b;
            this.j = c;
            this.g = d
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.u,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.g
            })
        }
    };
    var Mj = class {
        constructor() {
            this.g = Od `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        G(a, b, c = .01, d = "jserror") {
            if (Math.random() > c) return !1;
            De(b) || (b = new Ce(b, {
                context: a,
                id: d
            }));
            p.google_js_errors = p.google_js_errors || [];
            p.google_js_errors.push(b);
            p.error_rep_loaded || (Td(p.document, this.g), p.error_rep_loaded = !0);
            return !1
        }
        Z(a, b) {
            try {
                return b()
            } catch (c) {
                if (!this.G(a, c, .01, "jserror")) throw c;
            }
        }
        na(a, b) {
            return (...c) => this.Z(a, () => b.apply(void 0, c))
        }
        ea(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.G(a, c instanceof Error ? c : Error(c), void 0)
            })
        }
    };

    function Nj(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function Oj(a, b, c, d, e = !1) {
        const f = d || window,
            g = typeof queueMicrotask !== "undefined";
        return function(...h) {
            e && g && queueMicrotask(() => {
                f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                f.google_rum_task_id_counter += 1
            });
            const k = Me();
            let l, n = 3;
            try {
                l = b.apply(this, h)
            } catch (m) {
                n = 13;
                if (!c) throw m;
                c(a, m)
            } finally {
                f.google_measure_js_timing && k && Nj({
                    label: a.toString(),
                    value: k,
                    duration: (Me() || 0) - k,
                    type: n,
                    ...(e && g && {
                        taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                    })
                }, f)
            }
            return l
        }
    }

    function Pj(a, b) {
        return Oj(a, b, (c, d) => {
            (new Mj).G(c, d)
        }, void 0, !1)
    };

    function Qj(a, b, c) {
        return Oj(a, b, void 0, c, !0).apply()
    }

    function Rj(a) {
        if (!a) return null;
        var b = G(a, 7);
        if (G(a, 1) || a.getId() || dd(a, 4).length > 0) {
            var c = a.getId(),
                d = G(a, 1),
                e = dd(a, 4);
            b = ad(a, 2);
            var f = ad(a, 5);
            a = Sj(H(a, 6));
            let g = "";
            d && (g += d);
            c && (g += "#" + Ij(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + Ij(e[c]);
            b = (e = g) ? new Lj(e, b, f, a) : null
        } else b = b ? new Lj(b, ad(a, 2), ad(a, 5), Sj(H(a, 6))) : null;
        return b
    }
    const Tj = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Sj(a) {
        return a == null ? a : Tj[a]
    }
    const Uj = {
        1: 0,
        2: 1,
        3: 2,
        4: 3
    };

    function Vj(a) {
        return a.google_ama_state = a.google_ama_state || {}
    }

    function Wj(a) {
        a = Vj(a);
        return a.optimization = a.optimization || {}
    };
    var Xj = a => {
        switch (H(a, 8)) {
            case 1:
            case 2:
                if (a == null) var b = null;
                else b = E(a, Ch, 1), b == null ? b = null : (a = H(a, 2), b = a == null ? null : new Dh({
                    ob: [b],
                    Hb: a
                }));
                return b != null ? th(b) : vh(Error("Missing dimension when creating placement id"));
            case 3:
                return vh(Error("Missing dimension when creating placement id"));
            default:
                return vh(Error("Invalid type: " + H(a, 8)))
        }
    };
    var Yj = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function Zj(a, b) {
        const c = new Bh,
            d = new Ah;
        b.forEach(e => {
            if (gd(e, vj, 1, yj)) {
                e = gd(e, vj, 1, yj);
                if (E(e, Oh, 1) && E(E(e, Oh, 1), Ch, 1) && E(e, Oh, 2) && E(E(e, Oh, 2), Ch, 1)) {
                    const g = ak(a, E(E(e, Oh, 1), Ch, 1)),
                        h = ak(a, E(E(e, Oh, 2), Ch, 1));
                    if (g && h)
                        for (var f of Yj({
                                anchor: g,
                                position: H(E(e, Oh, 1), 2)
                            }, {
                                anchor: h,
                                position: H(E(e, Oh, 2), 2)
                            })) c.set(ka(f.anchor), f.position)
                }
                E(e, Oh, 3) && E(E(e, Oh, 3), Ch, 1) && (f = ak(a, E(E(e, Oh, 3), Ch, 1))) && c.set(ka(f), H(E(e, Oh, 3), 2))
            } else gd(e, wj, 2, yj) ? bk(a, gd(e, wj, 2, yj), c) : gd(e, uj, 3, yj) && ck(a, gd(e, uj, 3, yj), d)
        });
        return new dk(c, d)
    }
    var dk = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };
    const bk = (a, b, c) => {
            E(b, Oh, 2) ? (b = E(b, Oh, 2), (a = ak(a, E(b, Ch, 1))) && c.set(ka(a), H(b, 2))) : E(b, Ch, 1) && (a = ek(a, E(b, Ch, 1))) && a.forEach(d => {
                d = ka(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        ck = (a, b, c) => {
            E(b, Ch, 1) && (a = ek(a, E(b, Ch, 1))) && a.forEach(d => {
                c.add(ka(d))
            })
        },
        ak = (a, b) => (a = ek(a, b)) && a.length > 0 ? a[0] : null,
        ek = (a, b) => (b = Rj(b)) ? Kj(b, a) : null;

    function hg() {
        return "m202502180101"
    };
    var fk = md(eg);
    var gg = md(ig);

    function gk(a, b) {
        return b(a) ? a : void 0
    }

    function hk(a, b, c, d, e) {
        c = c instanceof Ce ? c.error : c;
        var f = new lg;
        const g = new kg;
        try {
            var h = ke(window);
            hd(g, 1, h)
        } catch (r) {}
        try {
            var k = N(ch).g();
            Mc(g, 2, k, $b)
        } catch (r) {}
        try {
            kd(g, 3, window.document.URL)
        } catch (r) {}
        h = Uc(f, 2, g);
        k = new jg;
        b = D(k, 1, y(b), 0);
        try {
            var l = Bb(c ? .name) ? c.name : "Unknown error";
            kd(b, 2, l)
        } catch (r) {}
        try {
            var n = Bb(c ? .message) ? c.message : `Caught ${c}`;
            kd(b, 3, n)
        } catch (r) {}
        try {
            var m = Bb(c ? .stack) ? c.stack : Error().stack;
            m && Mc(b, 4, m.split(/\n\s*/), kc)
        } catch (r) {}
        l = Vc(h, 1, mg, b);
        if (e) {
            n = 0;
            switch (e.errSrc) {
                case "LCC":
                    n =
                        1;
                    break;
                case "PVC":
                    n = 2
            }
            m = fg();
            b = gk(e.shv, Bb);
            m = kd(m, 2, b);
            n = D(m, 6, y(n), 0);
            m = fk();
            m = Ac(m);
            b = gk(e.es, Eb());
            m = Mc(m, 1, b, $b);
            m = Bc(m);
            n = Uc(n, 4, m);
            m = gk(e.client, Bb);
            n = jd(n, 3, m);
            m = gk(e.slotname, Bb);
            n = kd(n, 7, m);
            e = gk(e.tag_origin, Bb);
            e = kd(n, 8, e);
            e = Bc(e)
        } else e = Bc(fg());
        e = Vc(l, 6, ng, e);
        d = hd(e, 5, d ? ? 1);
        pg(a, d)
    };
    let ik, jk = 64;

    function kk() {
        try {
            return ik ? ? (ik = new Uint32Array(64)), jk >= 64 && (crypto.getRandomValues(ik), jk = 0), ik[jk++]
        } catch (a) {
            return Math.floor(Math.random() * 2 ** 32)
        }
    };
    var mk = class {
        constructor() {
            this.g = lk
        }
    };

    function lk() {
        return {
            Fb: kk() + (kk() & 2 ** 21 - 1) * 2 ** 32,
            vb: Number.MAX_SAFE_INTEGER
        }
    };
    var ok = class {
        constructor(a = !1) {
            this.A = nk;
            this.u = a;
            this.g = null;
            this.i = this.G
        }
        fb(a) {
            this.i = a
        }
        Ca(a) {
            this.g = a
        }
        j() {}
        Z(a, b, c) {
            let d;
            try {
                d = b()
            } catch (e) {
                b = this.u;
                try {
                    b = this.i(a, Ee(e), void 0, c)
                } catch (f) {
                    this.G(217, f)
                }
                if (b) window.console ? .error ? .(e);
                else throw e;
            }
            return d
        }
        na(a, b) {
            return (...c) => this.Z(a, () => b.apply(void 0, c))
        }
        ea(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.G(a, c instanceof Error ? c : Error(c), void 0, void 0)
            })
        }
        G(a, b, c, d) {
            try {
                c = c === void 0 ? 100 : c === 0 ? 0 : 1 / c;
                var e = (new mk).g();
                if (c > 0 && e.Fb * c <= e.vb) {
                    var f =
                        this.A;
                    e = {};
                    if (this.g) try {
                        this.g(e)
                    } catch (g) {}
                    if (d) try {
                        d(e)
                    } catch (g) {}
                    hk(f, a, b, c, e)
                }
            } catch (g) {}
            return this.u
        }
    };
    var W = class extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, W) : this.stack = Error().stack || ""
        }
    };
    let nk, pk, qk, rk;
    const sk = new Te(p);

    function tk(a) {
        a != null && (p.google_measure_js_timing = a);
        p.google_measure_js_timing || Se(sk)
    }(function(a, b, c = !0) {
        typeof p.google_srt !== "number" && (p.google_srt = Math.random());
        pk = a || new eh;
        dh(pk, p.google_srt);
        qk = new af(pk, c, sk);
        qk.j(!0);
        nk = b || new yg(2, hg(), 1E3);
        rk = new ok(c);
        p.document.readyState === "complete" ? tk() : sk.g && td(p, "load", () => {
            tk()
        })
    })();

    function uk(a, b, c) {
        return T(bi) ? rk.Z(a, b, c) : qk.Z(a, b, c)
    }

    function vk(a, b) {
        return T(bi) ? rk.na(a, b) : qk.na(a, b)
    }

    function wk(a, b) {
        T(bi) ? rk.ea(a, b) : qk.ea(a, b)
    }

    function xk(a, b, c = .01) {
        const d = N(ch).g();
        !b.eid && d.length && (b.eid = d.toString());
        $e(pk, a, b, !0, c)
    }

    function yk(a, b, c = .01, d, e) {
        return T(bi) ? rk.G(a, b, c, d, e) : qk.G(a, b, c, d, e)
    }

    function zk(a, b, c = .01, d, e) {
        return (De(b) ? b.msg || Fe(b.error) : Fe(b)).indexOf("TagError") === 0 ? ((De(b) ? b.error : b).pbr = !0, !1) : yk(a, b, c, d, e)
    };
    var Ak = class {
        constructor() {
            this.g = je();
            this.i = 0
        }
    };

    function Bk(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (Ck(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function Dk(a) {
        a = Ek(a);
        return a.has("all") || a.has("after")
    }

    function Fk(a) {
        a = Ek(a);
        return a.has("all") || a.has("before")
    }

    function Ek(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function Ck(a) {
        const b = Ek(a);
        return a && (a.tagName === "AUTO-ADS-EXCLUSION-AREA" || b.has("inside") || b.has("all"))
    }
    var Gk = class {
        constructor() {
            this.g = new Set;
            this.i = new Ak
        }
    };

    function Hk(a, b) {
        if (!a) return !1;
        a = Vd(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return a == "left" || a == "right"
    }

    function Ik(a) {
        for (a = a.previousSibling; a && a.nodeType != 1;) a = a.previousSibling;
        return a ? a : null
    }

    function Jk(a) {
        return !!a.nextSibling || !!a.parentNode && Jk(a.parentNode)
    };

    function Lk(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };
    var Rk = a => ({
        hc: u(a.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
        jc: u(a.document.querySelectorAll("body ins.adsbygoogle")),
        lb: Mk(a),
        mb: u(a.document.querySelectorAll(".google-auto-placed")),
        nb: u(a.document.querySelectorAll("ins.adsbygoogle[data-anchor-status]")),
        wb: Nk(a),
        nc: Ok(a),
        xc: Pk(a),
        Eb: Qk(a),
        mc: u(a.document.querySelectorAll("div.googlepublisherpluginad")),
        Ob: u(a.document.querySelectorAll("html > ins.adsbygoogle"))
    });
    const Ok = a => Sk(a) || u(a.document.querySelectorAll("div[id^=div-gpt-ad]")),
        Sk = a => {
            const b = Lk(a);
            return b ? Ma(Na(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => c != null) : null
        },
        Mk = a => u(a.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")),
        Pk = a => u(a.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]")),
        Nk = a => Ok(a).concat(u(a.document.querySelectorAll("iframe[id^=google_ads_iframe]"))),
        Qk = a => u(a.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]"));
    var Tk = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function Uk(a, b) {
        if (a.u) return !0;
        a.u = !0;
        const c = F(a.j, Qh, 1, C());
        a.i = 0;
        const d = Vk(a.I);
        var e = a.g;
        var f;
        try {
            var g = (f = e.localStorage.getItem("google_ama_settings")) ? Nh(f) : null
        } catch (r) {
            g = null
        }
        f = g !== null && J(g, 2);
        g = Vj(e);
        f && (g.eatf = !0, se(7, [!0, 0, !1]));
        b: {
            var h = {
                    zb: !1,
                    Ab: !1
                },
                k = u(e.document.querySelectorAll(".google-auto-placed")),
                l = u(e.document.querySelectorAll("ins.adsbygoogle[data-anchor-status]")),
                n = Pk(e);
            const r = Nk(e),
                x = Qk(e),
                t = u(e.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
                v = u(e.document.querySelectorAll("div.googlepublisherpluginad")),
                I = u(e.document.querySelectorAll("html > ins.adsbygoogle"));
            let P = [].concat(Mk(e), u(e.document.querySelectorAll("body ins.adsbygoogle")));f = [];
            for (const [$c, ic] of [
                    [h.qc, k],
                    [h.zb, l],
                    [h.tc, n],
                    [h.rc, r],
                    [h.uc, x],
                    [h.oc, t],
                    [h.sc, v],
                    [h.Ab, I]
                ]) $c === !1 ? f = f.concat(ic) : P = P.concat(ic);h = Tk(P);f = Tk(f);h = h.slice(0);
            for (m of f)
                for (f = 0; f < h.length; f++)(m.contains(h[f]) || h[f].contains(m)) && h.splice(f, 1);
            var m = h;e = Vi(e).clientHeight;
            for (f = 0; f < m.length; f++)
                if (!(m[f].getBoundingClientRect().top > e)) {
                    e = !0;
                    break b
                }
            e = !1
        }
        e =
            e ? g.eatfAbg = !0 : !1;
        if (e) return !0;
        e = new Ah([2]);
        for (g = 0; g < c.length; g++) {
            m = a;
            l = c[g];
            f = g;
            h = b;
            if (E(l, Hh, 4) && e.contains(H(E(l, Hh, 4), 1)) && H(l, 8) === 1 && Wk(l, d)) {
                m.i++;
                if (h = Xk(m, l, h, d)) k = Vj(m.g), k.numAutoAdsPlaced || (k.numAutoAdsPlaced = 0), (n = !E(l, Ch, 1)) || (l = E(l, Ch, 1), n = (ad(l, 5) ? ? void 0) == null), n || (k.numPostPlacementsPlaced ? k.numPostPlacementsPlaced++ : k.numPostPlacementsPlaced = 1), k.placed == null && (k.placed = []), k.numAutoAdsPlaced++, k.placed.push({
                    index: f,
                    element: h.fa
                }), se(7, [!1, m.i, !0]);
                m = h
            } else m = null;
            if (m) return !0
        }
        se(7, [!1, a.i, !1]);
        return !1
    }

    function Xk(a, b, c, d) {
        if (!Wk(b, d) || (H(b, 8) ? ? void 0) != 1) return null;
        d = E(b, Ch, 1);
        if (!d) return null;
        d = Rj(d);
        if (!d) return null;
        d = Kj(d, a.g.document);
        if (d.length == 0) return null;
        d = d[0];
        var e = H(b, 2);
        e = Uj[e];
        e = e === void 0 ? null : e;
        var f;
        if (!(f = e == null)) {
            a: {
                f = a.g;
                switch (e) {
                    case 0:
                        f = Hk(Ik(d), f);
                        break a;
                    case 3:
                        f = Hk(d, f);
                        break a;
                    case 2:
                        var g = d.lastChild;
                        f = Hk(g ? g.nodeType == 1 ? g : Ik(g) : null, f);
                        break a
                }
                f = !1
            }
            if (c = !f && !(!c && e == 2 && !Jk(d))) c = e == 1 || e == 2 ? d : d.parentNode,
            c = !(c && !Sh(c) && c.offsetWidth <= 0);f = !c
        }
        if (!(c = f)) {
            c = a.B;
            f = H(b, 2);
            g = c.i;
            var h = ka(d);
            g = g.g.get(h);
            if (!(g = g ? g.contains(f) : !1)) a: {
                if (c.g.contains(ka(d))) switch (f) {
                    case 2:
                    case 3:
                        g = !0;
                        break a;
                    default:
                        g = !1;
                        break a
                }
                for (f = d.parentElement; f;) {
                    if (c.g.contains(ka(f))) {
                        g = !0;
                        break a
                    }
                    f = f.parentElement
                }
                g = !1
            }
            c = g
        }
        if (!c) {
            c = a.F;
            g = H(b, 2);
            a: switch (g) {
                case 1:
                    f = Dk(d.previousElementSibling) || Fk(d);
                    break a;
                case 4:
                    f = Dk(d) || Fk(d.nextElementSibling);
                    break a;
                case 2:
                    f = Fk(d.firstElementChild);
                    break a;
                case 3:
                    f = Dk(d.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " +
                        g);
            }
            g = Bk(c, d, g);
            c = c.i;
            xk("ama_exclusion_zone", {
                typ: f ? g ? "siuex" : "siex" : g ? "suex" : "noex",
                cor: c.g,
                num: c.i++,
                dvc: ce()
            }, .1);
            c = f || g
        }
        if (c) return null;
        f = E(b, Ph, 3);
        c = {};
        f && (c.ib = G(f, 1), c.Sa = G(f, 2), c.tb = !!Vb(z(f, 3)));
        f = E(b, Hh, 4) && H(E(b, Hh, 4), 2) ? H(E(b, Hh, 4), 2) : null;
        f = Kh(f);
        g = ad(b, 12) != null ? ad(b, 12) : null;
        g = g == null ? null : new Jh(null, {
            google_ml_rank: g
        });
        b = Yk(a, b);
        b = Ih(a.A, f, g, b);
        f = a.g;
        a = a.P;
        h = f.document;
        var k = c.tb || !1;
        g = we((new xe(h)).g, "DIV");
        const l = g.style;
        l.width = "100%";
        l.height = "auto";
        l.clear = k ? "both" : "none";
        k = g.style;
        k.textAlign = "center";
        c.Gb && qj(k, c.Gb);
        h = we((new xe(h)).g, "INS");
        k = h.style;
        k.display = "block";
        k.margin = "auto";
        k.backgroundColor = "transparent";
        c.ib && (k.marginTop = c.ib);
        c.Sa && (k.marginBottom = c.Sa);
        c.kb && qj(k, c.kb);
        g.appendChild(h);
        c = {
            wa: g,
            fa: h
        };
        c.fa.setAttribute("data-ad-format", "auto");
        g = [];
        if (h = b && b.Ua) c.wa.className = h.join(" ");
        h = c.fa;
        h.className = "adsbygoogle";
        h.setAttribute("data-ad-client", a);
        g.length && h.setAttribute("data-ad-channel", g.join("+"));
        a: {
            try {
                var n = c.wa;
                if (T(ni)) {
                    {
                        const v = Qi(d,
                            e);
                        if (v.init) {
                            var m = v.init;
                            for (d = m; d = v.ha(d);) m = d;
                            var r = {
                                anchor: m,
                                position: v.ma
                            }
                        } else r = {
                            anchor: d,
                            position: e
                        }
                    }
                    n["google-ama-order-assurance"] = 0;
                    Th(n, r.anchor, r.position)
                } else Th(n, d, e);
                b: {
                    var x = c.fa;x.dataset.adsbygoogleStatus = "reserved";x.className += " adsbygoogle-noablate";n = {
                        element: x
                    };
                    var t = b && b.eb;
                    if (x.hasAttribute("data-pub-vars")) {
                        try {
                            t = JSON.parse(x.getAttribute("data-pub-vars"))
                        } catch (v) {
                            break b
                        }
                        x.removeAttribute("data-pub-vars")
                    }
                    t && (n.params = t);
                    (f.adsbygoogle = f.adsbygoogle || []).push(n)
                }
            } catch (v) {
                (x =
                    c.wa) && x.parentNode && (t = x.parentNode, t.removeChild(x), Sh(t) && (t.style.display = t.getAttribute("data-init-display") || "none"));
                x = !1;
                break a
            }
            x = !0
        }
        return x ? c : null
    }

    function Yk(a, b) {
        return xh(zh(Xj(b).map(Lh), c => {
            Vj(a.g).exception = c
        }))
    }
    var Zk = class {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.P = b;
            this.j = c;
            this.A = e || null;
            (this.I = d) ? (a = a.document, d = F(d, xj, 5, C()), d = Zj(a, d)) : d = Zj(a.document, []);
            this.B = d;
            this.F = new Gk;
            this.i = 0;
            this.u = !1
        }
    };

    function Vk(a) {
        const b = {};
        a && ed(a, 6).forEach(c => {
            b[c] = !0
        });
        return b
    }

    function Wk(a, b) {
        return a && Ec(a, Hh, 4) && b[H(E(a, Hh, 4), 2)] ? !1 : !0
    };
    var $k = nd(class extends M {});

    function al(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? wh(() => $k(c)) : th(null)
    };

    function bl() {
        if (cl) return cl;
        var a = ve() || window;
        const b = a.google_persistent_state_async;
        return b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? cl = b : a.google_persistent_state_async = cl = new dl
    }

    function el(a) {
        return fl[a] || `google_ps_${a}`
    }

    function gl(a, b, c) {
        b = el(b);
        a = a.S;
        const d = a[b];
        return d === void 0 ? (a[b] = c(), a[b]) : d
    }

    function hl(a, b, c) {
        return gl(a, b, () => c)
    }
    var dl = class {
            constructor() {
                this.S = {}
            }
        },
        cl = null;
    const fl = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function il(a) {
        this.g = a || {
            cookie: ""
        }
    }
    il.prototype.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        typeof c === "object" && (h = c.yc, g = c.zc || !1, f = c.domain || void 0, e = c.path || void 0, d = c.Cb);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        d === void 0 && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (d < 0 ? "" : d == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + d * 1E3)).toUTCString()) + (g ? ";secure" : "") + (h != null ? ";samesite=" + h : "")
    };
    il.prototype.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = ta(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    il.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    il.prototype.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [];
        var c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = ta(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (c = b.length - 1; c >= 0; c--) a = b[c], this.get(a), this.set(a, "", {
            Cb: 0,
            path: void 0,
            domain: void 0
        })
    };

    function jl(a, b = window) {
        if (J(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    };

    function kl(a) {
        var b = new ll;
        return A(b, 5, Ub(a))
    }
    var ll = class extends M {};

    function ml() {
        this.A = this.A;
        this.i = this.i
    }
    ml.prototype.A = !1;
    ml.prototype.dispose = function() {
        this.A || (this.A = !0, this.F())
    };
    ml.prototype[fa(Symbol, "dispose")] = function() {
        this.dispose()
    };

    function nl(a, b) {
        a.A ? b() : (a.i || (a.i = []), a.i.push(b))
    }
    ml.prototype.F = function() {
        if (this.i)
            for (; this.i.length;) this.i.shift()()
    };

    function ol(a) {
        a.addtlConsent !== void 0 && typeof a.addtlConsent !== "string" && (a.addtlConsent = void 0);
        a.gdprApplies !== void 0 && typeof a.gdprApplies !== "boolean" && (a.gdprApplies = void 0);
        return a.tcString !== void 0 && typeof a.tcString !== "string" || a.listenerId !== void 0 && typeof a.listenerId !== "number" ? 2 : a.cmpStatus && a.cmpStatus !== "error" ? 0 : 3
    }

    function pl(a) {
        if (a.gdprApplies === !1) return !0;
        a.internalErrorState === void 0 && (a.internalErrorState = ol(a));
        return a.cmpStatus === "error" || a.internalErrorState !== 0 ? a.internalBlockOnErrors ? (qe({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : a.cmpStatus !== "loaded" || a.eventStatus !== "tcloaded" && a.eventStatus !== "useractioncomplete" ? !1 : !0
    }

    function ql(a) {
        if (a.g) return a.g;
        a: {
            let d = a.j;
            for (let e = 0; e < 50; ++e) {
                try {
                    var b = !(!d.frames || !d.frames.__tcfapiLocator)
                } catch {
                    b = !1
                }
                if (b) {
                    b = d;
                    break a
                }
                b: {
                    try {
                        const f = d.parent;
                        if (f && f != d) {
                            var c = f;
                            break b
                        }
                    } catch {}
                    c = null
                }
                if (!(d = c)) break
            }
            b = null
        }
        a.g = b;
        return a.g
    }

    function rl(a, b, c, d) {
        c || (c = () => {});
        var e = a.j;
        typeof e.__tcfapi === "function" ? (a = e.__tcfapi, a(b, 2, c, d)) : ql(a) ? (sl(a), e = ++a.ba, a.B[e] = c, a.g && a.g.postMessage({
            __tcfapiCall: {
                command: b,
                version: 2,
                callId: e,
                parameter: d
            }
        }, "*")) : c({}, !1)
    }

    function sl(a) {
        if (!a.u) {
            var b = c => {
                try {
                    var d = (typeof c.data === "string" ? JSON.parse(c.data) : c.data).__tcfapiReturn;
                    a.B[d.callId](d.returnValue, d.success)
                } catch (e) {}
            };
            a.u = b;
            td(a.j, "message", b)
        }
    }
    var tl = class extends ml {
        constructor(a) {
            var b = {};
            super();
            this.g = null;
            this.B = {};
            this.ba = 0;
            this.u = null;
            this.j = a;
            this.P = b.hb ? ? 500;
            this.I = b.kc ? ? !1
        }
        F() {
            this.B = {};
            this.u && (ud(this.j, "message", this.u), delete this.u);
            delete this.B;
            delete this.j;
            delete this.g;
            super.F()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.I
            };
            const c = sd(() => a(b));
            let d = 0;
            this.P !== -1 && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.P));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState =
                    ol(b), b.internalBlockOnErrors = this.I, g && b.internalErrorState === 0 || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                rl(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && rl(this, "removeEventListener", null, a.listenerId)
        }
    };
    var yl = ({
            l: a,
            Y: b,
            hb: c,
            rb: d,
            ia: e = !1,
            ja: f = !1
        }) => {
            b = ul({
                l: a,
                Y: b,
                ia: e,
                ja: f
            });
            b.g != null || b.i.message != "tcunav" ? d(b) : vl(a, c).then(g => g.map(wl)).then(g => g.map(h => xl(a, h))).then(d)
        },
        ul = ({
            l: a,
            Y: b,
            ia: c = !1,
            ja: d = !1
        }) => {
            if (!zl({
                    l: a,
                    Y: b,
                    ia: c,
                    ja: d
                })) return xl(a, kl(!0));
            b = bl();
            return (b = hl(b, 24)) ? xl(a, wl(b)) : vh(Error("tcunav"))
        };

    function zl({
        l: a,
        Y: b,
        ia: c,
        ja: d
    }) {
        if (d = !d) d = new tl(a), d = typeof d.j.__tcfapi === "function" || ql(d) != null;
        if (!d) {
            if (c = !c) {
                if (b) {
                    a = al(a);
                    if (a.g != null)
                        if ((a = a.getValue()) && H(a, 1) != null) b: switch (a = L(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else yk(806, a.i), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function vl(a, b) {
        return Promise.race([Al(), Bl(a, b)])
    }

    function Al() {
        return (new Promise(a => {
            var b = bl();
            a = {
                resolve: a
            };
            const c = hl(b, 25, []);
            c.push(a);
            b.S[el(25)] = c
        })).then(Cl)
    }

    function Bl(a, b) {
        return new Promise(c => {
            a.setTimeout(c, b, vh(Error("tcto")))
        })
    }

    function Cl(a) {
        return a ? th(a) : vh(Error("tcnull"))
    }

    function wl(a) {
        var b = {};
        if (pl(a))
            if (a.gdprApplies === !1) a = !0;
            else if (a.tcString === "tcunavailable") a = !b.Wa;
        else if ((b.Wa || a.gdprApplies !== void 0 || b.lc) && (b.Wa || typeof a.tcString === "string" && a.tcString.length)) {
            b: {
                if (a.publisher && a.publisher.restrictions && (b = a.publisher.restrictions["1"], b !== void 0)) {
                    b = b["755"];
                    break b
                }
                b = void 0
            }
            b === 0 ? a = !1 : a.purpose && a.vendor ? (b = a.vendor.consents, (b = !(!b || !b["755"])) && a.purposeOneTreatment && a.publisherCC === "CH" ? a = !0 : (b && (a = a.purpose.consents, b = !(!a || !a["1"])), a = b)) : a = !0
        }
        else a = !0;
        else a = !1;
        return kl(a)
    }

    function xl(a, b) {
        return (a = jl(b, a)) ? th(a) : vh(Error("unav"))
    };
    var Dl = class extends M {};
    var El = class extends M {};
    var Fl = class extends M {
        g() {
            return E(this, El, 3)
        }
    };
    var Gl = class {
        constructor(a) {
            this.exception = a
        }
    };

    function Hl(a, b) {
        try {
            var c = a.i,
                d = c.resolve,
                e = a.g;
            Vj(e.g);
            F(e.j, Qh, 1, C());
            d.call(c, new Gl(b))
        } catch (f) {
            a.i.reject(f)
        }
    }
    var Il = class {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.i = c
        }
        start() {
            this.u()
        }
        u() {
            try {
                switch (this.j.document.readyState) {
                    case "complete":
                    case "interactive":
                        Uk(this.g, !0);
                        Hl(this);
                        break;
                    default:
                        Uk(this.g, !1) ? Hl(this) : this.j.setTimeout(pa(this.u, this), 100)
                }
            } catch (a) {
                Hl(this, a)
            }
        }
    };
    var Jl = class extends M {
        getVersion() {
            return bd(this, 2)
        }
    };

    function Kl(a) {
        return Ua(a.length % 4 !== 0 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function Ll(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function Ml(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function Nl(a) {
        var b = Kl(a),
            c = Ll(b.slice(0, 6));
        a = Ll(b.slice(6, 12));
        var d = new Jl;
        c = D(d, 1, ac(c), 0);
        a = D(c, 2, ac(a), 0);
        b = b.slice(12);
        c = Ll(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (e.length === 0) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = Ll(e[0]) === 0;
            e = e.slice(1);
            var g = Ol(e, b),
                h = d.length === 0 ? 0 : d[d.length - 1];
            h = Ml(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = Ol(e, b);
                g = Ml(f);
                for (let l = 0; l <= g; l++) d.push(h + l);
                e = e.slice(f.length)
            }
        }
        if (e.length >
            0) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return Mc(a, 3, d, $b)
    }

    function Ol(a, b) {
        const c = a.indexOf("11");
        if (c === -1) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var Pl = "a".charCodeAt(),
        Ql = zd(jh),
        Rl = zd(kh);

    function Sl() {
        var a = new Tl;
        return hd(a, 1, 0)
    }

    function Ul(a) {
        var b = Number; {
            var c = z(a, 1);
            const d = typeof c;
            c = c == null ? c : d === "bigint" ? String(Qb(64, c)) : Xb(c) ? d === "string" ? ec(c) : hc(c) : void 0
        }
        b = b(c ? ? "0");
        a = bd(a, 2);
        return new Date(b * 1E3 + a / 1E6)
    }
    var Tl = class extends M {};

    function Vl(a, b) {
        if (a.g + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.i.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function Wl(a) {
        let b = Vl(a, 12);
        const c = [];
        for (; b--;) {
            var d = !!Vl(a, 1) === !0,
                e = Vl(a, 16);
            if (d)
                for (d = Vl(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function Xl(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (Vl(a, 1)) {
                const f = e + 1;
                if (c && c.indexOf(f) === -1) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function Yl(a) {
        const b = Vl(a, 16);
        return !!Vl(a, 1) === !0 ? (a = Wl(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : Xl(a, b)
    }
    var Zl = class {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.i = a;
            this.g = 0
        }
        skip(a) {
            this.g += a
        }
    };
    var am = (a, b) => {
        try {
            var c = Ua(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new Zl(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = b;
            d.skip(78);
            c.cmpId = Vl(d, 12);
            c.cmpVersion = Vl(d, 12);
            d.skip(30);
            c.tcfPolicyVersion = Vl(d, 6);
            c.isServiceSpecific = !!Vl(d, 1);
            c.useNonStandardStacks = !!Vl(d, 1);
            c.specialFeatureOptins = $l(Xl(d, 12, Rl), Rl);
            c.purpose = {
                consents: $l(Xl(d, 24, Ql), Ql),
                legitimateInterests: $l(Xl(d, 24, Ql), Ql)
            };
            c.purposeOneTreatment = !!Vl(d, 1);
            c.publisherCC = String.fromCharCode(Pl + Vl(d, 6)) + String.fromCharCode(Pl +
                Vl(d, 6));
            c.vendor = {
                consents: $l(Yl(d), null),
                legitimateInterests: $l(Yl(d), null)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const $l = (a, b) => {
        const c = {};
        if (Array.isArray(b) && b.length !== 0)
            for (const d of b) c[d] = a.indexOf(d) !== -1;
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var bm = class extends M {
        g() {
            return G(this, 2) != null
        }
    };
    var cm = class extends M {
        g() {
            return G(this, 2) != null
        }
    };
    var dm = class extends M {};
    var em = nd(class extends M {});

    function fm(a) {
        a = gm(a);
        try {
            var b = a ? em(a) : null
        } catch (c) {
            b = null
        }
        return b ? E(b, dm, 4) || null : null
    }

    function gm(a) {
        a = (new il(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };
    zd(jh).map(a => Number(a));
    zd(kh).map(a => Number(a));

    function hm(a) {
        a.__tcfapiPostMessageReady || im(new jm(a))
    }

    function im(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.l.__tcfapi)(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = e.command === "removeEventListener" ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.l.addEventListener("message", a.g);
        a.l.__tcfapiPostMessageReady = !0
    }
    var jm = class {
        constructor(a) {
            this.l = a
        }
    };

    function km(a) {
        a.__uspapiPostMessageReady || lm(new mm(a))
    }

    function lm(a) {
        a.g = b => {
            const c = typeof b.data === "string";
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && e.command === "getUSPData" && a.l.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.l.addEventListener("message", a.g);
        a.l.__uspapiPostMessageReady = !0
    }
    var mm = class {
        constructor(a) {
            this.l = a;
            this.g = null
        }
    };
    var nm = class extends M {};
    var om = nd(class extends M {
        g() {
            return G(this, 1) != null
        }
    });

    function pm(a, b) {
        function c(m) {
            if (m.length < 10) return null;
            var r = h(m.slice(0, 4));
            r = k(r);
            m = h(m.slice(6, 10));
            m = l(m);
            return "1" + r + m + "N"
        }

        function d(m) {
            if (m.length < 10) return null;
            var r = h(m.slice(0, 6));
            r = k(r);
            m = h(m.slice(6, 10));
            m = l(m);
            return "1" + r + m + "N"
        }

        function e(m) {
            if (m.length < 12) return null;
            var r = h(m.slice(0, 6));
            r = k(r);
            m = h(m.slice(8, 12));
            m = l(m);
            return "1" + r + m + "N"
        }

        function f(m) {
            if (m.length < 18) return null;
            var r = h(m.slice(0, 8));
            r = k(r);
            m = h(m.slice(12, 18));
            m = l(m);
            return "1" + r + m + "N"
        }

        function g(m) {
            if (m.length < 10) return null;
            var r = h(m.slice(0, 6));
            r = k(r);
            m = h(m.slice(6, 10));
            m = l(m);
            return "1" + r + m + "N"
        }

        function h(m) {
            const r = [];
            let x = 0;
            for (let t = 0; t < m.length / 2; t++) r.push(Ll(m.slice(x, x + 2))), x += 2;
            return r
        }

        function k(m) {
            return m.every(r => r === 1) ? "Y" : "N"
        }

        function l(m) {
            return m.some(r => r === 1) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = Kl(a[0]);
        const n = Ll(a.slice(0, 6));
        a = a.slice(6);
        if (n !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function qm(a, b) {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = Ud("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };

    function rm(a) {
        var b = T(Gi);
        O !== O.top || O.__uspapi || O.frames.__uspapiLocator || (a = new sm(a, b), tm(a), um(a))
    }

    function tm(a) {
        !a.u || a.l.__uspapi || a.l.frames.__uspapiLocator || (a.l.__uspapiManager = "fc", qm(a.l, "__uspapiLocator"), qa("__uspapi", (b, c, d) => {
            typeof d === "function" && b === "getUSPData" && d({
                version: 1,
                uspString: a.i && !J(a.j, 3) ? "1---" : a.u
            }, !0)
        }, a.l), km(a.l))
    }

    function um(a) {
        !a.tcString || a.l.__tcfapi || a.l.frames.__tcfapiLocator || (a.l.__tcfapiManager = "fc", qm(a.l, "__tcfapiLocator"), a.l.__tcfapiEventListeners = a.l.__tcfapiEventListeners || [], qa("__tcfapi", (b, c, d, e) => {
            if (typeof d === "function")
                if (c && (c > 2.2 || c <= 1)) d(null, !1);
                else {
                    var f = a.l.__tcfapiEventListeners;
                    c = a.i && !J(a.j, 1);
                    switch (b) {
                        case "ping":
                            d({
                                gdprApplies: !c,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.2",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            e = f.push(d);
                            b = !c;
                            --e;
                            a.tcString ? (b = am(a.tcString, b), b.addtlConsent = a.g != null ? a.g : void 0, b.cmpStatus = "loaded", b.eventStatus = "tcloaded", e != null && (b.listenerId = e)) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && f[e] ? (f[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
                }
        }, a.l), hm(a.l))
    }

    function vm(a) {
        if (!a ? .g() || K(a, 1).length === 0 || F(a, nm, 2, C()).length === 0) return null;
        const b = K(a, 1);
        let c;
        try {
            var d = Nl(b.split("~")[0]);
            c = b.includes("~") ? b.split("~").slice(1) : []
        } catch (e) {
            return null
        }
        a = F(a, nm, 2, C()).reduce((e, f) => {
            var g = wm(e);
            g = Yc(g, 1) ? ? 0;
            var h = wm(f);
            h = Yc(h, 1) ? ? 0;
            return g > h ? e : f
        });
        d = Gc(d, 3, bc, C()).indexOf(bd(a, 1));
        return d === -1 || d >= c.length ? null : {
            uspString: pm(c[d], bd(a, 1)),
            va: Ul(wm(a))
        }
    }

    function xm(a) {
        a = a.find(b => b && L(b, 1) === 13);
        if (a ? .g()) try {
            return om(K(a, 2))
        } catch (b) {}
        return null
    }

    function wm(a) {
        return Ec(a, Tl, 2) ? E(a, Tl, 2) : Sl()
    }
    var sm = class {
        constructor(a, b) {
            var c = O;
            this.l = c;
            this.j = a;
            this.i = b;
            a = gm(this.l.document);
            try {
                var d = a ? em(a) : null
            } catch (e) {
                d = null
            }(a = d) ? (d = E(a, cm, 5) || null, a = F(a, bm, 7, C()), a = xm(a ? ? []), d = {
                Ta: d,
                Va: a
            }) : d = {
                Ta: null,
                Va: null
            };
            a = d;
            d = vm(a.Va);
            a = a.Ta;
            a ? .g() && K(a, 2).length !== 0 ? (b = Ec(a, Tl, 1) ? E(a, Tl, 1) : Sl(), a = {
                uspString: K(a, 2),
                va: Ul(b)
            }) : a = null;
            this.u = a && d ? d.va > a.va ? d.uspString : a.uspString : a ? a.uspString : d ? d.uspString : null;
            this.tcString = (d = fm(c.document)) && G(d, 1) != null ? K(d, 1) : null;
            this.g = (c = fm(c.document)) && G(c, 2) !=
                null ? K(c, 2) : null
        }
    };
    const ym = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function zm(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        xk("ama", b, .01)
    }

    function Am(a) {
        const b = {};
        Xd(ym, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };

    function Bm(a) {
        const b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                const e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function Cm(a) {
        let b = "";
        const c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            const e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function Dm(a) {
        a = ed(a, 2);
        if (!a) return !1;
        for (let b = 0; b < a.length; b++)
            if (a[b] == 1) return !0;
        return !1
    }

    function Em(a, b) {
        a = Cm(Bm(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        const c = Yd(a),
            d = Fm(a);
        return b.find(e => {
            if (Ec(e, tj, 7)) {
                var f = E(e, tj, 7);
                f = cc(z(f, 1))
            } else f = cc(z(e, 1));
            e = Ec(e, tj, 7) ? H(E(e, tj, 7), 2) : 2;
            if (typeof f !== "number") return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function Fm(a) {
        const b = {};
        for (;;) {
            b[Yd(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };
    let Gm = void 0;

    function X(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function Hm(a) {
        a = X(a);
        const b = a.space_collapsing || "none";
        return a.remove_ads_by_default ? {
            Ra: !0,
            Mb: b,
            ta: a.ablation_viewport_offset
        } : null
    }

    function Im(a) {
        a = X(a);
        a.had_ads_ablation = !0;
        a.remove_ads_by_default = !0;
        a.space_collapsing = "slot";
        a.ablation_viewport_offset = 1
    }

    function Jm(a) {
        X(O).allow_second_reactive_tag = a
    }

    function Km() {
        const a = X(window);
        a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
        return a.afg_slotcar_vars
    };

    function Lm(a) {
        return X(a) ? .head_tag_slot_vars ? .google_ad_host ? ? Mm(a)
    }

    function Mm(a) {
        return a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };
    const Nm = [2, 7, 1];

    function Om(a, b, c = "", d = null) {
        return b === 1 && d && (Pm(a, c, d) ? .A() ? ? !1) ? !0 : Qm(a, c, e => Oa(F(e, od, 2, C()), f => H(f, 1) === b))
    }

    function Rm(a) {
        const b = Sd(O) || O;
        return Sm(b, a) ? !0 : Qm(O, "", c => Oa(ed(c, 3), d => d === a))
    }

    function Sm(a, b) {
        a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
        return !!a && Qa(a.split(","), b.toString())
    }

    function Qm(a, b, c) {
        a = Sd(a) || a;
        const d = Tm(a);
        b && (b = Ae(String(b)));
        return yd(d, (e, f) => Object.prototype.hasOwnProperty.call(d, f) && (!b || b === f) && c(e))
    }

    function Tm(a) {
        a = Um(a);
        const b = {};
        Xd(a, (c, d) => {
            try {
                const e = ld(pd, uc(c));
                b[d] = e
            } catch (e) {}
        });
        return b
    }

    function Um(a) {
        wb(Gm, zb);
        a = ul({
            l: a,
            Y: Gm
        });
        return a.g != null ? Vm(a.getValue()) : {}
    }

    function Vm(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : xd(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && typeof e === "string" && Array.isArray(d))
        } catch (b) {
            return {}
        }
    }

    function Wm(a, b) {
        if (Lm(p)) return Nm;
        if (T(Ki)) return (a = Pm(p, a, b)) ? [...ed(Sc(a, El, 6), 3)] : Nm;
        if (b ? .j()) {
            const c = K(b.g(), 9);
            b = b ? .g() ? .g() ? .g();
            return a && c === a && b ? [...ed(b, 3)] : Nm
        }
        return b ? .u() && b ? .i() ? .g() === a && K(b, 17) === p.location.host ? (a = b ? .i() ? .i() ? .g() ? .g()) ? [...ed(a, 3)] : Nm : Nm
    }

    function Xm(a, b) {
        const c = [];
        a = Wm(a, b);
        a.includes(1) || c.push(1);
        a.includes(2) || c.push(2);
        a.includes(7) || c.push(7);
        return c
    }

    function Pm(a, b, c) {
        if (!b) return null;
        const d = Ym(c) ? .u();
        a = Ym(c) ? .g() ? .g() === b && a.location.host && K(c, 17) === a.location.host;
        return d === b || a ? Ym(c) : null
    };

    function Zm(a, b, c, d) {
        $m(new an(a, b, c, d))
    }

    function $m(a) {
        zh(yh(ul({
            l: a.l,
            Y: J(a.g, 6)
        }), b => {
            bn(a, b, !0)
        }), () => {
            cn(a)
        })
    }

    function bn(a, b, c) {
        zh(yh(dn(b), d => {
            en("ok");
            a.i(d, {
                fromLocalStorage: !0
            })
        }), () => {
            var d = a.l;
            try {
                b.removeItem("google_ama_config")
            } catch (e) {
                zm(d, {
                    lserr: 1
                })
            }
            c ? cn(a) : a.i(null, null)
        })
    }

    function cn(a) {
        zh(yh(fn(a), b => {
            a.i(b, {
                fromPABGSettings: !0
            })
        }), () => {
            gn(a)
        })
    }

    function dn(a) {
        if (T(mi)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? Fj(b) : null
        } catch (d) {
            c = null
        }
        return (a = (a = c) ? (E(a, sj, 3) ? .g() ? ? 0) > Date.now() ? a : null : null) ? th(a) : vh(Error("invlocst"))
    }

    function fn(a) {
        if (Lm(a.l) && !J(a.g, 22)) return vh(Error("invtag"));
        if (a = (a = Pm(a.l, a.j, a.g) ? .j()) && (F(a, Qh, 1, C()).length > 0 || F(a, Rh, 3, C()).length > 0) ? a : null) {
            var b = new Ej;
            var c = F(a, Qh, 1, C());
            b = Wc(b, 1, c);
            a = F(a, zj, 2, C());
            a = Wc(b, 7, a);
            a = th(a)
        } else a = vh(Error("invtag"));
        return a
    }

    function gn(a) {
        yl({
            l: a.l,
            Y: J(a.g, 6),
            hb: 50,
            rb: b => {
                hn(a, b)
            }
        })
    }

    function hn(a, b) {
        zh(yh(b, c => {
            bn(a, c, !1)
        }), c => {
            en(c.message);
            a.i(null, null)
        })
    }

    function en(a) {
        xk("abg::amalserr", {
            status: a,
            guarding: "true",
            timeout: 50,
            rate: .01
        }, .01)
    }
    class an {
        constructor(a, b, c, d) {
            this.l = a;
            this.g = b;
            this.j = c;
            this.i = d
        }
    };

    function jn(a, b, c, d) {
        var e = kn;
        try {
            const f = Em(a, F(c, zj, 7, C()));
            if (f && Dm(f)) {
                (G(f, 4) ? ? void 0) && (d = Ih(d, new Jh(null, {
                    google_package: G(f, 4) ? ? void 0
                })));
                const g = e(a, b, c, f, d);
                Qj(1E3, () => {
                    const h = new oh;
                    (new Il(a, g, h)).start();
                    return h.i
                }, a).then(() => {
                    zm(a, {
                        atf: 1
                    })
                }, h => {
                    (a.google_ama_state = a.google_ama_state || {}).exception = h;
                    zm(a, {
                        atf: 0
                    })
                })
            }
        } catch (f) {
            zm(a, {
                atf: -1
            })
        }
    }

    function kn(a, b, c, d, e) {
        return new Zk(a, b, c, d, e)
    };

    function ln(a) {
        return a.length ? a.join("~") : void 0
    };

    function mn(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (a.indexOf(b) != -1) return !0;
        b = nn(b);
        return b != "go" && a.indexOf(b) != -1 ? !0 : !1
    }

    function nn(a) {
        let b = "";
        Xd(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    };
    var on = class extends M {};
    var pn = class extends M {
        g() {
            return K(this, 3)
        }
        i() {
            return Vb(z(this, 4)) != null
        }
    };
    var qn = class extends M {
        g() {
            return Tc(this, pn, 1)
        }
    };

    function rn(a) {
        const b = new qn;
        var c = new pn;
        var d = bd(a, 1);
        c = A(c, 1, ac(d));
        d = bd(a, 18);
        c = A(c, 2, ac(d));
        c = jd(c, 3, K(a, 2));
        c = A(c, 4, Ub(J(a, 6)));
        c = A(c, 5, Ub(J(a, 20)));
        c = A(c, 6, Ub(J(a, 9)));
        c = A(c, 7, Ub(J(a, 25)));
        c = jd(c, 8, K(a, 8));
        c = jd(c, 9, K(a, 3));
        a = E(a, on, 26);
        a = Uc(c, 10, a);
        Uc(b, 1, a);
        return b
    };
    Sa || Ha();

    function sn() {
        const a = {};
        N(he).g(ii.g, ii.defaultValue) && (a.bust = N(he).g(ii.g, ii.defaultValue));
        return a
    };
    class tn {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function un() {
        const {
            promise: a,
            resolve: b
        } = new tn;
        return {
            promise: a,
            resolve: b
        }
    };

    function vn(a = () => {}) {
        p.google_llp || (p.google_llp = {});
        const b = p.google_llp;
        let c = b[7];
        if (c) return c;
        c = un();
        b[7] = c;
        a();
        return c
    }

    function wn(a) {
        return vn(() => {
            Td(p.document, a)
        }).promise
    };

    function xn(a) {
        a.google_reactive_ads_global_state ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements == null && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), a.google_reactive_ads_global_state.sideRailAvailableSpace == null && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), a.google_reactive_ads_global_state.sideRailPlasParam == null && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map), a.google_reactive_ads_global_state.sideRailMutationCallbacks ==
            null && (a.google_reactive_ads_global_state.sideRailMutationCallbacks = [])) : a.google_reactive_ads_global_state = new yn;
        return a.google_reactive_ads_global_state
    }
    var yn = class {
            constructor() {
                this.wasPlaTagProcessed = !1;
                this.wasReactiveAdConfigReceived = {};
                this.adCount = {};
                this.wasReactiveAdVisible = {};
                this.stateForType = {};
                this.reactiveTypeEnabledInAsfe = {};
                this.wasReactiveTagRequestSent = !1;
                this.reactiveTypeDisabledByPublisher = {};
                this.tagSpecificState = {};
                this.messageValidationEnabled = !1;
                this.floatingAdsStacking = new zn;
                this.sideRailProcessedFixedElements = new Set;
                this.sideRailAvailableSpace = new Map;
                this.sideRailPlasParam = new Map;
                this.sideRailMutationCallbacks = [];
                this.clickTriggeredInterstitialMayBeDisplayed = !1
            }
        },
        zn = class {
            constructor() {
                this.maxZIndexRestrictions = {};
                this.nextRestrictionId = 0;
                this.maxZIndexListeners = []
            }
        };
    var An = a => {
        if (p.google_apltlad || a.google_ad_intent_query) return null;
        var b = a.google_loader_used !== "sd" && T(pi) && (p.top == p ? 0 : Rd(p.top) ? 1 : 2) === 1;
        if (p !== p.top && !b || !a.google_ad_client) return null;
        p.google_apltlad = !0;
        b = {
            enable_page_level_ads: {
                pltais: !0
            },
            google_ad_client: a.google_ad_client
        };
        const c = b.enable_page_level_ads;
        Xd(a, (d, e) => {
            oj[e] && e !== "google_ad_client" && (c[e] = d)
        });
        c.google_pgb_reactive = 7;
        c.asro = T(Bi);
        c.aihb = T(qi);
        c.ailel = ln(Pi(zi));
        c.aiael = ln(Pi(si));
        c.aicel = ln(Pi(ui));
        c.aifxl = ln(Pi(wi));
        c.aiixl =
            ln(Pi(xi));
        U(Di) && (c.aiapm = U(Di));
        U(Ei) && (c.aiapmi = U(Ei));
        U(ri) && (c.aiact = U(ri));
        U(ti) && (c.aicct = U(ti));
        U(yi) && (c.ailct = U(yi));
        T(vi) && (c.aiescf = !0);
        c.aiof = ln(Pi(Ai));
        if ("google_ad_section" in a || "google_ad_region" in a) c.google_ad_section = a.google_ad_section || a.google_ad_region;
        return b
    };

    function Bn(a, b) {
        X(O).ama_ran_on_page || Qj(1001, () => {
            Cn(new Dn(a, b))
        }, p)
    }

    function Cn(a) {
        Zm(a.l, a.i, a.g.google_ad_client || "", (b, c) => {
            var d = a.l,
                e = a.g;
            X(O).ama_ran_on_page || b && En(d, e, b, c)
        })
    }
    class Dn {
        constructor(a, b) {
            this.l = p;
            this.g = a;
            this.i = b
        }
    }

    function En(a, b, c, d) {
        d && (Vj(a).configSourceInAbg = d);
        Ec(c, Dj, 24) && (d = Wj(a), d.availableAbg = !0, d.ablationFromStorage = !!E(c, Dj, 24) ? .g() ? .g());
        if (ja(b.enable_page_level_ads) && b.enable_page_level_ads.google_pgb_reactive === 7) {
            if (!Em(a, F(c, zj, 7, C()))) {
                xk("amaait", {
                    value: "true"
                });
                return
            }
            xk("amaait", {
                value: "false"
            })
        }
        X(O).ama_ran_on_page = !0;
        E(c, rj, 15) ? .g() && (X(a).enable_overlap_observer = !0);
        E(c, Dj, 24) ? .g() ? .g() && (Wj(a).ablatingThisPageview = !0, Im(a));
        se(3, [wc(c)]);
        const e = b.google_ad_client || "";
        b = Am(ja(b.enable_page_level_ads) ?
            b.enable_page_level_ads : {});
        const f = Ih(Mh, new Jh(null, b));
        uk(782, () => {
            jn(a, e, c, f)
        })
    };

    function Fn(a, b) {
        a = a.document;
        for (var c = void 0, d = 0; !c || a.getElementById(c + "_host");) c = "aswift_" + d++;
        a = c;
        c = Number(b.google_ad_width || 0);
        b = Number(b.google_ad_height || 0);
        d = document.createElement("div");
        d.id = a + "_host";
        const e = d.style;
        e.border = "none";
        e.height = `${b}px`;
        e.width = `${c}px`;
        e.margin = "0px";
        e.padding = "0px";
        e.position = "relative";
        e.visibility = "visible";
        e.backgroundColor = "transparent";
        e.display = "inline-block";
        return {
            yb: a,
            Pb: d
        }
    };

    function Gn({
        ua: a,
        Ba: b
    }) {
        return a || (b === "dev" ? "dev" : "")
    };

    function Hn(a) {
        return a.google_ad_client ? String(a.google_ad_client) : X(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client") ? ? ""
    };
    var In = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function Jn(a, b) {
        if (b == 15) {
            if (a >= 728) return 728;
            if (a >= 468) return 468
        } else if (b == 90) {
            if (a >= 200) return 200;
            if (a >= 180) return 180;
            if (a >= 160) return 160;
            if (a >= 120) return 120
        }
        return null
    };
    var Kn = class extends M {
        getVersion() {
            return K(this, 2)
        }
    };

    function Ln(a, b) {
        return jd(a, 2, b)
    }

    function Mn(a, b) {
        return jd(a, 3, b)
    }

    function Nn(a, b) {
        return jd(a, 4, b)
    }

    function On(a, b) {
        return jd(a, 5, b)
    }

    function Pn(a, b) {
        return jd(a, 9, b)
    }

    function Qn(a, b) {
        return Wc(a, 10, b)
    }

    function Rn(a, b) {
        return A(a, 11, Ub(b))
    }

    function Sn(a, b) {
        return jd(a, 1, b)
    }

    function Tn(a, b) {
        return A(a, 7, Ub(b))
    }
    var Un = class extends M {};
    const Vn = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function Wn() {
        var a = O;
        if (typeof a.navigator ? .userAgentData ? .getHighEntropyValues !== "function") return null;
        const b = a.google_tag_data ? ? (a.google_tag_data = {});
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Vn).then(c => {
            b.uach ? ? (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function Xn(a) {
        return Rn(Qn(On(Ln(Sn(Nn(Tn(Pn(Mn(new Un, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), a.fullVersionList ? .map(b => {
            var c = new Kn;
            c = jd(c, 1, b.brand);
            return jd(c, 2, b.version)
        }) || []), a.wow64 || !1)
    }

    function Yn() {
        return Wn() ? .then(a => Xn(a)) ? ? null
    };

    function Zn(a, b) {
        b.google_ad_host || (a = Mm(a)) && (b.google_ad_host = a)
    }

    function $n(a, b, c = "") {
        O.google_sa_queue || (O.google_sa_queue = [], O.google_process_slots = vk(215, () => {
            ao(O.google_sa_queue)
        }), a = bo(c, a, b), Td(O.document, a))
    }

    function ao(a) {
        const b = a.shift();
        typeof b === "function" && uk(216, b);
        a.length && p.setTimeout(vk(215, () => {
            ao(a)
        }), 0)
    }

    function co(a, b) {
        a.google_sa_queue = a.google_sa_queue || [];
        a.google_sa_impl ? b() : a.google_sa_queue.push(b)
    }

    function bo(a, b, c) {
        var d = O;
        b = J(c, 4) ? b.Ib : b.Jb;
        a: {
            if (J(c, 4)) {
                if (a = a || Hn(d)) {
                    b: {
                        try {
                            for (; d;) {
                                if (d.location ? .hostname) {
                                    var e = d.location.hostname;
                                    break b
                                }
                                d = d.parent
                            }
                        } catch (f) {}
                        e = ""
                    }
                    e = {
                        client: Ae(a),
                        plah: e
                    };
                    break a
                }
                throw Error("PublisherCodeNotFoundForAma");
            }
            e = {}
        }
        e = { ...e,
            ...sn()
        };
        d = U(Hi);
        !J(c, 4) && [0, 1].includes(d) && (e.osttc = `${d}`);
        return Pd(b, new Map(Object.entries(e)))
    }

    function eo(a, b, c, d) {
        const {
            yb: e,
            Pb: f
        } = Fn(a, b);
        c.appendChild(f);
        fo(a, c, b);
        c = b.google_start_time ? ? ih;
        const g = (new Date).getTime();
        b.google_lrv = Gn({
            ua: hg(),
            Ba: K(d, 2)
        });
        b.google_async_iframe_id = e;
        b.google_start_time = c;
        b.google_bpp = g > c ? g - c : 1;
        a.google_sv_map = a.google_sv_map || {};
        a.google_sv_map[e] = b;
        co(a, () => {
            var h = f;
            if (!h || !h.isConnected)
                if (h = a.document.getElementById(String(b.google_async_iframe_id) + "_host"), h == null) throw Error("no_div");
            (h = a.google_sa_impl({
                pubWin: a,
                vars: b,
                innerInsElement: h
            })) && wk(911,
                h)
        })
    }

    function fo(a, b, c) {
        var d = c.google_ad_output,
            e = c.google_ad_format,
            f = c.google_ad_width || 0,
            g = c.google_ad_height || 0;
        e || d !== "html" && d != null || (e = `${f}x${g}`);
        T(Ni) && (c.google_reactive_ad_format === 10 ? e = "interstitial" : c.google_reactive_ad_format === 11 && (e = "rewarded"));
        d = !c.google_ad_slot || c.google_override_format || !In[c.google_ad_width + "x" + c.google_ad_height] && c.google_loader_used === "aa";
        e = e && d ? e.toLowerCase() : "";
        c.google_ad_format = e;
        if (typeof c.google_reactive_sra_index !== "number" || !c.google_ad_unit_key) {
            e = [c.google_ad_slot,
                c.google_orig_ad_format || c.google_ad_format, c.google_ad_type, c.google_orig_ad_width || c.google_ad_width, c.google_orig_ad_height || c.google_ad_height
            ];
            d = [];
            f = 0;
            for (g = b; g && f < 25; g = g.parentNode, ++f) g.nodeType === 9 ? d.push("") : d.push(g.id);
            (d = d.join()) && e.push(d);
            c.google_ad_unit_key = Yd(e.join(":")).toString();
            e = [];
            for (d = 0; b && d < 25; ++d) {
                f = (f = b.nodeType !== 9 && b.id) ? "/" + f : "";
                a: {
                    if (b && b.nodeName && b.parentElement) {
                        g = b.nodeName.toString().toLowerCase();
                        const h = b.parentElement.childNodes;
                        let k = 0;
                        for (let l = 0; l < h.length; ++l) {
                            const n =
                                h[l];
                            if (n.nodeName && n.nodeName.toString().toLowerCase() === g) {
                                if (b === n) {
                                    g = "." + k;
                                    break a
                                }++k
                            }
                        }
                    }
                    g = ""
                }
                e.push((b.nodeName && b.nodeName.toString().toLowerCase()) + f + g);
                b = b.parentElement
            }
            b = e.join() + ":";
            e = [];
            if (a) try {
                let h = a.parent;
                for (d = 0; h && h !== a && d < 25; ++d) {
                    const k = h.frames;
                    for (f = 0; f < k.length; ++f)
                        if (a === k[f]) {
                            e.push(f);
                            break
                        }
                    a = h;
                    h = a.parent
                }
            } catch (h) {}
            c.google_ad_dom_fingerprint = Yd(b + e.join()).toString()
        }
    }

    function go() {
        var a = Sd(p);
        a && (a = xn(a), a.tagSpecificState[1] || (a.tagSpecificState[1] = {
            debugCard: null,
            debugCardRequested: !1
        }))
    }

    function ho() {
        const a = Yn();
        a != null && a.then(b => {
            O.google_user_agent_client_hint = JSON.stringify(wc(b))
        });
        ge()
    };
    var io = class {
        constructor(a, b) {
            this.g = a;
            this.u = b
        }
        height() {
            return this.u
        }
        i(a) {
            return a > U(li) && this.u > 300 ? this.g : Math.min(1200, Math.round(a))
        }
        j() {}
    };

    function jo(a) {
        return b => !!(b.X() & a)
    }
    var Y = class extends io {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.B = c;
            this.A = d
        }
        X() {
            return this.B
        }
        j(a, b, c) {
            c.style.height = `${this.height()}px`;
            b.rpe = !0
        }
    };
    const ko = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        lo = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        mo = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function no(a) {
        var b = 0;
        a.O && b++;
        a.J && b++;
        a.K && b++;
        if (b < 3) return {
            W: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.O.split(",");
        const c = a.K.split(",");
        a = a.J.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            W: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (b.length > 2) return {
            W: "The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while " + `you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        const d = [],
            e = [];
        for (let g = 0; g <
            b.length; g++) {
            var f = Number(c[g]);
            if (Number.isNaN(f) || f === 0) return {
                W: `Wrong value '${c[g]}' for ${"data-matched-content-rows-num"}.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || f === 0) return {
                W: `Wrong value '${a[g]}' for ${"data-matched-content-columns-num"}.`
            };
            e.push(f)
        }
        return {
            K: d,
            J: e,
            Za: b
        }
    }

    function oo(a) {
        return a >= 1200 ? {
            width: 1200,
            height: 600
        } : a >= 850 ? {
            width: a,
            height: Math.floor(a * .5)
        } : a >= 550 ? {
            width: a,
            height: Math.floor(a * .6)
        } : a >= 468 ? {
            width: a,
            height: Math.floor(a * .7)
        } : {
            width: a,
            height: Math.floor(a * 3.44)
        }
    }

    function po(a, b, c, d) {
        b = Math.floor(((a - 8 * b - 8) / b * ko[d] + lo[d]) * c + 8 * c + 8);
        return a > 1500 ? {
            width: 0,
            height: 0,
            Kb: `Calculated slot width is too large: ${a}`
        } : b > 1500 ? {
            width: 0,
            height: 0,
            Kb: `Calculated slot height is too large: ${b}`
        } : {
            width: a,
            height: b
        }
    }

    function qo(a, b) {
        const c = a - 8 - 8;
        --b;
        return {
            width: a,
            height: Math.floor(c / 1.91 + 70) + Math.floor((c * ko.mobile_banner_image_sidebyside + lo.mobile_banner_image_sidebyside) * b + 8 * b + 8)
        }
    };
    const ro = Ra("script");
    var so = class {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, l = null, n = null, m = null) {
            this.F = a;
            this.U = b;
            this.X = c;
            this.g = d;
            this.I = e;
            this.D = f;
            this.N = g;
            this.u = h;
            this.A = k;
            this.i = l;
            this.j = n;
            this.B = m
        }
        size() {
            return this.U
        }
    };
    const to = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var uo = class extends io {
        i(a) {
            return Math.min(1200, Math.max(this.g, Math.round(a)))
        }
    };

    function vo(a, b) {
        wo(a, b);
        if (b.google_content_recommendation_ui_type === "pedestal") return new so(9, new uo(a, Math.floor(a * b.google_phwr)));
        if (T(Yh)) {
            var c = vd();
            var d = U(Zh);
            var e = U(Xh),
                f = U(Wh);
            a < 468 ? c ? (a = qo(a, d), d = {
                V: a.width,
                T: a.height,
                J: 1,
                K: d,
                O: "mobile_banner_image_sidebyside"
            }) : (a = po(a, 1, d, "image_sidebyside"), d = {
                V: a.width,
                T: a.height,
                J: 1,
                K: d,
                O: "image_sidebyside"
            }) : (d = oo(a), e === 1 && (d.height = Math.floor(d.height * .5)), d = {
                V: d.width,
                T: d.height,
                J: f,
                K: e,
                O: "image_stacked"
            })
        } else d = vd(), a < 468 ? d ? (d = qo(a, 12), d = {
            V: d.width,
            T: d.height,
            J: 1,
            K: 12,
            O: "mobile_banner_image_sidebyside"
        }) : (d = oo(a), d = {
            V: d.width,
            T: d.height,
            J: 1,
            K: 13,
            O: "image_sidebyside"
        }) : (d = oo(a), d = {
            V: d.width,
            T: d.height,
            J: 4,
            K: 2,
            O: "image_stacked"
        });
        xo(b, d);
        return new so(9, new uo(d.V, d.T))
    }

    function yo(a, b) {
        wo(a, b); {
            const f = no({
                K: b.google_content_recommendation_rows_num,
                J: b.google_content_recommendation_columns_num,
                O: b.google_content_recommendation_ui_type
            });
            if (f.W) a = {
                V: 0,
                T: 0,
                J: 0,
                K: 0,
                O: "image_stacked",
                W: f.W
            };
            else {
                var c = f.Za.length === 2 && a >= 468 ? 1 : 0;
                var d = f.Za[c];
                d = d.indexOf("pub_control_") === 0 ? d : "pub_control_" + d;
                var e = mo[d];
                let g = f.J[c];
                for (; a / g < e && g > 1;) g--;
                e = g;
                c = f.K[c];
                a = po(a, e, c, d);
                a = {
                    V: a.width,
                    T: a.height,
                    J: e,
                    K: c,
                    O: d
                }
            }
        }
        if (a.W) throw new W(a.W);
        xo(b, a);
        return new so(9, new uo(a.V, a.T))
    }

    function wo(a, b) {
        if (a <= 0) throw new W(`Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`);
    }

    function xo(a, b) {
        a.google_content_recommendation_ui_type = b.O;
        a.google_content_recommendation_columns_num = b.J;
        a.google_content_recommendation_rows_num = b.K
    };
    var zo = class extends io {
        i() {
            return this.g
        }
        j(a, b, c) {
            fj(a, c);
            c.style.height = `${this.height()}px`;
            b.rpe = !0
        }
    };
    const Ao = {
        "image-top": a => a <= 600 ? 284 + (a - 250) * .414 : 429,
        "image-middle": a => a <= 500 ? 196 - (a - 250) * .13 : 164 + (a - 500) * .2,
        "image-side": a => a <= 500 ? 205 - (a - 250) * .28 : 134 + (a - 500) * .21,
        "text-only": a => a <= 500 ? 187 - .228 * (a - 250) : 130,
        "in-article": a => a <= 420 ? a / 1.2 : a <= 460 ? a / 1.91 + 130 : a <= 800 ? a / 4 : 200
    };
    var Bo = class extends io {
        i() {
            return Math.min(1200, this.g)
        }
    };

    function Co(a, b, c, d, e) {
        var f = e.google_ad_layout || "image-top";
        if (f === "in-article") {
            var g = a;
            if (e.google_full_width_responsive === "false") a = g;
            else if (a = aj(b, c, g, U(di), e), a !== !0) e.gfwrnwer = a, a = g;
            else if (a = V(b))
                if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                    b: {
                        g = c;
                        for (let h = 0; h < 100 && g.parentElement; ++h) {
                            const k = g.parentElement.childNodes;
                            for (let l = 0; l < k.length; ++l) {
                                const n = k[l];
                                if (n !== g && dj(b, n)) break b
                            }
                            g = g.parentElement;
                            g.style.width = "100%";
                            g.style.height = "auto"
                        }
                    }
                    fj(b, c)
                }
            else a = g;
            else a =
                g
        }
        if (a < 250) throw new W("Fluid responsive ads must be at least 250px wide: " + `availableWidth=${a}`);
        a = Math.min(1200, Math.floor(a));
        if (d && f !== "in-article") {
            f = Math.ceil(d);
            if (f < 50) throw new W("Fluid responsive ads must be at least 50px tall: " + `height=${f}`);
            return new so(11, new io(a, f))
        }
        if (f !== "in-article" && (d = e.google_ad_layout_key)) {
            f = `${d}`;
            if (d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length)
                for (b = [], e = 0; e < d; e++) b.push(parseInt(c[e], 36) / 1E3);
            else b = null;
            if (!b) throw new W(`Invalid data-ad-layout-key value: ${f}`);
            f = (a + -725) / 1E3;
            c = 0;
            d = 1;
            e = b.length;
            for (g = 0; g < e; g++) c += b[g] * d, d *= f;
            f = Math.ceil(c * 1E3 - -725 + 10);
            if (isNaN(f)) throw new W(`Invalid height: height=${f}`);
            if (f < 50) throw new W("Fluid responsive ads must be at least 50px tall: " + `height=${f}`);
            if (f > 1200) throw new W("Fluid responsive ads must be at most 1200px tall: " + `height=${f}`);
            return new so(11, new io(a, f))
        }
        d = Ao[f];
        if (!d) throw new W("Invalid data-ad-layout value: " + f);
        c = lj(c, b);
        b = V(b);
        b = f !== "in-article" || c || a !== b ? Math.ceil(d(a)) : Math.ceil(d(a) * 1.25);
        return new so(11,
            f === "in-article" ? new Bo(a, b) : new io(a, b))
    };

    function Do(a) {
        return b => {
            for (let c = a.length - 1; c >= 0; --c)
                if (!a[c](b)) return !1;
            return !0
        }
    }

    function Eo(a, b) {
        var c = Fo.slice(0);
        const d = c.length;
        let e = null;
        for (let f = 0; f < d; ++f) {
            const g = c[f];
            if (a(g)) {
                if (b == null || b(g)) return g;
                e === null && (e = g)
            }
        }
        return e
    };
    var Z = [new Y(970, 90, 2), new Y(728, 90, 2), new Y(468, 60, 2), new Y(336, 280, 1), new Y(320, 100, 2), new Y(320, 50, 2), new Y(300, 600, 4), new Y(300, 250, 1), new Y(250, 250, 1), new Y(234, 60, 2), new Y(200, 200, 1), new Y(180, 150, 1), new Y(160, 600, 4), new Y(125, 125, 1), new Y(120, 600, 4), new Y(120, 240, 4), new Y(120, 120, 1, !0)],
        Fo = [Z[6], Z[12], Z[3], Z[0], Z[7], Z[14], Z[1], Z[8], Z[10], Z[4], Z[15], Z[2], Z[11], Z[5], Z[13], Z[9], Z[16]];

    function Go(a, b, c, d, e) {
        e.google_full_width_responsive === "false" ? c = {
            H: a,
            D: 1
        } : b === "autorelaxed" && e.google_full_width_responsive || Ho(b) || e.google_ad_resize ? (b = bj(a, c, d, e), c = b !== !0 ? {
            H: a,
            D: b
        } : {
            H: V(c) || a,
            D: !0
        }) : c = {
            H: a,
            D: 2
        };
        const {
            H: f,
            D: g
        } = c;
        return g !== !0 ? {
            H: a,
            D: g
        } : d.parentElement ? {
            H: f,
            D: g
        } : {
            H: a,
            D: g
        }
    }

    function Io(a, b, c, d, e) {
        const {
            H: f,
            D: g
        } = uk(247, () => Go(a, b, c, d, e));
        var h = g === !0;
        const k = be(d.style.width),
            l = be(d.style.height),
            {
                U: n,
                N: m,
                X: r,
                Ya: x
            } = Jo(f, b, c, d, e, h);
        h = Ko(b, r);
        var t;
        const v = (t = gj(d, c, "marginLeft")) ? `${t}px` : "",
            I = (t = gj(d, c, "marginRight")) ? `${t}px` : "";
        t = ij(d, c) || "";
        return new so(h, n, r, null, x, g, m, v, I, l, k, t)
    }

    function Ho(a) {
        return a === "auto" || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
    }

    function Jo(a, b, c, d, e, f) {
        b = Lo(c, a, b);
        let g;
        var h = !1;
        let k = !1;
        var l = V(c) < 488;
        if (l) {
            g = Wi(d, c);
            var n = lj(d, c);
            h = !n && g;
            k = n && g
        }
        n = [jj(a), jo(b)];
        T(ji) || n.push(kj(l, c, d, k));
        e.google_max_responsive_height != null && n.push(mj(e.google_max_responsive_height));
        l = [t => !t.A];
        if (h || k) h = nj(c, d), l.push(mj(h));
        const m = Eo(Do(n), Do(l));
        if (!m) throw new W(`No slot size for availableWidth=${a}`);
        const {
            U: r,
            N: x
        } = uk(248, () => {
            var t;
            a: if (f) {
                if (e.gfwrnh && (t = be(e.gfwrnh))) {
                    t = {
                        U: new zo(a, t),
                        N: !0
                    };
                    break a
                }
                t = U(fi);
                t = t > 0 ? a / t : a / 1.2;
                if (e.google_resizing_allowed ||
                    e.google_full_width_responsive === "true") var v = Infinity;
                else {
                    v = d;
                    let P = Infinity;
                    do {
                        var I = gj(v, c, "height");
                        I && (P = Math.min(P, I));
                        (I = gj(v, c, "maxHeight")) && (P = Math.min(P, I))
                    } while (v.parentElement && (v = v.parentElement) && v.tagName !== "HTML");
                    v = P
                }!(T(hi) && v <= t * 2) && (v = Math.min(t, v), v < t * .5 || v < 100) && (v = t);
                t = {
                    U: new zo(a, Math.floor(v)),
                    N: v < t ? 102 : !0
                }
            } else t = {
                U: m,
                N: 100
            };
            return t
        });
        return e.google_ad_layout === "in-article" && Mo(c) ? {
            U: No(a, c, d, r, e),
            N: !1,
            X: b,
            Ya: g
        } : {
            U: r,
            N: x,
            X: b,
            Ya: g
        }
    }

    function Ko(a, b) {
        if (a === "auto") return 1;
        switch (b) {
            case 2:
                return 2;
            case 1:
                return 3;
            case 4:
                return 4;
            case 3:
                return 5;
            case 6:
                return 6;
            case 5:
                return 7;
            case 7:
                return 8;
            default:
                throw Error("bad mask");
        }
    }

    function Lo(a, b, c) {
        if (c === "auto") c = Math.min(1200, V(a)), b = b / c <= .25 ? 4 : 3;
        else {
            b = 0;
            for (const d in Ti) c.indexOf(d) !== -1 && (b |= Ti[d])
        }
        return b
    }

    function No(a, b, c, d, e) {
        const f = e.google_ad_height || gj(c, b, "height");
        b = Co(a, b, c, f, e).size();
        return b.g * b.height() > a * d.height() ? new Y(b.g, b.height(), 1) : d
    }

    function Mo(a) {
        return T(Vh) || a.location && a.location.hash === "#hffwroe2etoq"
    };

    function Oo(a, b, c, d, e) {
        var f;
        (f = V(b)) ? V(b) < 488 ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, fj(b, c), f = {
            H: f,
            D: !0
        }) : f = {
            H: a,
            D: 5
        } : f = {
            H: a,
            D: 4
        }: f = {
            H: a,
            D: 10
        };
        const {
            H: g,
            D: h
        } = f;
        if (h !== !0 || a === g) return new so(12, new io(a, d), null, null, !0, h, 100);
        const {
            U: k,
            N: l,
            X: n
        } = Jo(g, "auto", b, c, e, !0);
        return new so(1, k, n, 2, !0, h, l)
    };

    function Po(a, b) {
        var c = b.google_ad_format;
        if (c === "autorelaxed") {
            a: {
                if (b.google_content_recommendation_ui_type !== "pedestal")
                    for (const d of to)
                        if (b[d] != null) {
                            a = !0;
                            break a
                        }
                a = !1
            }
            return a ? 9 : 5
        }
        if (Ho(c)) return 1;
        if (c === "link") return 4;
        if (c === "fluid") {
            if (c = b.google_ad_layout === "in-article") c = T(ai) || a.location && (a.location.hash === "#hffwroe2etop" || a.location.hash === "#hffwroe2etoq");
            return c ? (Qo(b), 1) : 8
        }
        if (b.google_reactive_ad_format === 27) return Qo(b), 1
    }

    function Ro(a, b, c, d, e = !1) {
        var f = b.offsetWidth || (c.google_ad_resize || e) && gj(b, d, "width") || c.google_ad_width || 0;
        a === 4 && (c.google_ad_format = "auto", a = 1);
        e = (e = So(a, f, b, c, d)) ? e : Io(f, c.google_ad_format, d, b, c);
        e.size().j(d, c, b);
        e.X != null && (c.google_responsive_formats = e.X);
        e.I != null && (c.google_safe_for_responsive_override = e.I);
        e.D != null && (e.D === !0 ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = e.D));
        e.N != null && e.N !== !0 && (c.gfwrnher = e.N);
        d = e.j || c.google_ad_width;
        d != null && (c.google_resizing_width = d);
        d = e.i || c.google_ad_height;
        d != null && (c.google_resizing_height = d);
        d = e.size().i(f);
        const g = e.size().height();
        c.google_ad_width = d;
        c.google_ad_height = g;
        var h = e.size();
        f = `${h.i(f)}x${h.height()}`;
        c.google_ad_format = f;
        c.google_responsive_auto_format = e.F;
        e.g != null && (c.armr = e.g);
        c.google_ad_resizable = !0;
        c.google_override_format = 1;
        c.google_loader_features_used = 128;
        e.D === !0 && (c.gfwrnh = `${e.size().height()}px`);
        e.u != null && (c.gfwroml = e.u);
        e.A != null && (c.gfwromr = e.A);
        e.i != null &&
            (c.gfwroh = e.i);
        e.j != null && (c.gfwrow = e.j);
        e.B != null && (c.gfwroz = e.B);
        f = Sd(window) || window;
        mn(f.location, "google_responsive_dummy_ad") && (Qa([1, 2, 3, 4, 5, 6, 7, 8], e.F) || e.g === 1) && e.g !== 2 && (f = JSON.stringify({
            googMsgType: "adpnt",
            key_value: [{
                key: "qid",
                value: "DUMMY_AD"
            }]
        }), c.dash = `<${ro}>window.top.postMessage('${f}', '*'); 
          </${ro}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`);
        a !== 1 && (a = e.size().height(), b.style.height = `${a}px`)
    }

    function So(a, b, c, d, e) {
        const f = d.google_ad_height || gj(c, e, "height") || 0;
        switch (a) {
            case 5:
                const {
                    H: g,
                    D: h
                } = uk(247, () => Go(b, d.google_ad_format, e, c, d));
                h === !0 && b !== g && fj(e, c);
                h === !0 ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                return vo(g, d);
            case 9:
                return yo(b, d);
            case 8:
                return Co(b, e, c, f, d);
            case 10:
                return Oo(b, e, c, f, d)
        }
    }

    function Qo(a) {
        a.google_ad_format = "auto";
        a.armr = 3
    };

    function To(a, b) {
        a.google_resizing_allowed = !0;
        a.ovlp = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };

    function Uo(a, b) {
        var c = Sd(b);
        if (c) {
            c = V(c);
            const d = Vd(a, b) || {},
                e = d.direction;
            if (d.width === "0px" && d.cssFloat !== "none") return -1;
            if (e === "ltr" && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if (e === "rtl" && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function Vo(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            default:
                return b
        }
    }

    function Wo(a, b) {
        if (a.getAttribute("src")) {
            var c = a.getAttribute("src") || "",
                d = Nd(c, "client");
            d && (b.google_ad_client = Vo("google_ad_client", d));
            (c = Nd(c, "host")) && (b.google_ad_host = Vo("google_ad_host", c))
        }
        a = a.attributes;
        c = a.length;
        for (d = 0; d < c; d++) {
            var e = a[d];
            if (/data-/.test(e.name)) {
                const f = ta(e.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_"));
                b.hasOwnProperty(f) || (e = Vo(f, e.value), e !== null && (b[f] = e))
            }
        }
    }

    function Xo(a) {
        if (a = ue(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else return 12
    }

    function Yo(a, b, c, d) {
        Wo(a, b);
        if (c.document && c.document.body && !Po(c, b) && !b.google_reactive_ad_format && !b.google_ad_intent_query) {
            var e = parseInt(a.style.width, 10),
                f = Uo(a, c);
            if (f > 0 && e > f) {
                var g = parseInt(a.style.height, 10);
                e = !!In[e + "x" + g];
                let h = f;
                if (e) {
                    const k = Jn(f, g);
                    if (k) h = k, b.google_ad_format = k + "x" + g + "_0ads_al";
                    else throw new W("No slot size for availableWidth=" + f);
                }
                b.google_ad_resize = !0;
                b.google_ad_width = h;
                e || (b.google_ad_format = null, b.google_override_format = !0);
                f = h;
                a.style.width = `${f}px`;
                To(b, 4)
            }
        }
        if (T($h) ||
            V(c) < 488) {
            f = Sd(c) || c;
            g = a.offsetWidth || gj(a, c, "width") || b.google_ad_width || 0;
            e = b.google_ad_client;
            if (d = mn(f.location, "google_responsive_slot_preview") || Om(f, 1, e, d)) b: if (b.google_reactive_ad_format || b.google_ad_resize || Po(c, b) || Yi(a, b)) d = !1;
                else {
                    for (d = a; d; d = d.parentElement) {
                        f = Vd(d, c);
                        if (!f) {
                            b.gfwrnwer = 18;
                            d = !1;
                            break b
                        }
                        if (!Qa(["static", "relative"], f.position)) {
                            b.gfwrnwer = 17;
                            d = !1;
                            break b
                        }
                    }
                    if (!T(ki) && (d = U(ei), d = aj(c, a, g, d, b), d !== !0)) {
                        b.gfwrnwer = d;
                        d = !1;
                        break b
                    }
                    d = c === c.top ? !0 : !1
                }
            d ? (To(b, 1), d = !0) : d = !1
        } else d = !1;
        if (g = Po(c, b)) Ro(g, a, b, c, d);
        else {
            if (Yi(a, b)) {
                if (d = Vd(a, c)) a.style.width = d.width, a.style.height = d.height, Xi(d, b);
                b.google_ad_width || (b.google_ad_width = a.offsetWidth);
                b.google_ad_height || (b.google_ad_height = a.offsetHeight);
                b.google_loader_features_used = 256;
                b.google_responsive_auto_format = Xo(c)
            } else Xi(a.style, b);
            c.location && c.location.hash === "#gfwmrp" || b.google_responsive_auto_format === 12 && b.google_full_width_responsive === "true" ? Ro(10, a, b, c, !1) : Math.random() < .01 && b.google_responsive_auto_format ===
                12 && (a = bj(a.offsetWidth || parseInt(a.style.width, 10) || b.google_ad_width, c, a, b), a !== !0 ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
        }
    };

    function Zo(a) {
        if (a === a.top) return 0;
        for (let b = a; b && b !== b.top && Rd(b); b = b.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function $o(a, b, c) {
        for (const f of b) a: {
            b = a;
            var d = f,
                e = c;
            for (let g = 0; g < b.g.length; g++) {
                if (b.g[g].element.contains(d)) {
                    b.g[g].labels.add(e);
                    break a
                }
                if (d.contains(b.g[g].element)) {
                    b.g[g].element = d;
                    b.g[g].labels.add(e);
                    break a
                }
            }
            b.g.push({
                element: d,
                labels: new Set([e])
            })
        }
    }
    class ap {
        constructor() {
            this.g = []
        }
        getSlots() {
            return this.g
        }
    }

    function bp(a) {
        const b = Rk(a),
            c = new ap;
        $o(c, b.lb, 1);
        $o(c, b.mb, 2);
        $o(c, b.wb, 3);
        $o(c, b.Ob, 4);
        $o(c, b.nb, 5);
        $o(c, b.Eb, 6);
        return c.getSlots().map(d => {
            var e = new wf;
            var f = [...d.labels];
            e = Mc(e, 1, f, Yb);
            d = d.element.getBoundingClientRect();
            f = new vf;
            f = A(f, 1, ac(d.left + a.scrollX));
            f = A(f, 2, ac(d.top + a.scrollY));
            f = A(f, 3, ac(d.width));
            d = A(f, 4, ac(d.height));
            d = Bc(d);
            e = Uc(e, 2, d);
            return Bc(e)
        }).sort((d, e) => bd(E(d, vf, 2), 2) - bd(E(e, vf, 2), 2))
    };

    function wg(a, b, c = 0) {
        a.g.size > 0 || cp(a);
        c = Math.min(Math.max(0, c), 9);
        const d = a.g.get(c);
        d ? d.push(b) : a.g.set(c, [b])
    }

    function dp(a, b, c, d) {
        td(b, c, d);
        nl(a, () => ud(b, c, d))
    }

    function ep(a, b) {
        a.j !== 1 && (a.j = 1, a.g.size > 0 && fp(a, b))
    }

    function cp(a) {
        a.l.document.visibilityState ? dp(a, a.l.document, "visibilitychange", b => {
            a.l.document.visibilityState === "hidden" && ep(a, b);
            a.l.document.visibilityState === "visible" && (a.j = 0)
        }) : "onpagehide" in a.l ? (dp(a, a.l, "pagehide", b => {
            ep(a, b)
        }), dp(a, a.l, "pageshow", () => {
            a.j = 0
        })) : dp(a, a.l, "beforeunload", b => {
            ep(a, b)
        })
    }

    function fp(a, b) {
        for (let c = 9; c >= 0; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var gp = class extends ml {
        constructor(a) {
            super();
            this.l = a;
            this.j = 0;
            this.g = new Map
        }
    };
    async function hp(a, b) {
        var c = 10;
        return c <= 0 ? Promise.reject(Error(`wfc bad input ${c} ${200}`)) : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)))
            }, 200)
        })
    };

    function ip(a) {
        const b = a.g.pc;
        return b !== null && b !== 0 ? b : a.g.pc = ke(a.l)
    }

    function jp(a) {
        const b = a.g.wpc;
        return b !== null && b !== "" ? b : a.g.wpc = Hn(a.l)
    }

    function kp(a, b) {
        var c = new Lf;
        var d = ip(a);
        c = hd(c, 1, d);
        d = jp(a);
        c = kd(c, 2, d);
        c = hd(c, 3, a.g.sd);
        return hd(c, 7, Math.round(b || a.l.performance.now()))
    }
    async function lp(a) {
        await hp(a.l, () => !(!ip(a) || !jp(a)))
    }

    function mp(a) {
        var b = N(np);
        if (b.j) {
            var c = b.A;
            a(c);
            b.g.psi = wc(c)
        }
    }

    function op(a) {
        wg(a.u, () => {
            var b = kp(a);
            b = Vc(b, 12, Mf, a.B);
            a.j && !a.g.le.includes(3) && (a.g.le.push(3), sg(a.i, b))
        }, 9)
    }

    function pp(a) {
        const b = new Hf;
        wg(a.u, () => {
            Uc(b, 2, a.A);
            hd(b, 3, a.g.tar);
            var c = a.l;
            var d = new Af;
            var e = bp(c);
            d = Wc(d, 1, e);
            e = Bc(yf(xf(new zf, V(c)), Vi(c).clientHeight));
            d = Uc(d, 2, e);
            c = Bc(yf(xf(new zf, Vi(c).scrollWidth), Vi(c).scrollHeight));
            c = Uc(d, 3, c);
            c = Bc(c);
            Uc(b, 4, c);
            c = a.i;
            d = kp(a);
            d = Vc(d, 8, Mf, b);
            sg(c, d)
        }, 9)
    }
    async function qp(a) {
        var b = N(np);
        if (b.j && !b.g.le.includes(1)) {
            b.g.le.push(1);
            var c = b.l.performance.now();
            await lp(b);
            var d = new Df;
            a = D(d, 5, Ub(a), !1);
            d = yf(xf(new zf, Vi(b.l).scrollWidth), Vi(b.l).scrollHeight);
            a = Uc(a, 2, d);
            d = yf(xf(new zf, V(b.l)), Vi(b.l).clientHeight);
            a = Uc(a, 1, d);
            for (var e = d = b.l; d && d != d.parent;) d = d.parent, Rd(d) && (e = d);
            a = kd(a, 4, e.location.href);
            d = Zo(b.l);
            d !== 0 && (e = new Cf, d = A(e, 1, y(d)), Uc(a, 3, d));
            d = b.i;
            c = kp(b, c);
            c = Vc(c, 4, Mf, a);
            sg(d, c);
            op(b);
            pp(b)
        }
    }
    async function rp(a, b, c) {
        if (a.j && c.length && !a.g.lgdp.includes(Number(b))) {
            a.g.lgdp.push(Number(b));
            var d = a.l.performance.now();
            await lp(a);
            var e = a.i;
            a = kp(a, d);
            d = new Bf;
            b = D(d, 1, y(b), 0);
            c = Mc(b, 2, c, $b);
            c = Vc(a, 9, Mf, c);
            sg(e, c)
        }
    }
    async function sp(a, b) {
        await lp(a);
        var c = a.i;
        a = kp(a);
        a = hd(a, 3, 1);
        b = Vc(a, 10, Mf, b);
        sg(c, b)
    }
    var np = class {
        constructor(a, b) {
            this.l = ve() || window;
            this.u = b ? ? new gp(this.l);
            this.i = a ? ? new yg(2, hg(), 100, 100, !0, this.u);
            this.g = gl(bl(), 33, () => {
                const c = U(ci);
                return {
                    sd: c,
                    ssp: c > 0 && Wd() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null,
                    tar: 0,
                    cc: null
                }
            })
        }
        get j() {
            return this.g.ssp
        }
        get A() {
            return uk(1178, () => ld(Gf, uc(this.g.psi || []))) || new Gf
        }
        get B() {
            return uk(1227, () => ld(If, uc(this.g.cc || []))) || new If
        }
    };

    function tp() {
        var a = window;
        return p.google_adtest === "on" || p.google_adbreak_test === "on" || a.location.host.endsWith("h5games.usercontent.goog") || a.location.host === "gamesnacks.com" ? a.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(b => Math.floor(Number(b))).filter(b => !isNaN(b) && b > 0) || [] : []
    };

    function up(a, b) {
        return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1
    }

    function vp(a) {
        var b = O.document;
        if (b.currentScript) return up(b.currentScript, a);
        for (const c of b.scripts)
            if (up(c, a) === 0) return 0;
        return 1
    };

    function wp(a, b) {
        return {
            [3]: {
                [55]: () => a === 0,
                [23]: c => Om(O, Number(c)),
                [24]: c => Rm(Number(c)),
                [61]: () => J(b, 6),
                [63]: () => J(b, 6) || K(b, 8) === ".google.ch"
            },
            [4]: {},
            [5]: {
                [6]: () => K(b, 15)
            }
        }
    };

    function xp(a = p) {
        return a.ggeac || (a.ggeac = {})
    };

    function yp(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function zp(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    }

    function Ap(a, b = navigator) {
        try {
            return !!b.protectedAudience ? .queryFeatureSupport ? .(a)
        } catch (c) {
            return !1
        }
    };

    function Bp(a, b) {
        try {
            const d = a.split(".");
            a = p;
            let e = 0,
                f;
            for (; a != null && e < d.length; e++) f = a, a = a[d[e]], typeof a === "function" && (a = f[d[e]]());
            var c = a;
            if (typeof c === b) return c
        } catch {}
    }
    var Cp = {
        [3]: {
            [8]: a => {
                try {
                    return ia(a) != null
                } catch {}
            },
            [9]: a => {
                try {
                    var b = ia(a)
                } catch {
                    return
                }
                if (a = typeof b === "function") b = b && b.toString && b.toString(), a = typeof b === "string" && b.indexOf("[native code]") != -1;
                return a
            },
            [10]: () => window === window.top,
            [6]: a => Qa(N(ch).g(), Number(a)),
            [27]: a => {
                a = Bp(a, "boolean");
                return a !== void 0 ? a : void 0
            },
            [60]: a => {
                try {
                    return !!p.document.querySelector(a)
                } catch {}
            },
            [80]: a => {
                try {
                    return !!p.matchMedia(a).matches
                } catch {}
            },
            [69]: a => yp(a, p.document),
            [70]: a => zp(a, p.document),
            [79]: a => Ap(a,
                p.navigator)
        },
        [4]: {
            [3]: () => ce(),
            [6]: a => {
                a = Bp(a, "number");
                return a !== void 0 ? a : void 0
            }
        },
        [5]: {
            [2]: () => window.location.href,
            [3]: () => {
                try {
                    return window.top.location.hash
                } catch {
                    return ""
                }
            },
            [4]: a => {
                a = Bp(a, "string");
                return a !== void 0 ? a : void 0
            },
            [12]: a => {
                try {
                    const b = Bp(a, "string");
                    if (b !== void 0) return atob(b)
                } catch (b) {}
            }
        }
    };
    var Dp = class extends M {
        getId() {
            return bd(this, 1)
        }
    };

    function Ep(a) {
        return F(a, Dp, 2, C())
    }
    var Fp = class extends M {};
    var Gp = class extends M {};
    var Hp = class extends M {
        g() {
            return Yc(this, 2) ? ? 0
        }
        i() {
            return Yc(this, 4) ? ? 0
        }
        j() {
            return J(this, 3)
        }
    };
    var Ip = class extends M {};

    function Jp(a, b) {
        const c = new Map;
        for (const [f, g] of a[1].entries()) {
            var d = f,
                e = g;
            const {
                gb: h,
                ab: k,
                bb: l
            } = e[e.length - 1];
            c.set(d, h + k * l)
        }
        for (const f of b)
            for (const g of F(f, Fp, 2, C()))
                if (Ep(g).length !== 0) {
                    b = cc(z(g, 8)) ? ? 0;
                    !L(g, 4) || L(g, 13) || L(g, 14) || (b = c.get(L(g, 4)) ? ? 0, d = (cc(z(g, 1)) ? ? 0) * Ep(g).length, c.set(L(g, 4), b + d));
                    d = [];
                    for (e = 0; e < Ep(g).length; e++) {
                        const h = {
                            gb: b,
                            ab: cc(z(g, 1)) ? ? 0,
                            bb: Ep(g).length,
                            Db: e,
                            ga: L(f, 1),
                            oa: g,
                            R: Ep(g)[e]
                        };
                        d.push(h)
                    }
                    Kp(a[2], L(g, 10), d) || Kp(a[1], L(g, 4), d) || Kp(a[0], Ep(g)[0].getId(), d)
                }
        return a
    }

    function Kp(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        a.get(b).push(...c);
        return !0
    };

    function Lp(a = Wd()) {
        return b => Yd(`${b} + ${a}`) % 1E3
    };
    const Mp = [12, 13, 20];

    function Np(a, b) {
        var c = N(Eg).M;
        const d = lf(E(b.oa, df, 3), c);
        if (!d.success) return Cg(a.L, E(b.oa, df, 3), b.ga, b.R.getId(), d), !1;
        if (!d.value) return !1;
        c = lf(E(b.R, df, 3), c);
        return c.success ? c.value ? !0 : !1 : (Cg(a.L, E(b.R, df, 3), b.ga, b.R.getId(), c), !1)
    }

    function Op(a, b, c) {
        a.g[c] || (a.g[c] = []);
        a = a.g[c];
        a.includes(b) || a.push(b)
    }

    function Pp(a, b, c, d) {
        const e = [];
        var f;
        if (f = b !== 9) a.u[b] ? f = !0 : (a.u[b] = !0, f = !1);
        if (f) return Ag(a.L, b, c, e, [], 4), e;
        f = Mp.includes(b);
        const g = [],
            h = [];
        for (const m of [0, 1, 2])
            for (const [r, x] of a.ka[m].entries()) {
                var k = r,
                    l = x;
                const t = new Rf;
                var n = l.filter(v => v.ga === b && a.i[v.R.getId()] && Np(a, v));
                if (n.length)
                    for (const v of n) h.push(v.R);
                else if (!a.xa && (m === 2 ? (n = d[1], Nc(t, 2, Sf, y(k))) : n = d[0], k = n ? .(String(k)) ? ? (m === 2 && L(l[0].oa, 11) === 1 ? void 0 : d[0](String(k))), k !== void 0)) {
                    for (const v of l) {
                        if (v.ga !== b) continue;
                        l =
                            k - v.gb;
                        n = v.ab;
                        const I = v.bb,
                            P = v.Db;
                        l < 0 || l >= n * I || l % I !== P || !Np(a, v) || (l = L(v.oa, 13), l !== 0 && l !== void 0 && (n = a.j[String(l)], n !== void 0 && n !== v.R.getId() ? Bg(a.L, a.j[String(l)], v.R.getId(), l) : a.j[String(l)] = v.R.getId()), h.push(v.R))
                    }
                    Rc(t, Sf) !== 0 && (D(t, 3, ac(k), 0), g.push(t))
                }
            }
        for (const m of h) d = m.getId(), e.push(d), Op(a, d, f ? 4 : c), Ug(F(m, of , 2, C()), f ? Wg() : [c], a.L, d);
        Ag(a.L, b, c, e, g, 1);
        return e
    }

    function Qp(a, b) {
        b = b.map(c => new Gp(c)).filter(c => !Mp.includes(L(c, 1)));
        a.ka = Jp(a.ka, b)
    }

    function Rp(a, b) {
        Q(1, c => {
            a.i[c] = !0
        }, b);
        Q(2, (c, d, e) => Pp(a, c, d, e), b);
        Q(3, c => (a.g[c] || []).concat(a.g[4]), b);
        Q(12, c => void Qp(a, c), b);
        Q(16, (c, d) => void Op(a, c, d), b)
    }
    var Sp = class {
        constructor(a, b, c, {
            xa: d = !1,
            Ac: e = []
        } = {}) {
            this.ka = a;
            this.L = c;
            this.u = {};
            this.xa = d;
            this.g = {
                [b]: [],
                [4]: []
            };
            this.i = {};
            this.j = {};
            if (a = Ke()) {
                a = a.split(",") || [];
                for (const f of a)(a = Number(f)) && (this.i[a] = !0)
            }
            for (const f of e) this.i[f] = !0
        }
    };

    function Tp(a, b) {
        a.g = Yg(14, b, () => {})
    }
    class Up {
        constructor() {
            this.g = () => {}
        }
    }

    function Vp(a) {
        N(Up).g(a)
    };

    function Wp({
        xb: a,
        M: b,
        config: c,
        pb: d = xp(),
        qb: e = 0,
        L: f = new Dg(E(a, Hp, 5) ? .g() ? ? 0, E(a, Hp, 5) ? .i() ? ? 0, E(a, Hp, 5) ? .j() ? ? !1),
        ka: g = Jp({
            [0]: new Map,
            [1]: new Map,
            [2]: new Map
        }, F(a, Gp, 2, C(vb)))
    }) {
        d.hasOwnProperty("init-done") ? (Yg(12, d, () => {})(F(a, Gp, 2, C()).map(h => wc(h))), Yg(13, d, () => {})(F(a, of , 1, C()).map(h => wc(h)), e), b && Yg(14, d, () => {})(b), Xp(e, d)) : (Rp(new Sp(g, e, f, c), d), Zg(d), $g(d), ah(d), Xp(e, d), Ug(F(a, of , 1, C(vb)), [e], f, void 0, !0), Fg = Fg || !(!c || !c.Bb), Vp(Cp), b && Vp(b))
    }

    function Xp(a, b = xp()) {
        bh(N(ch), b, a);
        Yp(b, a);
        Tp(N(Up), b);
        N(he).B()
    }

    function Yp(a, b) {
        const c = N(he);
        c.i = (d, e) => Yg(5, a, () => !1)(d, e, b);
        c.u = (d, e) => Yg(6, a, () => 0)(d, e, b);
        c.g = (d, e) => Yg(7, a, () => "")(d, e, b);
        c.A = (d, e) => Yg(8, a, () => [])(d, e, b);
        c.j = (d, e) => Yg(17, a, () => [])(d, e, b);
        c.B = () => {
            Yg(15, a, () => {})(b)
        }
    };

    function Zp(a, b) {
        b = {
            [0]: Lp(ke(b).toString())
        };
        b = N(ch).u(a, b);
        gh.ea(1085, rp(N(np), a, b))
    }

    function $p(a, b, c) {
        var d = X(a);
        if (d.plle) Xp(1, xp(a));
        else {
            d.plle = !0;
            d = E(b, Ip, 12);
            var e = J(b, 9);
            Wp({
                xb: d,
                M: wp(c, b),
                config: {
                    xa: e && !!a.google_disable_experiments,
                    Bb: e
                },
                pb: xp(a),
                qb: 1
            });
            if (c = K(b, 15)) c = Number(c), N(ch).j(c);
            for (const f of Gc(b, 19, bc, C())) N(ch).i(f);
            Zp(12, a);
            Zp(10, a);
            a = Sd(a) || a;
            mn(a.location, "google_mc_lab") && N(ch).i(44738307)
        }
    };

    function aq(a) {
        (T(bi) ? rk : qk).Ca(b => {
            b.shv = String(a);
            b.mjsv = Gn({
                ua: hg(),
                Ba: a
            });
            const c = N(ch).g(),
                d = tp();
            b.eid = c.concat(d).join(",")
        })
    }

    function bq(a, b) {
        b = b ? .g();
        const c = b ? .i() ? J(b, 4) : J(a, 6);
        aq(b ? .g() || K(a, 2));
        wb(Gm, Cb);
        Gm = c
    };
    var cq = {
        google_pause_ad_requests: !0,
        google_user_agent_client_hint: !0
    };
    var dq = class extends M {
        g() {
            return E(this, Fl, 2)
        }
        i() {
            return J(this, 3)
        }
    };
    var eq = class extends M {
        g() {
            return K(this, 1)
        }
        i() {
            return L(this, 2)
        }
    };
    var fq = class extends M {
        u() {
            return K(this, 1)
        }
        g() {
            return E(this, eq, 2)
        }
        A() {
            return J(this, 3)
        }
        i() {
            return J(this, 4)
        }
        j() {
            return E(this, Dl, 5)
        }
    };
    var gq = class extends M {
        i() {
            return E(this, dq, 2)
        }
        g() {
            return K(this, 4)
        }
    };

    function Ym(a) {
        return gd(a, fq, 27, hq)
    }
    var jq = class extends M {
            g() {
                return gd(this, dq, 13, iq)
            }
            j() {
                return Fc(this, dq, Qc(this, iq, 13)) !== void 0
            }
            i() {
                return gd(this, gq, 14, iq)
            }
            u() {
                return Fc(this, gq, Qc(this, iq, 14)) !== void 0
            }
        },
        iq = [13, 14],
        hq = [27, 28];

    function kq(a) {
        var b = T(bi) ? rk : qk;
        try {
            if (wb(a, Bb), a.length > 0) return new jq(JSON.parse(a))
        } catch (c) {
            b.G(838, c instanceof Error ? c : Error(String(c)))
        }
        return new jq
    };

    function lq(a, b) {
        if (J(b, 22)) return 7;
        if (J(b, 16)) return 6;
        const c = Ym(b) ? .g() ? .g();
        b = Ym(b) ? .g() ? .i() ? ? 0;
        a = c === a;
        switch (b) {
            case 1:
                return a ? 9 : 8;
            case 2:
                return a ? 11 : 10;
            case 3:
                return a ? 13 : 12
        }
        return 1
    }

    function mq(a, b, c) {
        b.google_loader_used !== "sd" && (b.abgtt = lq(a, c))
    };

    function nq(a, b) {
        var c = new oq;
        try {
            if (Ia() && b.length) {
                var d = a.createElement("link");
                if (d.relList ? .supports("compression-dictionary")) {
                    var e = Od `https://pagead2.googlesyndication.com/pagead/managed/dict/${b}/${"adsbygoogle"}`;
                    if (e instanceof Ed) d.href = Gd(e).toString(), d.rel = "compression-dictionary";
                    else {
                        if (Jd.indexOf("compression-dictionary") === -1) throw Error('TrustedResourceUrl href attribute required with rel="compression-dictionary"');
                        var f = Hd.test(e) ? e : void 0;
                        f !== void 0 && (d.href = f, d.rel = "compression-dictionary")
                    }
                    a.head.appendChild(d)
                }
            }
        } catch (g) {
            c.sb.G(1296,
                g instanceof Error ? g : Error(String(g)))
        }
    };
    var oq = class {
        constructor() {
            this.sb = T(bi) ? rk : qk
        }
    };
    var pq = a => {
        td(window, "message", b => {
            let c;
            try {
                c = JSON.parse(b.data)
            } catch (d) {
                return
            }!c || c.googMsgType !== "sc-cnf" || a(c, b)
        })
    };

    function qq(a, b) {
        return b == null ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function rq(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function sq() {
        const a = new Set,
            b = Lk();
        try {
            if (!b) return a;
            const c = b.pubads();
            for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function tq(a) {
        a = a.id;
        return a != null && (sq().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function uq(a, b, c) {
        if (!a.sources) return !1;
        switch (vq(a)) {
            case 2:
                const d = wq(a);
                if (d) return c.some(f => xq(d, f));
                break;
            case 1:
                const e = yq(a);
                if (e) return b.some(f => xq(e, f))
        }
        return !1
    }

    function vq(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (a.length >= 1) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function yq(a) {
        return zq(a, b => b.currentRect)
    }

    function wq(a) {
        return zq(a, b => b.previousRect)
    }

    function zq(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && d.width * d.height !== 0 ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function xq(a, b) {
        const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return c <= 0 || a <= 0 ? !1 : c * a * 100 / ((b.right - b.left) * (b.bottom - b.top)) >= 50
    }

    function Aq() {
        const a = Array.from(document.getElementsByTagName("iframe")).filter(tq),
            b = [...sq()].map(c => document.getElementById(c)).filter(c => c !== null);
        Bq = window.scrollX;
        Cq = window.scrollY;
        return Dq = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function Eq() {
        var a = new Fq;
        if (T(Ji)) {
            var b = window;
            if (!b.google_plmetrics && window.PerformanceObserver) {
                b.google_plmetrics = !0;
                b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                a.jb.ub && b.push("event");
                for (const c of b) b = {
                    type: c,
                    buffered: !0
                }, c === "event" && (b.durationThreshold = 40), Gq(a).observe(b);
                Hq(a)
            }
        }
    }

    function Iq(a, b) {
        const c = Bq !== window.scrollX || Cq !== window.scrollY ? [] : Dq,
            d = Aq();
        for (const e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                Jq(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Ja = Math.floor(b.renderTime || b.loadTime);
                a.Ia = b.size;
                break;
            case "first-input":
                b = e;
                a.Fa = Number((b.processingStart - b.startTime).toFixed(3));
                a.Ga = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || Kq(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.B +=
                    b;
                a.P = Math.max(a.P, b);
                a.ra += 1;
                break;
            case "event":
                Kq(a, e);
                break;
            default:
                Pb(b, void 0)
        }
    }

    function Gq(a) {
        a.L || (a.L = new PerformanceObserver(Pj(640, b => {
            Iq(a, b)
        })));
        return a.L
    }

    function Hq(a) {
        const b = Pj(641, () => {
                var d = document;
                (d.prerendering ? 3 : {
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5
                }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) === 2 && Lq(a)
            }),
            c = Pj(641, () => void Lq(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.Ea = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            Gq(a).disconnect()
        }
    }

    function Lq(a) {
        if (!a.Ma) {
            a.Ma = !0;
            Gq(a).takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += rq("cls", a.F), b += rq("mls", a.ba), b += qq("nls", a.qa), window.LayoutShiftAttribution && (b += rq("cas", a.A), b += qq("nas", a.La), b += rq("was", a.Qa)), b += rq("wls", a.sa), b += rq("tls", a.Pa));
            window.LargestContentfulPaint && (b += qq("lcp", a.Ja), b += qq("lcps", a.Ia));
            window.PerformanceEventTiming && a.Ga && (b += qq("fid", a.Fa));
            window.PerformanceLongTaskTiming && (b += qq("cbt", a.B),
                b += qq("mbt", a.P), b += qq("nlt", a.ra));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) tq(c) && d++;
            b += qq("nif", d);
            b += qq("ifi", ze(window));
            c = N(ch).g();
            b += `&${"eid"}=${encodeURIComponent(c.join())}`;
            b += `&${"top"}=${p===p.top?1:0}`;
            b += a.Oa ? `&${"qqid"}=${encodeURIComponent(a.Oa)}` : qq("pvsid", ke(p));
            window.googletag && (b += "&gpt=1");
            c = Math.min(a.g.length - 1, Math.floor((a.L ? a.Ha : performance.interactionCount || 0) / 50));
            c >= 0 && (c = a.g[c].latency, c >= 0 && (b += qq("inp", c)));
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            a.Ea()
        }
    }

    function Jq(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.F += Number(b.value);
            Number(b.value) > a.ba && (a.ba = Number(b.value));
            a.qa += 1;
            if (c = uq(b, c, d)) a.A += b.value, a.La++;
            if (b.startTime - a.Ka > 5E3 || b.startTime - a.Na > 1E3) a.Ka = b.startTime, a.i = 0, a.j = 0;
            a.Na = b.startTime;
            a.i += b.value;
            c && (a.j += b.value);
            a.i > a.sa && (a.sa = a.i, a.Qa = a.j, a.Pa = b.startTime + b.duration)
        }
    }

    function Kq(a, b) {
        Mq(a, b);
        const c = a.g[a.g.length - 1],
            d = a.I[b.interactionId];
        if (d || a.g.length < 10 || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.I[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.I[e.id]
        })
    }

    function Mq(a, b) {
        b.interactionId && (a.pa = Math.min(a.pa, b.interactionId), a.u = Math.max(a.u, b.interactionId), a.Ha = a.u ? (a.u - a.pa) / 7 + 1 : 0)
    }
    var Fq = class {
            constructor() {
                this.j = this.i = this.qa = this.ba = this.F = 0;
                this.Na = this.Ka = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.I = {};
                this.Ha = 0;
                this.pa = Infinity;
                this.Fa = this.Ia = this.Ja = this.La = this.Qa = this.A = this.Pa = this.sa = this.u = 0;
                this.Ga = !1;
                this.ra = this.P = this.B = 0;
                this.L = null;
                this.Ma = !1;
                this.Ea = () => {};
                const a = document.querySelector("[data-google-query-id]");
                this.Oa = a ? a.getAttribute("data-google-query-id") : null;
                this.jb = {
                    ub: !0
                }
            }
        },
        Bq, Cq, Dq = [];
    let Nq = null;
    const Oq = [],
        Pq = new Map;
    let Qq = -1;

    function Rq(a) {
        return pj.test(a.className) && a.dataset.adsbygoogleStatus !== "done"
    }

    function Sq(a, b, c) {
        a.dataset.adsbygoogleStatus = "done";
        Tq(a, b, c)
    }

    function Tq(a, b, c) {
        var d = window;
        d.google_spfd || (d.google_spfd = Yo);
        var e = b.google_reactive_ads_config;
        e || Yo(a, b, d, c);
        Zn(d, b);
        if (!Uq(a, b, d)) {
            if (e) {
                e = e.page_level_pubvars || {};
                if (X(O).page_contains_reactive_tag && !X(O).allow_second_reactive_tag) {
                    if (e.pltais) {
                        Jm(!1);
                        return
                    }
                    throw new W("Only one 'enable_page_level_ads' allowed per page.");
                }
                X(O).page_contains_reactive_tag = !0;
                Jm(e.google_pgb_reactive === 7)
            }
            b.google_unique_id = ye(d);
            Xd(cq, (f, g) => {
                b[g] = b[g] || d[g]
            });
            b.google_loader_used !== "sd" && (b.google_loader_used =
                "aa");
            b.google_reactive_tag_first = (X(O).first_tag_on_page || 0) === 1;
            uk(164, () => {
                eo(d, b, a, c)
            })
        }
    }

    function Uq(a, b, c) {
        var d = b.google_reactive_ads_config,
            e = typeof a.className === "string" && RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className),
            f = Hm(c);
        if (f && f.Ra && b.google_adtest !== "on" && !e) {
            e = Zi(a, c);
            const g = Vi(c).clientHeight;
            e = g === 0 ? null : e / g;
            if (!f.ta || f.ta && (e || 0) >= f.ta) return a.className += " adsbygoogle-ablated-ad-slot", c = c.google_sv_map = c.google_sv_map || {}, d = ka(a), b.google_element_uid = d, c[b.google_element_uid] = b, a.setAttribute("google_element_uid", String(d)), f.Mb === "slot" && (ae(a.getAttribute("width")) !==
                null && a.setAttribute("width", "0"), ae(a.getAttribute("height")) !== null && a.setAttribute("height", "0"), a.style.width = "0px", a.style.height = "0px"), !0
        }
        if ((f = Vd(a, c)) && f.display === "none" && !(b.google_adtest === "on" || b.google_reactive_ad_format > 0 || d)) return c.document.createComment && a.appendChild(c.document.createComment("No ad requested because of display:none on the adsbygoogle tag")), !0;
        a = b.google_pgb_reactive == null || b.google_pgb_reactive === 3;
        return b.google_reactive_ad_format !== 1 && b.google_reactive_ad_format !==
            8 || !a ? !1 : (p.console && p.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + String(b.google_reactive_ad_format) + " is deprecated. Check out page-level ads at https://www.google.com/adsense"), !0)
    }

    function Vq(a) {
        var b = document.getElementsByTagName("INS");
        for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
            var c = e;
            if (Rq(c) && c.dataset.adsbygoogleStatus !== "reserved" && (!a || e.id === a)) return e
        }
        return null
    }

    function Wq(a, b, c) {
        if (a && "shift" in a) {
            mp(e => {
                cd(Ff(e), 2) || (e = Ff(e), id(e, 2))
            });
            for (var d = 20; a.length > 0 && d > 0;) {
                try {
                    Xq(a.shift(), b, c)
                } catch (e) {
                    setTimeout(() => {
                        throw e;
                    })
                }--d
            }
        }
    }

    function Yq() {
        const a = Ud("INS");
        a.className = "adsbygoogle";
        a.className += " adsbygoogle-noablate";
        de(a);
        return a
    }

    function Zq(a, b) {
        const c = {},
            d = Xm(a.google_ad_client, b);
        Xd(Ui, (g, h) => {
            a.enable_page_level_ads === !1 ? c[h] = !1 : a.hasOwnProperty(h) ? c[h] = a[h] : d.includes(g) && (c[h] = !1)
        });
        ja(a.enable_page_level_ads) && (c.page_level_pubvars = a.enable_page_level_ads);
        const e = Yq();
        le.body.appendChild(e);
        const f = {
            google_reactive_ads_config: c,
            google_ad_client: a.google_ad_client
        };
        f.google_pause_ad_requests = !!X(O).pause_ad_requests;
        mq($q(a) || Hn(O), f, b);
        Sq(e, f, b);
        mp(g => {
            cd(Ff(g), 6) || (g = Ff(g), id(g, 6))
        })
    }

    function ar(a, b) {
        xn(p).wasPlaTagProcessed = !0;
        const c = () => {
                Zq(a, b)
            },
            d = p.document;
        if (d.body || d.readyState === "complete" || d.readyState === "interactive") Zq(a, b);
        else {
            const e = sd(vk(191, c));
            td(d, "DOMContentLoaded", e);
            p.MutationObserver != null && (new p.MutationObserver((f, g) => {
                d.body && (e(), g.disconnect())
            })).observe(d, {
                childList: !0,
                subtree: !0
            })
        }
    }

    function Xq(a, b, c) {
        const d = {};
        uk(165, () => {
            br(a, d, b, c)
        }, e => {
            e.client = e.client || d.google_ad_client || a.google_ad_client;
            e.slotname = e.slotname || d.google_ad_slot;
            e.tag_origin = e.tag_origin || d.google_tag_origin
        })
    }

    function cr(a) {
        delete a.google_checked_head;
        Xd(a, (b, c) => {
            oj[c] || (delete a[c], b = c.replace("google", "data").replace(/_/g, "-"), p.console.warn(`AdSense head tag doesn't support ${b} attribute.`))
        })
    }

    function dr(a, b) {
        var c = O.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || O.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js?client="]:not([data-checked-head])') || O.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])') || O.document.querySelector('script[src*="/pagead/js/adsbygoogle_direct.js"][data-ad-client]:not([data-checked-head])');
        if (c) {
            c.setAttribute("data-checked-head",
                "true");
            var d = X(window);
            if (d.head_tag_slot_vars) er(c);
            else {
                mp(g => {
                    g = Ff(g);
                    D(g, 7, Ub(!0), !1)
                });
                var e = {};
                Wo(c, e);
                cr(e);
                var f = Ad(e);
                d.head_tag_slot_vars = f;
                c = {
                    google_ad_client: e.google_ad_client,
                    enable_page_level_ads: e
                };
                e.google_ad_intent_query && (c.enable_ad_intent_display_ads = !0, T(Ci) && (e.google_responsive_auto_format = 17));
                e.google_overlays === "bottom" && (c.overlays = {
                    bottom: !0
                });
                delete e.google_overlays;
                O.adsbygoogle || (O.adsbygoogle = []);
                d = O.adsbygoogle;
                d.loaded ? d.push(c) : d.splice && d.splice(0, 0, c);
                b = T(Li) ?
                    Ym(b) ? .i() : b.g() ? .i();
                e.google_adbreak_test || b ? fr(f, a) : pq(() => {
                    fr(f, a)
                })
            }
        }
    }

    function er(a) {
        const b = X(window).head_tag_slot_vars,
            c = a.getAttribute("src") || "";
        if ((a = Nd(c, "client") || a.getAttribute("data-ad-client") || "") && a !== b.google_ad_client) throw new W("Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page " + a + ", " + b.google_ad_client);
    }

    function gr(a) {
        if (typeof a === "object" && a != null) {
            if (typeof a.type === "string") return 2;
            if (typeof a.sound === "string" || typeof a.preloadAdBreaks === "string" || typeof a.h5AdsConfig === "object") return 3
        }
        return 0
    }

    function br(a, b, c, d) {
        if (a == null) throw new W("push() called with no parameters.");
        mp(f => {
            cd(Ff(f), 3) || (f = Ff(f), id(f, 3))
        });
        var e = gr(a);
        if (e !== 0)
            if (d = Km(), d.first_slotcar_request_processing_time || (d.first_slotcar_request_processing_time = Date.now(), d.adsbygoogle_execution_start_time = ih), Nq == null) hr(a), Oq.push(a);
            else if (e === 3) {
            const f = Nq;
            uk(787, () => {
                f.handleAdConfig(a)
            })
        } else wk(730, Nq.handleAdBreak(a));
        else {
            ih = (new Date).getTime();
            $n(c, d, $q(a));
            ir();
            a: {
                if (!a.enable_ad_intent_display_ads && a.enable_page_level_ads !=
                    void 0) {
                    if (typeof a.google_ad_client === "string") {
                        e = !0;
                        break a
                    }
                    throw new W("'google_ad_client' is missing from the tag config.");
                }
                e = !1
            }
            if (e) mp(f => {
                cd(Ff(f), 4) || (f = Ff(f), id(f, 4))
            }), jr(a, d);
            else if ((e = a.params) && Xd(e, (f, g) => {
                    b[g] = f
                }), b.google_ad_output === "js") console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
            else {
                mq($q(a) || Hn(O), b, d);
                e = kr(b, a);
                Wo(e, b);
                c = X(p).head_tag_slot_vars || {};
                Xd(c, (f, g) => {
                    b.hasOwnProperty(g) || (b[g] = f)
                });
                if (e.hasAttribute("data-require-head") && !X(p).head_tag_slot_vars) throw new W("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
                if (!b.google_ad_client) throw new W("Ad client is missing from the slot.");
                if (c = (X(O).first_tag_on_page || 0) === 0 && An(b)) mp(f => {
                    cd(Ff(f), 5) || (f = Ff(f), id(f, 5))
                }), lr(c);
                (X(O).first_tag_on_page || 0) === 0 && (X(O).first_tag_on_page = 2);
                b.google_pause_ad_requests = !!X(O).pause_ad_requests;
                Sq(e, b, d)
            }
        }
    }

    function $q(a) {
        return a.google_ad_client ? a.google_ad_client : (a = a.params) && a.google_ad_client ? a.google_ad_client : ""
    }

    function ir() {
        if (T(oi)) {
            const a = Hm(O);
            a && a.Ra || Im(O)
        }
    }

    function lr(a) {
        me(() => {
            xn(p).wasPlaTagProcessed || p.adsbygoogle && p.adsbygoogle.push(a)
        })
    }

    function jr(a, b) {
        (X(O).first_tag_on_page || 0) === 0 && (X(O).first_tag_on_page = 1);
        if (a.tag_partner) {
            var c = a.tag_partner;
            const d = X(p);
            d.tag_partners = d.tag_partners || [];
            d.tag_partners.push(c)
        }
        Bn(a, b);
        ar(a, b)
    }

    function kr(a, b) {
        if (a.google_ad_format === "rewarded") {
            if (a.google_ad_slot == null) throw new W("Rewarded format does not have valid ad slot");
            if (a.google_ad_loaded_callback == null) throw new W("Rewarded format does not have ad loaded callback");
            a.google_reactive_ad_format = 11;
            a.google_wrap_fullscreen_ad = !0;
            a.google_video_play_muted = !1;
            a.google_acr = a.google_ad_loaded_callback;
            delete a.google_ad_loaded_callback;
            delete a.google_ad_format
        }
        var c = !!a.google_wrap_fullscreen_ad;
        if (c) b = Yq(), b.dataset.adsbygoogleStatus =
            "reserved", le.documentElement.appendChild(b);
        else if (b = b.element) {
            if (!Rq(b) && (b.id ? b = Vq(b.id) : b = null, !b)) throw new W("'element' has already been filled.");
            if (!("innerHTML" in b)) throw new W("'element' is not a good DOM element.");
        } else if (b = Vq(), !b) throw new W("All 'ins' elements in the DOM with class=adsbygoogle already have ads in them.");
        if (c) {
            c = O;
            try {
                const e = (c || window).document,
                    f = e.compatMode == "CSS1Compat" ? e.documentElement : e.body;
                var d = (new te(f.clientWidth, f.clientHeight)).round()
            } catch (e) {
                d =
                    new te(-12245933, -12245933)
            }
            a.google_ad_height = d.height;
            a.google_ad_width = d.width;
            a.fsapi = !0
        }
        return b
    }

    function mr(a) {
        bl().S[el(26)] = !!Number(a)
    }

    function nr(a) {
        Number(a) ? X(O).pause_ad_requests = !0 : (X(O).pause_ad_requests = !1, a = () => {
            if (!X(O).pause_ad_requests) {
                var b = {};
                let c;
                typeof window.CustomEvent === "function" ? c = new CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", b) : (c = document.createEvent("CustomEvent"), c.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !!b.bubbles, !!b.cancelable, b.detail));
                O.dispatchEvent(c)
            }
        }, p.setTimeout(a, 0), p.setTimeout(a, 1E3))
    }

    function or(a) {
        a && a.call && typeof a === "function" && window.setTimeout(a, 0)
    }

    function fr(a, b) {
        const c = { ...sn()
            },
            d = U(Ii);
        [0, 1].includes(d) && (c.osttc = `${d}`);
        b = wn(Pd(b.Lb, new Map(Object.entries(c)))).then(e => {
            Nq == null && (e.init(a), Nq = e, pr(e))
        });
        wk(723, b);
        b.finally(() => {
            Oq.length = 0;
            xk("slotcar", {
                event: "api_ld",
                time: Date.now() - ih,
                time_pr: Date.now() - Qq
            });
            sp(N(np), Jf(23))
        })
    }

    function pr(a) {
        for (const [c, d] of Pq) {
            var b = c;
            const e = d;
            e !== -1 && (p.clearTimeout(e), Pq.delete(b))
        }
        for (b = 0; b < Oq.length; b++) {
            if (Pq.has(b)) continue;
            const c = Oq[b],
                d = gr(c);
            uk(723, () => {
                d === 3 ? a.handleAdConfig(c) : d === 2 && wk(730, a.handleAdBreakBeforeReady(c))
            })
        }
    }

    function hr(a) {
        var b = Oq.length;
        if (gr(a) === 2 && a.type === "preroll" && a.adBreakDone != null) {
            var c = a.adBreakDone;
            Qq === -1 && (Qq = Date.now());
            var d = p.setTimeout(() => {
                try {
                    c({
                        breakType: "preroll",
                        breakName: a.name,
                        breakFormat: "preroll",
                        breakStatus: "timeout"
                    }), Pq.set(b, -1), xk("slotcar", {
                        event: "pr_to",
                        source: "adsbygoogle"
                    }), sp(N(np), Jf(22))
                } catch (e) {
                    console.error("[Ad Placement API] adBreakDone callback threw an error:", e instanceof Error ? e : Error(String(e)))
                }
            }, U(Mi) * 1E3);
            Pq.set(b, d)
        }
    };
    (function(a, b, c, d = () => {}) {
        (T(bi) ? rk : qk).fb(zk);
        uk(166, () => {
            const e = new yg(2, a);
            try {
                $a(n => {
                    hk(e, 1191, n)
                })
            } catch (n) {}
            const f = kq(b);
            var g = rn(f);
            bq(f, g);
            d();
            se(16, [1, wc(f)]);
            var h = ve(ue(O)) || O;
            const k = c(Gn({
                ua: a,
                Ba: K(f, 2)
            }), f);
            var l = O.document.currentScript === null ? 1 : vp(k.Nb);
            $p(h, f, l);
            T(Fi) && nq(h.document, K(f, 29));
            mp(n => {
                var m = bd(n, 1) + 1;
                D(n, 1, ac(m), 0);
                O.top === O && (m = bd(n, 2) + 1, D(n, 2, ac(m), 0));
                cd(Ff(n), 1) || (n = Ff(n), id(n, 1))
            });
            wk(1086, qp(l === 0));
            if (!Fa() || ua(Ka(), 11) >= 0) {
                tk(T(Oi));
                ho();
                rm(Sc(f, on, 26));
                try {
                    Eq()
                } catch {}
                go();
                dr(k, f);
                h = window;
                l = h.adsbygoogle;
                if (!l || !l.loaded) {
                    xk("new_abg_tag", {
                        value: `${J(f,16)}`,
                        host_v: `${J(f,22)}`,
                        frequency: .01
                    }, .01);
                    g = {
                        push: n => {
                            Xq(n, k, f)
                        },
                        loaded: !0,
                        pageState: JSON.stringify(wc(g))
                    };
                    try {
                        Object.defineProperty(g, "requestNonPersonalizedAds", {
                            set: mr
                        }), Object.defineProperty(g, "pauseAdRequests", {
                            set: nr
                        }), Object.defineProperty(g, "onload", {
                            set: or
                        })
                    } catch {}
                    if (l)
                        for (const n of ["requestNonPersonalizedAds", "pauseAdRequests"]) l[n] !== void 0 && (g[n] = l[n]);
                    Wq(l, k, f);
                    h.adsbygoogle = g;
                    l && (g.onload = l.onload)
                }
            }
        })
    })(hg(),
        typeof sttc === "undefined" ? void 0 : sttc,
        function(a, b) {
            b = bd(b, 1) > 2012 ? `_fy${bd(b,1)}` : "";
            Od `data:text/javascript,//show_ads_impl_preview.js`;
            return {
                Lb: Od `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${b}.js`,
                Jb: Od `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl${b}.js`,
                Ib: Od `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_with_ama${b}.js`,
                Nb: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle(_direct)?)\.js(?:[?#].*)?$/
            }
        });
}).call(this, "[2021,\"r20250218\",\"r20190131\",null,null,null,null,\".google.co.in\",null,null,null,[[[698926295,null,null,[1]],[null,619278254,null,[null,10]],[676894296,null,null,[1]],[null,1130,null,[null,100]],[null,1340,null,[null,0.2]],[null,1338,null,[null,0.3]],[null,1336,null,[null,1.2]],[null,1339,null,[null,0.3]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,500]]]],[null,1224,null,[null,0.01]],[null,1346,null,[null,6]],[null,1347,null,[null,3]],[null,1343,null,[null,300]],[null,1263,null,[null,-1]],[null,1323,null,[null,-1]],[null,1265,null,[null,-1]],[null,1264,null,[null,-1]],[1267,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[1241,null,null,[1]],[1300,null,null,[1]],[null,null,null,[null,null,null,[\"en\",\"de\",\"fr\",\"es\",\"ja\"]],null,1273],[null,null,null,[null,null,null,[\"44786015\",\"44786016\"]],null,1261],[1318,null,null,[1]],[1372,null,null,[1]],[-1401403511,null,null,[1]],[null,1364,null,[null,300]],[1378,null,null,[1]],[null,null,null,[null,null,null,[\"1\",\"2\",\"3\",\"4\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"24\",\"29\",\"30\",\"34\"]],null,null,null,627094447],[null,null,622128249,[null,null,\"#FFFFFF\"]],[null,null,622128250,[null,null,\"#1A73E8\"]],[null,null,null,[null,null,null,[\"33\",\"38\"]],null,null,null,641845510],[686023322,null,null,[1]],[622128248,null,null,[]],[681379804,null,null,[1]],[717888913,null,null,[1]],[null,null,589752731,[null,null,\"#FFFFFF\"]],[null,null,589752730,[null,null,\"#1A73E8\"]],[null,null,null,[null,null,null,[\"29_18\",\"30_19\"]],null,null,null,635821288],[718840371,null,null,[1]],[null,null,null,[null,null,null,[\"29_5\",\"30_6\"]],null,null,null,636146137],[636570127,null,null,[1]],[null,null,null,[null,null,null,[\"1\",\"2\",\"4\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"24\",\"29\",\"30\",\"34\"]],null,null,null,627094446],[null,652486359,null,[null,3]],[null,626062006,null,[null,670]],[null,688905693,null,[null,2]],[null,666400580,null,[null,22]],[null,null,null,[null,null,null,[\"\",\"ar\",\"bn\",\"en\",\"es\",\"fr\",\"hi\",\"id\",\"ja\",\"ko\",\"mr\",\"pt\",\"ru\",\"sr\",\"te\",\"th\",\"tr\",\"uk\",\"vi\",\"zh\"]],null,712458671],[null,687270738,null,[null,500]],[null,null,null,[],null,null,null,683929765],[655991266,null,null,[1]],[686111728,null,null,[1]],[null,643258048,null,[null,0.15]],[null,643258049,null,[null,0.33938]],[null,618163195,null,[null,15000]],[null,624950166,null,[null,15000]],[null,623405755,null,[null,300]],[null,508040914,null,[null,500]],[null,547455356,null,[null,49]],[null,650548030,null,[null,2]],[null,650548032,null,[null,300]],[null,650548031,null,[null,1]],[null,655966487,null,[null,300]],[null,655966486,null,[null,250]],[null,469675170,null,[null,60000]],[711741274,null,null,[]],[null,684147713,null,[null,-1]],[null,684147711,null,[null,-1]],[null,684147712,null,[null,-1]],[45675855,null,null,[1]],[45669105,null,null,[1]],[45676172,null,null,[1]],[45675638,null,null,[1]],[45674344,null,null,[1]],[45664474,null,null,[1]],[45674084,null,null,[1]],[678806782,null,null,[1]],[570863962,null,null,[1]],[null,null,570879859,[null,null,\"control_1\\\\.\\\\d\"]],[null,570863961,null,[null,50]],[570879858,null,null,[1]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1080,null,[null,5]],[null,10019,null,[null,5]],[10016,null,null,[1]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[null,1079,null,[null,5]],[null,1050,null,[null,30]],[null,58,null,[null,120]],[715572365,null,null,[1]],[715572366,null,null,[1]],[555237685,null,null,[1]],[45460956,null,null,[]],[45414947,null,null,[1]],[null,472785970,null,[null,500]],[null,629808663,null,[null,100]],[null,550718588,null,[null,250]],[null,624290870,null,[null,50]],[null,null,null,[null,null,null,[\"AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"Amm8\/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq\/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A9wSqI5i0iwGdf6L1CERNdmsTPgVu44ewj8QxTBYgsv1LCPUVF7YmWOvTappqB1139jAymxUW\/RO8zmMqo4zlAAAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MzY4MTI4MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A+d7vJfYtay4OUbdtRPZA3y7bKQLsxaMEPmxgfhBGqKXNrdkCQeJlUwqa6EBbSfjwFtJWTrWIioXeMW+y8bWAgQAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MzY4MTI4MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[]]],[[12,[[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,59],[40,[[95340252],[95340253,[[662101537,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5],[40,[[95340254],[95340255,[[662101539,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]]]],[10,[[50,[[31067422],[31067423,[[null,1032,null,[]]]]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[null,[[31081539],[31081540,[[711741274,null,null,[1]]]]]],[10,[[31083552],[44776368]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[10,[[31084127],[31084128]]],[1,[[31089421],[31089422,[[676460084,null,null,[1]]]]],null,139,null,null,null,998,null,null,null,null,null,8],[1,[[31089423],[31089424]],[4,null,61],139,null,null,null,998,null,null,null,null,null,8],[1,[[31089628],[31089629,[[710737579,null,null,[1]]]]]],[50,[[31089910],[31089911,[[713788640,null,null,[1]]]]]],[null,[[31090148],[31090149,[[675298507,null,null,[1]]]]]],[null,[[31090261],[31090262,[[45675667,null,null,[1]]]]]],[10,[[31090340],[31090341,[[682658313,null,null,[1]]]]]],[10,[[31090353],[31090354,[[1290,null,null,[1]]]]]],[100,[[31090477],[31090478,[[723484983,null,null,[1]]]]]],[1000,[[31090497,[[null,null,14,[null,null,\"31090497\"]]],[6,null,null,null,6,null,\"31090497\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31090498,[[null,null,14,[null,null,\"31090498\"]]],[6,null,null,null,6,null,\"31090498\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31090526,[[null,null,14,[null,null,\"31090526\"]]],[6,null,null,null,6,null,\"31090526\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31090527,[[null,null,14,[null,null,\"31090527\"]]],[6,null,null,null,6,null,\"31090527\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31090558,[[null,null,14,[null,null,\"31090558\"]]],[6,null,null,null,6,null,\"31090558\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31090559,[[null,null,14,[null,null,\"31090559\"]]],[6,null,null,null,6,null,\"31090559\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[50,[[42531705],[42531706]]],[1,[[42532242],[42532243,[[1256,null,null,[1]],[290,null,null,[1]]]]]],[50,[[42532523],[42532524,[[1300,null,null,[]]]]]],[null,[[42532525],[42532526]]],[1,[[44719338],[44719339,[[334,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]]],[1,[[44801778],[44801779,[[506914611,null,null,[1]]]]],[4,null,55]],[10,[[95330276],[95330278,[[null,1336,null,[null,1]]]],[95330279,[[null,1336,null,[null,0.8]]]],[95332928,[[null,1336,null,[null,0.5]]]]]],[50,[[95331832],[95331833,[[1342,null,null,[1]]]]]],[10,[[95332584],[95332585,[[null,1343,null,[null,600]]]],[95332586,[[null,1343,null,[null,900]]]],[95332587,[[null,1343,null,[null,1200]]]]]],[10,[[95332589],[95332590,[[1344,null,null,[1]]]]]],[10,[[95332923],[95332924,[[null,1338,null,[null,0.8]]]],[95332925,[[null,1339,null,[null,0.8]]]],[95332926,[[null,1340,null,[null,0.8]]]],[95332927,[[null,1340,null,[null,0.8]],[null,1338,null,[null,0.8]],[null,1339,null,[null,0.8]]]]]],[10,[[95333409],[95333410,[[null,1346,null,[null,-1]],[null,1347,null,[null,-1]]]],[95333411,[[null,1346,null,[null,3]],[null,1347,null,[null,1]]]],[95333412,[[null,1346,null,[null,8]],[null,1347,null,[null,5]]]]]],[360,[[95334516,[[null,null,null,[null,null,null,[\"95334518\"]],null,null,null,630330362]]],[95334517,[[626390500,null,null,[1]],[null,null,null,[null,null,null,[\"95334519\"]],null,null,null,630330362]]]],[2,[[4,null,55],[12,null,null,null,2,null,\"buzzfun\\\\.me\/|diggfun\\\\.co\/|indiaimagine\\\\.com\/\"]]]],[50,[[95344787,[[null,null,null,[null,null,null,[\"95344792\"]],null,null,null,630330362]]],[95344788,[[566279275,null,null,[1]],[622128248,null,null,[1]],[null,null,null,[null,null,null,[\"95344793\"]],null,null,null,630330362]]],[95344789,[[622128248,null,null,[1]],[566279276,null,null,[1]],[null,null,null,[null,null,null,[\"95344794\"]],null,null,null,630330362]]],[95344790,[[566279275,null,null,[1]],[566279276,null,null,[1]],[null,null,null,[null,null,null,[\"95344795\"]],null,null,null,630330362]]],[95344791,[[566279275,null,null,[1]],[622128248,null,null,[1]],[566279276,null,null,[1]],[null,null,null,[null,null,null,[\"95344796\"]],null,null,null,630330362]]]],[4,null,55]],[1,[[95345037],[95345038,[[1377,null,null,[1]]]]],[4,null,55]],[10,[[95348574]]],[10,[[95348575,[[1367,null,null,[1]],[1349,null,null,[1]],[null,1366,null,[]],[null,1365,null,[null,2592000]]]]],null,138],[null,[[95348881],[95348882,[[45650867,null,null,[1]]]]],null,130,null,null,null,null,null,null,null,null,null,7],[null,[[95349395]]],[null,[[95349396,[[1367,null,null,[1]],[1349,null,null,[1]],[null,1366,null,[]],[null,1365,null,[null,2592000]],[45665162,null,null,[1]]]]],null,138],[200,[[95350441,[[null,null,null,[null,null,null,[\"95350443\"]],null,null,null,630330362]]],[95350442,[[707519017,null,null,[1]],[null,null,null,[null,null,null,[\"95350444\"]],null,null,null,630330362]]]],[4,null,55]],[100,[[95350548],[95350549,[[1381,null,null,[1]]]]]],[10,[[95352051,[[null,null,null,[null,null,null,[\"95352054\"]],null,null,null,630330362]]],[95352052,[[null,643258048,null,[]],[null,null,null,[null,null,null,[\"95352055\"]],null,null,null,630330362]]],[95352053,[[null,643258048,null,[]],[null,643258049,null,[]],[null,null,null,[null,null,null,[\"95352056\"]],null,null,null,630330362]]]],[4,null,55]],[10,[[95352076],[95352077,[[716210739,null,null,[1]]]]]],[50,[[95352637],[95352638]],null,51],[10,[[95353420],[95353421,[[10018,null,null,[1]]]]]],[1,[[95353559,[[null,null,null,[null,null,null,[\"95353571\"]],null,null,null,630330362]]],[95353560,[[null,717888910,null,[null,0.7]],[null,null,null,[null,null,null,[\"95353572\"]],null,null,null,630330362]]],[95353561,[[null,717888910,null,[null,0.6]],[null,null,null,[null,null,null,[\"95353573\"]],null,null,null,630330362]]],[95353562,[[null,717888910,null,[null,0.5]],[null,null,null,[null,null,null,[\"95353574\"]],null,null,null,630330362]]],[95353583,[[null,717888910,null,[null,0.4]],[null,null,null,[null,null,null,[\"95353586\"]],null,null,null,630330362]]]],[4,null,55]],[1,[[95353601,[[null,null,null,[null,null,null,[\"95353606\"]],null,null,null,630330362]]],[95353602,[[null,717888911,null,[null,0.7]],[null,null,null,[null,null,null,[\"95353607\"]],null,null,null,630330362]]],[95353603,[[null,717888911,null,[null,0.6]],[null,null,null,[null,null,null,[\"95353608\"]],null,null,null,630330362]]],[95353604,[[null,717888911,null,[null,0.5]],[null,null,null,[null,null,null,[\"95353609\"]],null,null,null,630330362]]],[95353605,[[null,717888911,null,[null,0.4]],[null,null,null,[null,null,null,[\"95353610\"]],null,null,null,630330362]]]],[4,null,55]],[1,[[95353611,[[null,null,null,[null,null,null,[\"95353616\"]],null,null,null,630330362]]],[95353612,[[null,717888912,null,[null,0.7]],[null,null,null,[null,null,null,[\"95353617\"]],null,null,null,630330362]]],[95353613,[[null,717888912,null,[null,0.6]],[null,null,null,[null,null,null,[\"95353618\"]],null,null,null,630330362]]],[95353614,[[null,717888912,null,[null,0.5]],[null,null,null,[null,null,null,[\"95353619\"]],null,null,null,630330362]]],[95353615,[[null,717888912,null,[null,0.4]],[null,null,null,[null,null,null,[\"95353620\"]],null,null,null,630330362]]]],[4,null,55]]]],[17,[[10,[[31084487],[31084488]],null,null,null,null,32,null,null,142,1],[10,[[31089209],[31089210]],null,null,null,null,39,null,null,189,1],[96,[[31090357]],[2,[[4,null,55],[7,null,null,15,null,20250512]]],null,null,null,null,null,null,194,1],[896,[[31090358,null,[4,null,71,null,null,null,null,[\"194\",\"14\"]]]],[2,[[4,null,55],[7,null,null,15,null,20250512]]],null,null,null,null,96,null,194,1],[500,[[95347432,[[null,null,null,[null,null,null,[\"95347434\"]],null,null,null,630330362]]],[95347433,[[636570127,null,null,[]],[null,null,null,[null,null,null,[\"95347435\"]],null,null,null,630330362]]]],[4,null,55],null,null,null,null,null,null,190,1],[100,[[95348347,[[null,null,null,[null,null,null,[\"95348349\"]],null,null,null,630330362]]],[95348348,[[null,652486359,null,[null,1]],[null,null,null,[null,null,null,[\"95348350\"]],null,null,null,630330362]]]],[4,null,55],null,null,null,null,null,null,191,1],[500,[[95350015,[[null,null,null,[null,null,null,[\"95350025\"]],null,null,null,630330362]]],[95350016,[[null,null,622128249,[null,null,\"#0B57D0\"]],[null,null,622128250,[null,null,\"#FFFFFF\"]],[null,null,null,[null,null,null,[\"95350026\"]],null,null,null,630330362]]]],[4,null,55],null,null,null,null,null,null,192,1],[null,[[95352177,[[null,null,null,[null,null,null,[\"95352177\",\"95352179\"]],null,null,null,631402549],[null,null,null,[null,null,null,[\"95352179\"]],null,null,null,630330362]]],[95352178,[[720093567,null,null,[1]],[713244099,null,null,[]],[null,null,null,[null,null,null,[\"95352178\",\"95352180\"]],null,null,null,631402549],[null,null,null,[null,null,null,[\"95352180\"]],null,null,null,630330362]]]],[4,null,55],null,null,null,null,null,null,193],[1,[[95353074],[95353075,[[null,619278254,null,[]]]],[95353076,[[null,619278254,null,[]]]],[95353077],[95353078],[95353079,[[null,619278254,null,[]]]]],null,null,null,null,null,null,null,195,1]]],[11,[[50,[[31088249],[31088250]],null,122,null,null,null,null,null,null,null,null,null,4]]]],null,null,[null,1000,1,1000]],[1,[null,[[[[null,0,null,null,null,null,\"DIV.syllabus-component-box\"],1,[\"10px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"DIV.syllabus-commout-out-box\"],1,[\"43.2px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"HEADER\"],4,[\"10px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"SECTION#notes\"],2,[\"10px\",\"10px\",1],[2],null,null,null,1]],[[null,[1,3,2,5],null,\"9854819310\",[[[[[null,3,null,null,null,null,\"DIV.contact-location-details\\u003eDIV.third-location-box.contact_box\\u003eUL\\u003eLI\"],3],[[null,null,null,null,null,null,\"DIV.social-contact-icon\"],2],[[null,0,null,null,null,null,\"DIV.social-contact-icon\"],1]]]],null,[0,2],null,null,[1,null,1],[1]]],[[[null,null,null,null,null,null,\"DIV.notes-box\"],[null,null,null,null,null,null,\"P\"],null,[null,null,null,null,null,null,\"H1,H2,H3,H4,P\"]],[[null,null,null,null,null,null,\"DIV.syllabus-commout-out-box\\u003eDIV.syllabu-left-box.syllabus-common-box\"],[null,null,null,null,null,null,\"P\"],null,[null,null,null,null,null,null,\"H2,P\"]],[[null,null,null,null,null,null,\"DIV.copywrite\"],[null,null,null,null,null,null,\"P\"]],[[null,0,null,null,null,null,\"ASIDE#notification\\u003eDIV.notification-data\"],[null,null,null,null,null,null,\"P\"],null,[null,null,null,null,null,null,\"H3,P\"]],[[null,null,null,null,null,null,\"DIV.syllabus-component-box\"],[null,null,null,null,null,null,\"P\"],null,[null,null,null,null,null,null,\"H1,H2,H3,H4,P\"]],[[null,null,null,null,null,null,\"DIV#college-info\\u003eASIDE.college-detail.college-info-boxes\"],[null,null,null,null,null,null,\"P\"],null,[null,null,null,null,null,null,\"H1,P\"]],[[null,null,null,null,null,null,\"DIV.name-instruction\"],[null,null,null,null,null,null,\"P\"],null,[null,null,null,null,null,null,\"H3,P\"]],[[null,null,null,null,null,null,\"DIV.syllabus-component-box\"],[]],[[null,null,null,null,null,null,\"DIV.login-popup\"],[null,null,null,null,null,null,\"P.login-popup-text\"],null,[null,null,null,null,null,null,\"H3.login-popup-title,P.login-popup-text\"]],[[null,null,null,null,null,null,\"DIV.home-info\"],[null,null,null,null,null,null,\"P\"],null,[null,null,null,null,null,null,\"H1,H1.header-sub-head,H3,IMG,P\"]]]],[null,null,[1,2]]],null,null,null,null,null,null,\"ca-pub-9796833231647897\"],null,\"31090526\",1,\"studyvault.online\",1347932215,null,null,null,null,null,null,null,[0,0,0],[\"ca-pub-9796833231647897\",null,1,null,[[[[null,0,null,null,null,null,\"DIV.syllabus-component-box\"],1,[\"10px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"DIV.syllabus-commout-out-box\"],1,[\"43.2px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"HEADER\"],4,[\"10px\",\"10px\",1],[2],null,null,null,1],[[null,0,null,null,null,null,\"SECTION#notes\"],2,[\"10px\",\"10px\",1],[2],null,null,null,1]],[[null,[1,3,2,5],null,\"9854819310\",[[[[[null,3,null,null,null,null,\"DIV.contact-location-details\\u003eDIV.third-location-box.contact_box\\u003eUL\\u003eLI\"],3],[[null,null,null,null,null,null,\"DIV.social-contact-icon\"],2],[[null,0,null,null,null,null,\"DIV.social-contact-icon\"],1]]]],null,[0,2],null,null,[1,null,1],[1]]]],[null,null,[1,2]]],null,\"m202502180101\"]");