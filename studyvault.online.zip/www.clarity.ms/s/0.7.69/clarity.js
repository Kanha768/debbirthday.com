/* clarity-js v0.7.69: https://github.com/microsoft/clarity (License: MIT) */ ! function() {
    "use strict";
    var t = Object.freeze({
            __proto__: null,
            get queue() {
                return kr
            },
            get start() {
                return wr
            },
            get stop() {
                return Sr
            },
            get track() {
                return vr
            }
        }),
        e = Object.freeze({
            __proto__: null,
            get clone() {
                return qr
            },
            get compute() {
                return Ur
            },
            get data() {
                return Yr
            },
            get keys() {
                return jr
            },
            get reset() {
                return Fr
            },
            get start() {
                return Hr
            },
            get stop() {
                return Br
            },
            get trigger() {
                return Wr
            },
            get update() {
                return Vr
            }
        }),
        n = Object.freeze({
            __proto__: null,
            get check() {
                return $r
            },
            get compute() {
                return ei
            },
            get data() {
                return Xr
            },
            get start() {
                return Qr
            },
            get stop() {
                return ni
            },
            get trigger() {
                return ti
            }
        }),
        a = Object.freeze({
            __proto__: null,
            get compute() {
                return si
            },
            get data() {
                return ai
            },
            get log() {
                return ci
            },
            get reset() {
                return li
            },
            get start() {
                return oi
            },
            get stop() {
                return ui
            },
            get updates() {
                return ri
            }
        }),
        r = Object.freeze({
            __proto__: null,
            get callback() {
                return Si
            },
            get callbacks() {
                return pi
            },
            get clear() {
                return ki
            },
            get consent() {
                return wi
            },
            get data() {
                return fi
            },
            get electron() {
                return hi
            },
            get id() {
                return bi
            },
            get metadata() {
                return yi
            },
            get save() {
                return Ti
            },
            get shortid() {
                return Mi
            },
            get start() {
                return gi
            },
            get stop() {
                return mi
            }
        }),
        i = Object.freeze({
            __proto__: null,
            get data() {
                return Pi
            },
            get envelope() {
                return ji
            },
            get start() {
                return Xi
            },
            get stop() {
                return Yi
            }
        }),
        o = {
            projectId: null,
            delay: 1e3,
            lean: !1,
            track: !0,
            content: !0,
            drop: [],
            mask: [],
            unmask: [],
            regions: [],
            cookies: [],
            fraud: !0,
            checksum: [],
            report: null,
            upload: null,
            fallback: null,
            upgrade: null,
            action: null,
            dob: null,
            delayDom: !1,
            throttleDom: !0,
            conversions: !1,
            includeSubdomains: !0,
            throttleMutations: !1,
            dropMutations: !1,
            criticalMs: 200,
            discard: []
        };

    function u(t) {
        return window.Zone && "__symbol__" in window.Zone ? window.Zone.__symbol__(t) : t
    }
    var c = 0;

    function s(t) {
        void 0 === t && (t = null);
        var e = t && t.timeStamp > 0 ? t.timeStamp : performance.now(),
            n = t && t.view ? t.view.performance.timeOrigin : performance.timeOrigin;
        return Math.max(Math.round(e + n - c), 0)
    }
    var l = "0.7.69";

    function d(t, e) {
        void 0 === e && (e = null);
        for (var n, a = 5381, r = a, i = 0; i < t.length; i += 2) {
            if (a = (a << 5) + a ^ t.charCodeAt(i), i + 1 < t.length) r = (r << 5) + r ^ t.charCodeAt(i + 1)
        }
        return n = Math.abs(a + 11579 * r), (e ? n % Math.pow(2, e) : n).toString(36)
    }
    var f = /\S/gi,
        p = 255,
        h = !0,
        v = null,
        g = null,
        m = null;

    function y(t, e, n, a, r) {
        if (void 0 === a && (a = !1), t) {
            if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
            switch (n) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return function(t) {
                                var e = -1,
                                    n = 0,
                                    a = !1,
                                    r = !1,
                                    i = !1,
                                    o = null;
                                E();
                                for (var u = 0; u < t.length; u++) {
                                    var c = t.charCodeAt(u);
                                    if (a = a || c >= 48 && c <= 57, r = r || 64 === c, i = 9 === c || 10 === c || 13 === c || 32 === c, 0 === u || u === t.length - 1 || i) {
                                        if (a || r) {
                                            null === o && (o = t.split(""));
                                            var s = t.substring(e + 1, i ? u : u + 1);
                                            s = h && null !== m ? s.match(m) ? s : S(s, "▪", "▫") : k(s), o.splice(e + 1 - n, s.length, s), n += s.length - 1
                                        }
                                        i && (a = !1, r = !1, e = u)
                                    }
                                }
                                return o ? o.join("") : t
                            }(t);
                        case "input":
                        case "change":
                            return T(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? w(t) : k(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                            return 3 === n ? "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return T(t);
                        case "placeholder":
                            return k(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? w(t) : k(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return S(t, "▪", "▫");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
            }
        }
        return t
    }

    function b(t, e, n) {
        void 0 === e && (e = !1), void 0 === n && (n = !1);
        var a = t;
        if (e) a = "".concat("https://").concat("Electron");
        else {
            var r = o.drop;
            if (r && r.length > 0 && t && t.indexOf("?") > 0) {
                var i = t.split("?"),
                    u = i[0],
                    c = i[1];
                a = u + "?" + c.split("&").map((function(t) {
                    return r.some((function(e) {
                        return 0 === t.indexOf("".concat(e, "="))
                    })) ? "".concat(t.split("=")[0], "=").concat("*na*") : t
                })).join("&")
            }
        }
        return n && (a = a.substring(0, p)), a
    }

    function w(t) {
        var e = t.trim();
        if (e.length > 0) {
            var n = e[0],
                a = t.indexOf(n),
                r = t.substr(0, a),
                i = t.substr(a + e.length);
            return "".concat(r).concat(e.length.toString(36)).concat(i)
        }
        return t
    }

    function k(t) {
        return t.replace(f, "•")
    }

    function S(t, e, n) {
        return E(), t ? t.replace(g, e).replace(v, n) : t
    }

    function T(t) {
        for (var e = 5 * (Math.floor(t.length / 5) + 1), n = "", a = 0; a < e; a++) n += a > 0 && a % 5 == 0 ? " " : "•";
        return n
    }

    function E() {
        if (h && null === v) try {
            v = new RegExp("\\p{N}", "gu"), g = new RegExp("\\p{L}", "gu"), m = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            h = !1
        }
    }
    var O = null,
        M = null,
        N = !1;

    function x() {
        N && (O = {
            time: s(),
            event: 4,
            data: {
                visible: M.visible,
                docWidth: M.docWidth,
                docHeight: M.docHeight,
                screenWidth: M.screenWidth,
                screenHeight: M.screenHeight,
                scrollX: M.scrollX,
                scrollY: M.scrollY,
                pointerX: M.pointerX,
                pointerY: M.pointerY,
                activityTime: M.activityTime,
                scrollTime: M.scrollTime,
                pointerTime: M.pointerTime,
                moveX: M.moveX,
                moveY: M.moveY,
                moveTime: M.moveTime,
                downX: M.downX,
                downY: M.downY,
                downTime: M.downTime,
                upX: M.upX,
                upY: M.upY,
                upTime: M.upTime,
                pointerPrevX: M.pointerPrevX,
                pointerPrevY: M.pointerPrevY,
                pointerPrevTime: M.pointerPrevTime
            }
        }), M = M || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: 0,
            moveX: 0,
            moveY: 0,
            moveTime: 0,
            downX: 0,
            downY: 0,
            downTime: 0,
            upX: 0,
            upY: 0,
            upTime: 0,
            pointerPrevX: 0,
            pointerPrevY: 0,
            pointerPrevTime: 0
        }
    }

    function _(t, e, n, a) {
        switch (t) {
            case 8:
                M.docWidth = e, M.docHeight = n;
                break;
            case 11:
                M.screenWidth = e, M.screenHeight = n;
                break;
            case 10:
                M.scrollX = e, M.scrollY = n, M.scrollTime = a;
                break;
            case 12:
                M.moveX = e, M.moveY = n, M.moveTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            case 13:
                M.downX = e, M.downY = n, M.downTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            case 14:
                M.upX = e, M.upY = n, M.upTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            default:
                M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a
        }
        N = !0
    }

    function I(t) {
        M.activityTime = t
    }

    function C(t, e) {
        M.visible = "visible" === e ? 1 : 0, M.visible || I(t), N = !0
    }

    function D() {
        N && Zr(4)
    }
    var P = Object.freeze({
            __proto__: null,
            activity: I,
            compute: D,
            reset: x,
            start: function() {
                N = !1, x()
            },
            get state() {
                return O
            },
            stop: function() {
                x()
            },
            track: _,
            visibility: C
        }),
        X = null;

    function Y(t, e) {
        to() && t && "string" == typeof t && t.length < 255 && (X = e && "string" == typeof e && e.length < 255 ? {
            key: t,
            value: e
        } : {
            value: t
        }, Zr(24))
    }
    var j, A = null,
        R = null;

    function L(t) {
        t in A || (A[t] = 0), t in R || (R[t] = 0), A[t]++, R[t]++
    }

    function z(t, e) {
        null !== e && (t in A || (A[t] = 0), t in R || (R[t] = 0), A[t] += e, R[t] += e)
    }

    function H(t, e) {
        null !== e && !1 === isNaN(e) && (t in A || (A[t] = 0), (e > A[t] || 0 === A[t]) && (R[t] = e, A[t] = e))
    }

    function W(t, e, n) {
        return window.setTimeout(Li(t), e, n)
    }

    function q(t) {
        return window.clearTimeout(t)
    }
    var U = 0,
        F = 0,
        V = null;

    function B() {
        V && q(V), V = W(J, F), U = s()
    }

    function J() {
        var t = s();
        j = {
            gap: t - U
        }, Zr(25), j.gap < 3e5 ? V = W(J, F) : Zi && (Y("clarity", "suspend"), No(), ["mousemove", "touchstart"].forEach((function(t) {
            return Hi(document, t, eo)
        })), ["resize", "scroll", "pageshow"].forEach((function(t) {
            return Hi(window, t, eo)
        })))
    }
    var G = Object.freeze({
            __proto__: null,
            get data() {
                return j
            },
            reset: B,
            start: function() {
                F = 6e4, U = 0
            },
            stop: function() {
                q(V), U = 0, F = 0
            }
        }),
        K = null;

    function Z(t, e) {
        if (t in K) {
            var n = K[t],
                a = n[n.length - 1];
            e - a[0] > 100 ? K[t].push([e, 0]) : a[1] = e - a[0]
        } else K[t] = [
            [e, 0]
        ]
    }

    function Q() {
        Zr(36)
    }

    function $() {
        K = {}
    }
    var tt = Object.freeze({
            __proto__: null,
            compute: Q,
            get data() {
                return K
            },
            reset: $,
            start: function() {
                K = {}
            },
            stop: function() {
                K = {}
            },
            track: Z
        }),
        et = null;

    function nt(t) {
        to() && o.lean && (o.lean = !1, et = {
            key: t
        }, Si(), Ti(), o.upgrade && o.upgrade(t), Zr(3))
    }
    var at = Object.freeze({
        __proto__: null,
        get data() {
            return et
        },
        start: function() {
            !o.lean && o.upgrade && o.upgrade("Config"), et = null
        },
        stop: function() {
            et = null
        },
        upgrade: nt
    });

    function rt(t, e, n, a) {
        return new(n || (n = Promise))((function(r, i) {
            function o(t) {
                try {
                    c(a.next(t))
                } catch (t) {
                    i(t)
                }
            }

            function u(t) {
                try {
                    c(a.throw(t))
                } catch (t) {
                    i(t)
                }
            }

            function c(t) {
                var e;
                t.done ? r(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                    t(e)
                }))).then(o, u)
            }
            c((a = a.apply(t, e || [])).next())
        }))
    }

    function it(t, e) {
        var n, a, r, i, o = {
            label: 0,
            sent: function() {
                if (1 & r[0]) throw r[1];
                return r[1]
            },
            trys: [],
            ops: []
        };
        return i = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this
        }), i;

        function u(u) {
            return function(c) {
                return function(u) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (; i && (i = 0, u[0] && (o = 0)), o;) try {
                        if (n = 1, a && (r = 2 & u[0] ? a.return : u[0] ? a.throw || ((r = a.return) && r.call(a), 0) : a.next) && !(r = r.call(a, u[1])).done) return r;
                        switch (a = 0, r && (u = [2 & u[0], r.value]), u[0]) {
                            case 0:
                            case 1:
                                r = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, a = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!(r = o.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!r || u[1] > r[0] && u[1] < r[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < r[1]) {
                                    o.label = r[1], r = u;
                                    break
                                }
                                if (r && o.label < r[2]) {
                                    o.label = r[2], o.ops.push(u);
                                    break
                                }
                                r[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = e.call(t, o)
                    } catch (t) {
                        u = [6, t], a = 0
                    } finally {
                        n = r = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, c])
            }
        }
    }
    var ot = null;

    function ut(t, e) {
        st(t, "string" == typeof e ? [e] : e)
    }

    function ct(t, e, n, a) {
        return void 0 === e && (e = null), void 0 === n && (n = null), void 0 === a && (a = null), rt(this, void 0, void 0, (function() {
            var r, i;
            return it(this, (function(o) {
                switch (o.label) {
                    case 0:
                        return i = {}, [4, ft(t)];
                    case 1:
                        return i.userId = o.sent(), i.userHint = a || ((u = t) && u.length >= 5 ? "".concat(u.substring(0, 2)).concat(S(u.substring(2), "*", "*")) : S(u, "*", "*")), st("userId", [(r = i).userId]), st("userHint", [r.userHint]), st("userType", [pt(t)]), e && (st("sessionId", [e]), r.sessionId = e), n && (st("pageId", [n]), r.pageId = n), [2, r]
                }
                var u
            }))
        }))
    }

    function st(t, e) {
        if (to() && t && e && "string" == typeof t && t.length < 255) {
            for (var n = (t in ot ? ot[t] : []), a = 0; a < e.length; a++) "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
            ot[t] = n
        }
    }

    function lt() {
        Zr(34)
    }

    function dt() {
        ot = {}
    }

    function ft(t) {
        return rt(this, void 0, void 0, (function() {
            var e;
            return it(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return n.trys.push([0, 4, , 5]), crypto && t ? [4, crypto.subtle.digest("SHA-256", (new TextEncoder).encode(t))] : [3, 2];
                    case 1:
                        return e = n.sent(), [2, Array.prototype.map.call(new Uint8Array(e), (function(t) {
                            return ("00" + t.toString(16)).slice(-2)
                        })).join("")];
                    case 2:
                        return [2, ""];
                    case 3:
                        return [3, 5];
                    case 4:
                        return n.sent(), [2, ""];
                    case 5:
                        return [2]
                }
            }))
        }))
    }

    function pt(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }
    var ht = "CompressionStream" in window;

    function vt(t) {
        return rt(this, void 0, void 0, (function() {
            var e, n;
            return it(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 3, , 4]), ht ? (e = new ReadableStream({
                            start: function(e) {
                                return rt(this, void 0, void 0, (function() {
                                    return it(this, (function(n) {
                                        return e.enqueue(t), e.close(), [2]
                                    }))
                                }))
                            }
                        }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip")), n = Uint8Array.bind, [4, gt(e)]) : [3, 2];
                    case 1:
                        return [2, new(n.apply(Uint8Array, [void 0, a.sent()]))];
                    case 2:
                        return [3, 4];
                    case 3:
                        return a.sent(), [3, 4];
                    case 4:
                        return [2, null]
                }
            }))
        }))
    }

    function gt(t) {
        return rt(this, void 0, void 0, (function() {
            var e, n, a, r, i;
            return it(this, (function(o) {
                switch (o.label) {
                    case 0:
                        e = t.getReader(), n = [], a = !1, r = [], o.label = 1;
                    case 1:
                        return a ? [3, 3] : [4, e.read()];
                    case 2:
                        return i = o.sent(), a = i.done, r = i.value, a ? [2, n] : (n.push.apply(n, r), [3, 1]);
                    case 3:
                        return [2, n]
                }
            }))
        }))
    }
    var mt = null;

    function yt(t) {
        try {
            if (!mt) return;
            var e = function(t) {
                try {
                    return JSON.parse(t)
                } catch (t) {
                    return []
                }
            }(t);
            e.forEach((function(t) {
                mt(t)
            }))
        } catch (t) {}
    }
    var bt = [P, a, Object.freeze({
        __proto__: null,
        compute: lt,
        get data() {
            return ot
        },
        identify: ct,
        reset: dt,
        set: ut,
        start: function() {
            dt()
        },
        stop: function() {
            dt()
        }
    }), n, tt, r, i, t, G, at, e];

    function wt() {
        A = {}, R = {}, L(5), bt.forEach((function(t) {
            return Li(t.start)()
        }))
    }

    function kt() {
        bt.slice().reverse().forEach((function(t) {
            return Li(t.stop)()
        })), A = {}, R = {}
    }

    function St() {
        lt(), D(), si(), Zr(0), Q(), ei(), Ur()
    }
    var Tt, Et = [];

    function Ot(t, e, n) {
        o.fraud && null !== t && n && n.length >= 5 && (Tt = {
            id: t,
            target: e,
            checksum: d(n, 28)
        }, Et.indexOf(Tt.checksum) < 0 && (Et.push(Tt.checksum), Ir(41)))
    }
    var Mt = "load,active,fixed,visible,focus,show,collaps,animat".split(","),
        Nt = {};

    function xt(t, e) {
        var n = t.attributes,
            a = t.prefix ? t.prefix[e] : null,
            r = 0 === e ? "".concat("~").concat(t.position - 1) : ":nth-of-type(".concat(t.position, ")");
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                if (null === a) return "";
                a = "".concat(a).concat(">"), t.tag = 0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag;
                var i = "".concat(a).concat(t.tag).concat(r),
                    o = "id" in n && n.id.length > 0 ? n.id : null,
                    u = "BODY" !== t.tag && "class" in n && n.class.length > 0 ? n.class.trim().split(/\s+/).filter((function(t) {
                        return _t(t)
                    })).join(".") : null;
                if (u && u.length > 0)
                    if (0 === e) {
                        var c = "".concat(function(t) {
                            for (var e = t.split(">"), n = 0; n < e.length; n++) {
                                var a = e[n].indexOf("~"),
                                    r = e[n].indexOf(".");
                                e[n] = e[n].substring(0, r > 0 ? r : a > 0 ? a : e[n].length)
                            }
                            return e.join(">")
                        }(a)).concat(t.tag).concat(".").concat(u);
                        c in Nt || (Nt[c] = []), Nt[c].indexOf(t.id) < 0 && Nt[c].push(t.id), i = "".concat(c).concat("~").concat(Nt[c].indexOf(t.id))
                    } else i = "".concat(a).concat(t.tag, ".").concat(u).concat(r);
                return i = o && _t(o) ? "".concat(function(t) {
                    var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("".concat("iframe:").concat("HTML")),
                        a = Math.max(e, n);
                    if (a < 0) return "";
                    return t.substring(0, t.indexOf(">", a) + 1)
                }(a)).concat("#").concat(o) : i, i
        }
    }

    function _t(t) {
        if (!t) return !1;
        if (Mt.some((function(e) {
                return t.toLowerCase().indexOf(e) >= 0
            }))) return !1;
        for (var e = 0; e < t.length; e++) {
            var n = t.charCodeAt(e);
            if (n >= 48 && n <= 57) return !1
        }
        return !0
    }
    var It = 1,
        Ct = null,
        Dt = [],
        Pt = [],
        Xt = {},
        Yt = [],
        jt = [],
        At = [],
        Rt = [],
        Lt = [],
        zt = [],
        Ht = null,
        Wt = null,
        qt = null,
        Ut = null;

    function Ft() {
        Bt(), Jt(document, !0)
    }

    function Vt() {
        Bt()
    }

    function Bt() {
        It = 1, Dt = [], Pt = [], Xt = {}, Yt = [], jt = [], At = "address,password,contact".split(","), Rt = "password,secret,pass,social,ssn,code,hidden".split(","), Lt = "radio,checkbox,range,button,reset,submit".split(","), zt = "INPUT,SELECT,TEXTAREA".split(","), Ct = new Map, Ht = new WeakMap, Wt = new WeakMap, qt = new WeakMap, Ut = new WeakMap, Nt = {}
    }

    function Jt(t, e) {
        void 0 === e && (e = !1);
        try {
            e && o.unmask.forEach((function(t) {
                return t.indexOf("!") < 0 ? jt.push(t) : Yt.push(t.substr(1))
            })), "querySelectorAll" in t && (o.regions.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return Za(t, "".concat(e[0]))
                }))
            })), o.mask.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return qt.set(t, 3)
                }))
            })), o.checksum.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return Ut.set(t, e[0])
                }))
            })), jt.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return qt.set(t, 0)
                }))
            })))
        } catch (t) {
            Pr(5, 1, t ? t.name : null)
        }
    }

    function Gt(t, e) {
        if (void 0 === e && (e = !1), null === t) return null;
        var n = Ht.get(t);
        return !n && e && (n = It++, Ht.set(t, n)), n || null
    }

    function Kt(t) {
        var e = !1;
        if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
            var n = t;
            try {
                n.contentDocument && (Wt.set(n.contentDocument, n), e = !0)
            } catch (t) {}
        }
        return e
    }

    function Zt(t) {
        var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
        return e && Wt.has(e) ? Wt.get(e) : null
    }

    function Qt(t, e, n) {
        if ("object" == typeof t[n] && "object" == typeof e[n]) {
            for (var a in t[n])
                if (t[n][a] !== e[n][a]) return !0;
            for (var a in e[n])
                if (e[n][a] !== t[n][a]) return !0;
            return !1
        }
        return t[n] !== e[n]
    }

    function $t(t) {
        var e = t.parent && t.parent in Dt ? Dt[t.parent] : null,
            n = e ? e.selector : null,
            a = t.data,
            r = function(t, e) {
                e.metadata.position = 1;
                for (var n = t ? t.children.indexOf(e.id) : -1; n-- > 0;) {
                    var a = Dt[t.children[n]];
                    if (e.data.tag === a.data.tag) {
                        e.metadata.position = a.metadata.position + 1;
                        break
                    }
                }
                return e.metadata.position
            }(e, t),
            i = {
                id: t.id,
                tag: a.tag,
                prefix: n,
                position: r,
                attributes: a.attributes
            };
        t.selector = [xt(i, 0), xt(i, 1)], t.hash = t.selector.map((function(t) {
            return t ? d(t) : null
        })), t.hash.forEach((function(e) {
            return Xt[e] = t.id
        }))
    }

    function te(t) {
        var e = ee(ae(t));
        return null !== e && null !== e.textContent ? e.textContent.substr(0, 25) : ""
    }

    function ee(t) {
        return Ct.has(t) ? Ct.get(t) : null
    }

    function ne(t) {
        var e = Gt(t);
        return e in Dt ? Dt[e] : null
    }

    function ae(t) {
        return t in Xt ? Xt[t] : null
    }

    function re(t) {
        return Ct.has(Gt(t))
    }

    function ie() {
        for (var t = [], e = 0, n = Pt; e < n.length; e++) {
            var a = n[e];
            a in Dt && t.push(Dt[a])
        }
        return Pt = [], t
    }

    function oe(t) {
        if (Ct.get(t).nodeType !== Node.DOCUMENT_FRAGMENT_NODE) {
            Ct.delete(t);
            var e = t in Dt ? Dt[t] : null;
            if (e && e.children)
                for (var n = 0, a = e.children; n < a.length; n++) {
                    oe(a[n])
                }
        }
    }

    function ue(t) {
        for (var e = null; null === e && t.previousSibling;) e = Gt(t.previousSibling), t = t.previousSibling;
        return e
    }

    function ce(t, e, n, a) {
        void 0 === n && (n = !0), void 0 === a && (a = !1);
        var r = Pt.indexOf(t);
        r >= 0 && 1 === e && a ? (Pt.splice(r, 1), Pt.push(t)) : -1 === r && n && Pt.push(t)
    }
    var se = Object.freeze({
            __proto__: null,
            add: function(t, e, n, a) {
                var r = e ? Gt(e) : null;
                if (e && r || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) {
                    var i = Gt(t, !0),
                        u = ue(t),
                        c = null,
                        s = Qa(t) ? i : null,
                        l = Ut.has(t) ? Ut.get(t) : null,
                        d = o.content ? 1 : 3;
                    r >= 0 && Dt[r] && ((c = Dt[r]).children.push(i), s = null === s ? c.region : s, l = null === l ? c.metadata.fraud : l, d = c.metadata.privacy), n.attributes && "data-clarity-region" in n.attributes && (Za(t, n.attributes["data-clarity-region"]), s = i), Ct.set(i, t), Dt[i] = {
                            id: i,
                            parent: r,
                            previous: u,
                            children: [],
                            data: n,
                            selector: null,
                            hash: null,
                            region: s,
                            metadata: {
                                active: !0,
                                suspend: !1,
                                privacy: d,
                                position: null,
                                fraud: l,
                                size: null
                            }
                        },
                        function(t, e, n) {
                            var a, r = e.data,
                                i = e.metadata,
                                o = i.privacy,
                                u = r.attributes || {},
                                c = r.tag.toUpperCase();
                            switch (!0) {
                                case zt.indexOf(c) >= 0:
                                    var s = u.type,
                                        l = "",
                                        d = ["class", "style"];
                                    Object.keys(u).filter((function(t) {
                                        return !d.includes(t)
                                    })).forEach((function(t) {
                                        return l += u[t].toLowerCase()
                                    }));
                                    var f = Rt.some((function(t) {
                                        return l.indexOf(t) >= 0
                                    }));
                                    i.privacy = "INPUT" === c && Lt.indexOf(s) >= 0 ? o : f ? 4 : 2;
                                    break;
                                case "data-clarity-mask" in u:
                                    i.privacy = 3;
                                    break;
                                case "data-clarity-unmask" in u:
                                    i.privacy = 0;
                                    break;
                                case qt.has(t):
                                    i.privacy = qt.get(t);
                                    break;
                                case Ut.has(t):
                                    i.privacy = 2;
                                    break;
                                case "*T" === c:
                                    var p = n && n.data ? n.data.tag : "",
                                        h = n && n.selector ? n.selector[1] : "",
                                        v = ["STYLE", "TITLE", "svg:style"];
                                    i.privacy = v.includes(p) || Yt.some((function(t) {
                                        return h.indexOf(t) >= 0
                                    })) ? 0 : o;
                                    break;
                                case 1 === o:
                                    i.privacy = function(t, e, n) {
                                        if (t && e.some((function(e) {
                                                return t.indexOf(e) >= 0
                                            }))) return 2;
                                        return n.privacy
                                    }(u.class, At, i);
                                    break;
                                case "IMG" === c:
                                    (null === (a = u.src) || void 0 === a ? void 0 : a.startsWith("blob:")) && (i.privacy = 3)
                            }
                        }(t, Dt[i], c), $t(Dt[i]),
                        function(t) {
                            if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
                                var e = ee(t.id);
                                !e || e.complete && 0 !== e.naturalWidth || Hi(e, "load", (function() {
                                    e.setAttribute("data-clarity-loaded", "".concat(Mi()))
                                })), t.metadata.size = []
                            }
                        }(Dt[i]), ce(i, a)
                }
            },
            get: ne,
            getId: Gt,
            getNode: ee,
            getValue: function(t) {
                return t in Dt ? Dt[t] : null
            },
            has: re,
            hashText: te,
            iframe: Zt,
            lookup: ae,
            parse: Jt,
            sameorigin: Kt,
            start: Ft,
            stop: Vt,
            update: function(t, e, n, a) {
                var r = Gt(t),
                    i = e ? Gt(e) : null,
                    o = ue(t),
                    u = !1,
                    c = !1;
                if (r in Dt) {
                    var s = Dt[r];
                    if (s.metadata.active = !0, s.previous !== o && (u = !0, s.previous = o), s.parent !== i) {
                        u = !0;
                        var l = s.parent;
                        if (s.parent = i, null !== i && i >= 0) {
                            var d = null === o ? 0 : Dt[i].children.indexOf(o) + 1;
                            Dt[i].children.splice(d, 0, r), s.region = Qa(t) ? r : Dt[i].region
                        } else ! function(t, e) {
                            if (t in Dt) {
                                var n = Dt[t];
                                n.metadata.active = !1, n.parent = null, ce(t, e), oe(t)
                            }
                        }(r, a);
                        if (null !== l && l >= 0) {
                            var f = Dt[l].children.indexOf(r);
                            f >= 0 && Dt[l].children.splice(f, 1)
                        }
                        c = !0
                    }
                    for (var p in n) Qt(s.data, n, p) && (u = !0, s.data[p] = n[p]);
                    $t(s), ce(r, a, u, c)
                }
            },
            updates: ie
        }),
        le = 5e3,
        de = {},
        fe = [],
        pe = null,
        he = null,
        ve = null;

    function ge() {
        de = {}, fe = [], pe = null, he = null
    }

    function me(t, e) {
        return void 0 === e && (e = 0), rt(this, void 0, void 0, (function() {
            var n, a, r;
            return it(this, (function(i) {
                for (n = 0, a = fe; n < a.length; n++)
                    if (a[n].task === t) return [2];
                return r = new Promise((function(n) {
                    fe[1 === e ? "unshift" : "push"]({
                        task: t,
                        resolve: n,
                        id: bi()
                    })
                })), null === pe && null === he && ye(), [2, r]
            }))
        }))
    }

    function ye() {
        var t = fe.shift();
        t && (pe = t, t.task().then((function() {
            t.id === bi() && (t.resolve(), pe = null, ye())
        })).catch((function(e) {
            t.id === bi() && (e && Pr(0, 1, e.name, e.message, e.stack), pe = null, ye())
        })))
    }

    function be(t) {
        var e = Te(t);
        return e in de ? performance.now() - de[e].start > de[e].yield ? 0 : 1 : 2
    }

    function we(t) {
        de[Te(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function ke(t) {
        var e = performance.now(),
            n = Te(t),
            a = e - de[n].start;
        z(t.cost, a), L(5), de[n].calls > 0 && z(4, a)
    }

    function Se(t) {
        return rt(this, void 0, void 0, (function() {
            var e, n;
            return it(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return (e = Te(t)) in de ? (ke(t), n = de[e], [4, Ee()]) : [3, 2];
                    case 1:
                        n.yield = a.sent().timeRemaining(),
                            function(t) {
                                var e = Te(t);
                                if (de && de[e]) {
                                    var n = de[e].calls,
                                        a = de[e].yield;
                                    we(t), de[e].calls = n + 1, de[e].yield = a
                                }
                            }(t), a.label = 2;
                    case 2:
                        return [2, e in de ? 1 : 2]
                }
            }))
        }))
    }

    function Te(t) {
        return "".concat(t.id, ".").concat(t.cost)
    }

    function Ee() {
        return rt(this, void 0, void 0, (function() {
            return it(this, (function(t) {
                switch (t.label) {
                    case 0:
                        return he ? [4, he] : [3, 2];
                    case 1:
                        t.sent(), t.label = 2;
                    case 2:
                        return [2, new Promise((function(t) {
                            Me(t, {
                                timeout: le
                            })
                        }))]
                }
            }))
        }))
    }
    var Oe, Me = window.requestIdleCallback || function(t, e) {
        var n = performance.now(),
            a = new MessageChannel,
            r = a.port1,
            i = a.port2;
        r.onmessage = function(a) {
            var r = performance.now(),
                o = r - n,
                u = r - a.data;
            if (u > 30 && o < e.timeout) requestAnimationFrame((function() {
                i.postMessage(r)
            }));
            else {
                var c = o > e.timeout;
                t({
                    didTimeout: c,
                    timeRemaining: function() {
                        return c ? 30 : Math.max(0, 30 - u)
                    }
                })
            }
        }, requestAnimationFrame((function() {
            i.postMessage(performance.now())
        }))
    };

    function Ne() {
        Oe = null
    }

    function xe() {
        xe.dn = 19;
        var t = document.body,
            e = document.documentElement,
            n = t ? t.clientWidth : null,
            a = t ? t.scrollWidth : null,
            r = t ? t.offsetWidth : null,
            i = e ? e.clientWidth : null,
            o = e ? e.scrollWidth : null,
            u = e ? e.offsetWidth : null,
            c = Math.max(n, a, r, i, o, u),
            s = t ? t.clientHeight : null,
            l = t ? t.scrollHeight : null,
            d = t ? t.offsetHeight : null,
            f = e ? e.clientHeight : null,
            p = e ? e.scrollHeight : null,
            h = e ? e.offsetHeight : null,
            v = Math.max(s, l, d, f, p, h);
        null !== Oe && c === Oe.width && v === Oe.height || null === c || null === v || (Oe = {
            width: c,
            height: v
        }, Ha(8))
    }
    var _e = [];

    function Ie(t) {
        Ie.dn = 5;
        var e = rr(t);
        if (e) {
            var n = e.value,
                a = n && n.length >= 5 && o.fraud && -1 === "password,secret,pass,social,ssn,code,hidden".indexOf(e.type) ? d(n, 28) : "";
            _e.push({
                time: s(t),
                event: 42,
                data: {
                    target: rr(t),
                    type: e.type,
                    value: n,
                    checksum: a
                }
            }), me(or.bind(this, 42))
        }
    }

    function Ce() {
        _e = []
    }

    function De(t) {
        var e = {
            x: 0,
            y: 0
        };
        if (t && t.offsetParent)
            do {
                var n = t.offsetParent,
                    a = null === n ? Zt(t.ownerDocument) : null;
                e.x += t.offsetLeft, e.y += t.offsetTop, t = a || n
            } while (t);
        return e
    }
    var Pe = ["input", "textarea", "radio", "button", "canvas"],
        Xe = [];

    function Ye(t) {
        Hi(t, "click", je.bind(this, 9, t), !0)
    }

    function je(t, e, n) {
        je.dn = 6;
        var a = Zt(e),
            r = a ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = De(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        var c = rr(n),
            l = function(t) {
                for (; t && t !== document;) {
                    if (t.nodeType === Node.ELEMENT_NODE) {
                        var e = t;
                        if ("A" === e.tagName) return e
                    }
                    t = t.parentNode
                }
                return null
            }(c),
            d = function(t) {
                var e = null,
                    n = document.documentElement;
                if ("function" == typeof t.getBoundingClientRect) {
                    var a = t.getBoundingClientRect();
                    a && a.width > 0 && a.height > 0 && (e = {
                        x: Math.floor(a.left + ("pageXOffset" in window ? window.pageXOffset : n.scrollLeft)),
                        y: Math.floor(a.top + ("pageYOffset" in window ? window.pageYOffset : n.scrollTop)),
                        w: Math.floor(a.width),
                        h: Math.floor(a.height)
                    })
                }
                return e
            }(c);
        0 === n.detail && d && (i = Math.round(d.x + d.w / 2), o = Math.round(d.y + d.h / 2));
        var f = d ? Math.max(Math.floor((i - d.x) / d.w * 32767), 0) : 0,
            p = d ? Math.max(Math.floor((o - d.y) / d.h * 32767), 0) : 0;
        if (null !== i && null !== o) {
            var h = function(t) {
                var e = null,
                    n = !1;
                if (t) {
                    var a = t.textContent || String(t.value || "") || t.alt;
                    if (a) {
                        var r = a.replace(/\s+/g, " ").trim();
                        n = (e = r.substring(0, 25)).length === r.length
                    }
                }
                return {
                    text: e,
                    isFullText: n ? 1 : 0
                }
            }(c);
            Xe.push({
                time: s(n),
                event: t,
                data: {
                    target: c,
                    x: i,
                    y: o,
                    eX: f,
                    eY: p,
                    button: n.button,
                    reaction: Ae(c),
                    context: Re(l),
                    text: h.text,
                    link: l ? l.href : null,
                    hash: null,
                    trust: n.isTrusted ? 1 : 0,
                    isFullText: h.isFullText
                }
            }), me(or.bind(this, t))
        }
    }

    function Ae(t) {
        if (t.nodeType === Node.ELEMENT_NODE) {
            var e = t.tagName.toLowerCase();
            if (Pe.indexOf(e) >= 0) return 0
        }
        return 1
    }

    function Re(t) {
        if (t && t.hasAttribute("target")) switch (t.getAttribute("target")) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function Le() {
        Xe = []
    }
    var ze = [];

    function He(t, e) {
        He.dn = 7, ze.push({
            time: s(e),
            event: 38,
            data: {
                target: rr(e),
                action: t
            }
        }), me(or.bind(this, 38))
    }

    function We() {
        ze = []
    }
    var qe = null,
        Ue = [];

    function Fe(t) {
        Fe.dn = 9;
        var e = rr(t),
            n = ne(e);
        if (e && e.type && n) {
            var a = e.value,
                r = e.type;
            switch (e.type) {
                case "radio":
                case "checkbox":
                    a = e.checked ? "true" : "false"
            }
            var i = {
                target: e,
                value: a,
                type: r
            };
            Ue.length > 0 && Ue[Ue.length - 1].data.target === i.target && Ue.pop(), Ue.push({
                time: s(t),
                event: 27,
                data: i
            }), q(qe), qe = W(Ve, 1e3, 27)
        }
    }

    function Ve(t) {
        me(or.bind(this, t))
    }

    function Be() {
        Ue = []
    }
    var Je, Ge = [],
        Ke = null,
        Ze = !1,
        Qe = 0,
        $e = new Set;

    function tn(t, e, n) {
        tn.dn = 10;
        var a = Zt(e),
            r = a ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = De(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        null !== i && null !== o && nn({
            time: s(n),
            event: t,
            data: {
                target: rr(n),
                x: i,
                y: o
            }
        })
    }

    function en(t, e, n) {
        en.dn = 11;
        var a = Zt(e),
            r = a ? a.contentDocument.documentElement : document.documentElement,
            i = n.changedTouches,
            o = s(n);
        if (i)
            for (var u = 0; u < i.length; u++) {
                var c = i[u],
                    l = "clientX" in c ? Math.round(c.clientX + r.scrollLeft) : null,
                    d = "clientY" in c ? Math.round(c.clientY + r.scrollTop) : null;
                l = l && a ? l + Math.round(a.offsetLeft) : l, d = d && a ? d + Math.round(a.offsetTop) : d;
                var f = "identifier" in c ? c.identifier : void 0;
                switch (t) {
                    case 17:
                        0 === $e.size && (Ze = !0, Qe = f), $e.add(f);
                        break;
                    case 18:
                    case 20:
                        $e.delete(f)
                }
                var p = Ze && Qe === f;
                null !== l && null !== d && nn({
                    time: o,
                    event: t,
                    data: {
                        target: rr(n),
                        x: l,
                        y: d,
                        id: f,
                        isPrimary: p
                    }
                }), 20 !== t && 18 !== t || Qe === f && (Ze = !1)
            }
    }

    function nn(t) {
        switch (t.event) {
            case 12:
            case 15:
            case 19:
                var e = Ge.length,
                    n = e > 1 ? Ge[e - 2] : null;
                n && function(t, e) {
                    var n = t.data.x - e.data.x,
                        a = t.data.y - e.data.y,
                        r = Math.sqrt(n * n + a * a),
                        i = e.time - t.time,
                        o = e.data.target === t.data.target;
                    return e.event === t.event && o && r < 20 && i < 25
                }(n, t) && Ge.pop(), Ge.push(t), q(Ke), Ke = W(an, 500, t.event);
                break;
            default:
                Ge.push(t), an(t.event)
        }
    }

    function an(t) {
        me(or.bind(this, t))
    }

    function rn() {
        Ge = []
    }
    var on = null,
        un = !1;

    function cn() {
        cn.dn = 12;
        var t = document.documentElement;
        Je = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, window.innerWidth) : window.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, window.innerHeight) : window.innerHeight
        }, un ? (q(on), on = W(sn, 500, 11)) : (or(11), un = !0)
    }

    function sn(t) {
        me(or.bind(this, t))
    }

    function ln() {
        Je = null, q(on)
    }
    var dn = [],
        fn = null,
        pn = null,
        hn = null;

    function vn(t) {
        void 0 === t && (t = null), vn.dn = 13;
        var e = window,
            n = document.documentElement,
            a = t ? rr(t) : n;
        if (a && a.nodeType === Node.DOCUMENT_NODE) {
            var r = Zt(a);
            e = r ? r.contentWindow : e, a = n = a.documentElement
        }
        var i = a === n && "pageXOffset" in e ? Math.round(e.pageXOffset) : Math.round(a.scrollLeft),
            o = a === n && "pageYOffset" in e ? Math.round(e.pageYOffset) : Math.round(a.scrollTop),
            u = window.innerWidth,
            c = window.innerHeight,
            l = u / 3,
            d = u > c ? .15 * c : .2 * c,
            f = c - d,
            p = gn(l, d),
            h = gn(l, f),
            v = {
                time: s(t),
                event: 10,
                data: {
                    target: a,
                    x: i,
                    y: o,
                    top: p,
                    bottom: h
                }
            };
        if (null === t && 0 === i && 0 === o || null === i || null === o) return fn = p, void(pn = h);
        var g = dn.length,
            m = g > 1 ? dn[g - 2] : null;
        m && function(t, e) {
            var n = t.data.x - e.data.x,
                a = t.data.y - e.data.y;
            return n * n + a * a < 400 && e.time - t.time < 25
        }(m, v) && dn.pop(), dn.push(v), q(hn), hn = W(mn, 500, 10)
    }

    function gn(t, e) {
        var n, a, r;
        return "caretPositionFromPoint" in document ? r = null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n ? void 0 : n.offsetNode : "caretRangeFromPoint" in document && (r = null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a ? void 0 : a.startContainer), r || (r = document.elementFromPoint(t, e)), r && r.nodeType === Node.TEXT_NODE && (r = r.parentNode), r
    }

    function mn(t) {
        me(or.bind(this, t))
    }

    function yn() {
        var t, e;
        if (yn.dn = 14, fn) {
            var n = ir(fn, null);
            ci(31, null === (t = null == n ? void 0 : n.hash) || void 0 === t ? void 0 : t.join("."))
        }
        if (pn) {
            var a = ir(pn, null);
            ci(32, null === (e = null == a ? void 0 : a.hash) || void 0 === e ? void 0 : e.join("."))
        }
    }
    var bn = null,
        wn = null,
        kn = null;

    function Sn(t) {
        Sn.dn = 15;
        var e = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
        if (null !== e && !(null === e.anchorNode && null === e.focusNode || e.anchorNode === e.focusNode && e.anchorOffset === e.focusOffset)) {
            var n = bn.start ? bn.start : null;
            null !== wn && null !== bn.start && n !== e.anchorNode && (q(kn), Tn(21)), bn = {
                start: e.anchorNode,
                startOffset: e.anchorOffset,
                end: e.focusNode,
                endOffset: e.focusOffset
            }, wn = e, q(kn), kn = W(Tn, 500, 21)
        }
    }

    function Tn(t) {
        me(or.bind(this, t))
    }

    function En() {
        wn = null, bn = {
            start: 0,
            startOffset: 0,
            end: 0,
            endOffset: 0
        }
    }
    var On, Mn, Nn = [];

    function xn(t) {
        xn.dn = 16, Nn.push({
            time: s(t),
            event: 39,
            data: {
                target: rr(t)
            }
        }), me(or.bind(this, 39))
    }

    function _n() {
        Nn = []
    }

    function In(t) {
        In.dn = 17, On = {
            name: t.type,
            persisted: t.persisted ? 1 : 0
        }, or(26, s(t)), No()
    }

    function Cn() {
        On = null
    }

    function Dn(t) {
        void 0 === t && (t = null), Dn.dn = 18, Mn = {
            visible: "visibilityState" in document ? document.visibilityState : "default"
        }, or(28, s(t))
    }

    function Pn() {
        Mn = null
    }

    function Xn(t) {
        ! function(t) {
            var e = Zt(t);
            Hi(e ? e.contentWindow : t === document ? window : t, "scroll", vn, !0)
        }(t), t.nodeType === Node.DOCUMENT_NODE && (Ye(t), function(t) {
            Hi(t, "cut", He.bind(this, 0), !0), Hi(t, "copy", He.bind(this, 1), !0), Hi(t, "paste", He.bind(this, 2), !0)
        }(t), function(t) {
            Hi(t, "mousedown", tn.bind(this, 13, t), !0), Hi(t, "mouseup", tn.bind(this, 14, t), !0), Hi(t, "mousemove", tn.bind(this, 12, t), !0), Hi(t, "wheel", tn.bind(this, 15, t), !0), Hi(t, "dblclick", tn.bind(this, 16, t), !0), Hi(t, "touchstart", en.bind(this, 17, t), !0), Hi(t, "touchend", en.bind(this, 18, t), !0), Hi(t, "touchmove", en.bind(this, 19, t), !0), Hi(t, "touchcancel", en.bind(this, 20, t), !0)
        }(t), function(t) {
            Hi(t, "input", Fe, !0)
        }(t), function(t) {
            Hi(t, "selectstart", Sn.bind(this, t), !0), Hi(t, "selectionchange", Sn.bind(this, t), !0)
        }(t), function(t) {
            Hi(t, "change", Ie, !0)
        }(t), function(t) {
            Hi(t, "submit", xn, !0)
        }(t))
    }
    var Yn = Object.freeze({
        __proto__: null,
        observe: Xn,
        start: function t() {
            t.dn = 8, ur = [], sr(), Le(), We(), rn(), Be(), un = !1, Hi(window, "resize", cn), cn(), Hi(document, "visibilitychange", Dn), Dn(), dn = [], vn(), En(), Ce(), _n(), Hi(window, "pagehide", In)
        },
        stop: function() {
            ur = [], sr(), Le(), We(), q(Ke), Ge.length > 0 && an(Ge[Ge.length - 1].event), q(qe), Be(), ln(), Pn(), q(hn), dn = [], fn = null, pn = null, En(), q(kn), Ce(), _n(), Cn()
        }
    });

    function jn(t, e, n, a) {
        return rt(this, void 0, void 0, (function() {
            var r, i, o, u, c;
            return it(this, (function(s) {
                switch (s.label) {
                    case 0:
                        r = [t], s.label = 1;
                    case 1:
                        if (!(r.length > 0)) return [3, 4];
                        for (i = r.shift(), o = i.firstChild; o;) r.push(o), o = o.nextSibling;
                        return 0 !== (u = be(e)) ? [3, 3] : [4, Se(e)];
                    case 2:
                        u = s.sent(), s.label = 3;
                    case 3:
                        return 2 === u ? [3, 4] : ((c = da(i, n, a)) && r.push(c), [3, 1]);
                    case 4:
                        return [2]
                }
            }))
        }))
    }
    var An = [],
        Rn = [],
        Ln = {},
        zn = null,
        Hn = null,
        Wn = null,
        qn = null,
        Un = null,
        Fn = [],
        Vn = null,
        Bn = null,
        Jn = null,
        Gn = {},
        Kn = null,
        Zn = ["data-google-query-id", "data-load-complete", "data-google-container-id"];

    function Qn() {
        if (Qn.dn = 21, An = [], Fn = [], Vn = null, Jn = 0, Gn = {}, Kn = 0, null === zn && (zn = CSSStyleSheet.prototype.insertRule, CSSStyleSheet.prototype.insertRule = function() {
                return to() && ra(this.ownerNode), zn.apply(this, arguments)
            }), "CSSMediaRule" in window && null === qn && (qn = CSSMediaRule.prototype.insertRule, CSSMediaRule.prototype.insertRule = function() {
                return to() && ra(this.parentStyleSheet.ownerNode), qn.apply(this, arguments)
            }), null === Hn && (Hn = CSSStyleSheet.prototype.deleteRule, CSSStyleSheet.prototype.deleteRule = function() {
                return to() && ra(this.ownerNode), Hn.apply(this, arguments)
            }), "CSSMediaRule" in window && null === Un && (Un = CSSMediaRule.prototype.deleteRule, CSSMediaRule.prototype.deleteRule = function() {
                return to() && ra(this.parentStyleSheet.ownerNode), Un.apply(this, arguments)
            }), null === Wn) {
            Wn = Element.prototype.attachShadow;
            try {
                Element.prototype.attachShadow = function() {
                    return to() ? ra(Wn.apply(this, arguments)) : Wn.apply(this, arguments)
                }
            } catch (t) {
                Wn = null
            }
        }
    }

    function $n(t) {
        $n.dn = 22;
        var e = s();
        Z(6, e), Rn.push({
            time: e,
            mutations: t
        }), me(ea, 1).then((function() {
            W(xe), Li($a)()
        }))
    }

    function ta(t, e, n, a) {
        return rt(this, void 0, void 0, (function() {
            var r, i, u;
            return it(this, (function(c) {
                switch (c.label) {
                    case 0:
                        return 0 !== (r = be(t)) ? [3, 2] : [4, Se(t)];
                    case 1:
                        r = c.sent(), c.label = 2;
                    case 2:
                        if (2 === r) return [2];
                        switch (i = e.target, u = o.throttleDom ? function(t, e, n, a) {
                            var r = t.target ? ne(t.target.parentNode) : null;
                            if (r && "HTML" !== r.data.tag) {
                                var i = a > Jn,
                                    u = n < Kn,
                                    c = ne(t.target),
                                    s = c && c.selector ? c.selector.join() : t.target.nodeName,
                                    l = r.selector ? r.selector.join() : "",
                                    d = o.throttleMutations && u && (0 === o.discard.length || o.discard.some((function(t) {
                                        return s.includes(t)
                                    }))),
                                    f = [l, s, t.attributeName, na(t.addedNodes), na(t.removedNodes)].join();
                                Gn[f] = f in Gn ? Gn[f] : [0, n];
                                var p = Gn[f];
                                if (!1 === i && p[0] >= 10 && aa(p[2], 2, e, a), p[0] = i || d ? p[1] === n ? p[0] : p[0] + 1 : 1, p[1] = n, p[0] >= 10 || d) return p[2] = t.removedNodes, n > a + 3e3 ? t.type : (o.dropMutations || (Ln[f] = {
                                    mutation: t,
                                    timestamp: a
                                }), "throttle")
                            }
                            return t.type
                        }(e, t, n, a) : e.type, u && i && i.ownerDocument && Jt(i.ownerDocument), u && i && i.nodeType == Node.DOCUMENT_FRAGMENT_NODE && i.host && Jt(i), u) {
                            case "attributes":
                                Zn.indexOf(e.attributeName) < 0 && da(i, 3, a);
                                break;
                            case "characterData":
                                da(i, 4, a);
                                break;
                            case "childList":
                                aa(e.addedNodes, 1, t, a), aa(e.removedNodes, 2, t, a)
                        }
                        return [2]
                }
            }))
        }))
    }

    function ea() {
        return rt(this, void 0, void 0, (function() {
            var t, e, n, a, r, i, o, u, c, l, d;
            return it(this, (function(f) {
                switch (f.label) {
                    case 0:
                        we(t = {
                            id: bi(),
                            cost: 3
                        }), f.label = 1;
                    case 1:
                        if (!(Rn.length > 0)) return [3, 7];
                        e = Rn.shift(), n = s(), a = 0, r = e.mutations, f.label = 2;
                    case 2:
                        return a < r.length ? (i = r[a], [4, ta(t, i, n, e.time)]) : [3, 5];
                    case 3:
                        f.sent(), f.label = 4;
                    case 4:
                        return a++, [3, 2];
                    case 5:
                        return [4, Ha(6, t, e.time)];
                    case 6:
                        return f.sent(), [3, 1];
                    case 7:
                        o = !1, u = 0, c = Object.keys(Ln), f.label = 8;
                    case 8:
                        return u < c.length ? (l = c[u], d = Ln[l], delete Ln[l], [4, ta(t, d.mutation, s(), d.timestamp)]) : [3, 11];
                    case 9:
                        f.sent(), o = !0, f.label = 10;
                    case 10:
                        return u++, [3, 8];
                    case 11:
                        return Object.keys(Ln).length > 0 && function() {
                            Bn && q(Bn);
                            Bn = W((function() {
                                me(ea, 1)
                            }), 33)
                        }(), 0 === Object.keys(Ln).length && o ? [4, Ha(6, t, s())] : [3, 13];
                    case 12:
                        f.sent(), f.label = 13;
                    case 13:
                        return function() {
                            var t = s();
                            Object.keys(Gn).length > 1e4 && (Gn = {}, L(38));
                            for (var e = 0, n = Object.keys(Gn); e < n.length; e++) {
                                var a = n[e];
                                t > Gn[a][1] + 3e4 && delete Gn[a]
                            }
                        }(), ke(t), [2]
                }
            }))
        }))
    }

    function na(t) {
        for (var e = [], n = 0; t && n < t.length; n++) e.push(t[n].nodeName);
        return e.join()
    }

    function aa(t, e, n, a) {
        return rt(this, void 0, void 0, (function() {
            var r, i, o, u;
            return it(this, (function(c) {
                switch (c.label) {
                    case 0:
                        r = t ? t.length : 0, i = 0, c.label = 1;
                    case 1:
                        return i < r ? (o = t[i], 1 !== e ? [3, 2] : (jn(o, n, e, a), [3, 5])) : [3, 6];
                    case 2:
                        return 0 !== (u = be(n)) ? [3, 4] : [4, Se(n)];
                    case 3:
                        u = c.sent(), c.label = 4;
                    case 4:
                        if (2 === u) return [3, 6];
                        da(o, e, a), c.label = 5;
                    case 5:
                        return i++, [3, 1];
                    case 6:
                        return [2]
                }
            }))
        }))
    }

    function ra(t) {
        return Fn.indexOf(t) < 0 && Fn.push(t), Vn && q(Vn), Vn = W((function() {
            ! function() {
                for (var t = 0, e = Fn; t < e.length; t++) {
                    var n = e[t];
                    if (n) {
                        var a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE;
                        if (a && re(n)) continue;
                        ia(n, a ? "childList" : "characterData")
                    }
                }
                Fn = []
            }()
        }), 33), t
    }

    function ia(t, e) {
        ia.dn = 23, Li($n)([{
            addedNodes: [t],
            attributeName: null,
            attributeNamespace: null,
            nextSibling: null,
            oldValue: null,
            previousSibling: null,
            removedNodes: [],
            target: t,
            type: e
        }])
    }
    var oa = /[^0-9\.]/g;

    function ua(t) {
        for (var e = 0, n = Object.keys(t); e < n.length; e++) {
            var a = n[e],
                r = t[a];
            if ("@type" === a && "string" == typeof r) switch (r = (r = r.toLowerCase()).indexOf("article") >= 0 || r.indexOf("posting") >= 0 ? "article" : r) {
                case "article":
                case "recipe":
                    ci(5, t[a]), ci(8, t.creator), ci(18, t.headline);
                    break;
                case "product":
                    ci(5, t[a]), ci(10, t.name), ci(12, t.sku), t.brand && ci(6, t.brand.name);
                    break;
                case "aggregaterating":
                    t.ratingValue && (H(11, ca(t.ratingValue, 100)), H(18, ca(t.bestRating)), H(19, ca(t.worstRating))), H(12, ca(t.ratingCount)), H(17, ca(t.reviewCount));
                    break;
                case "offer":
                    ci(7, t.availability), ci(14, t.itemCondition), ci(13, t.priceCurrency), ci(12, t.sku), H(13, ca(t.price));
                    break;
                case "brand":
                    ci(6, t.name)
            }
            null !== r && "object" == typeof r && ua(r)
        }
    }

    function ca(t, e) {
        if (void 0 === e && (e = 1), null !== t) switch (typeof t) {
            case "number":
                return Math.round(t * e);
            case "string":
                return Math.round(parseFloat(t.replace(oa, "")) * e)
        }
        return null
    }
    var sa = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label"],
        la = /[\r\n]+/g;

    function da(t, e, n) {
        var a, r = null;
        if (2 === e && !1 === re(t)) return r;
        0 !== e && t.nodeType === Node.TEXT_NODE && t.parentElement && "STYLE" === t.parentElement.tagName && (t = t.parentNode);
        var i = !1 === re(t) ? "add" : "update",
            o = t.parentElement ? t.parentElement : null,
            u = t.ownerDocument !== document;
        switch (t.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
                o = u && t.parentNode ? Zt(t.parentNode) : o;
                var c = t,
                    s = {
                        tag: (u ? "iframe:" : "") + "*D",
                        attributes: {
                            name: c.name ? c.name : "HTML",
                            publicId: c.publicId,
                            systemId: c.systemId
                        }
                    };
                se[i](t, o, s, e);
                break;
            case Node.DOCUMENT_NODE:
                t === document && Jt(document), Ea(t, n), fa(t);
                break;
            case Node.DOCUMENT_FRAGMENT_NODE:
                var l = t;
                if (l.host) {
                    if (Jt(l), "function" === typeof l.constructor && l.constructor.toString().indexOf("[native code]") >= 0) {
                        fa(l);
                        var d = {
                            tag: "*S",
                            attributes: {
                                style: ""
                            }
                        };
                        se[i](t, l.host, d, e)
                    } else se[i](t, l.host, {
                        tag: "*P",
                        attributes: {}
                    }, e);
                    Ea(t, n)
                }
                break;
            case Node.TEXT_NODE:
                if (o = o || t.parentNode, "update" === i || o && re(o) && "STYLE" !== o.tagName && "NOSCRIPT" !== o.tagName) {
                    var f = {
                        tag: "*T",
                        value: t.nodeValue
                    };
                    se[i](t, o, f, e)
                }
                break;
            case Node.ELEMENT_NODE:
                var p = t,
                    h = p.tagName,
                    v = function(t) {
                        var e = {},
                            n = t.attributes;
                        if (n && n.length > 0)
                            for (var a = 0; a < n.length; a++) {
                                var r = n[a].name;
                                sa.indexOf(r) < 0 && (e[r] = n[a].value)
                            }
                        "INPUT" === t.tagName && !("value" in e) && t.value && (e.value = t.value);
                        return e
                    }(p);
                switch (o = t.parentElement ? t.parentElement : t.parentNode ? t.parentNode : null, "http://www.w3.org/2000/svg" === p.namespaceURI && (h = "svg:" + h), h) {
                    case "HTML":
                        o = u && o ? Zt(o) : o;
                        var g = {
                            tag: (u ? "iframe:" : "") + h,
                            attributes: v
                        };
                        se[i](t, o, g, e);
                        break;
                    case "SCRIPT":
                        if ("type" in v && "application/ld+json" === v.type) try {
                            ua(JSON.parse(p.text.replace(la, "")))
                        } catch (t) {}
                        break;
                    case "NOSCRIPT":
                        var m = {
                            tag: h,
                            attributes: {},
                            value: ""
                        };
                        se[i](t, o, m, e);
                        break;
                    case "META":
                        var y = "property" in v ? "property" : "name" in v ? "name" : null;
                        if (y && "content" in v) {
                            var b = v.content;
                            switch (v[y]) {
                                case "og:title":
                                    ci(20, b);
                                    break;
                                case "og:type":
                                    ci(19, b);
                                    break;
                                case "generator":
                                    ci(21, b)
                            }
                        }
                        break;
                    case "HEAD":
                        var w = {
                                tag: h,
                                attributes: v
                            },
                            k = u && (null === (a = t.ownerDocument) || void 0 === a ? void 0 : a.location) ? t.ownerDocument.location : location;
                        w.attributes["*B"] = k.protocol + "//" + k.host + k.pathname, se[i](t, o, w, e);
                        break;
                    case "BASE":
                        var S = ne(t.parentElement);
                        if (S) {
                            var T = document.createElement("a");
                            T.href = v.href, S.data.attributes["*B"] = T.protocol + "//" + T.host + T.pathname
                        }
                        break;
                    case "STYLE":
                        var E = {
                            tag: h,
                            attributes: v,
                            value: pa(p)
                        };
                        se[i](t, o, E, e);
                        break;
                    case "IFRAME":
                        var O = t,
                            M = {
                                tag: h,
                                attributes: v
                            };
                        Kt(O) && (! function(t) {
                            !1 === re(t) && Hi(t, "load", ia.bind(this, t, "childList"), !0)
                        }(O), M.attributes["*O"] = "true", O.contentDocument && O.contentWindow && "loading" !== O.contentDocument.readyState && (r = O.contentDocument)), se[i](t, o, M, e);
                        break;
                    case "LINK":
                        if (hi && "stylesheet" === v.rel) {
                            for (var N in Object.keys(document.styleSheets)) {
                                var x = document.styleSheets[N];
                                if (x.ownerNode == p) {
                                    var _ = {
                                        tag: "STYLE",
                                        attributes: v,
                                        value: ha(x)
                                    };
                                    se[i](t, o, _, e);
                                    break
                                }
                            }
                            break
                        }
                        var I = {
                            tag: h,
                            attributes: v
                        };
                        se[i](t, o, I, e);
                        break;
                    case "VIDEO":
                    case "AUDIO":
                    case "SOURCE":
                        "src" in v && v.src.startsWith("data:") && (v.src = "");
                        var C = {
                            tag: h,
                            attributes: v
                        };
                        se[i](t, o, C, e);
                        break;
                    default:
                        var D = {
                            tag: h,
                            attributes: v
                        };
                        p.shadowRoot && (r = p.shadowRoot), se[i](t, o, D, e)
                }
        }
        return r
    }

    function fa(t) {
        re(t) || (! function(t) {
            try {
                var e = u("MutationObserver"),
                    n = e in window ? new window[e](Li($n)) : null;
                n && (n.observe(t, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                }), An.push(n))
            } catch (t) {
                Pr(2, 0, t ? t.name : null)
            }
        }(t), Xn(t))
    }

    function pa(t) {
        var e = t.textContent ? t.textContent.trim() : "",
            n = t.dataset ? Object.keys(t.dataset).length : 0;
        return (0 === e.length || n > 0 || t.id.length > 0) && (e = ha(t.sheet)), e
    }

    function ha(t) {
        var e = "",
            n = null;
        try {
            n = t ? t.cssRules : []
        } catch (t) {
            if (Pr(1, 1, t ? t.name : null), t && "SecurityError" !== t.name) throw t
        }
        if (null !== n)
            for (var a = 0; a < n.length; a++) e += n[a].cssText;
        return e
    }
    var va = [],
        ga = [],
        ma = null,
        ya = null,
        ba = "claritySheetId",
        wa = {},
        ka = {},
        Sa = [],
        Ta = [];

    function Ea(t, e) {
        if (-1 === Sa.indexOf(t) && Sa.push(t), e = e || s(), null == t ? void 0 : t.adoptedStyleSheets) {
            H(36, 1);
            for (var n = [], a = 0, r = t.adoptedStyleSheets; a < r.length; a++) {
                var i = r[a];
                i[ba] && -1 !== Ta.indexOf(i[ba]) || (i[ba] = Mi(), Ta.push(i[ba]), Ma(e, i[ba], 0), Ma(e, i[ba], 2, ha(i))), n.push(i[ba])
            }
            var o = Gt(t, !0);
            wa[o] || (wa[o] = []),
                function(t, e) {
                    if (t.length !== e.length) return !1;
                    return t.every((function(t, n) {
                        return t === e[n]
                    }))
                }(n, wa[o]) || (! function(t, e, n, a) {
                    ga.push({
                        time: t,
                        event: 45,
                        data: {
                            id: e,
                            operation: n,
                            newIds: a
                        }
                    }), Ha(45)
                }(e, t == document ? -1 : Gt(t), 3, n), wa[o] = n, ka[o] = e)
        }
    }

    function Oa() {
        ga = [], va = []
    }

    function Ma(t, e, n, a) {
        va.push({
            time: t,
            event: 46,
            data: {
                id: e,
                operation: n,
                cssRules: a
            }
        }), Ha(46)
    }
    var Na = [],
        xa = null,
        _a = null,
        Ia = null,
        Ca = null,
        Da = null,
        Pa = null,
        Xa = "clarityAnimationId",
        Ya = "clarityOperationCount",
        ja = 20;

    function Aa() {
        Na = []
    }

    function Ra(t, e, n, a, r, i, o) {
        Na.push({
            time: t,
            event: 44,
            data: {
                id: e,
                operation: n,
                keyFrames: a,
                timing: r,
                targetId: i,
                timeline: o
            }
        }), Ha(44)
    }

    function La(t, e) {
        null === t && (t = Animation.prototype[e], Animation.prototype[e] = function() {
            return za(this, e), t.apply(this, arguments)
        })
    }

    function za(t, e) {
        if (to()) {
            var n = t.effect,
                a = Gt(n.target);
            if (null !== a && n.getKeyframes && n.getTiming) {
                if (!t[Xa]) {
                    t[Xa] = Mi(), t[Ya] = 0;
                    var r = n.getKeyframes(),
                        i = n.getTiming();
                    Ra(s(), t[Xa], 0, JSON.stringify(r), JSON.stringify(i), a)
                }
                if (t[Ya]++ < ja) {
                    var o = null;
                    switch (e) {
                        case "play":
                            o = 1;
                            break;
                        case "pause":
                            o = 2;
                            break;
                        case "cancel":
                            o = 3;
                            break;
                        case "finish":
                            o = 4;
                            break;
                        case "commitStyles":
                            o = 5
                    }
                    o && Ra(s(), t[Xa], o)
                }
            }
        }
    }

    function Ha(t, e, n) {
        return void 0 === e && (e = null), void 0 === n && (n = null), rt(this, void 0, void 0, (function() {
            var a, r, i, u, c, l, d, f, p, h, v, g, m, b, w, k, S, T, E, O, M, N, x, C, D, P, X, Y, j;
            return it(this, (function(A) {
                switch (A.label) {
                    case 0:
                        switch (a = n || s(), r = [a, t], t) {
                            case 8:
                                return [3, 1];
                            case 7:
                                return [3, 2];
                            case 45:
                            case 46:
                                return [3, 3];
                            case 44:
                                return [3, 4];
                            case 5:
                            case 6:
                                return [3, 5]
                        }
                        return [3, 12];
                    case 1:
                        return i = Oe, r.push(i.width), r.push(i.height), _(t, i.width, i.height), kr(r), [3, 12];
                    case 2:
                        for (u = 0, c = Fa; u < c.length; u++) l = c[u], (r = [l.time, 7]).push(l.data.id), r.push(l.data.interaction), r.push(l.data.visibility), r.push(l.data.name), kr(r);
                        return ar(), [3, 12];
                    case 3:
                        for (d = 0, f = ga; d < f.length; d++) m = f[d], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.newIds), kr(r);
                        for (p = 0, h = va; p < h.length; p++) m = h[p], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.cssRules), kr(r);
                        return Oa(), [3, 12];
                    case 4:
                        for (v = 0, g = Na; v < g.length; v++) m = g[v], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.keyFrames), r.push(m.data.timing), r.push(m.data.timeline), r.push(m.data.targetId), kr(r);
                        return Aa(), [3, 12];
                    case 5:
                        if (2 === be(e)) return [3, 12];
                        if (!((b = ie()).length > 0)) return [3, 11];
                        w = 0, k = b, A.label = 6;
                    case 6:
                        return w < k.length ? (S = k[w], 0 !== (T = be(e)) ? [3, 8] : [4, Se(e)]) : [3, 10];
                    case 7:
                        T = A.sent(), A.label = 8;
                    case 8:
                        if (2 === T) return [3, 10];
                        for (E = S.data, O = S.metadata.active, M = S.metadata.suspend, N = S.metadata.privacy, x = function(t) {
                                var e = t.metadata.privacy;
                                return "*T" === t.data.tag && !(0 === e || 1 === e)
                            }(S), C = 0, D = O ? ["tag", "attributes", "value"] : ["tag"]; C < D.length; C++)
                            if (E[P = D[C]]) switch (P) {
                                case "tag":
                                    X = Wa(S), Y = x ? -1 : 1, r.push(S.id * Y), S.parent && O && (r.push(S.parent), S.previous && r.push(S.previous)), r.push(M ? "*M" : E[P]), X && 2 === X.length && r.push("".concat("#").concat(qa(X[0]), ".").concat(qa(X[1])));
                                    break;
                                case "attributes":
                                    for (j in E[P]) void 0 !== E[P][j] && r.push(Ua(j, E[P][j], N));
                                    break;
                                case "value":
                                    Ot(S.metadata.fraud, S.id, E[P]), r.push(y(E[P], E.tag, N, x))
                            }
                        A.label = 9;
                    case 9:
                        return w++, [3, 6];
                    case 10:
                        6 === t && I(a), kr(function(t) {
                            for (var e = [], n = {}, a = 0, r = null, i = 0; i < t.length; i++)
                                if ("string" == typeof t[i]) {
                                    var o = t[i],
                                        u = n[o] || -1;
                                    u >= 0 ? r ? r.push(u) : (r = [u], e.push(r), a++) : (r = null, e.push(o), n[o] = a++)
                                } else r = null, e.push(t[i]), a++;
                            return e
                        }(r), !o.lean), A.label = 11;
                    case 11:
                        return [3, 12];
                    case 12:
                        return [2]
                }
            }))
        }))
    }

    function Wa(t) {
        if (null !== t.metadata.size && 0 === t.metadata.size.length) {
            var e = ee(t.id);
            if (e) return [Math.floor(100 * e.offsetWidth), Math.floor(100 * e.offsetHeight)]
        }
        return t.metadata.size
    }

    function qa(t) {
        return t.toString(36)
    }

    function Ua(t, e, n) {
        return "".concat(t, "=").concat(y(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }
    var Fa = [],
        Va = null,
        Ba = {},
        Ja = [],
        Ga = !1,
        Ka = null;

    function Za(t, e) {
        !1 === Va.has(t) && (Va.set(t, e), (Ka = null === Ka && Ga ? new IntersectionObserver(tr, {
            threshold: [0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        }) : Ka) && t && t.nodeType === Node.ELEMENT_NODE && Ka.observe(t))
    }

    function Qa(t) {
        return Va && Va.has(t)
    }

    function $a() {
        $a.dn = 24;
        for (var t = [], e = 0, n = Ja; e < n.length; e++) {
            var a = n[e],
                r = Gt(a.node);
            r ? (a.state.data.id = r, Ba[r] = a.state.data, Fa.push(a.state)) : t.push(a)
        }
        Ja = t, Fa.length > 0 && Ha(7)
    }

    function tr(t) {
        for (var e = 0, n = t; e < n.length; e++) {
            var a = n[e],
                r = a.target,
                i = a.boundingClientRect,
                o = a.intersectionRect,
                u = a.rootBounds;
            if (Va.has(r) && i.width + i.height > 0 && u.width > 0 && u.height > 0) {
                var c = r ? Gt(r) : null,
                    s = c in Ba ? Ba[c] : {
                        id: c,
                        name: Va.get(r),
                        interaction: 16,
                        visibility: 0
                    },
                    l = (o ? o.width * o.height * 1 / (u.width * u.height) : 0) > .05 || a.intersectionRatio > .8,
                    d = (l || 10 == s.visibility) && Math.abs(i.top) + u.height > i.height;
                er(r, s, s.interaction, d ? 13 : l ? 10 : 0), s.visibility >= 13 && Ka && Ka.unobserve(r)
            }
        }
        Fa.length > 0 && Ha(7)
    }

    function er(t, e, n, a) {
        var r = n > e.interaction || a > e.visibility;
        e.interaction = n > e.interaction ? n : e.interaction, e.visibility = a > e.visibility ? a : e.visibility, e.id ? (e.id in Ba && r || !(e.id in Ba)) && (Ba[e.id] = e, Fa.push(nr(e))) : Ja.push({
            node: t,
            state: nr(e)
        })
    }

    function nr(t) {
        return {
            time: s(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function ar() {
        Fa = []
    }

    function rr(t) {
        var e = t.composed && t.composedPath ? t.composedPath() : null,
            n = e && e.length > 0 ? e[0] : t.target;
        return Jn = s() + 3e3, Kn = s() + o.criticalMs, n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    }

    function ir(t, e, n) {
        void 0 === n && (n = null);
        var a = {
            id: 0,
            hash: null,
            privacy: 2,
            node: t
        };
        if (t) {
            var r = ne(t);
            if (null !== r) {
                var i = r.metadata;
                a.id = r.id, a.hash = r.hash, a.privacy = i.privacy, r.region && function(t, e) {
                    var n = ee(t),
                        a = t in Ba ? Ba[t] : {
                            id: t,
                            visibility: 0,
                            interaction: 16,
                            name: Va.get(n)
                        },
                        r = 16;
                    switch (e) {
                        case 9:
                            r = 20;
                            break;
                        case 27:
                            r = 30
                    }
                    er(n, a, r, a.visibility)
                }(r.region, e), i.fraud && Ot(i.fraud, r.id, n || r.data.value)
            }
        }
        return a
    }

    function or(t, e) {
        return void 0 === e && (e = null), rt(this, void 0, void 0, (function() {
            var n, a, r, i, o, u, c, l, d, f, p, h, v, g, m, w, k, S, T, E, O, M, N, x, I, D, P, X, Y, j, A, R, L, z, H;
            return it(this, (function(W) {
                switch (n = e || s(), a = [n, t], t) {
                    case 13:
                    case 14:
                    case 12:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        for (r = 0, i = Ge; r < i.length; r++) z = i[r], (o = ir(z.data.target, z.event)).id > 0 && ((a = [z.time, z.event]).push(o.id), a.push(z.data.x), a.push(z.data.y), void 0 !== z.data.id && (a.push(z.data.id), void 0 !== z.data.isPrimary && a.push(z.data.isPrimary.toString())), kr(a), _(z.event, z.data.x, z.data.y, z.time));
                        rn();
                        break;
                    case 9:
                        for (u = 0, c = Xe; u < c.length; u++) z = c[u], l = ir(z.data.target, z.event, z.data.text), a = [z.time, z.event], d = l.hash ? l.hash.join(".") : "", a.push(l.id), a.push(z.data.x), a.push(z.data.y), a.push(z.data.eX), a.push(z.data.eY), a.push(z.data.button), a.push(z.data.reaction), a.push(z.data.context), a.push(y(z.data.text, "click", l.privacy)), a.push(b(z.data.link)), a.push(d), a.push(z.data.trust), a.push(z.data.isFullText), kr(a), lr(z.time, z.event, d, z.data.x, z.data.y, z.data.reaction, z.data.context);
                        Le();
                        break;
                    case 38:
                        for (f = 0, p = ze; f < p.length; f++) z = p[f], a = [z.time, z.event], (A = ir(z.data.target, z.event)).id > 0 && (a.push(A.id), a.push(z.data.action), kr(a));
                        We();
                        break;
                    case 11:
                        h = Je, a.push(h.width), a.push(h.height), _(t, h.width, h.height), ln(), kr(a);
                        break;
                    case 26:
                        v = On, a.push(v.name), a.push(v.persisted), Cn(), kr(a);
                        break;
                    case 27:
                        for (g = 0, m = Ue; g < m.length; g++) z = m[g], w = ir(z.data.target, z.event, z.data.value), (a = [z.time, z.event]).push(w.id), a.push(y(z.data.value, "input", w.privacy, !1, z.data.type)), kr(a);
                        Be();
                        break;
                    case 21:
                        (k = bn) && (S = ir(k.start, t), T = ir(k.end, t), a.push(S.id), a.push(k.startOffset), a.push(T.id), a.push(k.endOffset), En(), kr(a));
                        break;
                    case 10:
                        for (E = 0, O = dn; E < O.length; E++) z = O[E], M = ir(z.data.target, z.event), N = ir(z.data.top, z.event), x = ir(z.data.bottom, z.event), I = (null == N ? void 0 : N.hash) ? N.hash.join(".") : "", D = (null == x ? void 0 : x.hash) ? x.hash.join(".") : "", M.id > 0 && ((a = [z.time, z.event]).push(M.id), a.push(z.data.x), a.push(z.data.y), a.push(I), a.push(D), kr(a), _(z.event, z.data.x, z.data.y, z.time));
                        dn = [], fn = null, pn = null;
                        break;
                    case 42:
                        for (P = 0, X = _e; P < X.length; P++) z = X[P], a = [z.time, z.event], (A = ir(z.data.target, z.event)).id > 0 && ((a = [z.time, z.event]).push(A.id), a.push(z.data.type), a.push(y(z.data.value, "change", A.privacy)), a.push(y(z.data.checksum, "checksum", A.privacy)), kr(a));
                        Ce();
                        break;
                    case 39:
                        for (Y = 0, j = Nn; Y < j.length; Y++) z = j[Y], a = [z.time, z.event], (A = ir(z.data.target, z.event)).id > 0 && (a.push(A.id), kr(a));
                        _n();
                        break;
                    case 22:
                        for (R = 0, L = cr; R < L.length; R++) z = L[R], (a = [z.time, z.event]).push(z.data.type), a.push(z.data.hash), a.push(z.data.x), a.push(z.data.y), a.push(z.data.reaction), a.push(z.data.context), kr(a, !1);
                        sr();
                        break;
                    case 28:
                        H = Mn, a.push(H.visible), kr(a), C(n, H.visible), Pn()
                }
                return [2]
            }))
        }))
    }
    var ur = [],
        cr = [];

    function sr() {
        cr = []
    }

    function lr(t, e, n, a, r, i, o) {
        void 0 === i && (i = 1), void 0 === o && (o = 0), ur.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: n,
                x: a,
                y: r,
                reaction: i,
                context: o
            }
        }), _(e, a, r, t)
    }
    var dr, fr, pr, hr, vr, gr = 0,
        mr = 0,
        yr = null,
        br = 0;

    function wr() {
        hr = !0, gr = 0, mr = 0, br = 0, dr = [], fr = [], pr = {}, vr = null
    }

    function kr(t, e) {
        if (void 0 === e && (e = !0), hr) {
            var n = s(),
                a = t.length > 1 ? t[1] : null,
                r = JSON.stringify(t);
            switch (a) {
                case 5:
                    gr += r.length;
                case 37:
                case 6:
                case 43:
                case 45:
                case 46:
                    mr += r.length, dr.push(r);
                    break;
                default:
                    fr.push(r)
            }
            L(25);
            var i = function() {
                var t = !1 === o.lean && gr > 0 ? 100 : Pi.sequence * o.delay;
                return "string" == typeof o.upload ? Math.max(Math.min(t, 3e4), 100) : o.delay
            }();
            n - br > 2 * i && (q(yr), yr = null), e && null === yr && (25 !== a && B(), yr = W(Tr, i), br = n, $r(mr))
        }
    }

    function Sr() {
        q(yr), Tr(!0), gr = 0, mr = 0, br = 0, dr = [], fr = [], pr = {}, vr = null, hr = !1
    }

    function Tr(t) {
        return void 0 === t && (t = !1), rt(this, void 0, void 0, (function() {
            var e, n, a, r, i, u, c, s;
            return it(this, (function(l) {
                switch (l.label) {
                    case 0:
                        return yr = null, (e = !1 === o.lean && mr > 0 && (mr < 1048576 || Pi.sequence > 0)) && H(1, 1), $a(),
                            function() {
                                var t = [];
                                cr = [];
                                for (var e = Pi.start + Pi.duration, n = Math.max(e - 2e3, 0), a = 0, r = ur; a < r.length; a++) {
                                    var i = r[a];
                                    i.time >= n && (i.time <= e && cr.push(i), t.push(i))
                                }
                                ur = t, or(22)
                            }(), St(),
                            function() {
                                for (var t = 0, e = Sa; t < e.length; t++) {
                                    var n = e[t],
                                        a = n == document ? -1 : Gt(n),
                                        r = a in ka ? ka[a] : null;
                                    Ea(document, r)
                                }
                            }(), n = !0 === t, a = JSON.stringify(ji(n)), r = "[".concat(fr.join(), "]"), i = e ? "[".concat(dr.join(), "]") : "", u = function(t) {
                                return t.p.length > 0 ? '{"e":'.concat(t.e, ',"a":').concat(t.a, ',"p":').concat(t.p, "}") : '{"e":'.concat(t.e, ',"a":').concat(t.a, "}")
                            }({
                                e: a,
                                a: r,
                                p: i
                            }), n ? (s = null, [3, 3]) : [3, 1];
                    case 1:
                        return [4, vt(u)];
                    case 2:
                        s = l.sent(), l.label = 3;
                    case 3:
                        return z(2, (c = s) ? c.length : u.length), Er(u, c, Pi.sequence, n), fr = [], e && (dr = [], mr = 0, gr = 0), [2]
                }
            }))
        }))
    }

    function Er(t, e, n, a) {
        if (void 0 === a && (a = !1), "string" == typeof o.upload) {
            var r = o.upload,
                i = !1;
            if (a && "sendBeacon" in navigator) try {
                (i = navigator.sendBeacon.bind(navigator)(r, t)) && Mr(n)
            } catch (t) {}
            if (!1 === i) {
                n in pr ? pr[n].attempts++ : pr[n] = {
                    data: t,
                    attempts: 1
                };
                var u = new XMLHttpRequest;
                u.open("POST", r, !0), u.timeout = 15e3, u.ontimeout = function() {
                    Ri(new Error("".concat("Timeout", " : ").concat(r)))
                }, null !== n && (u.onreadystatechange = function() {
                    Li(Or)(u, n)
                }), u.withCredentials = !0, e ? (u.setRequestHeader("Accept", "application/x-clarity-gzip"), u.send(e)) : u.send(t)
            }
        } else if (o.upload) {
            (0, o.upload)(t), Mr(n)
        }
    }

    function Or(t, e) {
        var n = pr[e];
        t && 4 === t.readyState && n && ((t.status < 200 || t.status > 208) && n.attempts <= 1 ? t.status >= 400 && t.status < 500 ? ti(6) : (0 === t.status && (o.upload = o.fallback ? o.fallback : o.upload), Er(n.data, null, e)) : (vr = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, n.attempts > 1 && Zr(2), 200 === t.status && t.responseText && function(t) {
            for (var e = t && t.length > 0 ? t.split("\n") : [], n = 0, a = e; n < a.length; n++) {
                var r = a[n],
                    i = r && r.length > 0 ? r.split(/ (.*)/) : [""];
                switch (i[0]) {
                    case "END":
                        ti(6);
                        break;
                    case "UPGRADE":
                        nt("Auto");
                        break;
                    case "ACTION":
                        o.action && i.length > 1 && o.action(i[1]);
                        break;
                    case "EXTRACT":
                        i.length > 1 && Wr(i[1]);
                        break;
                    case "SIGNAL":
                        i.length > 1 && yt(i[1])
                }
            }
        }(t.responseText), 0 === t.status && (Er(n.data, null, e, !0), ti(3)), t.status >= 200 && t.status <= 208 && Mr(e), delete pr[e]))
    }

    function Mr(t) {
        1 === t && (Ti(), Si())
    }
    var Nr, xr = {};

    function _r(t) {
        _r.dn = 4;
        var e = t.error || t;
        return e.message in xr || (xr[e.message] = 0), xr[e.message]++ >= 5 || e && e.message && (Nr = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename
        }, Ir(31)), !0
    }

    function Ir(t) {
        return rt(this, void 0, void 0, (function() {
            var e;
            return it(this, (function(n) {
                switch (e = [s(), t], t) {
                    case 31:
                        e.push(Nr.message), e.push(Nr.line), e.push(Nr.column), e.push(Nr.stack), e.push(b(Nr.source)), kr(e);
                        break;
                    case 33:
                        Cr && (e.push(Cr.code), e.push(Cr.name), e.push(Cr.message), e.push(Cr.stack), e.push(Cr.severity), kr(e, !1));
                        break;
                    case 41:
                        Tt && (e.push(Tt.id), e.push(Tt.target), e.push(Tt.checksum), kr(e, !1))
                }
                return [2]
            }))
        }))
    }
    var Cr, Dr = {};

    function Pr(t, e, n, a, r) {
        void 0 === n && (n = null), void 0 === a && (a = null), void 0 === r && (r = null);
        var i = n ? "".concat(n, "|").concat(a) : "";
        t in Dr && Dr[t].indexOf(i) >= 0 || (Cr = {
            code: t,
            name: n,
            message: a,
            stack: r,
            severity: e
        }, t in Dr ? Dr[t].push(i) : Dr[t] = [i], Ir(33))
    }
    var Xr, Yr = {},
        jr = new Set,
        Ar = {},
        Rr = {},
        Lr = {},
        zr = {};

    function Hr() {
        Fr()
    }

    function Wr(t) {
        try {
            var e = t && t.length > 0 ? t.split(/ (.*)/) : [""],
                n = e[0].split(/\|(.*)/),
                a = parseInt(n[0]),
                r = n.length > 1 ? n[1] : "",
                i = e.length > 1 ? JSON.parse(e[1]) : {};
            for (var o in Ar[a] = {}, Rr[a] = {}, Lr[a] = {}, zr[a] = r, i) {
                var u = parseInt(o),
                    c = i[o],
                    s = 2;
                switch (c.startsWith("~") ? s = 0 : c.startsWith("!") && (s = 4), s) {
                    case 0:
                        var l = c.substring(1, c.length);
                        Ar[a][u] = Jr(l);
                        break;
                    case 2:
                        Rr[a][u] = c;
                        break;
                    case 4:
                        var d = c.substring(1, c.length);
                        Lr[a][u] = d
                }
            }
        } catch (t) {
            Pr(8, 1, t ? t.name : null)
        }
    }

    function qr(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function Ur() {
        try {
            for (var t in Ar) {
                var e = parseInt(t);
                if ("" == zr[e] || document.querySelector(zr[e])) {
                    var n = Ar[e];
                    for (var a in n) {
                        var r = parseInt(a),
                            i = (p = Gr(qr(n[r]))) ? JSON.stringify(p).substring(0, 1e4) : p;
                        i && Vr(e, r, i)
                    }
                    var o = Rr[e];
                    for (var u in o) {
                        var c = parseInt(u),
                            s = document.querySelectorAll(o[c]);
                        if (s) Vr(e, c, Array.from(s).map((function(t) {
                            return t.textContent
                        })).join("<SEP>").substring(0, 1e4))
                    }
                    var l = Lr[e];
                    for (var d in l) {
                        var f = parseInt(d);
                        Vr(e, f, te(l[f]).trim().substring(0, 1e4))
                    }
                }
            }
            jr.size > 0 && Zr(40)
        } catch (t) {
            Pr(5, 1, t ? t.name : null)
        }
        var p
    }

    function Fr() {
        jr.clear()
    }

    function Vr(t, e, n) {
        var a, r = !1;
        t in Yr || (Yr[t] = {}, r = !0), a = Lr[t], 0 == Object.keys(a).length || e in Yr[t] && Yr[t][e] == n || (r = !0), Yr[t][e] = n, r && jr.add(t)
    }

    function Br() {
        Fr()
    }

    function Jr(t) {
        for (var e = [], n = t.split("."); n.length > 0;) {
            var a = n.shift(),
                r = a.indexOf("["),
                i = a.indexOf("{"),
                o = a.indexOf("}");
            e.push({
                name: r > 0 ? a.substring(0, r) : i > 0 ? a.substring(0, i) : a,
                type: r > 0 ? 1 : i > 0 ? 2 : 3,
                condition: i > 0 ? a.substring(i + 1, o) : null
            })
        }
        return e
    }

    function Gr(t, e) {
        if (void 0 === e && (e = window), 0 == t.length) return e;
        var n, a = t.shift();
        if (e && e[a.name]) {
            var r = e[a.name];
            if (1 !== a.type && Kr(r, a.condition)) n = Gr(t, r);
            else if (Array.isArray(r)) {
                for (var i = [], o = 0, u = r; o < u.length; o++) {
                    var c = u[o];
                    if (Kr(c, a.condition)) {
                        var s = Gr(t, c);
                        s && i.push(s)
                    }
                }
                n = i
            }
            return n
        }
        return null
    }

    function Kr(t, e) {
        if (e) {
            var n = e.split(":");
            return n.length > 1 ? t[n[0]] == n[1] : t[n[0]]
        }
        return !0
    }

    function Zr(t) {
        var e = [s(), t];
        switch (t) {
            case 4:
                var n = O;
                n && ((e = [n.time, n.event]).push(n.data.visible), e.push(n.data.docWidth), e.push(n.data.docHeight), e.push(n.data.screenWidth), e.push(n.data.screenHeight), e.push(n.data.scrollX), e.push(n.data.scrollY), e.push(n.data.pointerX), e.push(n.data.pointerY), e.push(n.data.activityTime), e.push(n.data.scrollTime), e.push(n.data.pointerTime), e.push(n.data.moveX), e.push(n.data.moveY), e.push(n.data.moveTime), e.push(n.data.downX), e.push(n.data.downY), e.push(n.data.downTime), e.push(n.data.upX), e.push(n.data.upY), e.push(n.data.upTime), e.push(n.data.pointerPrevX), e.push(n.data.pointerPrevY), e.push(n.data.pointerPrevTime), kr(e, !1)), x();
                break;
            case 25:
                e.push(j.gap), kr(e);
                break;
            case 35:
                e.push(Xr.check), kr(e, !1);
                break;
            case 3:
                e.push(et.key), kr(e);
                break;
            case 2:
                e.push(vr.sequence), e.push(vr.attempts), e.push(vr.status), kr(e, !1);
                break;
            case 24:
                X.key && e.push(X.key), e.push(X.value), kr(e);
                break;
            case 34:
                var a = Object.keys(ot);
                if (a.length > 0) {
                    for (var r = 0, i = a; r < i.length; r++) {
                        var o = i[r];
                        e.push(o), e.push(ot[o])
                    }
                    dt(), kr(e, !1)
                }
                break;
            case 0:
                var u = Object.keys(R);
                if (u.length > 0) {
                    for (var c = 0, l = u; c < l.length; c++) {
                        var d = l[c],
                            f = parseInt(d, 10);
                        e.push(f), e.push(Math.round(R[d]))
                    }
                    R = {}, kr(e, !1)
                }
                break;
            case 1:
                var p = Object.keys(ri);
                if (p.length > 0) {
                    for (var h = 0, v = p; h < v.length; h++) {
                        var g = v[h];
                        f = parseInt(g, 10);
                        e.push(f), e.push(ri[g])
                    }
                    li(), kr(e, !1)
                }
                break;
            case 36:
                var m = Object.keys(K);
                if (m.length > 0) {
                    for (var y = 0, b = m; y < b.length; y++) {
                        var w = b[y];
                        f = parseInt(w, 10);
                        e.push(f), e.push([].concat.apply([], K[w]))
                    }
                    $(), kr(e, !1)
                }
                break;
            case 40:
                jr.forEach((function(t) {
                    e.push(t);
                    var n = [];
                    for (var a in Yr[t]) {
                        var r = parseInt(a, 10);
                        n.push(r), n.push(Yr[t][a])
                    }
                    e.push(n)
                })), Fr(), kr(e, !1)
        }
    }

    function Qr() {
        Xr = {
            check: 0
        }
    }

    function $r(t) {
        if (0 === Xr.check) {
            var e = Xr.check;
            e = Pi.sequence >= 128 ? 1 : e, e = Pi.pageNum >= 128 ? 7 : e, e = s() > 72e5 ? 2 : e, (e = t > 10485760 ? 2 : e) !== Xr.check && ti(e)
        }
    }

    function ti(t) {
        Xr.check = t, 5 !== t && (ki(), No())
    }

    function ei() {
        0 !== Xr.check && Zr(35)
    }

    function ni() {
        Xr = null
    }
    var ai = null,
        ri = null,
        ii = !1;

    function oi() {
        ai = {}, ri = {}, ii = !1
    }

    function ui() {
        ai = {}, ri = {}, ii = !1
    }

    function ci(t, e) {
        if (e && (e = "".concat(e), t in ai || (ai[t] = []), ai[t].indexOf(e) < 0)) {
            if (ai[t].length > 128) return void(ii || (ii = !0, ti(5)));
            ai[t].push(e), t in ri || (ri[t] = []), ri[t].push(e)
        }
    }

    function si() {
        Zr(1)
    }

    function li() {
        ri = {}, ii = !1
    }

    function di(t) {
        ci(36, t.toString())
    }
    var fi = null,
        pi = [],
        hi = 0,
        vi = null;

    function gi() {
        var t, e, n;
        vi = null;
        var a = navigator && "userAgent" in navigator ? navigator.userAgent : "",
            r = null !== (n = null === (e = null === (t = null === Intl || void 0 === Intl ? void 0 : Intl.DateTimeFormat()) || void 0 === t ? void 0 : t.resolvedOptions()) || void 0 === e ? void 0 : e.timeZone) && void 0 !== n ? n : "",
            i = (new Date).getTimezoneOffset().toString(),
            u = window.location.ancestorOrigins ? Array.from(window.location.ancestorOrigins).toString() : "",
            c = document && document.title ? document.title : "";
        hi = a.indexOf("Electron") > 0 ? 1 : 0;
        var s, l = function() {
                var t = {
                        session: Mi(),
                        ts: Math.round(Date.now()),
                        count: 1,
                        upgrade: null,
                        upload: ""
                    },
                    e = _i("_clsk", !o.includeSubdomains);
                if (e) {
                    var n = e.split("|");
                    n.length >= 5 && t.ts - Ni(n[1]) < 18e5 && (t.session = n[0], t.count = Ni(n[2]) + 1, t.upgrade = Ni(n[3]), t.upload = n.length >= 6 ? "".concat("https://").concat(n[5], "/").concat(n[4]) : "".concat("https://").concat(n[4]))
                }
                return t
            }(),
            f = xi(),
            p = o.projectId || d(location.host);
        fi = {
            projectId: p,
            userId: f.id,
            sessionId: l.session,
            pageNum: l.count
        }, o.lean = o.track && null !== l.upgrade ? 0 === l.upgrade : o.lean, o.upload = o.track && "string" == typeof o.upload && l.upload && l.upload.length > "https://".length ? l.upload : o.upload, ci(0, a), ci(3, c), ci(1, b(location.href, !!hi)), ci(2, document.referrer), ci(15, function() {
            var t = Mi();
            if (o.track && Ei(window, "sessionStorage")) {
                var e = sessionStorage.getItem("_cltk");
                t = e || t, sessionStorage.setItem("_cltk", t)
            }
            return t
        }()), ci(16, document.documentElement.lang), ci(17, document.dir), ci(26, "".concat(window.devicePixelRatio)), ci(28, f.dob.toString()), ci(29, f.version.toString()), ci(33, u), ci(34, r), ci(35, i), H(0, l.ts), H(1, 0), H(35, hi), navigator && (ci(9, navigator.language), H(33, navigator.hardwareConcurrency), H(32, navigator.maxTouchPoints), H(34, Math.round(navigator.deviceMemory)), (s = navigator.userAgentData) && s.getHighEntropyValues ? s.getHighEntropyValues(["model", "platform", "platformVersion", "uaFullVersion"]).then((function(t) {
            var e;
            ci(22, t.platform), ci(23, t.platformVersion), null === (e = t.brands) || void 0 === e || e.forEach((function(t) {
                ci(24, t.name + "~" + t.version)
            })), ci(25, t.model), H(27, t.mobile ? 1 : 0)
        })) : ci(22, navigator.platform)), screen && (H(14, Math.round(screen.width)), H(15, Math.round(screen.height)), H(16, Math.round(screen.colorDepth)));
        for (var h = 0, v = o.cookies; h < v.length; h++) {
            var g = v[h],
                m = _i(g);
            m && ut(g, m)
        }! function(t) {
            di(t ? 1 : 0)
        }(o.track), Oi(f)
    }

    function mi() {
        vi = null, fi = null, pi.forEach((function(t) {
            t.called = !1
        }))
    }

    function yi(t, e, n) {
        void 0 === e && (e = !0), void 0 === n && (n = !1);
        var a = o.lean ? 0 : 1,
            r = !1;
        fi && (a || !1 === e) && (t(fi, !o.lean), r = !0), !n && r || pi.push({
            callback: t,
            wait: e,
            recall: n,
            called: r
        })
    }

    function bi() {
        return fi ? [fi.userId, fi.sessionId, fi.pageNum].join(".") : ""
    }

    function wi(t) {
        if (void 0 === t && (t = !0), !t) return o.track = !1, Ci("_clsk", "", -Number.MAX_VALUE), Ci("_clck", "", -Number.MAX_VALUE), No(), void window.setTimeout(Mo, 250);
        to() && (o.track = !0, Oi(xi(), 1), Ti(), di(2))
    }

    function ki() {
        Ci("_clsk", "", 0)
    }

    function Si() {
        ! function(t) {
            if (pi.length > 0)
                for (var e = 0; e < pi.length; e++) {
                    var n = pi[e];
                    !n.callback || n.called || n.wait && !t || (n.callback(fi, !o.lean), n.called = !0, n.recall || (pi.splice(e, 1), e--))
                }
        }(o.lean ? 0 : 1)
    }

    function Ti() {
        if (fi && o.track) {
            var t = Math.round(Date.now()),
                e = o.upload && "string" == typeof o.upload ? o.upload.replace("https://", "") : "",
                n = o.lean ? 0 : 1;
            Ci("_clsk", [fi.sessionId, t, fi.pageNum, n, e].join("|"), 1)
        }
    }

    function Ei(t, e) {
        try {
            return !!t[e]
        } catch (t) {
            return !1
        }
    }

    function Oi(t, e) {
        void 0 === e && (e = null), e = null === e ? t.consent : e;
        var n = Math.ceil((Date.now() + 31536e6) / 864e5),
            a = 0 === t.dob ? null === o.dob ? 0 : o.dob : t.dob;
        (null === t.expiry || Math.abs(n - t.expiry) >= 1 || t.consent !== e || t.dob !== a) && Ci("_clck", [fi.userId, 2, n.toString(36), e, a].join("|"), 365)
    }

    function Mi() {
        var t = Math.floor(Math.random() * Math.pow(2, 32));
        return window && window.crypto && window.crypto.getRandomValues && Uint32Array && (t = window.crypto.getRandomValues(new Uint32Array(1))[0]), t.toString(36)
    }

    function Ni(t, e) {
        return void 0 === e && (e = 10), parseInt(t, e)
    }

    function xi() {
        var t = {
                id: Mi(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            e = _i("_clck", !o.includeSubdomains);
        if (e && e.length > 0) {
            for (var n = e.split("|"), a = 0, r = 0, i = document.cookie.split(";"); r < i.length; r++) {
                a += "_clck" === i[r].split("=")[0].trim() ? 1 : 0
            }
            if (1 === n.length || a > 1) {
                var u = "".concat(";").concat("expires=").concat(new Date(0).toUTCString()).concat(";path=/");
                document.cookie = "".concat("_clck", "=").concat(u), document.cookie = "".concat("_clsk", "=").concat(u)
            }
            n.length > 1 && (t.version = Ni(n[1])), n.length > 2 && (t.expiry = Ni(n[2], 36)), n.length > 3 && 1 === Ni(n[3]) && (t.consent = 1), n.length > 4 && Ni(n[1]) > 1 && (t.dob = Ni(n[4])), o.track = o.track || 1 === t.consent, t.id = o.track ? n[0] : t.id
        }
        return t
    }

    function _i(t, e) {
        var n;
        if (void 0 === e && (e = !1), Ei(document, "cookie")) {
            var a = document.cookie.split(";");
            if (a)
                for (var r = 0; r < a.length; r++) {
                    var i = a[r].split("=");
                    if (i.length > 1 && i[0] && i[0].trim() === t) {
                        for (var o = Ii(i[1]), u = o[0], c = o[1]; u;) u = (n = Ii(c))[0], c = n[1];
                        return e ? c.endsWith("".concat("~", "1")) ? c.substring(0, c.length - 2) : null : c
                    }
                }
        }
        return null
    }

    function Ii(t) {
        try {
            var e = decodeURIComponent(t);
            return [e != t, e]
        } catch (t) {}
        return [!1, t]
    }

    function Ci(t, e, n) {
        if ((o.track || "" == e) && (navigator && navigator.cookieEnabled || Ei(document, "cookie"))) {
            var a = function(t) {
                    return encodeURIComponent(t)
                }(e),
                r = new Date;
            r.setDate(r.getDate() + n);
            var i = r ? "expires=" + r.toUTCString() : "",
                u = "".concat(t, "=").concat(a).concat(";").concat(i).concat(";path=/");
            try {
                if (null === vi) {
                    for (var c = location.hostname ? location.hostname.split(".") : [], s = c.length - 1; s >= 0; s--)
                        if (vi = ".".concat(c[s]).concat(vi || ""), s < c.length - 1 && (document.cookie = "".concat(u).concat(";").concat("domain=").concat(vi), _i(t) === e)) return;
                    vi = ""
                }
            } catch (t) {
                vi = ""
            }
            document.cookie = vi ? "".concat(u).concat(";").concat("domain=").concat(vi) : u
        }
    }
    var Di, Pi = null;

    function Xi() {
        var t = fi;
        Pi = {
            version: l,
            sequence: 0,
            start: 0,
            duration: 0,
            projectId: t.projectId,
            userId: t.userId,
            sessionId: t.sessionId,
            pageNum: t.pageNum,
            upload: 0,
            end: 0,
            applicationPlatform: 0,
            url: ""
        }
    }

    function Yi() {
        Pi = null
    }

    function ji(t) {
        return Pi.start = Pi.start + Pi.duration, Pi.duration = s() - Pi.start, Pi.sequence++, Pi.upload = t && "sendBeacon" in navigator ? 1 : 0, Pi.end = t ? 1 : 0, Pi.applicationPlatform = 0, Pi.url = b(location.href, !1, !0), [Pi.version, Pi.sequence, Pi.start, Pi.duration, Pi.projectId, Pi.userId, Pi.sessionId, Pi.pageNum, Pi.upload, Pi.end, Pi.applicationPlatform, Pi.url]
    }

    function Ai() {
        Di = []
    }

    function Ri(t) {
        if (Di && -1 === Di.indexOf(t.message)) {
            var e = o.report;
            if (e && e.length > 0) {
                var n = {
                    v: Pi.version,
                    p: Pi.projectId,
                    u: Pi.userId,
                    s: Pi.sessionId,
                    n: Pi.pageNum
                };
                t.message && (n.m = t.message), t.stack && (n.e = t.stack);
                var a = new XMLHttpRequest;
                a.open("POST", e, !0), a.send(JSON.stringify(n)), Di.push(t.message)
            }
        }
        return t
    }

    function Li(t) {
        return function() {
            var e = performance.now();
            try {
                t.apply(this, arguments)
            } catch (t) {
                throw Ri(t)
            }
            var n = performance.now() - e;
            z(4, n), n > 30 && (L(7), H(6, n), Pr(9, 0, "".concat(t.dn || t.name, "-").concat(n)))
        }
    }
    var zi = [];

    function Hi(t, e, n, a, r) {
        void 0 === a && (a = !1), void 0 === r && (r = !0), n = Li(n);
        try {
            t[u("addEventListener")](e, n, {
                capture: a,
                passive: r
            }), zi.push({
                event: e,
                target: t,
                listener: n,
                options: {
                    capture: a,
                    passive: r
                }
            })
        } catch (t) {}
    }

    function Wi() {
        for (var t = 0, e = zi; t < e.length; t++) {
            var n = e[t];
            try {
                n.target[u("removeEventListener")](n.event, n.listener, {
                    capture: n.options.capture,
                    passive: n.options.passive
                })
            } catch (t) {}
        }
        zi = []
    }
    var qi = null,
        Ui = null,
        Fi = null,
        Vi = 0;

    function Bi() {
        return !(Vi++ > 20) || (Pr(4, 0), !1)
    }

    function Ji() {
        Ji.dn = 1, Vi = 0, Fi !== Ki() && (No(), window.setTimeout(Gi, 250))
    }

    function Gi() {
        Mo(), H(29, 1)
    }

    function Ki() {
        return location.href ? location.href.replace(location.hash, "") : location.href
    }
    var Zi = !1;

    function Qi() {
        Zi = !0, c = performance.now() + performance.timeOrigin, ge(), Wi(), Ai(), Fi = Ki(), Vi = 0, Hi(window, "popstate", Ji), null === qi && (qi = history.pushState, history.pushState = function() {
            qi.apply(this, arguments), to() && Bi() && Ji()
        }), null === Ui && (Ui = history.replaceState, history.replaceState = function() {
            Ui.apply(this, arguments), to() && Bi() && Ji()
        })
    }

    function $i() {
        Fi = null, Vi = 0, Ai(), Wi(), ge(), c = 0, Zi = !1
    }

    function to() {
        return Zi
    }

    function eo() {
        eo.dn = 2, Mo(), Y("clarity", "restart")
    }
    var no = Object.freeze({
        __proto__: null,
        start: function t() {
            t.dn = 3,
                function() {
                    Et = [], H(26, navigator.webdriver ? 1 : 0);
                    try {
                        H(31, window.top == window.self || window.top == window ? 1 : 2)
                    } catch (t) {
                        H(31, 0)
                    }
                }(), Hi(window, "error", _r), xr = {}, Dr = {}
        },
        stop: function() {
            Dr = {}
        }
    });

    function ao() {
        return rt(this, void 0, void 0, (function() {
            var t, e;
            return it(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return t = s(), we(e = {
                            id: bi(),
                            cost: 3
                        }), [4, jn(document, e, 0, t)];
                    case 1:
                        return n.sent(), Ea(document, t), [4, Ha(5, e, t)];
                    case 2:
                        return n.sent(), ke(e), [2]
                }
            }))
        }))
    }
    var ro = Object.freeze({
        __proto__: null,
        hashText: te,
        start: function t() {
            t.dn = 20, Ne(), xe(), ar(), Ka = null, Va = new WeakMap, Ba = {}, Ja = [], Ga = !!window.IntersectionObserver, Ft(), o.delayDom ? Hi(window, "load", (function() {
                    Qn()
                })) : Qn(), me(ao, 1).then((function() {
                    Li(xe)(), Li($a)(), Li(yn)()
                })), window.CSSStyleSheet && CSSStyleSheet.prototype && (null === ma && (ma = CSSStyleSheet.prototype.replace, CSSStyleSheet.prototype.replace = function() {
                    return to() && (H(36, 1), Ta.indexOf(this[ba]) > -1 && Ma(s(), this[ba], 1, arguments[0])), ma.apply(this, arguments)
                }), null === ya && (ya = CSSStyleSheet.prototype.replaceSync, CSSStyleSheet.prototype.replaceSync = function() {
                    return to() && (H(36, 1), Ta.indexOf(this[ba]) > -1 && Ma(s(), this[ba], 2, arguments[0])), ya.apply(this, arguments)
                })),
                function() {
                    if (window.Animation && window.Animation.prototype && window.KeyframeEffect && window.KeyframeEffect.prototype && window.KeyframeEffect.prototype.getKeyframes && window.KeyframeEffect.prototype.getTiming && (Aa(), La(_a, "play"), La(Ia, "pause"), La(Ca, "commitStyles"), La(Da, "cancel"), La(Pa, "finish"), null === xa && (xa = Element.prototype.animate, Element.prototype.animate = function() {
                            var t = xa.apply(this, arguments);
                            return za(t, "play"), t
                        }), document.getAnimations))
                        for (var t = 0, e = document.getAnimations(); t < e.length; t++) {
                            var n = e[t];
                            "finished" === n.playState ? za(n, "finish") : "paused" === n.playState || "idle" === n.playState ? za(n, "pause") : "running" === n.playState && za(n, "play")
                        }
                }()
        },
        stop: function() {
            ar(), Va = null, Ba = {}, Ja = [], Ka && (Ka.disconnect(), Ka = null), Ga = !1, Vt(),
                function() {
                    for (var t = 0, e = An; t < e.length; t++) {
                        var n = e[t];
                        n && n.disconnect()
                    }
                    An = [], Gn = {}, Rn = [], Ln = [], Fn = [], Jn = 0, Vn = null, Kn = 0
                }(), Ne(), wa = {}, ka = {}, Sa = [], Ta = [], Oa(), Aa()
        }
    });
    var io = null;

    function oo() {
        io = null
    }

    function uo(t) {
        io = {
                fetchStart: Math.round(t.fetchStart),
                connectStart: Math.round(t.connectStart),
                connectEnd: Math.round(t.connectEnd),
                requestStart: Math.round(t.requestStart),
                responseStart: Math.round(t.responseStart),
                responseEnd: Math.round(t.responseEnd),
                domInteractive: Math.round(t.domInteractive),
                domComplete: Math.round(t.domComplete),
                loadEventStart: Math.round(t.loadEventStart),
                loadEventEnd: Math.round(t.loadEventEnd),
                redirectCount: Math.round(t.redirectCount),
                size: t.transferSize ? t.transferSize : 0,
                type: t.type,
                protocol: t.nextHopProtocol,
                encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
                decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
            },
            function(t) {
                rt(this, void 0, void 0, (function() {
                    var e, n;
                    return it(this, (function(a) {
                        return e = s(), n = [e, t], 29 === t && (n.push(io.fetchStart), n.push(io.connectStart), n.push(io.connectEnd), n.push(io.requestStart), n.push(io.responseStart), n.push(io.responseEnd), n.push(io.domInteractive), n.push(io.domComplete), n.push(io.loadEventStart), n.push(io.loadEventEnd), n.push(io.redirectCount), n.push(io.size), n.push(io.type), n.push(io.protocol), n.push(io.encodedSize), n.push(io.decodedSize), oo(), kr(n)), [2]
                    }))
                }))
            }(29)
    }
    var co, so = 0,
        lo = 1 / 0,
        fo = 0,
        po = 0,
        ho = [],
        vo = new Map,
        go = function() {
            return so || 0
        },
        mo = function() {
            if (!ho.length) return -1;
            var t = Math.min(ho.length - 1, Math.floor((go() - po) / 50));
            return ho[t].latency
        },
        yo = function() {
            po = go(), ho.length = 0, vo.clear()
        },
        bo = function(t) {
            if (t.interactionId && !(t.duration < 40)) {
                ! function(t) {
                    "interactionCount" in performance ? so = performance.interactionCount : t.interactionId && (lo = Math.min(lo, t.interactionId), fo = Math.max(fo, t.interactionId), so = fo ? (fo - lo) / 7 + 1 : 0)
                }(t);
                var e = ho[ho.length - 1],
                    n = vo.get(t.interactionId);
                if (n || ho.length < 10 || t.duration > (null == e ? void 0 : e.latency)) {
                    if (n) t.duration > n.latency && (n.latency = t.duration);
                    else {
                        var a = {
                            id: t.interactionId,
                            latency: t.duration
                        };
                        vo.set(a.id, a), ho.push(a)
                    }
                    ho.sort((function(t, e) {
                        return e.latency - t.latency
                    })), ho.length > 10 && ho.splice(10).forEach((function(t) {
                        return vo.delete(t.id)
                    }))
                }
            }
        },
        wo = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"];

    function ko() {
        ko.dn = 26;
        try {
            co && co.disconnect(), co = new PerformanceObserver(Li(So));
            for (var t = 0, e = wo; t < e.length; t++) {
                var n = e[t];
                PerformanceObserver.supportedEntryTypes.indexOf(n) >= 0 && ("layout-shift" === n && z(9, 0), co.observe({
                    type: n,
                    buffered: !0
                }))
            }
        } catch (t) {
            Pr(3, 1)
        }
    }

    function So(t) {
        So.dn = 27,
            function(t) {
                for (var e = (!("visibilityState" in document) || "visible" === document.visibilityState), n = 0; n < t.length; n++) {
                    var a = t[n];
                    switch (a.entryType) {
                        case "navigation":
                            uo(a);
                            break;
                        case "resource":
                            var r = a.name;
                            ci(4, To(r)), r !== o.upload && r !== o.fallback || H(28, a.duration);
                            break;
                        case "longtask":
                            L(7);
                            break;
                        case "first-input":
                            e && H(10, a.processingStart - a.startTime);
                            break;
                        case "event":
                            e && "PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && (bo(a), ci(37, mo().toString()));
                            break;
                        case "layout-shift":
                            e && !a.hadRecentInput && z(9, 1e3 * a.value);
                            break;
                        case "largest-contentful-paint":
                            e && H(8, a.startTime)
                    }
                }
            }(t.getEntries())
    }

    function To(t) {
        var e = document.createElement("a");
        return e.href = t, e.host
    }
    var Eo = Object.freeze({
            __proto__: null,
            start: function t() {
                t.dn = 25, oo(),
                    function() {
                        navigator && "connection" in navigator && ci(27, navigator.connection.effectiveType), window.PerformanceObserver && PerformanceObserver.supportedEntryTypes ? "complete" !== document.readyState ? Hi(window, "load", W.bind(this, ko, 0)) : ko() : Pr(3, 0)
                    }()
            },
            stop: function() {
                co && co.disconnect(), co = null, yo(), oo()
            }
        }),
        Oo = [no, ro, Yn, Eo];

    function Mo(t) {
        void 0 === t && (t = null),
            function() {
                try {
                    var t = navigator && "globalPrivacyControl" in navigator && 1 == navigator.globalPrivacyControl;
                    return !1 === Zi && "undefined" != typeof Promise && window.MutationObserver && document.createTreeWalker && "now" in Date && "now" in performance && "undefined" != typeof WeakMap && !t
                } catch (t) {
                    return !1
                }
            }() && (! function(t) {
                if (null === t || Zi) return !1;
                for (var e in t) e in o && (o[e] = t[e])
            }(t), Qi(), wt(), Oo.forEach((function(t) {
                return Li(t.start)()
            })), null === t && Co())
    }

    function No() {
        to() && (Oo.slice().reverse().forEach((function(t) {
            return Li(t.stop)()
        })), kt(), $i(), void 0 !== _o && (_o[Io] = function() {
            (_o[Io].q = _o[Io].q || []).push(arguments), "start" === arguments[0] && _o[Io].q.unshift(_o[Io].q.pop()) && Co()
        }))
    }
    var xo = Object.freeze({
            __proto__: null,
            consent: wi,
            event: Y,
            hashText: te,
            identify: ct,
            metadata: yi,
            pause: function() {
                to() && (Y("clarity", "pause"), null === he && (he = new Promise((function(t) {
                    ve = t
                }))))
            },
            resume: function() {
                to() && (he && (ve(), he = null, null === pe && ye()), Y("clarity", "resume"))
            },
            set: ut,
            signal: function(t) {
                mt = t
            },
            start: Mo,
            stop: No,
            upgrade: nt,
            version: l
        }),
        _o = window,
        Io = "clarity";

    function Co() {
        if (void 0 !== _o) {
            if (_o[Io] && _o[Io].v) return console.warn("Error CL001: Multiple Clarity tags detected.");
            var t = _o[Io] && _o[Io].q || [];
            for (_o[Io] = function(t) {
                    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                    return xo[t].apply(xo, e)
                }, _o[Io].v = l; t.length > 0;) _o[Io].apply(_o, t.shift())
        }
    }
    Co()
}();