import {
    r as a,
    j as e
} from "./index-CoOseuI4.js";
const d = () => (a.useEffect(() => {
    {
        if (window.adsbygoogle = window.adsbygoogle || [], !document.querySelector('script[src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"]')) {
            const t = document.createElement("script");
            t.async = !0, t.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9796833231647897", t.crossOrigin = "anonymous", document.head.appendChild(t)
        }
        const o = setTimeout(() => {
            try {
                window.adsbygoogle && window.adsbygoogle.push({})
            } catch (t) {
                console.error("AdSense error:", t)
            }
        }, 500);
        return () => clearTimeout(o)
    }
}, []), e.jsxs("div", {
    style: {
        width: "100%",
        overflow: "hidden",
        position: "relative"
    },
    children: [e.jsx("div", {
        style: {
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%,-50%)",
            opacity: "0.5"
        },
        role: "status",
        "aria-label": "Loading",
        children: "Loading..."
    }), e.jsx("ins", {
        className: "adsbygoogle",
        style: {
            display: "block",
            textAlign: "center",
            minWidth: "250px",
            width: "100%"
        },
        "data-ad-layout": "in-article",
        "data-ad-format": "fluid",
        "data-ad-client": "ca-pub-9796833231647897",
        "data-ad-slot": "6534271728"
    })]
}));
export {
    d as M
};