const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/Filter-B1QLf4MC.js", "assets/lottie-pWNopbfh.js", "assets/AritcleAds-C6Frj4LM.js", "assets/Review-kxr3IsEe.js", "assets/Review-BUIVCdMi.css", "assets/Filter-DalkyZg-.css", "assets/Departmentlist-DKe7pzPz.js", "assets/Morenoteabove-D1egt4Ok.js", "assets/Login-0lBrvo7V.js", "assets/Backbutton-BKS_-_3U.js", "assets/Backbutton-Br8lH6qh.css", "assets/GoogleAuth-DvjRxpJp.js", "assets/GoogleAuth-BTvzFhZ_.css", "assets/Study⁐Vault-logo-black-B2nPMgwu.js", "assets/ReCaptha-BRT-ATxh.js", "assets/ReCaptha-8G0ySRWa.css", "assets/Login-DBGOLjd8.css", "assets/ForgatePw-BQYawr9P.js", "assets/ForgatePw-DRQilm-2.css", "assets/Allpages-DxZ3r7d1.js", "assets/Admine-DvPiGv4C.js", "assets/Admine-CWPHgkjX.css", "assets/Dashboard-B7wnVV2s.js", "assets/Dashboard-M5pp29g4.css", "assets/Question-CYwK6Uop.js", "assets/PDFButton-CZYBgW8y.js", "assets/createLucideIcon-DD_94sJv.js", "assets/Question-BWz7uXVc.css", "assets/UserSend-DKTd8B8R.js", "assets/CsUpload-Dp9MPJeR.js", "assets/ArticleContainerRouter-QlcUYETH.js", "assets/ArticleContainerRouter-B3Z8MX3F.css", "assets/CollegeArticleRouter-BIPPSNmS.js", "assets/NoteUpload-DT81vbA0.js", "assets/NoteUpload-n2Ytyda7.css", "assets/Alart-feY4T56g.js", "assets/Alart-Db7dc5KC.css", "assets/MaterialRouting-DARt4UAj.js", "assets/MaterialRouting-XpGAhWg7.css", "assets/PaymentStatus-BSOVYheG.js", "assets/PaymentStatus-CE8l2RS5.css", "assets/PaymentRouter-CiTrG1nx.js", "assets/Notes-s3JWzZ7O.js", "assets/Notes-Dd8WEm3Q.css", "assets/Cashfree-Dp3rS-Xt.js", "assets/Cashfree-CrYn4Txy.css", "assets/SyllabusUpload-CudDbegm.js", "assets/SyllabusUpload-CFyC46kK.css", "assets/NotFound-BeZrGTw4.js", "assets/Syllabus-CAXcPY9_.js", "assets/Syllabus-CXOG4Nsk.css", "assets/MpcArticle-911HG-l4.js", "assets/mpc5-CniSnMlF.js", "assets/MpcArticle-BHhg78Dt.css", "assets/CollegeAritcle-CCLiyiXn.js", "assets/CollegeAritcle-Bg5BHiCe.css", "assets/ArticleHome-BnrnIdKg.js", "assets/ArticleHome-MeB2byNS.css", "assets/TermsConditions-DIRjCuc8.js", "assets/TermsConditions-CphRMRG7.css", "assets/PrivecyandPolicy-DBMzI0uj.js", "assets/PrivecyandPolicy-B7M-NLhk.css", "assets/AdmineLogIn-D07-9XcW.js", "assets/AdmineLogIn-C82x8lDI.css", "assets/AboutUs-D244UCIW.js", "assets/AboutUs-C4skNuxe.css", "assets/Home-IZ44vQDY.js", "assets/Home-Bx8WVDpI.css", "assets/Profile-Baf-4-l7.js", "assets/Profile-CXTfqXAU.css", "assets/Contact-BdWc4PFa.js", "assets/Contact-DahY3r1B.css", "assets/Signup-DeeDnQZN.js", "assets/Signup-C4VerDne.css", "assets/Loginsignup-C0I2rfSl.js"]))) => i.map(i => d[i]);
import {
    g as z1
} from "./lottie-pWNopbfh.js";

function U1(e, t) {
    for (var n = 0; n < t.length; n++) {
        const r = t[n];
        if (typeof r != "string" && !Array.isArray(r)) {
            for (const i in r)
                if (i !== "default" && !(i in e)) {
                    const s = Object.getOwnPropertyDescriptor(r, i);
                    s && Object.defineProperty(e, i, s.get ? s : {
                        enumerable: !0,
                        get: () => r[i]
                    })
                }
        }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    }))
}(function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
    new MutationObserver(i => {
        for (const s of i)
            if (s.type === "childList")
                for (const o of s.addedNodes) o.tagName === "LINK" && o.rel === "modulepreload" && r(o)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function n(i) {
        const s = {};
        return i.integrity && (s.integrity = i.integrity), i.referrerPolicy && (s.referrerPolicy = i.referrerPolicy), i.crossOrigin === "use-credentials" ? s.credentials = "include" : i.crossOrigin === "anonymous" ? s.credentials = "omit" : s.credentials = "same-origin", s
    }

    function r(i) {
        if (i.ep) return;
        i.ep = !0;
        const s = n(i);
        fetch(i.href, s)
    }
})();
var $1 = {
        exports: {}
    },
    Tc = {},
    W1 = {
        exports: {}
    },
    ae = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var ol = Symbol.for("react.element"),
    fE = Symbol.for("react.portal"),
    dE = Symbol.for("react.fragment"),
    hE = Symbol.for("react.strict_mode"),
    pE = Symbol.for("react.profiler"),
    mE = Symbol.for("react.provider"),
    gE = Symbol.for("react.context"),
    yE = Symbol.for("react.forward_ref"),
    vE = Symbol.for("react.suspense"),
    xE = Symbol.for("react.memo"),
    _E = Symbol.for("react.lazy"),
    Gg = Symbol.iterator;

function wE(e) {
    return e === null || typeof e != "object" ? null : (e = Gg && e[Gg] || e["@@iterator"], typeof e == "function" ? e : null)
}
var H1 = {
        isMounted: function() {
            return !1
        },
        enqueueForceUpdate: function() {},
        enqueueReplaceState: function() {},
        enqueueSetState: function() {}
    },
    K1 = Object.assign,
    G1 = {};

function xo(e, t, n) {
    this.props = e, this.context = t, this.refs = G1, this.updater = n || H1
}
xo.prototype.isReactComponent = {};
xo.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, e, t, "setState")
};
xo.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
};

function Y1() {}
Y1.prototype = xo.prototype;

function _p(e, t, n) {
    this.props = e, this.context = t, this.refs = G1, this.updater = n || H1
}
var wp = _p.prototype = new Y1;
wp.constructor = _p;
K1(wp, xo.prototype);
wp.isPureReactComponent = !0;
var Yg = Array.isArray,
    X1 = Object.prototype.hasOwnProperty,
    Sp = {
        current: null
    },
    q1 = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function Q1(e, t, n) {
    var r, i = {},
        s = null,
        o = null;
    if (t != null)
        for (r in t.ref !== void 0 && (o = t.ref), t.key !== void 0 && (s = "" + t.key), t) X1.call(t, r) && !q1.hasOwnProperty(r) && (i[r] = t[r]);
    var a = arguments.length - 2;
    if (a === 1) i.children = n;
    else if (1 < a) {
        for (var l = Array(a), u = 0; u < a; u++) l[u] = arguments[u + 2];
        i.children = l
    }
    if (e && e.defaultProps)
        for (r in a = e.defaultProps, a) i[r] === void 0 && (i[r] = a[r]);
    return {
        $$typeof: ol,
        type: e,
        key: s,
        ref: o,
        props: i,
        _owner: Sp.current
    }
}

function SE(e, t) {
    return {
        $$typeof: ol,
        type: e.type,
        key: t,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
    }
}

function Cp(e) {
    return typeof e == "object" && e !== null && e.$$typeof === ol
}

function CE(e) {
    var t = {
        "=": "=0",
        ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
        return t[n]
    })
}
var Xg = /\/+/g;

function bf(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? CE("" + e.key) : t.toString(36)
}

function su(e, t, n, r, i) {
    var s = typeof e;
    (s === "undefined" || s === "boolean") && (e = null);
    var o = !1;
    if (e === null) o = !0;
    else switch (s) {
        case "string":
        case "number":
            o = !0;
            break;
        case "object":
            switch (e.$$typeof) {
                case ol:
                case fE:
                    o = !0
            }
    }
    if (o) return o = e, i = i(o), e = r === "" ? "." + bf(o, 0) : r, Yg(i) ? (n = "", e != null && (n = e.replace(Xg, "$&/") + "/"), su(i, t, n, "", function(u) {
        return u
    })) : i != null && (Cp(i) && (i = SE(i, n + (!i.key || o && o.key === i.key ? "" : ("" + i.key).replace(Xg, "$&/") + "/") + e)), t.push(i)), 1;
    if (o = 0, r = r === "" ? "." : r + ":", Yg(e))
        for (var a = 0; a < e.length; a++) {
            s = e[a];
            var l = r + bf(s, a);
            o += su(s, t, n, l, i)
        } else if (l = wE(e), typeof l == "function")
            for (e = l.call(e), a = 0; !(s = e.next()).done;) s = s.value, l = r + bf(s, a++), o += su(s, t, n, l, i);
        else if (s === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
    return o
}

function jl(e, t, n) {
    if (e == null) return e;
    var r = [],
        i = 0;
    return su(e, r, "", "", function(s) {
        return t.call(n, s, i++)
    }), r
}

function TE(e) {
    if (e._status === -1) {
        var t = e._result;
        t = t(), t.then(function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n)
        }, function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n)
        }), e._status === -1 && (e._status = 0, e._result = t)
    }
    if (e._status === 1) return e._result.default;
    throw e._result
}
var Vt = {
        current: null
    },
    ou = {
        transition: null
    },
    EE = {
        ReactCurrentDispatcher: Vt,
        ReactCurrentBatchConfig: ou,
        ReactCurrentOwner: Sp
    };

function J1() {
    throw Error("act(...) is not supported in production builds of React.")
}
ae.Children = {
    map: jl,
    forEach: function(e, t, n) {
        jl(e, function() {
            t.apply(this, arguments)
        }, n)
    },
    count: function(e) {
        var t = 0;
        return jl(e, function() {
            t++
        }), t
    },
    toArray: function(e) {
        return jl(e, function(t) {
            return t
        }) || []
    },
    only: function(e) {
        if (!Cp(e)) throw Error("React.Children.only expected to receive a single React element child.");
        return e
    }
};
ae.Component = xo;
ae.Fragment = dE;
ae.Profiler = pE;
ae.PureComponent = _p;
ae.StrictMode = hE;
ae.Suspense = vE;
ae.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = EE;
ae.act = J1;
ae.cloneElement = function(e, t, n) {
    if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
    var r = K1({}, e.props),
        i = e.key,
        s = e.ref,
        o = e._owner;
    if (t != null) {
        if (t.ref !== void 0 && (s = t.ref, o = Sp.current), t.key !== void 0 && (i = "" + t.key), e.type && e.type.defaultProps) var a = e.type.defaultProps;
        for (l in t) X1.call(t, l) && !q1.hasOwnProperty(l) && (r[l] = t[l] === void 0 && a !== void 0 ? a[l] : t[l])
    }
    var l = arguments.length - 2;
    if (l === 1) r.children = n;
    else if (1 < l) {
        a = Array(l);
        for (var u = 0; u < l; u++) a[u] = arguments[u + 2];
        r.children = a
    }
    return {
        $$typeof: ol,
        type: e.type,
        key: i,
        ref: s,
        props: r,
        _owner: o
    }
};
ae.createContext = function(e) {
    return e = {
        $$typeof: gE,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
    }, e.Provider = {
        $$typeof: mE,
        _context: e
    }, e.Consumer = e
};
ae.createElement = Q1;
ae.createFactory = function(e) {
    var t = Q1.bind(null, e);
    return t.type = e, t
};
ae.createRef = function() {
    return {
        current: null
    }
};
ae.forwardRef = function(e) {
    return {
        $$typeof: yE,
        render: e
    }
};
ae.isValidElement = Cp;
ae.lazy = function(e) {
    return {
        $$typeof: _E,
        _payload: {
            _status: -1,
            _result: e
        },
        _init: TE
    }
};
ae.memo = function(e, t) {
    return {
        $$typeof: xE,
        type: e,
        compare: t === void 0 ? null : t
    }
};
ae.startTransition = function(e) {
    var t = ou.transition;
    ou.transition = {};
    try {
        e()
    } finally {
        ou.transition = t
    }
};
ae.unstable_act = J1;
ae.useCallback = function(e, t) {
    return Vt.current.useCallback(e, t)
};
ae.useContext = function(e) {
    return Vt.current.useContext(e)
};
ae.useDebugValue = function() {};
ae.useDeferredValue = function(e) {
    return Vt.current.useDeferredValue(e)
};
ae.useEffect = function(e, t) {
    return Vt.current.useEffect(e, t)
};
ae.useId = function() {
    return Vt.current.useId()
};
ae.useImperativeHandle = function(e, t, n) {
    return Vt.current.useImperativeHandle(e, t, n)
};
ae.useInsertionEffect = function(e, t) {
    return Vt.current.useInsertionEffect(e, t)
};
ae.useLayoutEffect = function(e, t) {
    return Vt.current.useLayoutEffect(e, t)
};
ae.useMemo = function(e, t) {
    return Vt.current.useMemo(e, t)
};
ae.useReducer = function(e, t, n) {
    return Vt.current.useReducer(e, t, n)
};
ae.useRef = function(e) {
    return Vt.current.useRef(e)
};
ae.useState = function(e) {
    return Vt.current.useState(e)
};
ae.useSyncExternalStore = function(e, t, n) {
    return Vt.current.useSyncExternalStore(e, t, n)
};
ae.useTransition = function() {
    return Vt.current.useTransition()
};
ae.version = "18.3.1";
W1.exports = ae;
var C = W1.exports;
const Z1 = z1(C),
    Dd = U1({
        __proto__: null,
        default: Z1
    }, [C]);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var PE = C,
    kE = Symbol.for("react.element"),
    bE = Symbol.for("react.fragment"),
    RE = Object.prototype.hasOwnProperty,
    AE = PE.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    DE = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function ex(e, t, n) {
    var r, i = {},
        s = null,
        o = null;
    n !== void 0 && (s = "" + n), t.key !== void 0 && (s = "" + t.key), t.ref !== void 0 && (o = t.ref);
    for (r in t) RE.call(t, r) && !DE.hasOwnProperty(r) && (i[r] = t[r]);
    if (e && e.defaultProps)
        for (r in t = e.defaultProps, t) i[r] === void 0 && (i[r] = t[r]);
    return {
        $$typeof: kE,
        type: e,
        key: s,
        ref: o,
        props: i,
        _owner: AE.current
    }
}
Tc.Fragment = bE;
Tc.jsx = ex;
Tc.jsxs = ex;
$1.exports = Tc;
var g = $1.exports,
    jd = {},
    tx = {
        exports: {}
    },
    vn = {},
    nx = {
        exports: {}
    },
    rx = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
    function t(M, B) {
        var H = M.length;
        M.push(B);
        e: for (; 0 < H;) {
            var ie = H - 1 >>> 1,
                ne = M[ie];
            if (0 < i(ne, B)) M[ie] = B, M[H] = ne, H = ie;
            else break e
        }
    }

    function n(M) {
        return M.length === 0 ? null : M[0]
    }

    function r(M) {
        if (M.length === 0) return null;
        var B = M[0],
            H = M.pop();
        if (H !== B) {
            M[0] = H;
            e: for (var ie = 0, ne = M.length, St = ne >>> 1; ie < St;) {
                var xe = 2 * (ie + 1) - 1,
                    ke = M[xe],
                    ct = xe + 1,
                    Lt = M[ct];
                if (0 > i(ke, H)) ct < ne && 0 > i(Lt, ke) ? (M[ie] = Lt, M[ct] = H, ie = ct) : (M[ie] = ke, M[xe] = H, ie = xe);
                else if (ct < ne && 0 > i(Lt, H)) M[ie] = Lt, M[ct] = H, ie = ct;
                else break e
            }
        }
        return B
    }

    function i(M, B) {
        var H = M.sortIndex - B.sortIndex;
        return H !== 0 ? H : M.id - B.id
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
        var s = performance;
        e.unstable_now = function() {
            return s.now()
        }
    } else {
        var o = Date,
            a = o.now();
        e.unstable_now = function() {
            return o.now() - a
        }
    }
    var l = [],
        u = [],
        c = 1,
        f = null,
        d = 3,
        p = !1,
        m = !1,
        h = !1,
        _ = typeof setTimeout == "function" ? setTimeout : null,
        v = typeof clearTimeout == "function" ? clearTimeout : null,
        y = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

    function x(M) {
        for (var B = n(u); B !== null;) {
            if (B.callback === null) r(u);
            else if (B.startTime <= M) r(u), B.sortIndex = B.expirationTime, t(l, B);
            else break;
            B = n(u)
        }
    }

    function T(M) {
        if (h = !1, x(M), !m)
            if (n(l) !== null) m = !0, re(E);
            else {
                var B = n(u);
                B !== null && q(T, B.startTime - M)
            }
    }

    function E(M, B) {
        m = !1, h && (h = !1, v(P), P = -1), p = !0;
        var H = d;
        try {
            for (x(B), f = n(l); f !== null && (!(f.expirationTime > B) || M && !O());) {
                var ie = f.callback;
                if (typeof ie == "function") {
                    f.callback = null, d = f.priorityLevel;
                    var ne = ie(f.expirationTime <= B);
                    B = e.unstable_now(), typeof ne == "function" ? f.callback = ne : f === n(l) && r(l), x(B)
                } else r(l);
                f = n(l)
            }
            if (f !== null) var St = !0;
            else {
                var xe = n(u);
                xe !== null && q(T, xe.startTime - B), St = !1
            }
            return St
        } finally {
            f = null, d = H, p = !1
        }
    }
    var k = !1,
        S = null,
        P = -1,
        A = 5,
        w = -1;

    function O() {
        return !(e.unstable_now() - w < A)
    }

    function F() {
        if (S !== null) {
            var M = e.unstable_now();
            w = M;
            var B = !0;
            try {
                B = S(!0, M)
            } finally {
                B ? V() : (k = !1, S = null)
            }
        } else k = !1
    }
    var V;
    if (typeof y == "function") V = function() {
        y(F)
    };
    else if (typeof MessageChannel < "u") {
        var W = new MessageChannel,
            Z = W.port2;
        W.port1.onmessage = F, V = function() {
            Z.postMessage(null)
        }
    } else V = function() {
        _(F, 0)
    };

    function re(M) {
        S = M, k || (k = !0, V())
    }

    function q(M, B) {
        P = _(function() {
            M(e.unstable_now())
        }, B)
    }
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(M) {
        M.callback = null
    }, e.unstable_continueExecution = function() {
        m || p || (m = !0, re(E))
    }, e.unstable_forceFrameRate = function(M) {
        0 > M || 125 < M ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : A = 0 < M ? Math.floor(1e3 / M) : 5
    }, e.unstable_getCurrentPriorityLevel = function() {
        return d
    }, e.unstable_getFirstCallbackNode = function() {
        return n(l)
    }, e.unstable_next = function(M) {
        switch (d) {
            case 1:
            case 2:
            case 3:
                var B = 3;
                break;
            default:
                B = d
        }
        var H = d;
        d = B;
        try {
            return M()
        } finally {
            d = H
        }
    }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = function() {}, e.unstable_runWithPriority = function(M, B) {
        switch (M) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                M = 3
        }
        var H = d;
        d = M;
        try {
            return B()
        } finally {
            d = H
        }
    }, e.unstable_scheduleCallback = function(M, B, H) {
        var ie = e.unstable_now();
        switch (typeof H == "object" && H !== null ? (H = H.delay, H = typeof H == "number" && 0 < H ? ie + H : ie) : H = ie, M) {
            case 1:
                var ne = -1;
                break;
            case 2:
                ne = 250;
                break;
            case 5:
                ne = 1073741823;
                break;
            case 4:
                ne = 1e4;
                break;
            default:
                ne = 5e3
        }
        return ne = H + ne, M = {
            id: c++,
            callback: B,
            priorityLevel: M,
            startTime: H,
            expirationTime: ne,
            sortIndex: -1
        }, H > ie ? (M.sortIndex = H, t(u, M), n(l) === null && M === n(u) && (h ? (v(P), P = -1) : h = !0, q(T, H - ie))) : (M.sortIndex = ne, t(l, M), m || p || (m = !0, re(E))), M
    }, e.unstable_shouldYield = O, e.unstable_wrapCallback = function(M) {
        var B = d;
        return function() {
            var H = d;
            d = B;
            try {
                return M.apply(this, arguments)
            } finally {
                d = H
            }
        }
    }
})(rx);
nx.exports = rx;
var jE = nx.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var OE = C,
    mn = jE;

function I(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
var ix = new Set,
    Sa = {};

function is(e, t) {
    Qs(e, t), Qs(e + "Capture", t)
}

function Qs(e, t) {
    for (Sa[e] = t, e = 0; e < t.length; e++) ix.add(t[e])
}
var Er = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
    Od = Object.prototype.hasOwnProperty,
    LE = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    qg = {},
    Qg = {};

function ME(e) {
    return Od.call(Qg, e) ? !0 : Od.call(qg, e) ? !1 : LE.test(e) ? Qg[e] = !0 : (qg[e] = !0, !1)
}

function NE(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
        case "function":
        case "symbol":
            return !0;
        case "boolean":
            return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
        default:
            return !1
    }
}

function FE(e, t, n, r) {
    if (t === null || typeof t > "u" || NE(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null) switch (n.type) {
        case 3:
            return !t;
        case 4:
            return t === !1;
        case 5:
            return isNaN(t);
        case 6:
            return isNaN(t) || 1 > t
    }
    return !1
}

function Bt(e, t, n, r, i, s, o) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = i, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = s, this.removeEmptyString = o
}
var wt = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    wt[e] = new Bt(e, 0, !1, e, null, !1, !1)
});
[
    ["acceptCharset", "accept-charset"],
    ["className", "class"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"]
].forEach(function(e) {
    var t = e[0];
    wt[t] = new Bt(t, 1, !1, e[1], null, !1, !1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    wt[e] = new Bt(e, 2, !1, e.toLowerCase(), null, !1, !1)
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    wt[e] = new Bt(e, 2, !1, e, null, !1, !1)
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    wt[e] = new Bt(e, 3, !1, e.toLowerCase(), null, !1, !1)
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
    wt[e] = new Bt(e, 3, !0, e, null, !1, !1)
});
["capture", "download"].forEach(function(e) {
    wt[e] = new Bt(e, 4, !1, e, null, !1, !1)
});
["cols", "rows", "size", "span"].forEach(function(e) {
    wt[e] = new Bt(e, 6, !1, e, null, !1, !1)
});
["rowSpan", "start"].forEach(function(e) {
    wt[e] = new Bt(e, 5, !1, e.toLowerCase(), null, !1, !1)
});
var Tp = /[\-:]([a-z])/g;

function Ep(e) {
    return e[1].toUpperCase()
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(Tp, Ep);
    wt[t] = new Bt(t, 1, !1, e, null, !1, !1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(Tp, Ep);
    wt[t] = new Bt(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
    var t = e.replace(Tp, Ep);
    wt[t] = new Bt(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
});
["tabIndex", "crossOrigin"].forEach(function(e) {
    wt[e] = new Bt(e, 1, !1, e.toLowerCase(), null, !1, !1)
});
wt.xlinkHref = new Bt("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
    wt[e] = new Bt(e, 1, !1, e.toLowerCase(), null, !0, !0)
});

function Pp(e, t, n, r) {
    var i = wt.hasOwnProperty(t) ? wt[t] : null;
    (i !== null ? i.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (FE(t, n, i, r) && (n = null), r || i === null ? ME(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : i.mustUseProperty ? e[i.propertyName] = n === null ? i.type === 3 ? !1 : "" : n : (t = i.attributeName, r = i.attributeNamespace, n === null ? e.removeAttribute(t) : (i = i.type, n = i === 3 || i === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var Lr = OE.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    Ol = Symbol.for("react.element"),
    ws = Symbol.for("react.portal"),
    Ss = Symbol.for("react.fragment"),
    kp = Symbol.for("react.strict_mode"),
    Ld = Symbol.for("react.profiler"),
    sx = Symbol.for("react.provider"),
    ox = Symbol.for("react.context"),
    bp = Symbol.for("react.forward_ref"),
    Md = Symbol.for("react.suspense"),
    Nd = Symbol.for("react.suspense_list"),
    Rp = Symbol.for("react.memo"),
    zr = Symbol.for("react.lazy"),
    ax = Symbol.for("react.offscreen"),
    Jg = Symbol.iterator;

function Do(e) {
    return e === null || typeof e != "object" ? null : (e = Jg && e[Jg] || e["@@iterator"], typeof e == "function" ? e : null)
}
var Ue = Object.assign,
    Rf;

function Go(e) {
    if (Rf === void 0) try {
        throw Error()
    } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        Rf = t && t[1] || ""
    }
    return `
` + Rf + e
}
var Af = !1;

function Df(e, t) {
    if (!e || Af) return "";
    Af = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
        if (t)
            if (t = function() {
                    throw Error()
                }, Object.defineProperty(t.prototype, "props", {
                    set: function() {
                        throw Error()
                    }
                }), typeof Reflect == "object" && Reflect.construct) {
                try {
                    Reflect.construct(t, [])
                } catch (u) {
                    var r = u
                }
                Reflect.construct(e, [], t)
            } else {
                try {
                    t.call()
                } catch (u) {
                    r = u
                }
                e.call(t.prototype)
            }
        else {
            try {
                throw Error()
            } catch (u) {
                r = u
            }
            e()
        }
    } catch (u) {
        if (u && r && typeof u.stack == "string") {
            for (var i = u.stack.split(`
`), s = r.stack.split(`
`), o = i.length - 1, a = s.length - 1; 1 <= o && 0 <= a && i[o] !== s[a];) a--;
            for (; 1 <= o && 0 <= a; o--, a--)
                if (i[o] !== s[a]) {
                    if (o !== 1 || a !== 1)
                        do
                            if (o--, a--, 0 > a || i[o] !== s[a]) {
                                var l = `
` + i[o].replace(" at new ", " at ");
                                return e.displayName && l.includes("<anonymous>") && (l = l.replace("<anonymous>", e.displayName)), l
                            }
                    while (1 <= o && 0 <= a);
                    break
                }
        }
    } finally {
        Af = !1, Error.prepareStackTrace = n
    }
    return (e = e ? e.displayName || e.name : "") ? Go(e) : ""
}

function IE(e) {
    switch (e.tag) {
        case 5:
            return Go(e.type);
        case 16:
            return Go("Lazy");
        case 13:
            return Go("Suspense");
        case 19:
            return Go("SuspenseList");
        case 0:
        case 2:
        case 15:
            return e = Df(e.type, !1), e;
        case 11:
            return e = Df(e.type.render, !1), e;
        case 1:
            return e = Df(e.type, !0), e;
        default:
            return ""
    }
}

function Fd(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
        case Ss:
            return "Fragment";
        case ws:
            return "Portal";
        case Ld:
            return "Profiler";
        case kp:
            return "StrictMode";
        case Md:
            return "Suspense";
        case Nd:
            return "SuspenseList"
    }
    if (typeof e == "object") switch (e.$$typeof) {
        case ox:
            return (e.displayName || "Context") + ".Consumer";
        case sx:
            return (e._context.displayName || "Context") + ".Provider";
        case bp:
            var t = e.render;
            return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case Rp:
            return t = e.displayName || null, t !== null ? t : Fd(e.type) || "Memo";
        case zr:
            t = e._payload, e = e._init;
            try {
                return Fd(e(t))
            } catch {}
    }
    return null
}

function VE(e) {
    var t = e.type;
    switch (e.tag) {
        case 24:
            return "Cache";
        case 9:
            return (t.displayName || "Context") + ".Consumer";
        case 10:
            return (t._context.displayName || "Context") + ".Provider";
        case 18:
            return "DehydratedFragment";
        case 11:
            return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
        case 7:
            return "Fragment";
        case 5:
            return t;
        case 4:
            return "Portal";
        case 3:
            return "Root";
        case 6:
            return "Text";
        case 16:
            return Fd(t);
        case 8:
            return t === kp ? "StrictMode" : "Mode";
        case 22:
            return "Offscreen";
        case 12:
            return "Profiler";
        case 21:
            return "Scope";
        case 13:
            return "Suspense";
        case 19:
            return "SuspenseList";
        case 25:
            return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
            if (typeof t == "function") return t.displayName || t.name || null;
            if (typeof t == "string") return t
    }
    return null
}

function ai(e) {
    switch (typeof e) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
            return e;
        case "object":
            return e;
        default:
            return ""
    }
}

function lx(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
}

function BE(e) {
    var t = lx(e) ? "checked" : "value",
        n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
        r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
        var i = n.get,
            s = n.set;
        return Object.defineProperty(e, t, {
            configurable: !0,
            get: function() {
                return i.call(this)
            },
            set: function(o) {
                r = "" + o, s.call(this, o)
            }
        }), Object.defineProperty(e, t, {
            enumerable: n.enumerable
        }), {
            getValue: function() {
                return r
            },
            setValue: function(o) {
                r = "" + o
            },
            stopTracking: function() {
                e._valueTracker = null, delete e[t]
            }
        }
    }
}

function Ll(e) {
    e._valueTracker || (e._valueTracker = BE(e))
}

function ux(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
        r = "";
    return e && (r = lx(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
}

function Du(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
    try {
        return e.activeElement || e.body
    } catch {
        return e.body
    }
}

function Id(e, t) {
    var n = t.checked;
    return Ue({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: n ? ? e._wrapperState.initialChecked
    })
}

function Zg(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
        r = t.checked != null ? t.checked : t.defaultChecked;
    n = ai(t.value != null ? t.value : n), e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    }
}

function cx(e, t) {
    t = t.checked, t != null && Pp(e, "checked", t, !1)
}

function Vd(e, t) {
    cx(e, t);
    var n = ai(t.value),
        r = t.type;
    if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
        e.removeAttribute("value");
        return
    }
    t.hasOwnProperty("value") ? Bd(e, t.type, n) : t.hasOwnProperty("defaultValue") && Bd(e, t.type, ai(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}

function ey(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var r = t.type;
        if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
        t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
    }
    n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
}

function Bd(e, t, n) {
    (t !== "number" || Du(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}
var Yo = Array.isArray;

function Bs(e, t, n, r) {
    if (e = e.options, t) {
        t = {};
        for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0;
        for (n = 0; n < e.length; n++) i = t.hasOwnProperty("$" + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0)
    } else {
        for (n = "" + ai(n), t = null, i = 0; i < e.length; i++) {
            if (e[i].value === n) {
                e[i].selected = !0, r && (e[i].defaultSelected = !0);
                return
            }
            t !== null || e[i].disabled || (t = e[i])
        }
        t !== null && (t.selected = !0)
    }
}

function zd(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(I(91));
    return Ue({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: "" + e._wrapperState.initialValue
    })
}

function ty(e, t) {
    var n = t.value;
    if (n == null) {
        if (n = t.children, t = t.defaultValue, n != null) {
            if (t != null) throw Error(I(92));
            if (Yo(n)) {
                if (1 < n.length) throw Error(I(93));
                n = n[0]
            }
            t = n
        }
        t == null && (t = ""), n = t
    }
    e._wrapperState = {
        initialValue: ai(n)
    }
}

function fx(e, t) {
    var n = ai(t.value),
        r = ai(t.defaultValue);
    n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
}

function ny(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}

function dx(e) {
    switch (e) {
        case "svg":
            return "http://www.w3.org/2000/svg";
        case "math":
            return "http://www.w3.org/1998/Math/MathML";
        default:
            return "http://www.w3.org/1999/xhtml"
    }
}

function Ud(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? dx(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
}
var Ml, hx = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, i) {
        MSApp.execUnsafeLocalFunction(function() {
            return e(t, n, r, i)
        })
    } : e
}(function(e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
    else {
        for (Ml = Ml || document.createElement("div"), Ml.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = Ml.firstChild; e.firstChild;) e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild)
    }
});

function Ca(e, t) {
    if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
            n.nodeValue = t;
            return
        }
    }
    e.textContent = t
}
var sa = {
        animationIterationCount: !0,
        aspectRatio: !0,
        borderImageOutset: !0,
        borderImageSlice: !0,
        borderImageWidth: !0,
        boxFlex: !0,
        boxFlexGroup: !0,
        boxOrdinalGroup: !0,
        columnCount: !0,
        columns: !0,
        flex: !0,
        flexGrow: !0,
        flexPositive: !0,
        flexShrink: !0,
        flexNegative: !0,
        flexOrder: !0,
        gridArea: !0,
        gridRow: !0,
        gridRowEnd: !0,
        gridRowSpan: !0,
        gridRowStart: !0,
        gridColumn: !0,
        gridColumnEnd: !0,
        gridColumnSpan: !0,
        gridColumnStart: !0,
        fontWeight: !0,
        lineClamp: !0,
        lineHeight: !0,
        opacity: !0,
        order: !0,
        orphans: !0,
        tabSize: !0,
        widows: !0,
        zIndex: !0,
        zoom: !0,
        fillOpacity: !0,
        floodOpacity: !0,
        stopOpacity: !0,
        strokeDasharray: !0,
        strokeDashoffset: !0,
        strokeMiterlimit: !0,
        strokeOpacity: !0,
        strokeWidth: !0
    },
    zE = ["Webkit", "ms", "Moz", "O"];
Object.keys(sa).forEach(function(e) {
    zE.forEach(function(t) {
        t = t + e.charAt(0).toUpperCase() + e.substring(1), sa[t] = sa[e]
    })
});

function px(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || sa.hasOwnProperty(e) && sa[e] ? ("" + t).trim() : t + "px"
}

function mx(e, t) {
    e = e.style;
    for (var n in t)
        if (t.hasOwnProperty(n)) {
            var r = n.indexOf("--") === 0,
                i = px(n, t[n], r);
            n === "float" && (n = "cssFloat"), r ? e.setProperty(n, i) : e[n] = i
        }
}
var UE = Ue({
    menuitem: !0
}, {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
});

function $d(e, t) {
    if (t) {
        if (UE[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(I(137, e));
        if (t.dangerouslySetInnerHTML != null) {
            if (t.children != null) throw Error(I(60));
            if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(I(61))
        }
        if (t.style != null && typeof t.style != "object") throw Error(I(62))
    }
}

function Wd(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
            return !1;
        default:
            return !0
    }
}
var Hd = null;

function Ap(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
}
var Kd = null,
    zs = null,
    Us = null;

function ry(e) {
    if (e = ul(e)) {
        if (typeof Kd != "function") throw Error(I(280));
        var t = e.stateNode;
        t && (t = Rc(t), Kd(e.stateNode, e.type, t))
    }
}

function gx(e) {
    zs ? Us ? Us.push(e) : Us = [e] : zs = e
}

function yx() {
    if (zs) {
        var e = zs,
            t = Us;
        if (Us = zs = null, ry(e), t)
            for (e = 0; e < t.length; e++) ry(t[e])
    }
}

function vx(e, t) {
    return e(t)
}

function xx() {}
var jf = !1;

function _x(e, t, n) {
    if (jf) return e(t, n);
    jf = !0;
    try {
        return vx(e, t, n)
    } finally {
        jf = !1, (zs !== null || Us !== null) && (xx(), yx())
    }
}

function Ta(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = Rc(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
            (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
            break e;
        default:
            e = !1
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(I(231, t, typeof n));
    return n
}
var Gd = !1;
if (Er) try {
    var jo = {};
    Object.defineProperty(jo, "passive", {
        get: function() {
            Gd = !0
        }
    }), window.addEventListener("test", jo, jo), window.removeEventListener("test", jo, jo)
} catch {
    Gd = !1
}

function $E(e, t, n, r, i, s, o, a, l) {
    var u = Array.prototype.slice.call(arguments, 3);
    try {
        t.apply(n, u)
    } catch (c) {
        this.onError(c)
    }
}
var oa = !1,
    ju = null,
    Ou = !1,
    Yd = null,
    WE = {
        onError: function(e) {
            oa = !0, ju = e
        }
    };

function HE(e, t, n, r, i, s, o, a, l) {
    oa = !1, ju = null, $E.apply(WE, arguments)
}

function KE(e, t, n, r, i, s, o, a, l) {
    if (HE.apply(this, arguments), oa) {
        if (oa) {
            var u = ju;
            oa = !1, ju = null
        } else throw Error(I(198));
        Ou || (Ou = !0, Yd = u)
    }
}

function ss(e) {
    var t = e,
        n = e;
    if (e.alternate)
        for (; t.return;) t = t.return;
    else {
        e = t;
        do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
    }
    return t.tag === 3 ? n : null
}

function wx(e) {
    if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
    }
    return null
}

function iy(e) {
    if (ss(e) !== e) throw Error(I(188))
}

function GE(e) {
    var t = e.alternate;
    if (!t) {
        if (t = ss(e), t === null) throw Error(I(188));
        return t !== e ? null : e
    }
    for (var n = e, r = t;;) {
        var i = n.return;
        if (i === null) break;
        var s = i.alternate;
        if (s === null) {
            if (r = i.return, r !== null) {
                n = r;
                continue
            }
            break
        }
        if (i.child === s.child) {
            for (s = i.child; s;) {
                if (s === n) return iy(i), e;
                if (s === r) return iy(i), t;
                s = s.sibling
            }
            throw Error(I(188))
        }
        if (n.return !== r.return) n = i, r = s;
        else {
            for (var o = !1, a = i.child; a;) {
                if (a === n) {
                    o = !0, n = i, r = s;
                    break
                }
                if (a === r) {
                    o = !0, r = i, n = s;
                    break
                }
                a = a.sibling
            }
            if (!o) {
                for (a = s.child; a;) {
                    if (a === n) {
                        o = !0, n = s, r = i;
                        break
                    }
                    if (a === r) {
                        o = !0, r = s, n = i;
                        break
                    }
                    a = a.sibling
                }
                if (!o) throw Error(I(189))
            }
        }
        if (n.alternate !== r) throw Error(I(190))
    }
    if (n.tag !== 3) throw Error(I(188));
    return n.stateNode.current === n ? e : t
}

function Sx(e) {
    return e = GE(e), e !== null ? Cx(e) : null
}

function Cx(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
        var t = Cx(e);
        if (t !== null) return t;
        e = e.sibling
    }
    return null
}
var Tx = mn.unstable_scheduleCallback,
    sy = mn.unstable_cancelCallback,
    YE = mn.unstable_shouldYield,
    XE = mn.unstable_requestPaint,
    Ze = mn.unstable_now,
    qE = mn.unstable_getCurrentPriorityLevel,
    Dp = mn.unstable_ImmediatePriority,
    Ex = mn.unstable_UserBlockingPriority,
    Lu = mn.unstable_NormalPriority,
    QE = mn.unstable_LowPriority,
    Px = mn.unstable_IdlePriority,
    Ec = null,
    rr = null;

function JE(e) {
    if (rr && typeof rr.onCommitFiberRoot == "function") try {
        rr.onCommitFiberRoot(Ec, e, void 0, (e.current.flags & 128) === 128)
    } catch {}
}
var zn = Math.clz32 ? Math.clz32 : tP,
    ZE = Math.log,
    eP = Math.LN2;

function tP(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - (ZE(e) / eP | 0) | 0
}
var Nl = 64,
    Fl = 4194304;

function Xo(e) {
    switch (e & -e) {
        case 1:
            return 1;
        case 2:
            return 2;
        case 4:
            return 4;
        case 8:
            return 8;
        case 16:
            return 16;
        case 32:
            return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return e & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return e & 130023424;
        case 134217728:
            return 134217728;
        case 268435456:
            return 268435456;
        case 536870912:
            return 536870912;
        case 1073741824:
            return 1073741824;
        default:
            return e
    }
}

function Mu(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
        i = e.suspendedLanes,
        s = e.pingedLanes,
        o = n & 268435455;
    if (o !== 0) {
        var a = o & ~i;
        a !== 0 ? r = Xo(a) : (s &= o, s !== 0 && (r = Xo(s)))
    } else o = n & ~i, o !== 0 ? r = Xo(o) : s !== 0 && (r = Xo(s));
    if (r === 0) return 0;
    if (t !== 0 && t !== r && !(t & i) && (i = r & -r, s = t & -t, i >= s || i === 16 && (s & 4194240) !== 0)) return t;
    if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
        for (e = e.entanglements, t &= r; 0 < t;) n = 31 - zn(t), i = 1 << n, r |= e[n], t &= ~i;
    return r
}

function nP(e, t) {
    switch (e) {
        case 1:
        case 2:
        case 4:
            return t + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
            return -1;
        default:
            return -1
    }
}

function rP(e, t) {
    for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, s = e.pendingLanes; 0 < s;) {
        var o = 31 - zn(s),
            a = 1 << o,
            l = i[o];
        l === -1 ? (!(a & n) || a & r) && (i[o] = nP(a, t)) : l <= t && (e.expiredLanes |= a), s &= ~a
    }
}

function Xd(e) {
    return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
}

function kx() {
    var e = Nl;
    return Nl <<= 1, !(Nl & 4194240) && (Nl = 64), e
}

function Of(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t
}

function al(e, t, n) {
    e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - zn(t), e[t] = n
}

function iP(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
        var i = 31 - zn(n),
            s = 1 << i;
        t[i] = 0, r[i] = -1, e[i] = -1, n &= ~s
    }
}

function jp(e, t) {
    var n = e.entangledLanes |= t;
    for (e = e.entanglements; n;) {
        var r = 31 - zn(n),
            i = 1 << r;
        i & t | e[r] & t && (e[r] |= t), n &= ~i
    }
}
var ve = 0;

function bx(e) {
    return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
}
var Rx, Op, Ax, Dx, jx, qd = !1,
    Il = [],
    Qr = null,
    Jr = null,
    Zr = null,
    Ea = new Map,
    Pa = new Map,
    $r = [],
    sP = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

function oy(e, t) {
    switch (e) {
        case "focusin":
        case "focusout":
            Qr = null;
            break;
        case "dragenter":
        case "dragleave":
            Jr = null;
            break;
        case "mouseover":
        case "mouseout":
            Zr = null;
            break;
        case "pointerover":
        case "pointerout":
            Ea.delete(t.pointerId);
            break;
        case "gotpointercapture":
        case "lostpointercapture":
            Pa.delete(t.pointerId)
    }
}

function Oo(e, t, n, r, i, s) {
    return e === null || e.nativeEvent !== s ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: s,
        targetContainers: [i]
    }, t !== null && (t = ul(t), t !== null && Op(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e)
}

function oP(e, t, n, r, i) {
    switch (t) {
        case "focusin":
            return Qr = Oo(Qr, e, t, n, r, i), !0;
        case "dragenter":
            return Jr = Oo(Jr, e, t, n, r, i), !0;
        case "mouseover":
            return Zr = Oo(Zr, e, t, n, r, i), !0;
        case "pointerover":
            var s = i.pointerId;
            return Ea.set(s, Oo(Ea.get(s) || null, e, t, n, r, i)), !0;
        case "gotpointercapture":
            return s = i.pointerId, Pa.set(s, Oo(Pa.get(s) || null, e, t, n, r, i)), !0
    }
    return !1
}

function Ox(e) {
    var t = Li(e.target);
    if (t !== null) {
        var n = ss(t);
        if (n !== null) {
            if (t = n.tag, t === 13) {
                if (t = wx(n), t !== null) {
                    e.blockedOn = t, jx(e.priority, function() {
                        Ax(n)
                    });
                    return
                }
            } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                return
            }
        }
    }
    e.blockedOn = null
}

function au(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
        var n = Qd(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
        if (n === null) {
            n = e.nativeEvent;
            var r = new n.constructor(n.type, n);
            Hd = r, n.target.dispatchEvent(r), Hd = null
        } else return t = ul(n), t !== null && Op(t), e.blockedOn = n, !1;
        t.shift()
    }
    return !0
}

function ay(e, t, n) {
    au(e) && n.delete(t)
}

function aP() {
    qd = !1, Qr !== null && au(Qr) && (Qr = null), Jr !== null && au(Jr) && (Jr = null), Zr !== null && au(Zr) && (Zr = null), Ea.forEach(ay), Pa.forEach(ay)
}

function Lo(e, t) {
    e.blockedOn === t && (e.blockedOn = null, qd || (qd = !0, mn.unstable_scheduleCallback(mn.unstable_NormalPriority, aP)))
}

function ka(e) {
    function t(i) {
        return Lo(i, e)
    }
    if (0 < Il.length) {
        Lo(Il[0], e);
        for (var n = 1; n < Il.length; n++) {
            var r = Il[n];
            r.blockedOn === e && (r.blockedOn = null)
        }
    }
    for (Qr !== null && Lo(Qr, e), Jr !== null && Lo(Jr, e), Zr !== null && Lo(Zr, e), Ea.forEach(t), Pa.forEach(t), n = 0; n < $r.length; n++) r = $r[n], r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < $r.length && (n = $r[0], n.blockedOn === null);) Ox(n), n.blockedOn === null && $r.shift()
}
var $s = Lr.ReactCurrentBatchConfig,
    Nu = !0;

function lP(e, t, n, r) {
    var i = ve,
        s = $s.transition;
    $s.transition = null;
    try {
        ve = 1, Lp(e, t, n, r)
    } finally {
        ve = i, $s.transition = s
    }
}

function uP(e, t, n, r) {
    var i = ve,
        s = $s.transition;
    $s.transition = null;
    try {
        ve = 4, Lp(e, t, n, r)
    } finally {
        ve = i, $s.transition = s
    }
}

function Lp(e, t, n, r) {
    if (Nu) {
        var i = Qd(e, t, n, r);
        if (i === null) $f(e, t, r, Fu, n), oy(e, r);
        else if (oP(i, e, t, n, r)) r.stopPropagation();
        else if (oy(e, r), t & 4 && -1 < sP.indexOf(e)) {
            for (; i !== null;) {
                var s = ul(i);
                if (s !== null && Rx(s), s = Qd(e, t, n, r), s === null && $f(e, t, r, Fu, n), s === i) break;
                i = s
            }
            i !== null && r.stopPropagation()
        } else $f(e, t, r, null, n)
    }
}
var Fu = null;

function Qd(e, t, n, r) {
    if (Fu = null, e = Ap(r), e = Li(e), e !== null)
        if (t = ss(e), t === null) e = null;
        else if (n = t.tag, n === 13) {
        if (e = wx(t), e !== null) return e;
        e = null
    } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null
    } else t !== e && (e = null);
    return Fu = e, null
}

function Lx(e) {
    switch (e) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
            return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
            return 4;
        case "message":
            switch (qE()) {
                case Dp:
                    return 1;
                case Ex:
                    return 4;
                case Lu:
                case QE:
                    return 16;
                case Px:
                    return 536870912;
                default:
                    return 16
            }
        default:
            return 16
    }
}
var Hr = null,
    Mp = null,
    lu = null;

function Mx() {
    if (lu) return lu;
    var e, t = Mp,
        n = t.length,
        r, i = "value" in Hr ? Hr.value : Hr.textContent,
        s = i.length;
    for (e = 0; e < n && t[e] === i[e]; e++);
    var o = n - e;
    for (r = 1; r <= o && t[n - r] === i[s - r]; r++);
    return lu = i.slice(e, 1 < r ? 1 - r : void 0)
}

function uu(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
}

function Vl() {
    return !0
}

function ly() {
    return !1
}

function xn(e) {
    function t(n, r, i, s, o) {
        this._reactName = n, this._targetInst = i, this.type = r, this.nativeEvent = s, this.target = o, this.currentTarget = null;
        for (var a in e) e.hasOwnProperty(a) && (n = e[a], this[a] = n ? n(s) : s[a]);
        return this.isDefaultPrevented = (s.defaultPrevented != null ? s.defaultPrevented : s.returnValue === !1) ? Vl : ly, this.isPropagationStopped = ly, this
    }
    return Ue(t.prototype, {
        preventDefault: function() {
            this.defaultPrevented = !0;
            var n = this.nativeEvent;
            n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = Vl)
        },
        stopPropagation: function() {
            var n = this.nativeEvent;
            n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = Vl)
        },
        persist: function() {},
        isPersistent: Vl
    }), t
}
var _o = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function(e) {
            return e.timeStamp || Date.now()
        },
        defaultPrevented: 0,
        isTrusted: 0
    },
    Np = xn(_o),
    ll = Ue({}, _o, {
        view: 0,
        detail: 0
    }),
    cP = xn(ll),
    Lf, Mf, Mo, Pc = Ue({}, ll, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: Fp,
        button: 0,
        buttons: 0,
        relatedTarget: function(e) {
            return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
        },
        movementX: function(e) {
            return "movementX" in e ? e.movementX : (e !== Mo && (Mo && e.type === "mousemove" ? (Lf = e.screenX - Mo.screenX, Mf = e.screenY - Mo.screenY) : Mf = Lf = 0, Mo = e), Lf)
        },
        movementY: function(e) {
            return "movementY" in e ? e.movementY : Mf
        }
    }),
    uy = xn(Pc),
    fP = Ue({}, Pc, {
        dataTransfer: 0
    }),
    dP = xn(fP),
    hP = Ue({}, ll, {
        relatedTarget: 0
    }),
    Nf = xn(hP),
    pP = Ue({}, _o, {
        animationName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    mP = xn(pP),
    gP = Ue({}, _o, {
        clipboardData: function(e) {
            return "clipboardData" in e ? e.clipboardData : window.clipboardData
        }
    }),
    yP = xn(gP),
    vP = Ue({}, _o, {
        data: 0
    }),
    cy = xn(vP),
    xP = {
        Esc: "Escape",
        Spacebar: " ",
        Left: "ArrowLeft",
        Up: "ArrowUp",
        Right: "ArrowRight",
        Down: "ArrowDown",
        Del: "Delete",
        Win: "OS",
        Menu: "ContextMenu",
        Apps: "ContextMenu",
        Scroll: "ScrollLock",
        MozPrintableKey: "Unidentified"
    },
    _P = {
        8: "Backspace",
        9: "Tab",
        12: "Clear",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        45: "Insert",
        46: "Delete",
        112: "F1",
        113: "F2",
        114: "F3",
        115: "F4",
        116: "F5",
        117: "F6",
        118: "F7",
        119: "F8",
        120: "F9",
        121: "F10",
        122: "F11",
        123: "F12",
        144: "NumLock",
        145: "ScrollLock",
        224: "Meta"
    },
    wP = {
        Alt: "altKey",
        Control: "ctrlKey",
        Meta: "metaKey",
        Shift: "shiftKey"
    };

function SP(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = wP[e]) ? !!t[e] : !1
}

function Fp() {
    return SP
}
var CP = Ue({}, ll, {
        key: function(e) {
            if (e.key) {
                var t = xP[e.key] || e.key;
                if (t !== "Unidentified") return t
            }
            return e.type === "keypress" ? (e = uu(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? _P[e.keyCode] || "Unidentified" : ""
        },
        code: 0,
        location: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        repeat: 0,
        locale: 0,
        getModifierState: Fp,
        charCode: function(e) {
            return e.type === "keypress" ? uu(e) : 0
        },
        keyCode: function(e) {
            return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        },
        which: function(e) {
            return e.type === "keypress" ? uu(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        }
    }),
    TP = xn(CP),
    EP = Ue({}, Pc, {
        pointerId: 0,
        width: 0,
        height: 0,
        pressure: 0,
        tangentialPressure: 0,
        tiltX: 0,
        tiltY: 0,
        twist: 0,
        pointerType: 0,
        isPrimary: 0
    }),
    fy = xn(EP),
    PP = Ue({}, ll, {
        touches: 0,
        targetTouches: 0,
        changedTouches: 0,
        altKey: 0,
        metaKey: 0,
        ctrlKey: 0,
        shiftKey: 0,
        getModifierState: Fp
    }),
    kP = xn(PP),
    bP = Ue({}, _o, {
        propertyName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    RP = xn(bP),
    AP = Ue({}, Pc, {
        deltaX: function(e) {
            return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
        },
        deltaY: function(e) {
            return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
        },
        deltaZ: 0,
        deltaMode: 0
    }),
    DP = xn(AP),
    jP = [9, 13, 27, 32],
    Ip = Er && "CompositionEvent" in window,
    aa = null;
Er && "documentMode" in document && (aa = document.documentMode);
var OP = Er && "TextEvent" in window && !aa,
    Nx = Er && (!Ip || aa && 8 < aa && 11 >= aa),
    dy = " ",
    hy = !1;

function Fx(e, t) {
    switch (e) {
        case "keyup":
            return jP.indexOf(t.keyCode) !== -1;
        case "keydown":
            return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
            return !0;
        default:
            return !1
    }
}

function Ix(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
}
var Cs = !1;

function LP(e, t) {
    switch (e) {
        case "compositionend":
            return Ix(t);
        case "keypress":
            return t.which !== 32 ? null : (hy = !0, dy);
        case "textInput":
            return e = t.data, e === dy && hy ? null : e;
        default:
            return null
    }
}

function MP(e, t) {
    if (Cs) return e === "compositionend" || !Ip && Fx(e, t) ? (e = Mx(), lu = Mp = Hr = null, Cs = !1, e) : null;
    switch (e) {
        case "paste":
            return null;
        case "keypress":
            if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                if (t.char && 1 < t.char.length) return t.char;
                if (t.which) return String.fromCharCode(t.which)
            }
            return null;
        case "compositionend":
            return Nx && t.locale !== "ko" ? null : t.data;
        default:
            return null
    }
}
var NP = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
};

function py(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!NP[e.type] : t === "textarea"
}

function Vx(e, t, n, r) {
    gx(r), t = Iu(t, "onChange"), 0 < t.length && (n = new Np("onChange", "change", null, n, r), e.push({
        event: n,
        listeners: t
    }))
}
var la = null,
    ba = null;

function FP(e) {
    qx(e, 0)
}

function kc(e) {
    var t = Ps(e);
    if (ux(t)) return e
}

function IP(e, t) {
    if (e === "change") return t
}
var Bx = !1;
if (Er) {
    var Ff;
    if (Er) {
        var If = "oninput" in document;
        if (!If) {
            var my = document.createElement("div");
            my.setAttribute("oninput", "return;"), If = typeof my.oninput == "function"
        }
        Ff = If
    } else Ff = !1;
    Bx = Ff && (!document.documentMode || 9 < document.documentMode)
}

function gy() {
    la && (la.detachEvent("onpropertychange", zx), ba = la = null)
}

function zx(e) {
    if (e.propertyName === "value" && kc(ba)) {
        var t = [];
        Vx(t, ba, e, Ap(e)), _x(FP, t)
    }
}

function VP(e, t, n) {
    e === "focusin" ? (gy(), la = t, ba = n, la.attachEvent("onpropertychange", zx)) : e === "focusout" && gy()
}

function BP(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown") return kc(ba)
}

function zP(e, t) {
    if (e === "click") return kc(t)
}

function UP(e, t) {
    if (e === "input" || e === "change") return kc(t)
}

function $P(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var $n = typeof Object.is == "function" ? Object.is : $P;

function Ra(e, t) {
    if ($n(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
    var n = Object.keys(e),
        r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
        var i = n[r];
        if (!Od.call(t, i) || !$n(e[i], t[i])) return !1
    }
    return !0
}

function yy(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e
}

function vy(e, t) {
    var n = yy(e);
    e = 0;
    for (var r; n;) {
        if (n.nodeType === 3) {
            if (r = e + n.textContent.length, e <= t && r >= t) return {
                node: n,
                offset: t - e
            };
            e = r
        }
        e: {
            for (; n;) {
                if (n.nextSibling) {
                    n = n.nextSibling;
                    break e
                }
                n = n.parentNode
            }
            n = void 0
        }
        n = yy(n)
    }
}

function Ux(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Ux(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
}

function $x() {
    for (var e = window, t = Du(); t instanceof e.HTMLIFrameElement;) {
        try {
            var n = typeof t.contentWindow.location.href == "string"
        } catch {
            n = !1
        }
        if (n) e = t.contentWindow;
        else break;
        t = Du(e.document)
    }
    return t
}

function Vp(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
}

function WP(e) {
    var t = $x(),
        n = e.focusedElem,
        r = e.selectionRange;
    if (t !== n && n && n.ownerDocument && Ux(n.ownerDocument.documentElement, n)) {
        if (r !== null && Vp(n)) {
            if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
            else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
                e = e.getSelection();
                var i = n.textContent.length,
                    s = Math.min(r.start, i);
                r = r.end === void 0 ? s : Math.min(r.end, i), !e.extend && s > r && (i = r, r = s, s = i), i = vy(n, s);
                var o = vy(n, r);
                i && o && (e.rangeCount !== 1 || e.anchorNode !== i.node || e.anchorOffset !== i.offset || e.focusNode !== o.node || e.focusOffset !== o.offset) && (t = t.createRange(), t.setStart(i.node, i.offset), e.removeAllRanges(), s > r ? (e.addRange(t), e.extend(o.node, o.offset)) : (t.setEnd(o.node, o.offset), e.addRange(t)))
            }
        }
        for (t = [], e = n; e = e.parentNode;) e.nodeType === 1 && t.push({
            element: e,
            left: e.scrollLeft,
            top: e.scrollTop
        });
        for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top
    }
}
var HP = Er && "documentMode" in document && 11 >= document.documentMode,
    Ts = null,
    Jd = null,
    ua = null,
    Zd = !1;

function xy(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    Zd || Ts == null || Ts !== Du(r) || (r = Ts, "selectionStart" in r && Vp(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
    }), ua && Ra(ua, r) || (ua = r, r = Iu(Jd, "onSelect"), 0 < r.length && (t = new Np("onSelect", "select", null, t, n), e.push({
        event: t,
        listeners: r
    }), t.target = Ts)))
}

function Bl(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
}
var Es = {
        animationend: Bl("Animation", "AnimationEnd"),
        animationiteration: Bl("Animation", "AnimationIteration"),
        animationstart: Bl("Animation", "AnimationStart"),
        transitionend: Bl("Transition", "TransitionEnd")
    },
    Vf = {},
    Wx = {};
Er && (Wx = document.createElement("div").style, "AnimationEvent" in window || (delete Es.animationend.animation, delete Es.animationiteration.animation, delete Es.animationstart.animation), "TransitionEvent" in window || delete Es.transitionend.transition);

function bc(e) {
    if (Vf[e]) return Vf[e];
    if (!Es[e]) return e;
    var t = Es[e],
        n;
    for (n in t)
        if (t.hasOwnProperty(n) && n in Wx) return Vf[e] = t[n];
    return e
}
var Hx = bc("animationend"),
    Kx = bc("animationiteration"),
    Gx = bc("animationstart"),
    Yx = bc("transitionend"),
    Xx = new Map,
    _y = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

function pi(e, t) {
    Xx.set(e, t), is(t, [e])
}
for (var Bf = 0; Bf < _y.length; Bf++) {
    var zf = _y[Bf],
        KP = zf.toLowerCase(),
        GP = zf[0].toUpperCase() + zf.slice(1);
    pi(KP, "on" + GP)
}
pi(Hx, "onAnimationEnd");
pi(Kx, "onAnimationIteration");
pi(Gx, "onAnimationStart");
pi("dblclick", "onDoubleClick");
pi("focusin", "onFocus");
pi("focusout", "onBlur");
pi(Yx, "onTransitionEnd");
Qs("onMouseEnter", ["mouseout", "mouseover"]);
Qs("onMouseLeave", ["mouseout", "mouseover"]);
Qs("onPointerEnter", ["pointerout", "pointerover"]);
Qs("onPointerLeave", ["pointerout", "pointerover"]);
is("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
is("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
is("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
is("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
is("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
is("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var qo = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
    YP = new Set("cancel close invalid load scroll toggle".split(" ").concat(qo));

function wy(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, KE(r, t, void 0, e), e.currentTarget = null
}

function qx(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
        var r = e[n],
            i = r.event;
        r = r.listeners;
        e: {
            var s = void 0;
            if (t)
                for (var o = r.length - 1; 0 <= o; o--) {
                    var a = r[o],
                        l = a.instance,
                        u = a.currentTarget;
                    if (a = a.listener, l !== s && i.isPropagationStopped()) break e;
                    wy(i, a, u), s = l
                } else
                    for (o = 0; o < r.length; o++) {
                        if (a = r[o], l = a.instance, u = a.currentTarget, a = a.listener, l !== s && i.isPropagationStopped()) break e;
                        wy(i, a, u), s = l
                    }
        }
    }
    if (Ou) throw e = Yd, Ou = !1, Yd = null, e
}

function Re(e, t) {
    var n = t[ih];
    n === void 0 && (n = t[ih] = new Set);
    var r = e + "__bubble";
    n.has(r) || (Qx(t, e, 2, !1), n.add(r))
}

function Uf(e, t, n) {
    var r = 0;
    t && (r |= 4), Qx(n, e, r, t)
}
var zl = "_reactListening" + Math.random().toString(36).slice(2);

function Aa(e) {
    if (!e[zl]) {
        e[zl] = !0, ix.forEach(function(n) {
            n !== "selectionchange" && (YP.has(n) || Uf(n, !1, e), Uf(n, !0, e))
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[zl] || (t[zl] = !0, Uf("selectionchange", !1, t))
    }
}

function Qx(e, t, n, r) {
    switch (Lx(t)) {
        case 1:
            var i = lP;
            break;
        case 4:
            i = uP;
            break;
        default:
            i = Lp
    }
    n = i.bind(null, t, n, e), i = void 0, !Gd || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (i = !0), r ? i !== void 0 ? e.addEventListener(t, n, {
        capture: !0,
        passive: i
    }) : e.addEventListener(t, n, !0) : i !== void 0 ? e.addEventListener(t, n, {
        passive: i
    }) : e.addEventListener(t, n, !1)
}

function $f(e, t, n, r, i) {
    var s = r;
    if (!(t & 1) && !(t & 2) && r !== null) e: for (;;) {
        if (r === null) return;
        var o = r.tag;
        if (o === 3 || o === 4) {
            var a = r.stateNode.containerInfo;
            if (a === i || a.nodeType === 8 && a.parentNode === i) break;
            if (o === 4)
                for (o = r.return; o !== null;) {
                    var l = o.tag;
                    if ((l === 3 || l === 4) && (l = o.stateNode.containerInfo, l === i || l.nodeType === 8 && l.parentNode === i)) return;
                    o = o.return
                }
            for (; a !== null;) {
                if (o = Li(a), o === null) return;
                if (l = o.tag, l === 5 || l === 6) {
                    r = s = o;
                    continue e
                }
                a = a.parentNode
            }
        }
        r = r.return
    }
    _x(function() {
        var u = s,
            c = Ap(n),
            f = [];
        e: {
            var d = Xx.get(e);
            if (d !== void 0) {
                var p = Np,
                    m = e;
                switch (e) {
                    case "keypress":
                        if (uu(n) === 0) break e;
                    case "keydown":
                    case "keyup":
                        p = TP;
                        break;
                    case "focusin":
                        m = "focus", p = Nf;
                        break;
                    case "focusout":
                        m = "blur", p = Nf;
                        break;
                    case "beforeblur":
                    case "afterblur":
                        p = Nf;
                        break;
                    case "click":
                        if (n.button === 2) break e;
                    case "auxclick":
                    case "dblclick":
                    case "mousedown":
                    case "mousemove":
                    case "mouseup":
                    case "mouseout":
                    case "mouseover":
                    case "contextmenu":
                        p = uy;
                        break;
                    case "drag":
                    case "dragend":
                    case "dragenter":
                    case "dragexit":
                    case "dragleave":
                    case "dragover":
                    case "dragstart":
                    case "drop":
                        p = dP;
                        break;
                    case "touchcancel":
                    case "touchend":
                    case "touchmove":
                    case "touchstart":
                        p = kP;
                        break;
                    case Hx:
                    case Kx:
                    case Gx:
                        p = mP;
                        break;
                    case Yx:
                        p = RP;
                        break;
                    case "scroll":
                        p = cP;
                        break;
                    case "wheel":
                        p = DP;
                        break;
                    case "copy":
                    case "cut":
                    case "paste":
                        p = yP;
                        break;
                    case "gotpointercapture":
                    case "lostpointercapture":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "pointerup":
                        p = fy
                }
                var h = (t & 4) !== 0,
                    _ = !h && e === "scroll",
                    v = h ? d !== null ? d + "Capture" : null : d;
                h = [];
                for (var y = u, x; y !== null;) {
                    x = y;
                    var T = x.stateNode;
                    if (x.tag === 5 && T !== null && (x = T, v !== null && (T = Ta(y, v), T != null && h.push(Da(y, T, x)))), _) break;
                    y = y.return
                }
                0 < h.length && (d = new p(d, m, null, n, c), f.push({
                    event: d,
                    listeners: h
                }))
            }
        }
        if (!(t & 7)) {
            e: {
                if (d = e === "mouseover" || e === "pointerover", p = e === "mouseout" || e === "pointerout", d && n !== Hd && (m = n.relatedTarget || n.fromElement) && (Li(m) || m[Pr])) break e;
                if ((p || d) && (d = c.window === c ? c : (d = c.ownerDocument) ? d.defaultView || d.parentWindow : window, p ? (m = n.relatedTarget || n.toElement, p = u, m = m ? Li(m) : null, m !== null && (_ = ss(m), m !== _ || m.tag !== 5 && m.tag !== 6) && (m = null)) : (p = null, m = u), p !== m)) {
                    if (h = uy, T = "onMouseLeave", v = "onMouseEnter", y = "mouse", (e === "pointerout" || e === "pointerover") && (h = fy, T = "onPointerLeave", v = "onPointerEnter", y = "pointer"), _ = p == null ? d : Ps(p), x = m == null ? d : Ps(m), d = new h(T, y + "leave", p, n, c), d.target = _, d.relatedTarget = x, T = null, Li(c) === u && (h = new h(v, y + "enter", m, n, c), h.target = x, h.relatedTarget = _, T = h), _ = T, p && m) t: {
                        for (h = p, v = m, y = 0, x = h; x; x = hs(x)) y++;
                        for (x = 0, T = v; T; T = hs(T)) x++;
                        for (; 0 < y - x;) h = hs(h),
                        y--;
                        for (; 0 < x - y;) v = hs(v),
                        x--;
                        for (; y--;) {
                            if (h === v || v !== null && h === v.alternate) break t;
                            h = hs(h), v = hs(v)
                        }
                        h = null
                    }
                    else h = null;
                    p !== null && Sy(f, d, p, h, !1), m !== null && _ !== null && Sy(f, _, m, h, !0)
                }
            }
            e: {
                if (d = u ? Ps(u) : window, p = d.nodeName && d.nodeName.toLowerCase(), p === "select" || p === "input" && d.type === "file") var E = IP;
                else if (py(d))
                    if (Bx) E = UP;
                    else {
                        E = BP;
                        var k = VP
                    }
                else(p = d.nodeName) && p.toLowerCase() === "input" && (d.type === "checkbox" || d.type === "radio") && (E = zP);
                if (E && (E = E(e, u))) {
                    Vx(f, E, n, c);
                    break e
                }
                k && k(e, d, u),
                e === "focusout" && (k = d._wrapperState) && k.controlled && d.type === "number" && Bd(d, "number", d.value)
            }
            switch (k = u ? Ps(u) : window, e) {
                case "focusin":
                    (py(k) || k.contentEditable === "true") && (Ts = k, Jd = u, ua = null);
                    break;
                case "focusout":
                    ua = Jd = Ts = null;
                    break;
                case "mousedown":
                    Zd = !0;
                    break;
                case "contextmenu":
                case "mouseup":
                case "dragend":
                    Zd = !1, xy(f, n, c);
                    break;
                case "selectionchange":
                    if (HP) break;
                case "keydown":
                case "keyup":
                    xy(f, n, c)
            }
            var S;
            if (Ip) e: {
                switch (e) {
                    case "compositionstart":
                        var P = "onCompositionStart";
                        break e;
                    case "compositionend":
                        P = "onCompositionEnd";
                        break e;
                    case "compositionupdate":
                        P = "onCompositionUpdate";
                        break e
                }
                P = void 0
            }
            else Cs ? Fx(e, n) && (P = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (P = "onCompositionStart");P && (Nx && n.locale !== "ko" && (Cs || P !== "onCompositionStart" ? P === "onCompositionEnd" && Cs && (S = Mx()) : (Hr = c, Mp = "value" in Hr ? Hr.value : Hr.textContent, Cs = !0)), k = Iu(u, P), 0 < k.length && (P = new cy(P, e, null, n, c), f.push({
                event: P,
                listeners: k
            }), S ? P.data = S : (S = Ix(n), S !== null && (P.data = S)))),
            (S = OP ? LP(e, n) : MP(e, n)) && (u = Iu(u, "onBeforeInput"), 0 < u.length && (c = new cy("onBeforeInput", "beforeinput", null, n, c), f.push({
                event: c,
                listeners: u
            }), c.data = S))
        }
        qx(f, t)
    })
}

function Da(e, t, n) {
    return {
        instance: e,
        listener: t,
        currentTarget: n
    }
}

function Iu(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
        var i = e,
            s = i.stateNode;
        i.tag === 5 && s !== null && (i = s, s = Ta(e, n), s != null && r.unshift(Da(e, s, i)), s = Ta(e, t), s != null && r.push(Da(e, s, i))), e = e.return
    }
    return r
}

function hs(e) {
    if (e === null) return null;
    do e = e.return; while (e && e.tag !== 5);
    return e || null
}

function Sy(e, t, n, r, i) {
    for (var s = t._reactName, o = []; n !== null && n !== r;) {
        var a = n,
            l = a.alternate,
            u = a.stateNode;
        if (l !== null && l === r) break;
        a.tag === 5 && u !== null && (a = u, i ? (l = Ta(n, s), l != null && o.unshift(Da(n, l, a))) : i || (l = Ta(n, s), l != null && o.push(Da(n, l, a)))), n = n.return
    }
    o.length !== 0 && e.push({
        event: t,
        listeners: o
    })
}
var XP = /\r\n?/g,
    qP = /\u0000|\uFFFD/g;

function Cy(e) {
    return (typeof e == "string" ? e : "" + e).replace(XP, `
`).replace(qP, "")
}

function Ul(e, t, n) {
    if (t = Cy(t), Cy(e) !== t && n) throw Error(I(425))
}

function Vu() {}
var eh = null,
    th = null;

function nh(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
}
var rh = typeof setTimeout == "function" ? setTimeout : void 0,
    QP = typeof clearTimeout == "function" ? clearTimeout : void 0,
    Ty = typeof Promise == "function" ? Promise : void 0,
    JP = typeof queueMicrotask == "function" ? queueMicrotask : typeof Ty < "u" ? function(e) {
        return Ty.resolve(null).then(e).catch(ZP)
    } : rh;

function ZP(e) {
    setTimeout(function() {
        throw e
    })
}

function Wf(e, t) {
    var n = t,
        r = 0;
    do {
        var i = n.nextSibling;
        if (e.removeChild(n), i && i.nodeType === 8)
            if (n = i.data, n === "/$") {
                if (r === 0) {
                    e.removeChild(i), ka(t);
                    return
                }
                r--
            } else n !== "$" && n !== "$?" && n !== "$!" || r++;
        n = i
    } while (n);
    ka(t)
}

function ei(e) {
    for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
            if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
            if (t === "/$") return null
        }
    }
    return e
}

function Ey(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
        if (e.nodeType === 8) {
            var n = e.data;
            if (n === "$" || n === "$!" || n === "$?") {
                if (t === 0) return e;
                t--
            } else n === "/$" && t++
        }
        e = e.previousSibling
    }
    return null
}
var wo = Math.random().toString(36).slice(2),
    er = "__reactFiber$" + wo,
    ja = "__reactProps$" + wo,
    Pr = "__reactContainer$" + wo,
    ih = "__reactEvents$" + wo,
    ek = "__reactListeners$" + wo,
    tk = "__reactHandles$" + wo;

function Li(e) {
    var t = e[er];
    if (t) return t;
    for (var n = e.parentNode; n;) {
        if (t = n[Pr] || n[er]) {
            if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                for (e = Ey(e); e !== null;) {
                    if (n = e[er]) return n;
                    e = Ey(e)
                }
            return t
        }
        e = n, n = e.parentNode
    }
    return null
}

function ul(e) {
    return e = e[er] || e[Pr], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
}

function Ps(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(I(33))
}

function Rc(e) {
    return e[ja] || null
}
var sh = [],
    ks = -1;

function mi(e) {
    return {
        current: e
    }
}

function Ae(e) {
    0 > ks || (e.current = sh[ks], sh[ks] = null, ks--)
}

function Ee(e, t) {
    ks++, sh[ks] = e.current, e.current = t
}
var li = {},
    Ot = mi(li),
    Wt = mi(!1),
    Xi = li;

function Js(e, t) {
    var n = e.type.contextTypes;
    if (!n) return li;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
    var i = {},
        s;
    for (s in n) i[s] = t[s];
    return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = i), i
}

function Ht(e) {
    return e = e.childContextTypes, e != null
}

function Bu() {
    Ae(Wt), Ae(Ot)
}

function Py(e, t, n) {
    if (Ot.current !== li) throw Error(I(168));
    Ee(Ot, t), Ee(Wt, n)
}

function Jx(e, t, n) {
    var r = e.stateNode;
    if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
    r = r.getChildContext();
    for (var i in r)
        if (!(i in t)) throw Error(I(108, VE(e) || "Unknown", i));
    return Ue({}, n, r)
}

function zu(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || li, Xi = Ot.current, Ee(Ot, e), Ee(Wt, Wt.current), !0
}

function ky(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(I(169));
    n ? (e = Jx(e, t, Xi), r.__reactInternalMemoizedMergedChildContext = e, Ae(Wt), Ae(Ot), Ee(Ot, e)) : Ae(Wt), Ee(Wt, n)
}
var gr = null,
    Ac = !1,
    Hf = !1;

function Zx(e) {
    gr === null ? gr = [e] : gr.push(e)
}

function nk(e) {
    Ac = !0, Zx(e)
}

function gi() {
    if (!Hf && gr !== null) {
        Hf = !0;
        var e = 0,
            t = ve;
        try {
            var n = gr;
            for (ve = 1; e < n.length; e++) {
                var r = n[e];
                do r = r(!0); while (r !== null)
            }
            gr = null, Ac = !1
        } catch (i) {
            throw gr !== null && (gr = gr.slice(e + 1)), Tx(Dp, gi), i
        } finally {
            ve = t, Hf = !1
        }
    }
    return null
}
var bs = [],
    Rs = 0,
    Uu = null,
    $u = 0,
    Tn = [],
    En = 0,
    qi = null,
    xr = 1,
    _r = "";

function ki(e, t) {
    bs[Rs++] = $u, bs[Rs++] = Uu, Uu = e, $u = t
}

function e_(e, t, n) {
    Tn[En++] = xr, Tn[En++] = _r, Tn[En++] = qi, qi = e;
    var r = xr;
    e = _r;
    var i = 32 - zn(r) - 1;
    r &= ~(1 << i), n += 1;
    var s = 32 - zn(t) + i;
    if (30 < s) {
        var o = i - i % 5;
        s = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, xr = 1 << 32 - zn(t) + i | n << i | r, _r = s + e
    } else xr = 1 << s | n << i | r, _r = e
}

function Bp(e) {
    e.return !== null && (ki(e, 1), e_(e, 1, 0))
}

function zp(e) {
    for (; e === Uu;) Uu = bs[--Rs], bs[Rs] = null, $u = bs[--Rs], bs[Rs] = null;
    for (; e === qi;) qi = Tn[--En], Tn[En] = null, _r = Tn[--En], Tn[En] = null, xr = Tn[--En], Tn[En] = null
}
var un = null,
    an = null,
    Le = !1,
    Bn = null;

function t_(e, t) {
    var n = kn(5, null, null, 0);
    n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n)
}

function by(e, t) {
    switch (e.tag) {
        case 5:
            var n = e.type;
            return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, un = e, an = ei(t.firstChild), !0) : !1;
        case 6:
            return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, un = e, an = null, !0) : !1;
        case 13:
            return t = t.nodeType !== 8 ? null : t, t !== null ? (n = qi !== null ? {
                id: xr,
                overflow: _r
            } : null, e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824
            }, n = kn(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, un = e, an = null, !0) : !1;
        default:
            return !1
    }
}

function oh(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0
}

function ah(e) {
    if (Le) {
        var t = an;
        if (t) {
            var n = t;
            if (!by(e, t)) {
                if (oh(e)) throw Error(I(418));
                t = ei(n.nextSibling);
                var r = un;
                t && by(e, t) ? t_(r, n) : (e.flags = e.flags & -4097 | 2, Le = !1, un = e)
            }
        } else {
            if (oh(e)) throw Error(I(418));
            e.flags = e.flags & -4097 | 2, Le = !1, un = e
        }
    }
}

function Ry(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
    un = e
}

function $l(e) {
    if (e !== un) return !1;
    if (!Le) return Ry(e), Le = !0, !1;
    var t;
    if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !nh(e.type, e.memoizedProps)), t && (t = an)) {
        if (oh(e)) throw n_(), Error(I(418));
        for (; t;) t_(e, t), t = ei(t.nextSibling)
    }
    if (Ry(e), e.tag === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(I(317));
        e: {
            for (e = e.nextSibling, t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === "/$") {
                        if (t === 0) {
                            an = ei(e.nextSibling);
                            break e
                        }
                        t--
                    } else n !== "$" && n !== "$!" && n !== "$?" || t++
                }
                e = e.nextSibling
            }
            an = null
        }
    } else an = un ? ei(e.stateNode.nextSibling) : null;
    return !0
}

function n_() {
    for (var e = an; e;) e = ei(e.nextSibling)
}

function Zs() {
    an = un = null, Le = !1
}

function Up(e) {
    Bn === null ? Bn = [e] : Bn.push(e)
}
var rk = Lr.ReactCurrentBatchConfig;

function No(e, t, n) {
    if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
        if (n._owner) {
            if (n = n._owner, n) {
                if (n.tag !== 1) throw Error(I(309));
                var r = n.stateNode
            }
            if (!r) throw Error(I(147, e));
            var i = r,
                s = "" + e;
            return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === s ? t.ref : (t = function(o) {
                var a = i.refs;
                o === null ? delete a[s] : a[s] = o
            }, t._stringRef = s, t)
        }
        if (typeof e != "string") throw Error(I(284));
        if (!n._owner) throw Error(I(290, e))
    }
    return e
}

function Wl(e, t) {
    throw e = Object.prototype.toString.call(t), Error(I(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
}

function Ay(e) {
    var t = e._init;
    return t(e._payload)
}

function r_(e) {
    function t(v, y) {
        if (e) {
            var x = v.deletions;
            x === null ? (v.deletions = [y], v.flags |= 16) : x.push(y)
        }
    }

    function n(v, y) {
        if (!e) return null;
        for (; y !== null;) t(v, y), y = y.sibling;
        return null
    }

    function r(v, y) {
        for (v = new Map; y !== null;) y.key !== null ? v.set(y.key, y) : v.set(y.index, y), y = y.sibling;
        return v
    }

    function i(v, y) {
        return v = ii(v, y), v.index = 0, v.sibling = null, v
    }

    function s(v, y, x) {
        return v.index = x, e ? (x = v.alternate, x !== null ? (x = x.index, x < y ? (v.flags |= 2, y) : x) : (v.flags |= 2, y)) : (v.flags |= 1048576, y)
    }

    function o(v) {
        return e && v.alternate === null && (v.flags |= 2), v
    }

    function a(v, y, x, T) {
        return y === null || y.tag !== 6 ? (y = Jf(x, v.mode, T), y.return = v, y) : (y = i(y, x), y.return = v, y)
    }

    function l(v, y, x, T) {
        var E = x.type;
        return E === Ss ? c(v, y, x.props.children, T, x.key) : y !== null && (y.elementType === E || typeof E == "object" && E !== null && E.$$typeof === zr && Ay(E) === y.type) ? (T = i(y, x.props), T.ref = No(v, y, x), T.return = v, T) : (T = gu(x.type, x.key, x.props, null, v.mode, T), T.ref = No(v, y, x), T.return = v, T)
    }

    function u(v, y, x, T) {
        return y === null || y.tag !== 4 || y.stateNode.containerInfo !== x.containerInfo || y.stateNode.implementation !== x.implementation ? (y = Zf(x, v.mode, T), y.return = v, y) : (y = i(y, x.children || []), y.return = v, y)
    }

    function c(v, y, x, T, E) {
        return y === null || y.tag !== 7 ? (y = Ui(x, v.mode, T, E), y.return = v, y) : (y = i(y, x), y.return = v, y)
    }

    function f(v, y, x) {
        if (typeof y == "string" && y !== "" || typeof y == "number") return y = Jf("" + y, v.mode, x), y.return = v, y;
        if (typeof y == "object" && y !== null) {
            switch (y.$$typeof) {
                case Ol:
                    return x = gu(y.type, y.key, y.props, null, v.mode, x), x.ref = No(v, null, y), x.return = v, x;
                case ws:
                    return y = Zf(y, v.mode, x), y.return = v, y;
                case zr:
                    var T = y._init;
                    return f(v, T(y._payload), x)
            }
            if (Yo(y) || Do(y)) return y = Ui(y, v.mode, x, null), y.return = v, y;
            Wl(v, y)
        }
        return null
    }

    function d(v, y, x, T) {
        var E = y !== null ? y.key : null;
        if (typeof x == "string" && x !== "" || typeof x == "number") return E !== null ? null : a(v, y, "" + x, T);
        if (typeof x == "object" && x !== null) {
            switch (x.$$typeof) {
                case Ol:
                    return x.key === E ? l(v, y, x, T) : null;
                case ws:
                    return x.key === E ? u(v, y, x, T) : null;
                case zr:
                    return E = x._init, d(v, y, E(x._payload), T)
            }
            if (Yo(x) || Do(x)) return E !== null ? null : c(v, y, x, T, null);
            Wl(v, x)
        }
        return null
    }

    function p(v, y, x, T, E) {
        if (typeof T == "string" && T !== "" || typeof T == "number") return v = v.get(x) || null, a(y, v, "" + T, E);
        if (typeof T == "object" && T !== null) {
            switch (T.$$typeof) {
                case Ol:
                    return v = v.get(T.key === null ? x : T.key) || null, l(y, v, T, E);
                case ws:
                    return v = v.get(T.key === null ? x : T.key) || null, u(y, v, T, E);
                case zr:
                    var k = T._init;
                    return p(v, y, x, k(T._payload), E)
            }
            if (Yo(T) || Do(T)) return v = v.get(x) || null, c(y, v, T, E, null);
            Wl(y, T)
        }
        return null
    }

    function m(v, y, x, T) {
        for (var E = null, k = null, S = y, P = y = 0, A = null; S !== null && P < x.length; P++) {
            S.index > P ? (A = S, S = null) : A = S.sibling;
            var w = d(v, S, x[P], T);
            if (w === null) {
                S === null && (S = A);
                break
            }
            e && S && w.alternate === null && t(v, S), y = s(w, y, P), k === null ? E = w : k.sibling = w, k = w, S = A
        }
        if (P === x.length) return n(v, S), Le && ki(v, P), E;
        if (S === null) {
            for (; P < x.length; P++) S = f(v, x[P], T), S !== null && (y = s(S, y, P), k === null ? E = S : k.sibling = S, k = S);
            return Le && ki(v, P), E
        }
        for (S = r(v, S); P < x.length; P++) A = p(S, v, P, x[P], T), A !== null && (e && A.alternate !== null && S.delete(A.key === null ? P : A.key), y = s(A, y, P), k === null ? E = A : k.sibling = A, k = A);
        return e && S.forEach(function(O) {
            return t(v, O)
        }), Le && ki(v, P), E
    }

    function h(v, y, x, T) {
        var E = Do(x);
        if (typeof E != "function") throw Error(I(150));
        if (x = E.call(x), x == null) throw Error(I(151));
        for (var k = E = null, S = y, P = y = 0, A = null, w = x.next(); S !== null && !w.done; P++, w = x.next()) {
            S.index > P ? (A = S, S = null) : A = S.sibling;
            var O = d(v, S, w.value, T);
            if (O === null) {
                S === null && (S = A);
                break
            }
            e && S && O.alternate === null && t(v, S), y = s(O, y, P), k === null ? E = O : k.sibling = O, k = O, S = A
        }
        if (w.done) return n(v, S), Le && ki(v, P), E;
        if (S === null) {
            for (; !w.done; P++, w = x.next()) w = f(v, w.value, T), w !== null && (y = s(w, y, P), k === null ? E = w : k.sibling = w, k = w);
            return Le && ki(v, P), E
        }
        for (S = r(v, S); !w.done; P++, w = x.next()) w = p(S, v, P, w.value, T), w !== null && (e && w.alternate !== null && S.delete(w.key === null ? P : w.key), y = s(w, y, P), k === null ? E = w : k.sibling = w, k = w);
        return e && S.forEach(function(F) {
            return t(v, F)
        }), Le && ki(v, P), E
    }

    function _(v, y, x, T) {
        if (typeof x == "object" && x !== null && x.type === Ss && x.key === null && (x = x.props.children), typeof x == "object" && x !== null) {
            switch (x.$$typeof) {
                case Ol:
                    e: {
                        for (var E = x.key, k = y; k !== null;) {
                            if (k.key === E) {
                                if (E = x.type, E === Ss) {
                                    if (k.tag === 7) {
                                        n(v, k.sibling), y = i(k, x.props.children), y.return = v, v = y;
                                        break e
                                    }
                                } else if (k.elementType === E || typeof E == "object" && E !== null && E.$$typeof === zr && Ay(E) === k.type) {
                                    n(v, k.sibling), y = i(k, x.props), y.ref = No(v, k, x), y.return = v, v = y;
                                    break e
                                }
                                n(v, k);
                                break
                            } else t(v, k);
                            k = k.sibling
                        }
                        x.type === Ss ? (y = Ui(x.props.children, v.mode, T, x.key), y.return = v, v = y) : (T = gu(x.type, x.key, x.props, null, v.mode, T), T.ref = No(v, y, x), T.return = v, v = T)
                    }
                    return o(v);
                case ws:
                    e: {
                        for (k = x.key; y !== null;) {
                            if (y.key === k)
                                if (y.tag === 4 && y.stateNode.containerInfo === x.containerInfo && y.stateNode.implementation === x.implementation) {
                                    n(v, y.sibling), y = i(y, x.children || []), y.return = v, v = y;
                                    break e
                                } else {
                                    n(v, y);
                                    break
                                }
                            else t(v, y);
                            y = y.sibling
                        }
                        y = Zf(x, v.mode, T),
                        y.return = v,
                        v = y
                    }
                    return o(v);
                case zr:
                    return k = x._init, _(v, y, k(x._payload), T)
            }
            if (Yo(x)) return m(v, y, x, T);
            if (Do(x)) return h(v, y, x, T);
            Wl(v, x)
        }
        return typeof x == "string" && x !== "" || typeof x == "number" ? (x = "" + x, y !== null && y.tag === 6 ? (n(v, y.sibling), y = i(y, x), y.return = v, v = y) : (n(v, y), y = Jf(x, v.mode, T), y.return = v, v = y), o(v)) : n(v, y)
    }
    return _
}
var eo = r_(!0),
    i_ = r_(!1),
    Wu = mi(null),
    Hu = null,
    As = null,
    $p = null;

function Wp() {
    $p = As = Hu = null
}

function Hp(e) {
    var t = Wu.current;
    Ae(Wu), e._currentValue = t
}

function lh(e, t, n) {
    for (; e !== null;) {
        var r = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
        e = e.return
    }
}

function Ws(e, t) {
    Hu = e, $p = As = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && ($t = !0), e.firstContext = null)
}

function An(e) {
    var t = e._currentValue;
    if ($p !== e)
        if (e = {
                context: e,
                memoizedValue: t,
                next: null
            }, As === null) {
            if (Hu === null) throw Error(I(308));
            As = e, Hu.dependencies = {
                lanes: 0,
                firstContext: e
            }
        } else As = As.next = e;
    return t
}
var Mi = null;

function Kp(e) {
    Mi === null ? Mi = [e] : Mi.push(e)
}

function s_(e, t, n, r) {
    var i = t.interleaved;
    return i === null ? (n.next = n, Kp(t)) : (n.next = i.next, i.next = n), t.interleaved = n, kr(e, r)
}

function kr(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
    return n.tag === 3 ? n.stateNode : null
}
var Ur = !1;

function Gp(e) {
    e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
            pending: null,
            interleaved: null,
            lanes: 0
        },
        effects: null
    }
}

function o_(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects
    })
}

function wr(e, t) {
    return {
        eventTime: e,
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
    }
}

function ti(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (r = r.shared, fe & 2) {
        var i = r.pending;
        return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, kr(e, n)
    }
    return i = r.interleaved, i === null ? (t.next = t, Kp(r)) : (t.next = i.next, i.next = t), r.interleaved = t, kr(e, n)
}

function cu(e, t, n) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, jp(e, n)
    }
}

function Dy(e, t) {
    var n = e.updateQueue,
        r = e.alternate;
    if (r !== null && (r = r.updateQueue, n === r)) {
        var i = null,
            s = null;
        if (n = n.firstBaseUpdate, n !== null) {
            do {
                var o = {
                    eventTime: n.eventTime,
                    lane: n.lane,
                    tag: n.tag,
                    payload: n.payload,
                    callback: n.callback,
                    next: null
                };
                s === null ? i = s = o : s = s.next = o, n = n.next
            } while (n !== null);
            s === null ? i = s = t : s = s.next = t
        } else i = s = t;
        n = {
            baseState: r.baseState,
            firstBaseUpdate: i,
            lastBaseUpdate: s,
            shared: r.shared,
            effects: r.effects
        }, e.updateQueue = n;
        return
    }
    e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
}

function Ku(e, t, n, r) {
    var i = e.updateQueue;
    Ur = !1;
    var s = i.firstBaseUpdate,
        o = i.lastBaseUpdate,
        a = i.shared.pending;
    if (a !== null) {
        i.shared.pending = null;
        var l = a,
            u = l.next;
        l.next = null, o === null ? s = u : o.next = u, o = l;
        var c = e.alternate;
        c !== null && (c = c.updateQueue, a = c.lastBaseUpdate, a !== o && (a === null ? c.firstBaseUpdate = u : a.next = u, c.lastBaseUpdate = l))
    }
    if (s !== null) {
        var f = i.baseState;
        o = 0, c = u = l = null, a = s;
        do {
            var d = a.lane,
                p = a.eventTime;
            if ((r & d) === d) {
                c !== null && (c = c.next = {
                    eventTime: p,
                    lane: 0,
                    tag: a.tag,
                    payload: a.payload,
                    callback: a.callback,
                    next: null
                });
                e: {
                    var m = e,
                        h = a;
                    switch (d = t, p = n, h.tag) {
                        case 1:
                            if (m = h.payload, typeof m == "function") {
                                f = m.call(p, f, d);
                                break e
                            }
                            f = m;
                            break e;
                        case 3:
                            m.flags = m.flags & -65537 | 128;
                        case 0:
                            if (m = h.payload, d = typeof m == "function" ? m.call(p, f, d) : m, d == null) break e;
                            f = Ue({}, f, d);
                            break e;
                        case 2:
                            Ur = !0
                    }
                }
                a.callback !== null && a.lane !== 0 && (e.flags |= 64, d = i.effects, d === null ? i.effects = [a] : d.push(a))
            } else p = {
                eventTime: p,
                lane: d,
                tag: a.tag,
                payload: a.payload,
                callback: a.callback,
                next: null
            }, c === null ? (u = c = p, l = f) : c = c.next = p, o |= d;
            if (a = a.next, a === null) {
                if (a = i.shared.pending, a === null) break;
                d = a, a = d.next, d.next = null, i.lastBaseUpdate = d, i.shared.pending = null
            }
        } while (!0);
        if (c === null && (l = f), i.baseState = l, i.firstBaseUpdate = u, i.lastBaseUpdate = c, t = i.shared.interleaved, t !== null) {
            i = t;
            do o |= i.lane, i = i.next; while (i !== t)
        } else s === null && (i.shared.lanes = 0);
        Ji |= o, e.lanes = o, e.memoizedState = f
    }
}

function jy(e, t, n) {
    if (e = t.effects, t.effects = null, e !== null)
        for (t = 0; t < e.length; t++) {
            var r = e[t],
                i = r.callback;
            if (i !== null) {
                if (r.callback = null, r = n, typeof i != "function") throw Error(I(191, i));
                i.call(r)
            }
        }
}
var cl = {},
    ir = mi(cl),
    Oa = mi(cl),
    La = mi(cl);

function Ni(e) {
    if (e === cl) throw Error(I(174));
    return e
}

function Yp(e, t) {
    switch (Ee(La, t), Ee(Oa, e), Ee(ir, cl), e = t.nodeType, e) {
        case 9:
        case 11:
            t = (t = t.documentElement) ? t.namespaceURI : Ud(null, "");
            break;
        default:
            e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = Ud(t, e)
    }
    Ae(ir), Ee(ir, t)
}

function to() {
    Ae(ir), Ae(Oa), Ae(La)
}

function a_(e) {
    Ni(La.current);
    var t = Ni(ir.current),
        n = Ud(t, e.type);
    t !== n && (Ee(Oa, e), Ee(ir, n))
}

function Xp(e) {
    Oa.current === e && (Ae(ir), Ae(Oa))
}
var Fe = mi(0);

function Gu(e) {
    for (var t = e; t !== null;) {
        if (t.tag === 13) {
            var n = t.memoizedState;
            if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
            if (t.flags & 128) return t
        } else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue
        }
        if (t === e) break;
        for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return null;
            t = t.return
        }
        t.sibling.return = t.return, t = t.sibling
    }
    return null
}
var Kf = [];

function qp() {
    for (var e = 0; e < Kf.length; e++) Kf[e]._workInProgressVersionPrimary = null;
    Kf.length = 0
}
var fu = Lr.ReactCurrentDispatcher,
    Gf = Lr.ReactCurrentBatchConfig,
    Qi = 0,
    ze = null,
    lt = null,
    dt = null,
    Yu = !1,
    ca = !1,
    Ma = 0,
    ik = 0;

function Ct() {
    throw Error(I(321))
}

function Qp(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
        if (!$n(e[n], t[n])) return !1;
    return !0
}

function Jp(e, t, n, r, i, s) {
    if (Qi = s, ze = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, fu.current = e === null || e.memoizedState === null ? lk : uk, e = n(r, i), ca) {
        s = 0;
        do {
            if (ca = !1, Ma = 0, 25 <= s) throw Error(I(301));
            s += 1, dt = lt = null, t.updateQueue = null, fu.current = ck, e = n(r, i)
        } while (ca)
    }
    if (fu.current = Xu, t = lt !== null && lt.next !== null, Qi = 0, dt = lt = ze = null, Yu = !1, t) throw Error(I(300));
    return e
}

function Zp() {
    var e = Ma !== 0;
    return Ma = 0, e
}

function qn() {
    var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
    };
    return dt === null ? ze.memoizedState = dt = e : dt = dt.next = e, dt
}

function Dn() {
    if (lt === null) {
        var e = ze.alternate;
        e = e !== null ? e.memoizedState : null
    } else e = lt.next;
    var t = dt === null ? ze.memoizedState : dt.next;
    if (t !== null) dt = t, lt = e;
    else {
        if (e === null) throw Error(I(310));
        lt = e, e = {
            memoizedState: lt.memoizedState,
            baseState: lt.baseState,
            baseQueue: lt.baseQueue,
            queue: lt.queue,
            next: null
        }, dt === null ? ze.memoizedState = dt = e : dt = dt.next = e
    }
    return dt
}

function Na(e, t) {
    return typeof t == "function" ? t(e) : t
}

function Yf(e) {
    var t = Dn(),
        n = t.queue;
    if (n === null) throw Error(I(311));
    n.lastRenderedReducer = e;
    var r = lt,
        i = r.baseQueue,
        s = n.pending;
    if (s !== null) {
        if (i !== null) {
            var o = i.next;
            i.next = s.next, s.next = o
        }
        r.baseQueue = i = s, n.pending = null
    }
    if (i !== null) {
        s = i.next, r = r.baseState;
        var a = o = null,
            l = null,
            u = s;
        do {
            var c = u.lane;
            if ((Qi & c) === c) l !== null && (l = l.next = {
                lane: 0,
                action: u.action,
                hasEagerState: u.hasEagerState,
                eagerState: u.eagerState,
                next: null
            }), r = u.hasEagerState ? u.eagerState : e(r, u.action);
            else {
                var f = {
                    lane: c,
                    action: u.action,
                    hasEagerState: u.hasEagerState,
                    eagerState: u.eagerState,
                    next: null
                };
                l === null ? (a = l = f, o = r) : l = l.next = f, ze.lanes |= c, Ji |= c
            }
            u = u.next
        } while (u !== null && u !== s);
        l === null ? o = r : l.next = a, $n(r, t.memoizedState) || ($t = !0), t.memoizedState = r, t.baseState = o, t.baseQueue = l, n.lastRenderedState = r
    }
    if (e = n.interleaved, e !== null) {
        i = e;
        do s = i.lane, ze.lanes |= s, Ji |= s, i = i.next; while (i !== e)
    } else i === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch]
}

function Xf(e) {
    var t = Dn(),
        n = t.queue;
    if (n === null) throw Error(I(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
        i = n.pending,
        s = t.memoizedState;
    if (i !== null) {
        n.pending = null;
        var o = i = i.next;
        do s = e(s, o.action), o = o.next; while (o !== i);
        $n(s, t.memoizedState) || ($t = !0), t.memoizedState = s, t.baseQueue === null && (t.baseState = s), n.lastRenderedState = s
    }
    return [s, r]
}

function l_() {}

function u_(e, t) {
    var n = ze,
        r = Dn(),
        i = t(),
        s = !$n(r.memoizedState, i);
    if (s && (r.memoizedState = i, $t = !0), r = r.queue, em(d_.bind(null, n, r, e), [e]), r.getSnapshot !== t || s || dt !== null && dt.memoizedState.tag & 1) {
        if (n.flags |= 2048, Fa(9, f_.bind(null, n, r, i, t), void 0, null), ht === null) throw Error(I(349));
        Qi & 30 || c_(n, t, i)
    }
    return i
}

function c_(e, t, n) {
    e.flags |= 16384, e = {
        getSnapshot: t,
        value: n
    }, t = ze.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, ze.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
}

function f_(e, t, n, r) {
    t.value = n, t.getSnapshot = r, h_(t) && p_(e)
}

function d_(e, t, n) {
    return n(function() {
        h_(t) && p_(e)
    })
}

function h_(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
        var n = t();
        return !$n(e, n)
    } catch {
        return !0
    }
}

function p_(e) {
    var t = kr(e, 1);
    t !== null && Un(t, e, 1, -1)
}

function Oy(e) {
    var t = qn();
    return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Na,
        lastRenderedState: e
    }, t.queue = e, e = e.dispatch = ak.bind(null, ze, e), [t.memoizedState, e]
}

function Fa(e, t, n, r) {
    return e = {
        tag: e,
        create: t,
        destroy: n,
        deps: r,
        next: null
    }, t = ze.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, ze.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e
}

function m_() {
    return Dn().memoizedState
}

function du(e, t, n, r) {
    var i = qn();
    ze.flags |= e, i.memoizedState = Fa(1 | t, n, void 0, r === void 0 ? null : r)
}

function Dc(e, t, n, r) {
    var i = Dn();
    r = r === void 0 ? null : r;
    var s = void 0;
    if (lt !== null) {
        var o = lt.memoizedState;
        if (s = o.destroy, r !== null && Qp(r, o.deps)) {
            i.memoizedState = Fa(t, n, s, r);
            return
        }
    }
    ze.flags |= e, i.memoizedState = Fa(1 | t, n, s, r)
}

function Ly(e, t) {
    return du(8390656, 8, e, t)
}

function em(e, t) {
    return Dc(2048, 8, e, t)
}

function g_(e, t) {
    return Dc(4, 2, e, t)
}

function y_(e, t) {
    return Dc(4, 4, e, t)
}

function v_(e, t) {
    if (typeof t == "function") return e = e(), t(e),
        function() {
            t(null)
        };
    if (t != null) return e = e(), t.current = e,
        function() {
            t.current = null
        }
}

function x_(e, t, n) {
    return n = n != null ? n.concat([e]) : null, Dc(4, 4, v_.bind(null, t, e), n)
}

function tm() {}

function __(e, t) {
    var n = Dn();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Qp(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
}

function w_(e, t) {
    var n = Dn();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && Qp(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
}

function S_(e, t, n) {
    return Qi & 21 ? ($n(n, t) || (n = kx(), ze.lanes |= n, Ji |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, $t = !0), e.memoizedState = n)
}

function sk(e, t) {
    var n = ve;
    ve = n !== 0 && 4 > n ? n : 4, e(!0);
    var r = Gf.transition;
    Gf.transition = {};
    try {
        e(!1), t()
    } finally {
        ve = n, Gf.transition = r
    }
}

function C_() {
    return Dn().memoizedState
}

function ok(e, t, n) {
    var r = ri(e);
    if (n = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, T_(e)) E_(t, n);
    else if (n = s_(e, t, n, r), n !== null) {
        var i = It();
        Un(n, e, r, i), P_(n, t, r)
    }
}

function ak(e, t, n) {
    var r = ri(e),
        i = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
    if (T_(e)) E_(t, i);
    else {
        var s = e.alternate;
        if (e.lanes === 0 && (s === null || s.lanes === 0) && (s = t.lastRenderedReducer, s !== null)) try {
            var o = t.lastRenderedState,
                a = s(o, n);
            if (i.hasEagerState = !0, i.eagerState = a, $n(a, o)) {
                var l = t.interleaved;
                l === null ? (i.next = i, Kp(t)) : (i.next = l.next, l.next = i), t.interleaved = i;
                return
            }
        } catch {} finally {}
        n = s_(e, t, i, r), n !== null && (i = It(), Un(n, e, r, i), P_(n, t, r))
    }
}

function T_(e) {
    var t = e.alternate;
    return e === ze || t !== null && t === ze
}

function E_(e, t) {
    ca = Yu = !0;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
}

function P_(e, t, n) {
    if (n & 4194240) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, jp(e, n)
    }
}
var Xu = {
        readContext: An,
        useCallback: Ct,
        useContext: Ct,
        useEffect: Ct,
        useImperativeHandle: Ct,
        useInsertionEffect: Ct,
        useLayoutEffect: Ct,
        useMemo: Ct,
        useReducer: Ct,
        useRef: Ct,
        useState: Ct,
        useDebugValue: Ct,
        useDeferredValue: Ct,
        useTransition: Ct,
        useMutableSource: Ct,
        useSyncExternalStore: Ct,
        useId: Ct,
        unstable_isNewReconciler: !1
    },
    lk = {
        readContext: An,
        useCallback: function(e, t) {
            return qn().memoizedState = [e, t === void 0 ? null : t], e
        },
        useContext: An,
        useEffect: Ly,
        useImperativeHandle: function(e, t, n) {
            return n = n != null ? n.concat([e]) : null, du(4194308, 4, v_.bind(null, t, e), n)
        },
        useLayoutEffect: function(e, t) {
            return du(4194308, 4, e, t)
        },
        useInsertionEffect: function(e, t) {
            return du(4, 2, e, t)
        },
        useMemo: function(e, t) {
            var n = qn();
            return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e
        },
        useReducer: function(e, t, n) {
            var r = qn();
            return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                pending: null,
                interleaved: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: e,
                lastRenderedState: t
            }, r.queue = e, e = e.dispatch = ok.bind(null, ze, e), [r.memoizedState, e]
        },
        useRef: function(e) {
            var t = qn();
            return e = {
                current: e
            }, t.memoizedState = e
        },
        useState: Oy,
        useDebugValue: tm,
        useDeferredValue: function(e) {
            return qn().memoizedState = e
        },
        useTransition: function() {
            var e = Oy(!1),
                t = e[0];
            return e = sk.bind(null, e[1]), qn().memoizedState = e, [t, e]
        },
        useMutableSource: function() {},
        useSyncExternalStore: function(e, t, n) {
            var r = ze,
                i = qn();
            if (Le) {
                if (n === void 0) throw Error(I(407));
                n = n()
            } else {
                if (n = t(), ht === null) throw Error(I(349));
                Qi & 30 || c_(r, t, n)
            }
            i.memoizedState = n;
            var s = {
                value: n,
                getSnapshot: t
            };
            return i.queue = s, Ly(d_.bind(null, r, s, e), [e]), r.flags |= 2048, Fa(9, f_.bind(null, r, s, n, t), void 0, null), n
        },
        useId: function() {
            var e = qn(),
                t = ht.identifierPrefix;
            if (Le) {
                var n = _r,
                    r = xr;
                n = (r & ~(1 << 32 - zn(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = Ma++, 0 < n && (t += "H" + n.toString(32)), t += ":"
            } else n = ik++, t = ":" + t + "r" + n.toString(32) + ":";
            return e.memoizedState = t
        },
        unstable_isNewReconciler: !1
    },
    uk = {
        readContext: An,
        useCallback: __,
        useContext: An,
        useEffect: em,
        useImperativeHandle: x_,
        useInsertionEffect: g_,
        useLayoutEffect: y_,
        useMemo: w_,
        useReducer: Yf,
        useRef: m_,
        useState: function() {
            return Yf(Na)
        },
        useDebugValue: tm,
        useDeferredValue: function(e) {
            var t = Dn();
            return S_(t, lt.memoizedState, e)
        },
        useTransition: function() {
            var e = Yf(Na)[0],
                t = Dn().memoizedState;
            return [e, t]
        },
        useMutableSource: l_,
        useSyncExternalStore: u_,
        useId: C_,
        unstable_isNewReconciler: !1
    },
    ck = {
        readContext: An,
        useCallback: __,
        useContext: An,
        useEffect: em,
        useImperativeHandle: x_,
        useInsertionEffect: g_,
        useLayoutEffect: y_,
        useMemo: w_,
        useReducer: Xf,
        useRef: m_,
        useState: function() {
            return Xf(Na)
        },
        useDebugValue: tm,
        useDeferredValue: function(e) {
            var t = Dn();
            return lt === null ? t.memoizedState = e : S_(t, lt.memoizedState, e)
        },
        useTransition: function() {
            var e = Xf(Na)[0],
                t = Dn().memoizedState;
            return [e, t]
        },
        useMutableSource: l_,
        useSyncExternalStore: u_,
        useId: C_,
        unstable_isNewReconciler: !1
    };

function Fn(e, t) {
    if (e && e.defaultProps) {
        t = Ue({}, t), e = e.defaultProps;
        for (var n in e) t[n] === void 0 && (t[n] = e[n]);
        return t
    }
    return t
}

function uh(e, t, n, r) {
    t = e.memoizedState, n = n(r, t), n = n == null ? t : Ue({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
}
var jc = {
    isMounted: function(e) {
        return (e = e._reactInternals) ? ss(e) === e : !1
    },
    enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = It(),
            i = ri(e),
            s = wr(r, i);
        s.payload = t, n != null && (s.callback = n), t = ti(e, s, i), t !== null && (Un(t, e, i, r), cu(t, e, i))
    },
    enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = It(),
            i = ri(e),
            s = wr(r, i);
        s.tag = 1, s.payload = t, n != null && (s.callback = n), t = ti(e, s, i), t !== null && (Un(t, e, i, r), cu(t, e, i))
    },
    enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = It(),
            r = ri(e),
            i = wr(n, r);
        i.tag = 2, t != null && (i.callback = t), t = ti(e, i, r), t !== null && (Un(t, e, r, n), cu(t, e, r))
    }
};

function My(e, t, n, r, i, s, o) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, s, o) : t.prototype && t.prototype.isPureReactComponent ? !Ra(n, r) || !Ra(i, s) : !0
}

function k_(e, t, n) {
    var r = !1,
        i = li,
        s = t.contextType;
    return typeof s == "object" && s !== null ? s = An(s) : (i = Ht(t) ? Xi : Ot.current, r = t.contextTypes, s = (r = r != null) ? Js(e, i) : li), t = new t(n, s), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = jc, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = i, e.__reactInternalMemoizedMaskedChildContext = s), t
}

function Ny(e, t, n, r) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && jc.enqueueReplaceState(t, t.state, null)
}

function ch(e, t, n, r) {
    var i = e.stateNode;
    i.props = n, i.state = e.memoizedState, i.refs = {}, Gp(e);
    var s = t.contextType;
    typeof s == "object" && s !== null ? i.context = An(s) : (s = Ht(t) ? Xi : Ot.current, i.context = Js(e, s)), i.state = e.memoizedState, s = t.getDerivedStateFromProps, typeof s == "function" && (uh(e, t, s, n), i.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof i.getSnapshotBeforeUpdate == "function" || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (t = i.state, typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount(), t !== i.state && jc.enqueueReplaceState(i, i.state, null), Ku(e, n, i, r), i.state = e.memoizedState), typeof i.componentDidMount == "function" && (e.flags |= 4194308)
}

function no(e, t) {
    try {
        var n = "",
            r = t;
        do n += IE(r), r = r.return; while (r);
        var i = n
    } catch (s) {
        i = `
Error generating stack: ` + s.message + `
` + s.stack
    }
    return {
        value: e,
        source: t,
        stack: i,
        digest: null
    }
}

function qf(e, t, n) {
    return {
        value: e,
        source: null,
        stack: n ? ? null,
        digest: t ? ? null
    }
}

function fh(e, t) {
    try {
        console.error(t.value)
    } catch (n) {
        setTimeout(function() {
            throw n
        })
    }
}
var fk = typeof WeakMap == "function" ? WeakMap : Map;

function b_(e, t, n) {
    n = wr(-1, n), n.tag = 3, n.payload = {
        element: null
    };
    var r = t.value;
    return n.callback = function() {
        Qu || (Qu = !0, wh = r), fh(e, t)
    }, n
}

function R_(e, t, n) {
    n = wr(-1, n), n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
        var i = t.value;
        n.payload = function() {
            return r(i)
        }, n.callback = function() {
            fh(e, t)
        }
    }
    var s = e.stateNode;
    return s !== null && typeof s.componentDidCatch == "function" && (n.callback = function() {
        fh(e, t), typeof r != "function" && (ni === null ? ni = new Set([this]) : ni.add(this));
        var o = t.stack;
        this.componentDidCatch(t.value, {
            componentStack: o !== null ? o : ""
        })
    }), n
}

function Fy(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
        r = e.pingCache = new fk;
        var i = new Set;
        r.set(t, i)
    } else i = r.get(t), i === void 0 && (i = new Set, r.set(t, i));
    i.has(n) || (i.add(n), e = Ek.bind(null, e, t, n), t.then(e, e))
}

function Iy(e) {
    do {
        var t;
        if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
        e = e.return
    } while (e !== null);
    return null
}

function Vy(e, t, n, r, i) {
    return e.mode & 1 ? (e.flags |= 65536, e.lanes = i, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = wr(-1, 1), t.tag = 2, ti(n, t, 1))), n.lanes |= 1), e)
}
var dk = Lr.ReactCurrentOwner,
    $t = !1;

function Mt(e, t, n, r) {
    t.child = e === null ? i_(t, null, n, r) : eo(t, e.child, n, r)
}

function By(e, t, n, r, i) {
    n = n.render;
    var s = t.ref;
    return Ws(t, i), r = Jp(e, t, n, r, s, i), n = Zp(), e !== null && !$t ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, br(e, t, i)) : (Le && n && Bp(t), t.flags |= 1, Mt(e, t, r, i), t.child)
}

function zy(e, t, n, r, i) {
    if (e === null) {
        var s = n.type;
        return typeof s == "function" && !um(s) && s.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = s, A_(e, t, s, r, i)) : (e = gu(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e)
    }
    if (s = e.child, !(e.lanes & i)) {
        var o = s.memoizedProps;
        if (n = n.compare, n = n !== null ? n : Ra, n(o, r) && e.ref === t.ref) return br(e, t, i)
    }
    return t.flags |= 1, e = ii(s, r), e.ref = t.ref, e.return = t, t.child = e
}

function A_(e, t, n, r, i) {
    if (e !== null) {
        var s = e.memoizedProps;
        if (Ra(s, r) && e.ref === t.ref)
            if ($t = !1, t.pendingProps = r = s, (e.lanes & i) !== 0) e.flags & 131072 && ($t = !0);
            else return t.lanes = e.lanes, br(e, t, i)
    }
    return dh(e, t, n, r, i)
}

function D_(e, t, n) {
    var r = t.pendingProps,
        i = r.children,
        s = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
        if (!(t.mode & 1)) t.memoizedState = {
            baseLanes: 0,
            cachePool: null,
            transitions: null
        }, Ee(js, tn), tn |= n;
        else {
            if (!(n & 1073741824)) return e = s !== null ? s.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                baseLanes: e,
                cachePool: null,
                transitions: null
            }, t.updateQueue = null, Ee(js, tn), tn |= e, null;
            t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            }, r = s !== null ? s.baseLanes : n, Ee(js, tn), tn |= r
        }
    else s !== null ? (r = s.baseLanes | n, t.memoizedState = null) : r = n, Ee(js, tn), tn |= r;
    return Mt(e, t, i, n), t.child
}

function j_(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
}

function dh(e, t, n, r, i) {
    var s = Ht(n) ? Xi : Ot.current;
    return s = Js(t, s), Ws(t, i), n = Jp(e, t, n, r, s, i), r = Zp(), e !== null && !$t ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, br(e, t, i)) : (Le && r && Bp(t), t.flags |= 1, Mt(e, t, n, i), t.child)
}

function Uy(e, t, n, r, i) {
    if (Ht(n)) {
        var s = !0;
        zu(t)
    } else s = !1;
    if (Ws(t, i), t.stateNode === null) hu(e, t), k_(t, n, r), ch(t, n, r, i), r = !0;
    else if (e === null) {
        var o = t.stateNode,
            a = t.memoizedProps;
        o.props = a;
        var l = o.context,
            u = n.contextType;
        typeof u == "object" && u !== null ? u = An(u) : (u = Ht(n) ? Xi : Ot.current, u = Js(t, u));
        var c = n.getDerivedStateFromProps,
            f = typeof c == "function" || typeof o.getSnapshotBeforeUpdate == "function";
        f || typeof o.UNSAFE_componentWillReceiveProps != "function" && typeof o.componentWillReceiveProps != "function" || (a !== r || l !== u) && Ny(t, o, r, u), Ur = !1;
        var d = t.memoizedState;
        o.state = d, Ku(t, r, o, i), l = t.memoizedState, a !== r || d !== l || Wt.current || Ur ? (typeof c == "function" && (uh(t, n, c, r), l = t.memoizedState), (a = Ur || My(t, n, a, r, d, l, u)) ? (f || typeof o.UNSAFE_componentWillMount != "function" && typeof o.componentWillMount != "function" || (typeof o.componentWillMount == "function" && o.componentWillMount(), typeof o.UNSAFE_componentWillMount == "function" && o.UNSAFE_componentWillMount()), typeof o.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof o.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = l), o.props = r, o.state = l, o.context = u, r = a) : (typeof o.componentDidMount == "function" && (t.flags |= 4194308), r = !1)
    } else {
        o = t.stateNode, o_(e, t), a = t.memoizedProps, u = t.type === t.elementType ? a : Fn(t.type, a), o.props = u, f = t.pendingProps, d = o.context, l = n.contextType, typeof l == "object" && l !== null ? l = An(l) : (l = Ht(n) ? Xi : Ot.current, l = Js(t, l));
        var p = n.getDerivedStateFromProps;
        (c = typeof p == "function" || typeof o.getSnapshotBeforeUpdate == "function") || typeof o.UNSAFE_componentWillReceiveProps != "function" && typeof o.componentWillReceiveProps != "function" || (a !== f || d !== l) && Ny(t, o, r, l), Ur = !1, d = t.memoizedState, o.state = d, Ku(t, r, o, i);
        var m = t.memoizedState;
        a !== f || d !== m || Wt.current || Ur ? (typeof p == "function" && (uh(t, n, p, r), m = t.memoizedState), (u = Ur || My(t, n, u, r, d, m, l) || !1) ? (c || typeof o.UNSAFE_componentWillUpdate != "function" && typeof o.componentWillUpdate != "function" || (typeof o.componentWillUpdate == "function" && o.componentWillUpdate(r, m, l), typeof o.UNSAFE_componentWillUpdate == "function" && o.UNSAFE_componentWillUpdate(r, m, l)), typeof o.componentDidUpdate == "function" && (t.flags |= 4), typeof o.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof o.componentDidUpdate != "function" || a === e.memoizedProps && d === e.memoizedState || (t.flags |= 4), typeof o.getSnapshotBeforeUpdate != "function" || a === e.memoizedProps && d === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = m), o.props = r, o.state = m, o.context = l, r = u) : (typeof o.componentDidUpdate != "function" || a === e.memoizedProps && d === e.memoizedState || (t.flags |= 4), typeof o.getSnapshotBeforeUpdate != "function" || a === e.memoizedProps && d === e.memoizedState || (t.flags |= 1024), r = !1)
    }
    return hh(e, t, n, r, s, i)
}

function hh(e, t, n, r, i, s) {
    j_(e, t);
    var o = (t.flags & 128) !== 0;
    if (!r && !o) return i && ky(t, n, !1), br(e, t, s);
    r = t.stateNode, dk.current = t;
    var a = o && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1, e !== null && o ? (t.child = eo(t, e.child, null, s), t.child = eo(t, null, a, s)) : Mt(e, t, a, s), t.memoizedState = r.state, i && ky(t, n, !0), t.child
}

function O_(e) {
    var t = e.stateNode;
    t.pendingContext ? Py(e, t.pendingContext, t.pendingContext !== t.context) : t.context && Py(e, t.context, !1), Yp(e, t.containerInfo)
}

function $y(e, t, n, r, i) {
    return Zs(), Up(i), t.flags |= 256, Mt(e, t, n, r), t.child
}
var ph = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0
};

function mh(e) {
    return {
        baseLanes: e,
        cachePool: null,
        transitions: null
    }
}

function L_(e, t, n) {
    var r = t.pendingProps,
        i = Fe.current,
        s = !1,
        o = (t.flags & 128) !== 0,
        a;
    if ((a = o) || (a = e !== null && e.memoizedState === null ? !1 : (i & 2) !== 0), a ? (s = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (i |= 1), Ee(Fe, i & 1), e === null) return ah(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (o = r.children, e = r.fallback, s ? (r = t.mode, s = t.child, o = {
        mode: "hidden",
        children: o
    }, !(r & 1) && s !== null ? (s.childLanes = 0, s.pendingProps = o) : s = Mc(o, r, 0, null), e = Ui(e, r, n, null), s.return = t, e.return = t, s.sibling = e, t.child = s, t.child.memoizedState = mh(n), t.memoizedState = ph, e) : nm(t, o));
    if (i = e.memoizedState, i !== null && (a = i.dehydrated, a !== null)) return hk(e, t, o, r, a, i, n);
    if (s) {
        s = r.fallback, o = t.mode, i = e.child, a = i.sibling;
        var l = {
            mode: "hidden",
            children: r.children
        };
        return !(o & 1) && t.child !== i ? (r = t.child, r.childLanes = 0, r.pendingProps = l, t.deletions = null) : (r = ii(i, l), r.subtreeFlags = i.subtreeFlags & 14680064), a !== null ? s = ii(a, s) : (s = Ui(s, o, n, null), s.flags |= 2), s.return = t, r.return = t, r.sibling = s, t.child = r, r = s, s = t.child, o = e.child.memoizedState, o = o === null ? mh(n) : {
            baseLanes: o.baseLanes | n,
            cachePool: null,
            transitions: o.transitions
        }, s.memoizedState = o, s.childLanes = e.childLanes & ~n, t.memoizedState = ph, r
    }
    return s = e.child, e = s.sibling, r = ii(s, {
        mode: "visible",
        children: r.children
    }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r
}

function nm(e, t) {
    return t = Mc({
        mode: "visible",
        children: t
    }, e.mode, 0, null), t.return = e, e.child = t
}

function Hl(e, t, n, r) {
    return r !== null && Up(r), eo(t, e.child, null, n), e = nm(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
}

function hk(e, t, n, r, i, s, o) {
    if (n) return t.flags & 256 ? (t.flags &= -257, r = qf(Error(I(422))), Hl(e, t, o, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (s = r.fallback, i = t.mode, r = Mc({
        mode: "visible",
        children: r.children
    }, i, 0, null), s = Ui(s, i, o, null), s.flags |= 2, r.return = t, s.return = t, r.sibling = s, t.child = r, t.mode & 1 && eo(t, e.child, null, o), t.child.memoizedState = mh(o), t.memoizedState = ph, s);
    if (!(t.mode & 1)) return Hl(e, t, o, null);
    if (i.data === "$!") {
        if (r = i.nextSibling && i.nextSibling.dataset, r) var a = r.dgst;
        return r = a, s = Error(I(419)), r = qf(s, r, void 0), Hl(e, t, o, r)
    }
    if (a = (o & e.childLanes) !== 0, $t || a) {
        if (r = ht, r !== null) {
            switch (o & -o) {
                case 4:
                    i = 2;
                    break;
                case 16:
                    i = 8;
                    break;
                case 64:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                case 67108864:
                    i = 32;
                    break;
                case 536870912:
                    i = 268435456;
                    break;
                default:
                    i = 0
            }
            i = i & (r.suspendedLanes | o) ? 0 : i, i !== 0 && i !== s.retryLane && (s.retryLane = i, kr(e, i), Un(r, e, i, -1))
        }
        return lm(), r = qf(Error(I(421))), Hl(e, t, o, r)
    }
    return i.data === "$?" ? (t.flags |= 128, t.child = e.child, t = Pk.bind(null, e), i._reactRetry = t, null) : (e = s.treeContext, an = ei(i.nextSibling), un = t, Le = !0, Bn = null, e !== null && (Tn[En++] = xr, Tn[En++] = _r, Tn[En++] = qi, xr = e.id, _r = e.overflow, qi = t), t = nm(t, r.children), t.flags |= 4096, t)
}

function Wy(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    r !== null && (r.lanes |= t), lh(e.return, t, n)
}

function Qf(e, t, n, r, i) {
    var s = e.memoizedState;
    s === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: i
    } : (s.isBackwards = t, s.rendering = null, s.renderingStartTime = 0, s.last = r, s.tail = n, s.tailMode = i)
}

function M_(e, t, n) {
    var r = t.pendingProps,
        i = r.revealOrder,
        s = r.tail;
    if (Mt(e, t, r.children, n), r = Fe.current, r & 2) r = r & 1 | 2, t.flags |= 128;
    else {
        if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
            if (e.tag === 13) e.memoizedState !== null && Wy(e, n, t);
            else if (e.tag === 19) Wy(e, n, t);
            else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break e;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) break e;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        r &= 1
    }
    if (Ee(Fe, r), !(t.mode & 1)) t.memoizedState = null;
    else switch (i) {
        case "forwards":
            for (n = t.child, i = null; n !== null;) e = n.alternate, e !== null && Gu(e) === null && (i = n), n = n.sibling;
            n = i, n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), Qf(t, !1, i, n, s);
            break;
        case "backwards":
            for (n = null, i = t.child, t.child = null; i !== null;) {
                if (e = i.alternate, e !== null && Gu(e) === null) {
                    t.child = i;
                    break
                }
                e = i.sibling, i.sibling = n, n = i, i = e
            }
            Qf(t, !0, n, null, s);
            break;
        case "together":
            Qf(t, !1, null, null, void 0);
            break;
        default:
            t.memoizedState = null
    }
    return t.child
}

function hu(e, t) {
    !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2)
}

function br(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies), Ji |= t.lanes, !(n & t.childLanes)) return null;
    if (e !== null && t.child !== e.child) throw Error(I(153));
    if (t.child !== null) {
        for (e = t.child, n = ii(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = ii(e, e.pendingProps), n.return = t;
        n.sibling = null
    }
    return t.child
}

function pk(e, t, n) {
    switch (t.tag) {
        case 3:
            O_(t), Zs();
            break;
        case 5:
            a_(t);
            break;
        case 1:
            Ht(t.type) && zu(t);
            break;
        case 4:
            Yp(t, t.stateNode.containerInfo);
            break;
        case 10:
            var r = t.type._context,
                i = t.memoizedProps.value;
            Ee(Wu, r._currentValue), r._currentValue = i;
            break;
        case 13:
            if (r = t.memoizedState, r !== null) return r.dehydrated !== null ? (Ee(Fe, Fe.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? L_(e, t, n) : (Ee(Fe, Fe.current & 1), e = br(e, t, n), e !== null ? e.sibling : null);
            Ee(Fe, Fe.current & 1);
            break;
        case 19:
            if (r = (n & t.childLanes) !== 0, e.flags & 128) {
                if (r) return M_(e, t, n);
                t.flags |= 128
            }
            if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), Ee(Fe, Fe.current), r) break;
            return null;
        case 22:
        case 23:
            return t.lanes = 0, D_(e, t, n)
    }
    return br(e, t, n)
}
var N_, gh, F_, I_;
N_ = function(e, t) {
    for (var n = t.child; n !== null;) {
        if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
        else if (n.tag !== 4 && n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === t) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === t) return;
            n = n.return
        }
        n.sibling.return = n.return, n = n.sibling
    }
};
gh = function() {};
F_ = function(e, t, n, r) {
    var i = e.memoizedProps;
    if (i !== r) {
        e = t.stateNode, Ni(ir.current);
        var s = null;
        switch (n) {
            case "input":
                i = Id(e, i), r = Id(e, r), s = [];
                break;
            case "select":
                i = Ue({}, i, {
                    value: void 0
                }), r = Ue({}, r, {
                    value: void 0
                }), s = [];
                break;
            case "textarea":
                i = zd(e, i), r = zd(e, r), s = [];
                break;
            default:
                typeof i.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Vu)
        }
        $d(n, r);
        var o;
        n = null;
        for (u in i)
            if (!r.hasOwnProperty(u) && i.hasOwnProperty(u) && i[u] != null)
                if (u === "style") {
                    var a = i[u];
                    for (o in a) a.hasOwnProperty(o) && (n || (n = {}), n[o] = "")
                } else u !== "dangerouslySetInnerHTML" && u !== "children" && u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && u !== "autoFocus" && (Sa.hasOwnProperty(u) ? s || (s = []) : (s = s || []).push(u, null));
        for (u in r) {
            var l = r[u];
            if (a = i != null ? i[u] : void 0, r.hasOwnProperty(u) && l !== a && (l != null || a != null))
                if (u === "style")
                    if (a) {
                        for (o in a) !a.hasOwnProperty(o) || l && l.hasOwnProperty(o) || (n || (n = {}), n[o] = "");
                        for (o in l) l.hasOwnProperty(o) && a[o] !== l[o] && (n || (n = {}), n[o] = l[o])
                    } else n || (s || (s = []), s.push(u, n)), n = l;
            else u === "dangerouslySetInnerHTML" ? (l = l ? l.__html : void 0, a = a ? a.__html : void 0, l != null && a !== l && (s = s || []).push(u, l)) : u === "children" ? typeof l != "string" && typeof l != "number" || (s = s || []).push(u, "" + l) : u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && (Sa.hasOwnProperty(u) ? (l != null && u === "onScroll" && Re("scroll", e), s || a === l || (s = [])) : (s = s || []).push(u, l))
        }
        n && (s = s || []).push("style", n);
        var u = s;
        (t.updateQueue = u) && (t.flags |= 4)
    }
};
I_ = function(e, t, n, r) {
    n !== r && (t.flags |= 4)
};

function Fo(e, t) {
    if (!Le) switch (e.tailMode) {
        case "hidden":
            t = e.tail;
            for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
            n === null ? e.tail = null : n.sibling = null;
            break;
        case "collapsed":
            n = e.tail;
            for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
            r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
    }
}

function Tt(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
    if (t)
        for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 14680064, r |= i.flags & 14680064, i.return = e, i = i.sibling;
    else
        for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
    return e.subtreeFlags |= r, e.childLanes = n, t
}

function mk(e, t, n) {
    var r = t.pendingProps;
    switch (zp(t), t.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
            return Tt(t), null;
        case 1:
            return Ht(t.type) && Bu(), Tt(t), null;
        case 3:
            return r = t.stateNode, to(), Ae(Wt), Ae(Ot), qp(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && ($l(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Bn !== null && (Th(Bn), Bn = null))), gh(e, t), Tt(t), null;
        case 5:
            Xp(t);
            var i = Ni(La.current);
            if (n = t.type, e !== null && t.stateNode != null) F_(e, t, n, r, i), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
            else {
                if (!r) {
                    if (t.stateNode === null) throw Error(I(166));
                    return Tt(t), null
                }
                if (e = Ni(ir.current), $l(t)) {
                    r = t.stateNode, n = t.type;
                    var s = t.memoizedProps;
                    switch (r[er] = t, r[ja] = s, e = (t.mode & 1) !== 0, n) {
                        case "dialog":
                            Re("cancel", r), Re("close", r);
                            break;
                        case "iframe":
                        case "object":
                        case "embed":
                            Re("load", r);
                            break;
                        case "video":
                        case "audio":
                            for (i = 0; i < qo.length; i++) Re(qo[i], r);
                            break;
                        case "source":
                            Re("error", r);
                            break;
                        case "img":
                        case "image":
                        case "link":
                            Re("error", r), Re("load", r);
                            break;
                        case "details":
                            Re("toggle", r);
                            break;
                        case "input":
                            Zg(r, s), Re("invalid", r);
                            break;
                        case "select":
                            r._wrapperState = {
                                wasMultiple: !!s.multiple
                            }, Re("invalid", r);
                            break;
                        case "textarea":
                            ty(r, s), Re("invalid", r)
                    }
                    $d(n, s), i = null;
                    for (var o in s)
                        if (s.hasOwnProperty(o)) {
                            var a = s[o];
                            o === "children" ? typeof a == "string" ? r.textContent !== a && (s.suppressHydrationWarning !== !0 && Ul(r.textContent, a, e), i = ["children", a]) : typeof a == "number" && r.textContent !== "" + a && (s.suppressHydrationWarning !== !0 && Ul(r.textContent, a, e), i = ["children", "" + a]) : Sa.hasOwnProperty(o) && a != null && o === "onScroll" && Re("scroll", r)
                        }
                    switch (n) {
                        case "input":
                            Ll(r), ey(r, s, !0);
                            break;
                        case "textarea":
                            Ll(r), ny(r);
                            break;
                        case "select":
                        case "option":
                            break;
                        default:
                            typeof s.onClick == "function" && (r.onclick = Vu)
                    }
                    r = i, t.updateQueue = r, r !== null && (t.flags |= 4)
                } else {
                    o = i.nodeType === 9 ? i : i.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = dx(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = o.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = o.createElement(n, {
                        is: r.is
                    }) : (e = o.createElement(n), n === "select" && (o = e, r.multiple ? o.multiple = !0 : r.size && (o.size = r.size))) : e = o.createElementNS(e, n), e[er] = t, e[ja] = r, N_(e, t, !1, !1), t.stateNode = e;
                    e: {
                        switch (o = Wd(n, r), n) {
                            case "dialog":
                                Re("cancel", e), Re("close", e), i = r;
                                break;
                            case "iframe":
                            case "object":
                            case "embed":
                                Re("load", e), i = r;
                                break;
                            case "video":
                            case "audio":
                                for (i = 0; i < qo.length; i++) Re(qo[i], e);
                                i = r;
                                break;
                            case "source":
                                Re("error", e), i = r;
                                break;
                            case "img":
                            case "image":
                            case "link":
                                Re("error", e), Re("load", e), i = r;
                                break;
                            case "details":
                                Re("toggle", e), i = r;
                                break;
                            case "input":
                                Zg(e, r), i = Id(e, r), Re("invalid", e);
                                break;
                            case "option":
                                i = r;
                                break;
                            case "select":
                                e._wrapperState = {
                                    wasMultiple: !!r.multiple
                                }, i = Ue({}, r, {
                                    value: void 0
                                }), Re("invalid", e);
                                break;
                            case "textarea":
                                ty(e, r), i = zd(e, r), Re("invalid", e);
                                break;
                            default:
                                i = r
                        }
                        $d(n, i),
                        a = i;
                        for (s in a)
                            if (a.hasOwnProperty(s)) {
                                var l = a[s];
                                s === "style" ? mx(e, l) : s === "dangerouslySetInnerHTML" ? (l = l ? l.__html : void 0, l != null && hx(e, l)) : s === "children" ? typeof l == "string" ? (n !== "textarea" || l !== "") && Ca(e, l) : typeof l == "number" && Ca(e, "" + l) : s !== "suppressContentEditableWarning" && s !== "suppressHydrationWarning" && s !== "autoFocus" && (Sa.hasOwnProperty(s) ? l != null && s === "onScroll" && Re("scroll", e) : l != null && Pp(e, s, l, o))
                            }
                        switch (n) {
                            case "input":
                                Ll(e), ey(e, r, !1);
                                break;
                            case "textarea":
                                Ll(e), ny(e);
                                break;
                            case "option":
                                r.value != null && e.setAttribute("value", "" + ai(r.value));
                                break;
                            case "select":
                                e.multiple = !!r.multiple, s = r.value, s != null ? Bs(e, !!r.multiple, s, !1) : r.defaultValue != null && Bs(e, !!r.multiple, r.defaultValue, !0);
                                break;
                            default:
                                typeof i.onClick == "function" && (e.onclick = Vu)
                        }
                        switch (n) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                r = !!r.autoFocus;
                                break e;
                            case "img":
                                r = !0;
                                break e;
                            default:
                                r = !1
                        }
                    }
                    r && (t.flags |= 4)
                }
                t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
            }
            return Tt(t), null;
        case 6:
            if (e && t.stateNode != null) I_(e, t, e.memoizedProps, r);
            else {
                if (typeof r != "string" && t.stateNode === null) throw Error(I(166));
                if (n = Ni(La.current), Ni(ir.current), $l(t)) {
                    if (r = t.stateNode, n = t.memoizedProps, r[er] = t, (s = r.nodeValue !== n) && (e = un, e !== null)) switch (e.tag) {
                        case 3:
                            Ul(r.nodeValue, n, (e.mode & 1) !== 0);
                            break;
                        case 5:
                            e.memoizedProps.suppressHydrationWarning !== !0 && Ul(r.nodeValue, n, (e.mode & 1) !== 0)
                    }
                    s && (t.flags |= 4)
                } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[er] = t, t.stateNode = r
            }
            return Tt(t), null;
        case 13:
            if (Ae(Fe), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                if (Le && an !== null && t.mode & 1 && !(t.flags & 128)) n_(), Zs(), t.flags |= 98560, s = !1;
                else if (s = $l(t), r !== null && r.dehydrated !== null) {
                    if (e === null) {
                        if (!s) throw Error(I(318));
                        if (s = t.memoizedState, s = s !== null ? s.dehydrated : null, !s) throw Error(I(317));
                        s[er] = t
                    } else Zs(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                    Tt(t), s = !1
                } else Bn !== null && (Th(Bn), Bn = null), s = !0;
                if (!s) return t.flags & 65536 ? t : null
            }
            return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || Fe.current & 1 ? ut === 0 && (ut = 3) : lm())), t.updateQueue !== null && (t.flags |= 4), Tt(t), null);
        case 4:
            return to(), gh(e, t), e === null && Aa(t.stateNode.containerInfo), Tt(t), null;
        case 10:
            return Hp(t.type._context), Tt(t), null;
        case 17:
            return Ht(t.type) && Bu(), Tt(t), null;
        case 19:
            if (Ae(Fe), s = t.memoizedState, s === null) return Tt(t), null;
            if (r = (t.flags & 128) !== 0, o = s.rendering, o === null)
                if (r) Fo(s, !1);
                else {
                    if (ut !== 0 || e !== null && e.flags & 128)
                        for (e = t.child; e !== null;) {
                            if (o = Gu(e), o !== null) {
                                for (t.flags |= 128, Fo(s, !1), r = o.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null;) s = n, e = r, s.flags &= 14680066, o = s.alternate, o === null ? (s.childLanes = 0, s.lanes = e, s.child = null, s.subtreeFlags = 0, s.memoizedProps = null, s.memoizedState = null, s.updateQueue = null, s.dependencies = null, s.stateNode = null) : (s.childLanes = o.childLanes, s.lanes = o.lanes, s.child = o.child, s.subtreeFlags = 0, s.deletions = null, s.memoizedProps = o.memoizedProps, s.memoizedState = o.memoizedState, s.updateQueue = o.updateQueue, s.type = o.type, e = o.dependencies, s.dependencies = e === null ? null : {
                                    lanes: e.lanes,
                                    firstContext: e.firstContext
                                }), n = n.sibling;
                                return Ee(Fe, Fe.current & 1 | 2), t.child
                            }
                            e = e.sibling
                        }
                    s.tail !== null && Ze() > ro && (t.flags |= 128, r = !0, Fo(s, !1), t.lanes = 4194304)
                }
            else {
                if (!r)
                    if (e = Gu(o), e !== null) {
                        if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), Fo(s, !0), s.tail === null && s.tailMode === "hidden" && !o.alternate && !Le) return Tt(t), null
                    } else 2 * Ze() - s.renderingStartTime > ro && n !== 1073741824 && (t.flags |= 128, r = !0, Fo(s, !1), t.lanes = 4194304);
                s.isBackwards ? (o.sibling = t.child, t.child = o) : (n = s.last, n !== null ? n.sibling = o : t.child = o, s.last = o)
            }
            return s.tail !== null ? (t = s.tail, s.rendering = t, s.tail = t.sibling, s.renderingStartTime = Ze(), t.sibling = null, n = Fe.current, Ee(Fe, r ? n & 1 | 2 : n & 1), t) : (Tt(t), null);
        case 22:
        case 23:
            return am(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? tn & 1073741824 && (Tt(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Tt(t), null;
        case 24:
            return null;
        case 25:
            return null
    }
    throw Error(I(156, t.tag))
}

function gk(e, t) {
    switch (zp(t), t.tag) {
        case 1:
            return Ht(t.type) && Bu(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
            return to(), Ae(Wt), Ae(Ot), qp(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
        case 5:
            return Xp(t), null;
        case 13:
            if (Ae(Fe), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                if (t.alternate === null) throw Error(I(340));
                Zs()
            }
            return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
            return Ae(Fe), null;
        case 4:
            return to(), null;
        case 10:
            return Hp(t.type._context), null;
        case 22:
        case 23:
            return am(), null;
        case 24:
            return null;
        default:
            return null
    }
}
var Kl = !1,
    kt = !1,
    yk = typeof WeakSet == "function" ? WeakSet : Set,
    U = null;

function Ds(e, t) {
    var n = e.ref;
    if (n !== null)
        if (typeof n == "function") try {
            n(null)
        } catch (r) {
            Ye(e, t, r)
        } else n.current = null
}

function yh(e, t, n) {
    try {
        n()
    } catch (r) {
        Ye(e, t, r)
    }
}
var Hy = !1;

function vk(e, t) {
    if (eh = Nu, e = $x(), Vp(e)) {
        if ("selectionStart" in e) var n = {
            start: e.selectionStart,
            end: e.selectionEnd
        };
        else e: {
            n = (n = e.ownerDocument) && n.defaultView || window;
            var r = n.getSelection && n.getSelection();
            if (r && r.rangeCount !== 0) {
                n = r.anchorNode;
                var i = r.anchorOffset,
                    s = r.focusNode;
                r = r.focusOffset;
                try {
                    n.nodeType, s.nodeType
                } catch {
                    n = null;
                    break e
                }
                var o = 0,
                    a = -1,
                    l = -1,
                    u = 0,
                    c = 0,
                    f = e,
                    d = null;
                t: for (;;) {
                    for (var p; f !== n || i !== 0 && f.nodeType !== 3 || (a = o + i), f !== s || r !== 0 && f.nodeType !== 3 || (l = o + r), f.nodeType === 3 && (o += f.nodeValue.length), (p = f.firstChild) !== null;) d = f, f = p;
                    for (;;) {
                        if (f === e) break t;
                        if (d === n && ++u === i && (a = o), d === s && ++c === r && (l = o), (p = f.nextSibling) !== null) break;
                        f = d, d = f.parentNode
                    }
                    f = p
                }
                n = a === -1 || l === -1 ? null : {
                    start: a,
                    end: l
                }
            } else n = null
        }
        n = n || {
            start: 0,
            end: 0
        }
    } else n = null;
    for (th = {
            focusedElem: e,
            selectionRange: n
        }, Nu = !1, U = t; U !== null;)
        if (t = U, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, U = e;
        else
            for (; U !== null;) {
                t = U;
                try {
                    var m = t.alternate;
                    if (t.flags & 1024) switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if (m !== null) {
                                var h = m.memoizedProps,
                                    _ = m.memoizedState,
                                    v = t.stateNode,
                                    y = v.getSnapshotBeforeUpdate(t.elementType === t.type ? h : Fn(t.type, h), _);
                                v.__reactInternalSnapshotBeforeUpdate = y
                            }
                            break;
                        case 3:
                            var x = t.stateNode.containerInfo;
                            x.nodeType === 1 ? x.textContent = "" : x.nodeType === 9 && x.documentElement && x.removeChild(x.documentElement);
                            break;
                        case 5:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            throw Error(I(163))
                    }
                } catch (T) {
                    Ye(t, t.return, T)
                }
                if (e = t.sibling, e !== null) {
                    e.return = t.return, U = e;
                    break
                }
                U = t.return
            }
    return m = Hy, Hy = !1, m
}

function fa(e, t, n) {
    var r = t.updateQueue;
    if (r = r !== null ? r.lastEffect : null, r !== null) {
        var i = r = r.next;
        do {
            if ((i.tag & e) === e) {
                var s = i.destroy;
                i.destroy = void 0, s !== void 0 && yh(t, n, s)
            }
            i = i.next
        } while (i !== r)
    }
}

function Oc(e, t) {
    if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
        var n = t = t.next;
        do {
            if ((n.tag & e) === e) {
                var r = n.create;
                n.destroy = r()
            }
            n = n.next
        } while (n !== t)
    }
}

function vh(e) {
    var t = e.ref;
    if (t !== null) {
        var n = e.stateNode;
        switch (e.tag) {
            case 5:
                e = n;
                break;
            default:
                e = n
        }
        typeof t == "function" ? t(e) : t.current = e
    }
}

function V_(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, V_(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[er], delete t[ja], delete t[ih], delete t[ek], delete t[tk])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
}

function B_(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4
}

function Ky(e) {
    e: for (;;) {
        for (; e.sibling === null;) {
            if (e.return === null || B_(e.return)) return null;
            e = e.return
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
            if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
            e.child.return = e, e = e.child
        }
        if (!(e.flags & 2)) return e.stateNode
    }
}

function xh(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Vu));
    else if (r !== 4 && (e = e.child, e !== null))
        for (xh(e, t, n), e = e.sibling; e !== null;) xh(e, t, n), e = e.sibling
}

function _h(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child, e !== null))
        for (_h(e, t, n), e = e.sibling; e !== null;) _h(e, t, n), e = e.sibling
}
var gt = null,
    In = !1;

function Ir(e, t, n) {
    for (n = n.child; n !== null;) z_(e, t, n), n = n.sibling
}

function z_(e, t, n) {
    if (rr && typeof rr.onCommitFiberUnmount == "function") try {
        rr.onCommitFiberUnmount(Ec, n)
    } catch {}
    switch (n.tag) {
        case 5:
            kt || Ds(n, t);
        case 6:
            var r = gt,
                i = In;
            gt = null, Ir(e, t, n), gt = r, In = i, gt !== null && (In ? (e = gt, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : gt.removeChild(n.stateNode));
            break;
        case 18:
            gt !== null && (In ? (e = gt, n = n.stateNode, e.nodeType === 8 ? Wf(e.parentNode, n) : e.nodeType === 1 && Wf(e, n), ka(e)) : Wf(gt, n.stateNode));
            break;
        case 4:
            r = gt, i = In, gt = n.stateNode.containerInfo, In = !0, Ir(e, t, n), gt = r, In = i;
            break;
        case 0:
        case 11:
        case 14:
        case 15:
            if (!kt && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
                i = r = r.next;
                do {
                    var s = i,
                        o = s.destroy;
                    s = s.tag, o !== void 0 && (s & 2 || s & 4) && yh(n, t, o), i = i.next
                } while (i !== r)
            }
            Ir(e, t, n);
            break;
        case 1:
            if (!kt && (Ds(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
                r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
            } catch (a) {
                Ye(n, t, a)
            }
            Ir(e, t, n);
            break;
        case 21:
            Ir(e, t, n);
            break;
        case 22:
            n.mode & 1 ? (kt = (r = kt) || n.memoizedState !== null, Ir(e, t, n), kt = r) : Ir(e, t, n);
            break;
        default:
            Ir(e, t, n)
    }
}

function Gy(e) {
    var t = e.updateQueue;
    if (t !== null) {
        e.updateQueue = null;
        var n = e.stateNode;
        n === null && (n = e.stateNode = new yk), t.forEach(function(r) {
            var i = kk.bind(null, e, r);
            n.has(r) || (n.add(r), r.then(i, i))
        })
    }
}

function Mn(e, t) {
    var n = t.deletions;
    if (n !== null)
        for (var r = 0; r < n.length; r++) {
            var i = n[r];
            try {
                var s = e,
                    o = t,
                    a = o;
                e: for (; a !== null;) {
                    switch (a.tag) {
                        case 5:
                            gt = a.stateNode, In = !1;
                            break e;
                        case 3:
                            gt = a.stateNode.containerInfo, In = !0;
                            break e;
                        case 4:
                            gt = a.stateNode.containerInfo, In = !0;
                            break e
                    }
                    a = a.return
                }
                if (gt === null) throw Error(I(160));
                z_(s, o, i), gt = null, In = !1;
                var l = i.alternate;
                l !== null && (l.return = null), i.return = null
            } catch (u) {
                Ye(i, t, u)
            }
        }
    if (t.subtreeFlags & 12854)
        for (t = t.child; t !== null;) U_(t, e), t = t.sibling
}

function U_(e, t) {
    var n = e.alternate,
        r = e.flags;
    switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
            if (Mn(t, e), Gn(e), r & 4) {
                try {
                    fa(3, e, e.return), Oc(3, e)
                } catch (h) {
                    Ye(e, e.return, h)
                }
                try {
                    fa(5, e, e.return)
                } catch (h) {
                    Ye(e, e.return, h)
                }
            }
            break;
        case 1:
            Mn(t, e), Gn(e), r & 512 && n !== null && Ds(n, n.return);
            break;
        case 5:
            if (Mn(t, e), Gn(e), r & 512 && n !== null && Ds(n, n.return), e.flags & 32) {
                var i = e.stateNode;
                try {
                    Ca(i, "")
                } catch (h) {
                    Ye(e, e.return, h)
                }
            }
            if (r & 4 && (i = e.stateNode, i != null)) {
                var s = e.memoizedProps,
                    o = n !== null ? n.memoizedProps : s,
                    a = e.type,
                    l = e.updateQueue;
                if (e.updateQueue = null, l !== null) try {
                    a === "input" && s.type === "radio" && s.name != null && cx(i, s), Wd(a, o);
                    var u = Wd(a, s);
                    for (o = 0; o < l.length; o += 2) {
                        var c = l[o],
                            f = l[o + 1];
                        c === "style" ? mx(i, f) : c === "dangerouslySetInnerHTML" ? hx(i, f) : c === "children" ? Ca(i, f) : Pp(i, c, f, u)
                    }
                    switch (a) {
                        case "input":
                            Vd(i, s);
                            break;
                        case "textarea":
                            fx(i, s);
                            break;
                        case "select":
                            var d = i._wrapperState.wasMultiple;
                            i._wrapperState.wasMultiple = !!s.multiple;
                            var p = s.value;
                            p != null ? Bs(i, !!s.multiple, p, !1) : d !== !!s.multiple && (s.defaultValue != null ? Bs(i, !!s.multiple, s.defaultValue, !0) : Bs(i, !!s.multiple, s.multiple ? [] : "", !1))
                    }
                    i[ja] = s
                } catch (h) {
                    Ye(e, e.return, h)
                }
            }
            break;
        case 6:
            if (Mn(t, e), Gn(e), r & 4) {
                if (e.stateNode === null) throw Error(I(162));
                i = e.stateNode, s = e.memoizedProps;
                try {
                    i.nodeValue = s
                } catch (h) {
                    Ye(e, e.return, h)
                }
            }
            break;
        case 3:
            if (Mn(t, e), Gn(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                ka(t.containerInfo)
            } catch (h) {
                Ye(e, e.return, h)
            }
            break;
        case 4:
            Mn(t, e), Gn(e);
            break;
        case 13:
            Mn(t, e), Gn(e), i = e.child, i.flags & 8192 && (s = i.memoizedState !== null, i.stateNode.isHidden = s, !s || i.alternate !== null && i.alternate.memoizedState !== null || (sm = Ze())), r & 4 && Gy(e);
            break;
        case 22:
            if (c = n !== null && n.memoizedState !== null, e.mode & 1 ? (kt = (u = kt) || c, Mn(t, e), kt = u) : Mn(t, e), Gn(e), r & 8192) {
                if (u = e.memoizedState !== null, (e.stateNode.isHidden = u) && !c && e.mode & 1)
                    for (U = e, c = e.child; c !== null;) {
                        for (f = U = c; U !== null;) {
                            switch (d = U, p = d.child, d.tag) {
                                case 0:
                                case 11:
                                case 14:
                                case 15:
                                    fa(4, d, d.return);
                                    break;
                                case 1:
                                    Ds(d, d.return);
                                    var m = d.stateNode;
                                    if (typeof m.componentWillUnmount == "function") {
                                        r = d, n = d.return;
                                        try {
                                            t = r, m.props = t.memoizedProps, m.state = t.memoizedState, m.componentWillUnmount()
                                        } catch (h) {
                                            Ye(r, n, h)
                                        }
                                    }
                                    break;
                                case 5:
                                    Ds(d, d.return);
                                    break;
                                case 22:
                                    if (d.memoizedState !== null) {
                                        Xy(f);
                                        continue
                                    }
                            }
                            p !== null ? (p.return = d, U = p) : Xy(f)
                        }
                        c = c.sibling
                    }
                e: for (c = null, f = e;;) {
                    if (f.tag === 5) {
                        if (c === null) {
                            c = f;
                            try {
                                i = f.stateNode, u ? (s = i.style, typeof s.setProperty == "function" ? s.setProperty("display", "none", "important") : s.display = "none") : (a = f.stateNode, l = f.memoizedProps.style, o = l != null && l.hasOwnProperty("display") ? l.display : null, a.style.display = px("display", o))
                            } catch (h) {
                                Ye(e, e.return, h)
                            }
                        }
                    } else if (f.tag === 6) {
                        if (c === null) try {
                            f.stateNode.nodeValue = u ? "" : f.memoizedProps
                        } catch (h) {
                            Ye(e, e.return, h)
                        }
                    } else if ((f.tag !== 22 && f.tag !== 23 || f.memoizedState === null || f === e) && f.child !== null) {
                        f.child.return = f, f = f.child;
                        continue
                    }
                    if (f === e) break e;
                    for (; f.sibling === null;) {
                        if (f.return === null || f.return === e) break e;
                        c === f && (c = null), f = f.return
                    }
                    c === f && (c = null), f.sibling.return = f.return, f = f.sibling
                }
            }
            break;
        case 19:
            Mn(t, e), Gn(e), r & 4 && Gy(e);
            break;
        case 21:
            break;
        default:
            Mn(t, e), Gn(e)
    }
}

function Gn(e) {
    var t = e.flags;
    if (t & 2) {
        try {
            e: {
                for (var n = e.return; n !== null;) {
                    if (B_(n)) {
                        var r = n;
                        break e
                    }
                    n = n.return
                }
                throw Error(I(160))
            }
            switch (r.tag) {
                case 5:
                    var i = r.stateNode;
                    r.flags & 32 && (Ca(i, ""), r.flags &= -33);
                    var s = Ky(e);
                    _h(e, s, i);
                    break;
                case 3:
                case 4:
                    var o = r.stateNode.containerInfo,
                        a = Ky(e);
                    xh(e, a, o);
                    break;
                default:
                    throw Error(I(161))
            }
        }
        catch (l) {
            Ye(e, e.return, l)
        }
        e.flags &= -3
    }
    t & 4096 && (e.flags &= -4097)
}

function xk(e, t, n) {
    U = e, $_(e)
}

function $_(e, t, n) {
    for (var r = (e.mode & 1) !== 0; U !== null;) {
        var i = U,
            s = i.child;
        if (i.tag === 22 && r) {
            var o = i.memoizedState !== null || Kl;
            if (!o) {
                var a = i.alternate,
                    l = a !== null && a.memoizedState !== null || kt;
                a = Kl;
                var u = kt;
                if (Kl = o, (kt = l) && !u)
                    for (U = i; U !== null;) o = U, l = o.child, o.tag === 22 && o.memoizedState !== null ? qy(i) : l !== null ? (l.return = o, U = l) : qy(i);
                for (; s !== null;) U = s, $_(s), s = s.sibling;
                U = i, Kl = a, kt = u
            }
            Yy(e)
        } else i.subtreeFlags & 8772 && s !== null ? (s.return = i, U = s) : Yy(e)
    }
}

function Yy(e) {
    for (; U !== null;) {
        var t = U;
        if (t.flags & 8772) {
            var n = t.alternate;
            try {
                if (t.flags & 8772) switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        kt || Oc(5, t);
                        break;
                    case 1:
                        var r = t.stateNode;
                        if (t.flags & 4 && !kt)
                            if (n === null) r.componentDidMount();
                            else {
                                var i = t.elementType === t.type ? n.memoizedProps : Fn(t.type, n.memoizedProps);
                                r.componentDidUpdate(i, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                            }
                        var s = t.updateQueue;
                        s !== null && jy(t, s, r);
                        break;
                    case 3:
                        var o = t.updateQueue;
                        if (o !== null) {
                            if (n = null, t.child !== null) switch (t.child.tag) {
                                case 5:
                                    n = t.child.stateNode;
                                    break;
                                case 1:
                                    n = t.child.stateNode
                            }
                            jy(t, o, n)
                        }
                        break;
                    case 5:
                        var a = t.stateNode;
                        if (n === null && t.flags & 4) {
                            n = a;
                            var l = t.memoizedProps;
                            switch (t.type) {
                                case "button":
                                case "input":
                                case "select":
                                case "textarea":
                                    l.autoFocus && n.focus();
                                    break;
                                case "img":
                                    l.src && (n.src = l.src)
                            }
                        }
                        break;
                    case 6:
                        break;
                    case 4:
                        break;
                    case 12:
                        break;
                    case 13:
                        if (t.memoizedState === null) {
                            var u = t.alternate;
                            if (u !== null) {
                                var c = u.memoizedState;
                                if (c !== null) {
                                    var f = c.dehydrated;
                                    f !== null && ka(f)
                                }
                            }
                        }
                        break;
                    case 19:
                    case 17:
                    case 21:
                    case 22:
                    case 23:
                    case 25:
                        break;
                    default:
                        throw Error(I(163))
                }
                kt || t.flags & 512 && vh(t)
            } catch (d) {
                Ye(t, t.return, d)
            }
        }
        if (t === e) {
            U = null;
            break
        }
        if (n = t.sibling, n !== null) {
            n.return = t.return, U = n;
            break
        }
        U = t.return
    }
}

function Xy(e) {
    for (; U !== null;) {
        var t = U;
        if (t === e) {
            U = null;
            break
        }
        var n = t.sibling;
        if (n !== null) {
            n.return = t.return, U = n;
            break
        }
        U = t.return
    }
}

function qy(e) {
    for (; U !== null;) {
        var t = U;
        try {
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    var n = t.return;
                    try {
                        Oc(4, t)
                    } catch (l) {
                        Ye(t, n, l)
                    }
                    break;
                case 1:
                    var r = t.stateNode;
                    if (typeof r.componentDidMount == "function") {
                        var i = t.return;
                        try {
                            r.componentDidMount()
                        } catch (l) {
                            Ye(t, i, l)
                        }
                    }
                    var s = t.return;
                    try {
                        vh(t)
                    } catch (l) {
                        Ye(t, s, l)
                    }
                    break;
                case 5:
                    var o = t.return;
                    try {
                        vh(t)
                    } catch (l) {
                        Ye(t, o, l)
                    }
            }
        } catch (l) {
            Ye(t, t.return, l)
        }
        if (t === e) {
            U = null;
            break
        }
        var a = t.sibling;
        if (a !== null) {
            a.return = t.return, U = a;
            break
        }
        U = t.return
    }
}
var _k = Math.ceil,
    qu = Lr.ReactCurrentDispatcher,
    rm = Lr.ReactCurrentOwner,
    Rn = Lr.ReactCurrentBatchConfig,
    fe = 0,
    ht = null,
    at = null,
    xt = 0,
    tn = 0,
    js = mi(0),
    ut = 0,
    Ia = null,
    Ji = 0,
    Lc = 0,
    im = 0,
    da = null,
    Ut = null,
    sm = 0,
    ro = 1 / 0,
    pr = null,
    Qu = !1,
    wh = null,
    ni = null,
    Gl = !1,
    Kr = null,
    Ju = 0,
    ha = 0,
    Sh = null,
    pu = -1,
    mu = 0;

function It() {
    return fe & 6 ? Ze() : pu !== -1 ? pu : pu = Ze()
}

function ri(e) {
    return e.mode & 1 ? fe & 2 && xt !== 0 ? xt & -xt : rk.transition !== null ? (mu === 0 && (mu = kx()), mu) : (e = ve, e !== 0 || (e = window.event, e = e === void 0 ? 16 : Lx(e.type)), e) : 1
}

function Un(e, t, n, r) {
    if (50 < ha) throw ha = 0, Sh = null, Error(I(185));
    al(e, n, r), (!(fe & 2) || e !== ht) && (e === ht && (!(fe & 2) && (Lc |= n), ut === 4 && Wr(e, xt)), Kt(e, r), n === 1 && fe === 0 && !(t.mode & 1) && (ro = Ze() + 500, Ac && gi()))
}

function Kt(e, t) {
    var n = e.callbackNode;
    rP(e, t);
    var r = Mu(e, e === ht ? xt : 0);
    if (r === 0) n !== null && sy(n), e.callbackNode = null, e.callbackPriority = 0;
    else if (t = r & -r, e.callbackPriority !== t) {
        if (n != null && sy(n), t === 1) e.tag === 0 ? nk(Qy.bind(null, e)) : Zx(Qy.bind(null, e)), JP(function() {
            !(fe & 6) && gi()
        }), n = null;
        else {
            switch (bx(r)) {
                case 1:
                    n = Dp;
                    break;
                case 4:
                    n = Ex;
                    break;
                case 16:
                    n = Lu;
                    break;
                case 536870912:
                    n = Px;
                    break;
                default:
                    n = Lu
            }
            n = Q_(n, W_.bind(null, e))
        }
        e.callbackPriority = t, e.callbackNode = n
    }
}

function W_(e, t) {
    if (pu = -1, mu = 0, fe & 6) throw Error(I(327));
    var n = e.callbackNode;
    if (Hs() && e.callbackNode !== n) return null;
    var r = Mu(e, e === ht ? xt : 0);
    if (r === 0) return null;
    if (r & 30 || r & e.expiredLanes || t) t = Zu(e, r);
    else {
        t = r;
        var i = fe;
        fe |= 2;
        var s = K_();
        (ht !== e || xt !== t) && (pr = null, ro = Ze() + 500, zi(e, t));
        do try {
            Ck();
            break
        } catch (a) {
            H_(e, a)
        }
        while (!0);
        Wp(), qu.current = s, fe = i, at !== null ? t = 0 : (ht = null, xt = 0, t = ut)
    }
    if (t !== 0) {
        if (t === 2 && (i = Xd(e), i !== 0 && (r = i, t = Ch(e, i))), t === 1) throw n = Ia, zi(e, 0), Wr(e, r), Kt(e, Ze()), n;
        if (t === 6) Wr(e, r);
        else {
            if (i = e.current.alternate, !(r & 30) && !wk(i) && (t = Zu(e, r), t === 2 && (s = Xd(e), s !== 0 && (r = s, t = Ch(e, s))), t === 1)) throw n = Ia, zi(e, 0), Wr(e, r), Kt(e, Ze()), n;
            switch (e.finishedWork = i, e.finishedLanes = r, t) {
                case 0:
                case 1:
                    throw Error(I(345));
                case 2:
                    bi(e, Ut, pr);
                    break;
                case 3:
                    if (Wr(e, r), (r & 130023424) === r && (t = sm + 500 - Ze(), 10 < t)) {
                        if (Mu(e, 0) !== 0) break;
                        if (i = e.suspendedLanes, (i & r) !== r) {
                            It(), e.pingedLanes |= e.suspendedLanes & i;
                            break
                        }
                        e.timeoutHandle = rh(bi.bind(null, e, Ut, pr), t);
                        break
                    }
                    bi(e, Ut, pr);
                    break;
                case 4:
                    if (Wr(e, r), (r & 4194240) === r) break;
                    for (t = e.eventTimes, i = -1; 0 < r;) {
                        var o = 31 - zn(r);
                        s = 1 << o, o = t[o], o > i && (i = o), r &= ~s
                    }
                    if (r = i, r = Ze() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * _k(r / 1960)) - r, 10 < r) {
                        e.timeoutHandle = rh(bi.bind(null, e, Ut, pr), r);
                        break
                    }
                    bi(e, Ut, pr);
                    break;
                case 5:
                    bi(e, Ut, pr);
                    break;
                default:
                    throw Error(I(329))
            }
        }
    }
    return Kt(e, Ze()), e.callbackNode === n ? W_.bind(null, e) : null
}

function Ch(e, t) {
    var n = da;
    return e.current.memoizedState.isDehydrated && (zi(e, t).flags |= 256), e = Zu(e, t), e !== 2 && (t = Ut, Ut = n, t !== null && Th(t)), e
}

function Th(e) {
    Ut === null ? Ut = e : Ut.push.apply(Ut, e)
}

function wk(e) {
    for (var t = e;;) {
        if (t.flags & 16384) {
            var n = t.updateQueue;
            if (n !== null && (n = n.stores, n !== null))
                for (var r = 0; r < n.length; r++) {
                    var i = n[r],
                        s = i.getSnapshot;
                    i = i.value;
                    try {
                        if (!$n(s(), i)) return !1
                    } catch {
                        return !1
                    }
                }
        }
        if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
        else {
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return !0;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
    }
    return !0
}

function Wr(e, t) {
    for (t &= ~im, t &= ~Lc, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
        var n = 31 - zn(t),
            r = 1 << n;
        e[n] = -1, t &= ~r
    }
}

function Qy(e) {
    if (fe & 6) throw Error(I(327));
    Hs();
    var t = Mu(e, 0);
    if (!(t & 1)) return Kt(e, Ze()), null;
    var n = Zu(e, t);
    if (e.tag !== 0 && n === 2) {
        var r = Xd(e);
        r !== 0 && (t = r, n = Ch(e, r))
    }
    if (n === 1) throw n = Ia, zi(e, 0), Wr(e, t), Kt(e, Ze()), n;
    if (n === 6) throw Error(I(345));
    return e.finishedWork = e.current.alternate, e.finishedLanes = t, bi(e, Ut, pr), Kt(e, Ze()), null
}

function om(e, t) {
    var n = fe;
    fe |= 1;
    try {
        return e(t)
    } finally {
        fe = n, fe === 0 && (ro = Ze() + 500, Ac && gi())
    }
}

function Zi(e) {
    Kr !== null && Kr.tag === 0 && !(fe & 6) && Hs();
    var t = fe;
    fe |= 1;
    var n = Rn.transition,
        r = ve;
    try {
        if (Rn.transition = null, ve = 1, e) return e()
    } finally {
        ve = r, Rn.transition = n, fe = t, !(fe & 6) && gi()
    }
}

function am() {
    tn = js.current, Ae(js)
}

function zi(e, t) {
    e.finishedWork = null, e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1, QP(n)), at !== null)
        for (n = at.return; n !== null;) {
            var r = n;
            switch (zp(r), r.tag) {
                case 1:
                    r = r.type.childContextTypes, r != null && Bu();
                    break;
                case 3:
                    to(), Ae(Wt), Ae(Ot), qp();
                    break;
                case 5:
                    Xp(r);
                    break;
                case 4:
                    to();
                    break;
                case 13:
                    Ae(Fe);
                    break;
                case 19:
                    Ae(Fe);
                    break;
                case 10:
                    Hp(r.type._context);
                    break;
                case 22:
                case 23:
                    am()
            }
            n = n.return
        }
    if (ht = e, at = e = ii(e.current, null), xt = tn = t, ut = 0, Ia = null, im = Lc = Ji = 0, Ut = da = null, Mi !== null) {
        for (t = 0; t < Mi.length; t++)
            if (n = Mi[t], r = n.interleaved, r !== null) {
                n.interleaved = null;
                var i = r.next,
                    s = n.pending;
                if (s !== null) {
                    var o = s.next;
                    s.next = i, r.next = o
                }
                n.pending = r
            }
        Mi = null
    }
    return e
}

function H_(e, t) {
    do {
        var n = at;
        try {
            if (Wp(), fu.current = Xu, Yu) {
                for (var r = ze.memoizedState; r !== null;) {
                    var i = r.queue;
                    i !== null && (i.pending = null), r = r.next
                }
                Yu = !1
            }
            if (Qi = 0, dt = lt = ze = null, ca = !1, Ma = 0, rm.current = null, n === null || n.return === null) {
                ut = 1, Ia = t, at = null;
                break
            }
            e: {
                var s = e,
                    o = n.return,
                    a = n,
                    l = t;
                if (t = xt, a.flags |= 32768, l !== null && typeof l == "object" && typeof l.then == "function") {
                    var u = l,
                        c = a,
                        f = c.tag;
                    if (!(c.mode & 1) && (f === 0 || f === 11 || f === 15)) {
                        var d = c.alternate;
                        d ? (c.updateQueue = d.updateQueue, c.memoizedState = d.memoizedState, c.lanes = d.lanes) : (c.updateQueue = null, c.memoizedState = null)
                    }
                    var p = Iy(o);
                    if (p !== null) {
                        p.flags &= -257, Vy(p, o, a, s, t), p.mode & 1 && Fy(s, u, t), t = p, l = u;
                        var m = t.updateQueue;
                        if (m === null) {
                            var h = new Set;
                            h.add(l), t.updateQueue = h
                        } else m.add(l);
                        break e
                    } else {
                        if (!(t & 1)) {
                            Fy(s, u, t), lm();
                            break e
                        }
                        l = Error(I(426))
                    }
                } else if (Le && a.mode & 1) {
                    var _ = Iy(o);
                    if (_ !== null) {
                        !(_.flags & 65536) && (_.flags |= 256), Vy(_, o, a, s, t), Up(no(l, a));
                        break e
                    }
                }
                s = l = no(l, a),
                ut !== 4 && (ut = 2),
                da === null ? da = [s] : da.push(s),
                s = o;do {
                    switch (s.tag) {
                        case 3:
                            s.flags |= 65536, t &= -t, s.lanes |= t;
                            var v = b_(s, l, t);
                            Dy(s, v);
                            break e;
                        case 1:
                            a = l;
                            var y = s.type,
                                x = s.stateNode;
                            if (!(s.flags & 128) && (typeof y.getDerivedStateFromError == "function" || x !== null && typeof x.componentDidCatch == "function" && (ni === null || !ni.has(x)))) {
                                s.flags |= 65536, t &= -t, s.lanes |= t;
                                var T = R_(s, a, t);
                                Dy(s, T);
                                break e
                            }
                    }
                    s = s.return
                } while (s !== null)
            }
            Y_(n)
        } catch (E) {
            t = E, at === n && n !== null && (at = n = n.return);
            continue
        }
        break
    } while (!0)
}

function K_() {
    var e = qu.current;
    return qu.current = Xu, e === null ? Xu : e
}

function lm() {
    (ut === 0 || ut === 3 || ut === 2) && (ut = 4), ht === null || !(Ji & 268435455) && !(Lc & 268435455) || Wr(ht, xt)
}

function Zu(e, t) {
    var n = fe;
    fe |= 2;
    var r = K_();
    (ht !== e || xt !== t) && (pr = null, zi(e, t));
    do try {
        Sk();
        break
    } catch (i) {
        H_(e, i)
    }
    while (!0);
    if (Wp(), fe = n, qu.current = r, at !== null) throw Error(I(261));
    return ht = null, xt = 0, ut
}

function Sk() {
    for (; at !== null;) G_(at)
}

function Ck() {
    for (; at !== null && !YE();) G_(at)
}

function G_(e) {
    var t = q_(e.alternate, e, tn);
    e.memoizedProps = e.pendingProps, t === null ? Y_(e) : at = t, rm.current = null
}

function Y_(e) {
    var t = e;
    do {
        var n = t.alternate;
        if (e = t.return, t.flags & 32768) {
            if (n = gk(n, t), n !== null) {
                n.flags &= 32767, at = n;
                return
            }
            if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
            else {
                ut = 6, at = null;
                return
            }
        } else if (n = mk(n, t, tn), n !== null) {
            at = n;
            return
        }
        if (t = t.sibling, t !== null) {
            at = t;
            return
        }
        at = t = e
    } while (t !== null);
    ut === 0 && (ut = 5)
}

function bi(e, t, n) {
    var r = ve,
        i = Rn.transition;
    try {
        Rn.transition = null, ve = 1, Tk(e, t, n, r)
    } finally {
        Rn.transition = i, ve = r
    }
    return null
}

function Tk(e, t, n, r) {
    do Hs(); while (Kr !== null);
    if (fe & 6) throw Error(I(327));
    n = e.finishedWork;
    var i = e.finishedLanes;
    if (n === null) return null;
    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(I(177));
    e.callbackNode = null, e.callbackPriority = 0;
    var s = n.lanes | n.childLanes;
    if (iP(e, s), e === ht && (at = ht = null, xt = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || Gl || (Gl = !0, Q_(Lu, function() {
            return Hs(), null
        })), s = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || s) {
        s = Rn.transition, Rn.transition = null;
        var o = ve;
        ve = 1;
        var a = fe;
        fe |= 4, rm.current = null, vk(e, n), U_(n, e), WP(th), Nu = !!eh, th = eh = null, e.current = n, xk(n), XE(), fe = a, ve = o, Rn.transition = s
    } else e.current = n;
    if (Gl && (Gl = !1, Kr = e, Ju = i), s = e.pendingLanes, s === 0 && (ni = null), JE(n.stateNode), Kt(e, Ze()), t !== null)
        for (r = e.onRecoverableError, n = 0; n < t.length; n++) i = t[n], r(i.value, {
            componentStack: i.stack,
            digest: i.digest
        });
    if (Qu) throw Qu = !1, e = wh, wh = null, e;
    return Ju & 1 && e.tag !== 0 && Hs(), s = e.pendingLanes, s & 1 ? e === Sh ? ha++ : (ha = 0, Sh = e) : ha = 0, gi(), null
}

function Hs() {
    if (Kr !== null) {
        var e = bx(Ju),
            t = Rn.transition,
            n = ve;
        try {
            if (Rn.transition = null, ve = 16 > e ? 16 : e, Kr === null) var r = !1;
            else {
                if (e = Kr, Kr = null, Ju = 0, fe & 6) throw Error(I(331));
                var i = fe;
                for (fe |= 4, U = e.current; U !== null;) {
                    var s = U,
                        o = s.child;
                    if (U.flags & 16) {
                        var a = s.deletions;
                        if (a !== null) {
                            for (var l = 0; l < a.length; l++) {
                                var u = a[l];
                                for (U = u; U !== null;) {
                                    var c = U;
                                    switch (c.tag) {
                                        case 0:
                                        case 11:
                                        case 15:
                                            fa(8, c, s)
                                    }
                                    var f = c.child;
                                    if (f !== null) f.return = c, U = f;
                                    else
                                        for (; U !== null;) {
                                            c = U;
                                            var d = c.sibling,
                                                p = c.return;
                                            if (V_(c), c === u) {
                                                U = null;
                                                break
                                            }
                                            if (d !== null) {
                                                d.return = p, U = d;
                                                break
                                            }
                                            U = p
                                        }
                                }
                            }
                            var m = s.alternate;
                            if (m !== null) {
                                var h = m.child;
                                if (h !== null) {
                                    m.child = null;
                                    do {
                                        var _ = h.sibling;
                                        h.sibling = null, h = _
                                    } while (h !== null)
                                }
                            }
                            U = s
                        }
                    }
                    if (s.subtreeFlags & 2064 && o !== null) o.return = s, U = o;
                    else e: for (; U !== null;) {
                        if (s = U, s.flags & 2048) switch (s.tag) {
                            case 0:
                            case 11:
                            case 15:
                                fa(9, s, s.return)
                        }
                        var v = s.sibling;
                        if (v !== null) {
                            v.return = s.return, U = v;
                            break e
                        }
                        U = s.return
                    }
                }
                var y = e.current;
                for (U = y; U !== null;) {
                    o = U;
                    var x = o.child;
                    if (o.subtreeFlags & 2064 && x !== null) x.return = o, U = x;
                    else e: for (o = y; U !== null;) {
                        if (a = U, a.flags & 2048) try {
                            switch (a.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    Oc(9, a)
                            }
                        } catch (E) {
                            Ye(a, a.return, E)
                        }
                        if (a === o) {
                            U = null;
                            break e
                        }
                        var T = a.sibling;
                        if (T !== null) {
                            T.return = a.return, U = T;
                            break e
                        }
                        U = a.return
                    }
                }
                if (fe = i, gi(), rr && typeof rr.onPostCommitFiberRoot == "function") try {
                    rr.onPostCommitFiberRoot(Ec, e)
                } catch {}
                r = !0
            }
            return r
        } finally {
            ve = n, Rn.transition = t
        }
    }
    return !1
}

function Jy(e, t, n) {
    t = no(n, t), t = b_(e, t, 1), e = ti(e, t, 1), t = It(), e !== null && (al(e, 1, t), Kt(e, t))
}

function Ye(e, t, n) {
    if (e.tag === 3) Jy(e, e, n);
    else
        for (; t !== null;) {
            if (t.tag === 3) {
                Jy(t, e, n);
                break
            } else if (t.tag === 1) {
                var r = t.stateNode;
                if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (ni === null || !ni.has(r))) {
                    e = no(n, e), e = R_(t, e, 1), t = ti(t, e, 1), e = It(), t !== null && (al(t, 1, e), Kt(t, e));
                    break
                }
            }
            t = t.return
        }
}

function Ek(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t), t = It(), e.pingedLanes |= e.suspendedLanes & n, ht === e && (xt & n) === n && (ut === 4 || ut === 3 && (xt & 130023424) === xt && 500 > Ze() - sm ? zi(e, 0) : im |= n), Kt(e, t)
}

function X_(e, t) {
    t === 0 && (e.mode & 1 ? (t = Fl, Fl <<= 1, !(Fl & 130023424) && (Fl = 4194304)) : t = 1);
    var n = It();
    e = kr(e, t), e !== null && (al(e, t, n), Kt(e, n))
}

function Pk(e) {
    var t = e.memoizedState,
        n = 0;
    t !== null && (n = t.retryLane), X_(e, n)
}

function kk(e, t) {
    var n = 0;
    switch (e.tag) {
        case 13:
            var r = e.stateNode,
                i = e.memoizedState;
            i !== null && (n = i.retryLane);
            break;
        case 19:
            r = e.stateNode;
            break;
        default:
            throw Error(I(314))
    }
    r !== null && r.delete(t), X_(e, n)
}
var q_;
q_ = function(e, t, n) {
    if (e !== null)
        if (e.memoizedProps !== t.pendingProps || Wt.current) $t = !0;
        else {
            if (!(e.lanes & n) && !(t.flags & 128)) return $t = !1, pk(e, t, n);
            $t = !!(e.flags & 131072)
        }
    else $t = !1, Le && t.flags & 1048576 && e_(t, $u, t.index);
    switch (t.lanes = 0, t.tag) {
        case 2:
            var r = t.type;
            hu(e, t), e = t.pendingProps;
            var i = Js(t, Ot.current);
            Ws(t, n), i = Jp(null, t, r, e, i, n);
            var s = Zp();
            return t.flags |= 1, typeof i == "object" && i !== null && typeof i.render == "function" && i.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, Ht(r) ? (s = !0, zu(t)) : s = !1, t.memoizedState = i.state !== null && i.state !== void 0 ? i.state : null, Gp(t), i.updater = jc, t.stateNode = i, i._reactInternals = t, ch(t, r, e, n), t = hh(null, t, r, !0, s, n)) : (t.tag = 0, Le && s && Bp(t), Mt(null, t, i, n), t = t.child), t;
        case 16:
            r = t.elementType;
            e: {
                switch (hu(e, t), e = t.pendingProps, i = r._init, r = i(r._payload), t.type = r, i = t.tag = Rk(r), e = Fn(r, e), i) {
                    case 0:
                        t = dh(null, t, r, e, n);
                        break e;
                    case 1:
                        t = Uy(null, t, r, e, n);
                        break e;
                    case 11:
                        t = By(null, t, r, e, n);
                        break e;
                    case 14:
                        t = zy(null, t, r, Fn(r.type, e), n);
                        break e
                }
                throw Error(I(306, r, ""))
            }
            return t;
        case 0:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Fn(r, i), dh(e, t, r, i, n);
        case 1:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Fn(r, i), Uy(e, t, r, i, n);
        case 3:
            e: {
                if (O_(t), e === null) throw Error(I(387));r = t.pendingProps,
                s = t.memoizedState,
                i = s.element,
                o_(e, t),
                Ku(t, r, null, n);
                var o = t.memoizedState;
                if (r = o.element, s.isDehydrated)
                    if (s = {
                            element: r,
                            isDehydrated: !1,
                            cache: o.cache,
                            pendingSuspenseBoundaries: o.pendingSuspenseBoundaries,
                            transitions: o.transitions
                        }, t.updateQueue.baseState = s, t.memoizedState = s, t.flags & 256) {
                        i = no(Error(I(423)), t), t = $y(e, t, r, n, i);
                        break e
                    } else if (r !== i) {
                    i = no(Error(I(424)), t), t = $y(e, t, r, n, i);
                    break e
                } else
                    for (an = ei(t.stateNode.containerInfo.firstChild), un = t, Le = !0, Bn = null, n = i_(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                else {
                    if (Zs(), r === i) {
                        t = br(e, t, n);
                        break e
                    }
                    Mt(e, t, r, n)
                }
                t = t.child
            }
            return t;
        case 5:
            return a_(t), e === null && ah(t), r = t.type, i = t.pendingProps, s = e !== null ? e.memoizedProps : null, o = i.children, nh(r, i) ? o = null : s !== null && nh(r, s) && (t.flags |= 32), j_(e, t), Mt(e, t, o, n), t.child;
        case 6:
            return e === null && ah(t), null;
        case 13:
            return L_(e, t, n);
        case 4:
            return Yp(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = eo(t, null, r, n) : Mt(e, t, r, n), t.child;
        case 11:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Fn(r, i), By(e, t, r, i, n);
        case 7:
            return Mt(e, t, t.pendingProps, n), t.child;
        case 8:
            return Mt(e, t, t.pendingProps.children, n), t.child;
        case 12:
            return Mt(e, t, t.pendingProps.children, n), t.child;
        case 10:
            e: {
                if (r = t.type._context, i = t.pendingProps, s = t.memoizedProps, o = i.value, Ee(Wu, r._currentValue), r._currentValue = o, s !== null)
                    if ($n(s.value, o)) {
                        if (s.children === i.children && !Wt.current) {
                            t = br(e, t, n);
                            break e
                        }
                    } else
                        for (s = t.child, s !== null && (s.return = t); s !== null;) {
                            var a = s.dependencies;
                            if (a !== null) {
                                o = s.child;
                                for (var l = a.firstContext; l !== null;) {
                                    if (l.context === r) {
                                        if (s.tag === 1) {
                                            l = wr(-1, n & -n), l.tag = 2;
                                            var u = s.updateQueue;
                                            if (u !== null) {
                                                u = u.shared;
                                                var c = u.pending;
                                                c === null ? l.next = l : (l.next = c.next, c.next = l), u.pending = l
                                            }
                                        }
                                        s.lanes |= n, l = s.alternate, l !== null && (l.lanes |= n), lh(s.return, n, t), a.lanes |= n;
                                        break
                                    }
                                    l = l.next
                                }
                            } else if (s.tag === 10) o = s.type === t.type ? null : s.child;
                            else if (s.tag === 18) {
                                if (o = s.return, o === null) throw Error(I(341));
                                o.lanes |= n, a = o.alternate, a !== null && (a.lanes |= n), lh(o, n, t), o = s.sibling
                            } else o = s.child;
                            if (o !== null) o.return = s;
                            else
                                for (o = s; o !== null;) {
                                    if (o === t) {
                                        o = null;
                                        break
                                    }
                                    if (s = o.sibling, s !== null) {
                                        s.return = o.return, o = s;
                                        break
                                    }
                                    o = o.return
                                }
                            s = o
                        }
                Mt(e, t, i.children, n),
                t = t.child
            }
            return t;
        case 9:
            return i = t.type, r = t.pendingProps.children, Ws(t, n), i = An(i), r = r(i), t.flags |= 1, Mt(e, t, r, n), t.child;
        case 14:
            return r = t.type, i = Fn(r, t.pendingProps), i = Fn(r.type, i), zy(e, t, r, i, n);
        case 15:
            return A_(e, t, t.type, t.pendingProps, n);
        case 17:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Fn(r, i), hu(e, t), t.tag = 1, Ht(r) ? (e = !0, zu(t)) : e = !1, Ws(t, n), k_(t, r, i), ch(t, r, i, n), hh(null, t, r, !0, e, n);
        case 19:
            return M_(e, t, n);
        case 22:
            return D_(e, t, n)
    }
    throw Error(I(156, t.tag))
};

function Q_(e, t) {
    return Tx(e, t)
}

function bk(e, t, n, r) {
    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
}

function kn(e, t, n, r) {
    return new bk(e, t, n, r)
}

function um(e) {
    return e = e.prototype, !(!e || !e.isReactComponent)
}

function Rk(e) {
    if (typeof e == "function") return um(e) ? 1 : 0;
    if (e != null) {
        if (e = e.$$typeof, e === bp) return 11;
        if (e === Rp) return 14
    }
    return 2
}

function ii(e, t) {
    var n = e.alternate;
    return n === null ? (n = kn(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
}

function gu(e, t, n, r, i, s) {
    var o = 2;
    if (r = e, typeof e == "function") um(e) && (o = 1);
    else if (typeof e == "string") o = 5;
    else e: switch (e) {
        case Ss:
            return Ui(n.children, i, s, t);
        case kp:
            o = 8, i |= 8;
            break;
        case Ld:
            return e = kn(12, n, t, i | 2), e.elementType = Ld, e.lanes = s, e;
        case Md:
            return e = kn(13, n, t, i), e.elementType = Md, e.lanes = s, e;
        case Nd:
            return e = kn(19, n, t, i), e.elementType = Nd, e.lanes = s, e;
        case ax:
            return Mc(n, i, s, t);
        default:
            if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                case sx:
                    o = 10;
                    break e;
                case ox:
                    o = 9;
                    break e;
                case bp:
                    o = 11;
                    break e;
                case Rp:
                    o = 14;
                    break e;
                case zr:
                    o = 16, r = null;
                    break e
            }
            throw Error(I(130, e == null ? e : typeof e, ""))
    }
    return t = kn(o, n, t, i), t.elementType = e, t.type = r, t.lanes = s, t
}

function Ui(e, t, n, r) {
    return e = kn(7, e, r, t), e.lanes = n, e
}

function Mc(e, t, n, r) {
    return e = kn(22, e, r, t), e.elementType = ax, e.lanes = n, e.stateNode = {
        isHidden: !1
    }, e
}

function Jf(e, t, n) {
    return e = kn(6, e, null, t), e.lanes = n, e
}

function Zf(e, t, n) {
    return t = kn(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
    }, t
}

function Ak(e, t, n, r, i) {
    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Of(0), this.expirationTimes = Of(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Of(0), this.identifierPrefix = r, this.onRecoverableError = i, this.mutableSourceEagerHydrationData = null
}

function cm(e, t, n, r, i, s, o, a, l) {
    return e = new Ak(e, t, n, a, l), t === 1 ? (t = 1, s === !0 && (t |= 8)) : t = 0, s = kn(3, null, null, t), e.current = s, s.stateNode = e, s.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null
    }, Gp(s), e
}

function Dk(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
        $$typeof: ws,
        key: r == null ? null : "" + r,
        children: e,
        containerInfo: t,
        implementation: n
    }
}

function J_(e) {
    if (!e) return li;
    e = e._reactInternals;
    e: {
        if (ss(e) !== e || e.tag !== 1) throw Error(I(170));
        var t = e;do {
            switch (t.tag) {
                case 3:
                    t = t.stateNode.context;
                    break e;
                case 1:
                    if (Ht(t.type)) {
                        t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                        break e
                    }
            }
            t = t.return
        } while (t !== null);
        throw Error(I(171))
    }
    if (e.tag === 1) {
        var n = e.type;
        if (Ht(n)) return Jx(e, n, t)
    }
    return t
}

function Z_(e, t, n, r, i, s, o, a, l) {
    return e = cm(n, r, !0, e, i, s, o, a, l), e.context = J_(null), n = e.current, r = It(), i = ri(n), s = wr(r, i), s.callback = t ? ? null, ti(n, s, i), e.current.lanes = i, al(e, i, r), Kt(e, r), e
}

function Nc(e, t, n, r) {
    var i = t.current,
        s = It(),
        o = ri(i);
    return n = J_(n), t.context === null ? t.context = n : t.pendingContext = n, t = wr(s, o), t.payload = {
        element: e
    }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = ti(i, t, o), e !== null && (Un(e, i, o, s), cu(e, i, o)), o
}

function ec(e) {
    if (e = e.current, !e.child) return null;
    switch (e.child.tag) {
        case 5:
            return e.child.stateNode;
        default:
            return e.child.stateNode
    }
}

function Zy(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
    }
}

function fm(e, t) {
    Zy(e, t), (e = e.alternate) && Zy(e, t)
}

function jk() {
    return null
}
var ew = typeof reportError == "function" ? reportError : function(e) {
    console.error(e)
};

function dm(e) {
    this._internalRoot = e
}
Fc.prototype.render = dm.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null) throw Error(I(409));
    Nc(e, t, null, null)
};
Fc.prototype.unmount = dm.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        Zi(function() {
            Nc(null, e, null, null)
        }), t[Pr] = null
    }
};

function Fc(e) {
    this._internalRoot = e
}
Fc.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
        var t = Dx();
        e = {
            blockedOn: null,
            target: e,
            priority: t
        };
        for (var n = 0; n < $r.length && t !== 0 && t < $r[n].priority; n++);
        $r.splice(n, 0, e), n === 0 && Ox(e)
    }
};

function hm(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
}

function Ic(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
}

function e0() {}

function Ok(e, t, n, r, i) {
    if (i) {
        if (typeof r == "function") {
            var s = r;
            r = function() {
                var u = ec(o);
                s.call(u)
            }
        }
        var o = Z_(t, r, e, 0, null, !1, !1, "", e0);
        return e._reactRootContainer = o, e[Pr] = o.current, Aa(e.nodeType === 8 ? e.parentNode : e), Zi(), o
    }
    for (; i = e.lastChild;) e.removeChild(i);
    if (typeof r == "function") {
        var a = r;
        r = function() {
            var u = ec(l);
            a.call(u)
        }
    }
    var l = cm(e, 0, !1, null, null, !1, !1, "", e0);
    return e._reactRootContainer = l, e[Pr] = l.current, Aa(e.nodeType === 8 ? e.parentNode : e), Zi(function() {
        Nc(t, l, n, r)
    }), l
}

function Vc(e, t, n, r, i) {
    var s = n._reactRootContainer;
    if (s) {
        var o = s;
        if (typeof i == "function") {
            var a = i;
            i = function() {
                var l = ec(o);
                a.call(l)
            }
        }
        Nc(t, o, e, i)
    } else o = Ok(n, t, e, i, r);
    return ec(o)
}
Rx = function(e) {
    switch (e.tag) {
        case 3:
            var t = e.stateNode;
            if (t.current.memoizedState.isDehydrated) {
                var n = Xo(t.pendingLanes);
                n !== 0 && (jp(t, n | 1), Kt(t, Ze()), !(fe & 6) && (ro = Ze() + 500, gi()))
            }
            break;
        case 13:
            Zi(function() {
                var r = kr(e, 1);
                if (r !== null) {
                    var i = It();
                    Un(r, e, 1, i)
                }
            }), fm(e, 1)
    }
};
Op = function(e) {
    if (e.tag === 13) {
        var t = kr(e, 134217728);
        if (t !== null) {
            var n = It();
            Un(t, e, 134217728, n)
        }
        fm(e, 134217728)
    }
};
Ax = function(e) {
    if (e.tag === 13) {
        var t = ri(e),
            n = kr(e, t);
        if (n !== null) {
            var r = It();
            Un(n, e, t, r)
        }
        fm(e, t)
    }
};
Dx = function() {
    return ve
};
jx = function(e, t) {
    var n = ve;
    try {
        return ve = e, t()
    } finally {
        ve = n
    }
};
Kd = function(e, t, n) {
    switch (t) {
        case "input":
            if (Vd(e, n), t = n.name, n.type === "radio" && t != null) {
                for (n = e; n.parentNode;) n = n.parentNode;
                for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                    var r = n[t];
                    if (r !== e && r.form === e.form) {
                        var i = Rc(r);
                        if (!i) throw Error(I(90));
                        ux(r), Vd(r, i)
                    }
                }
            }
            break;
        case "textarea":
            fx(e, n);
            break;
        case "select":
            t = n.value, t != null && Bs(e, !!n.multiple, t, !1)
    }
};
vx = om;
xx = Zi;
var Lk = {
        usingClientEntryPoint: !1,
        Events: [ul, Ps, Rc, gx, yx, om]
    },
    Io = {
        findFiberByHostInstance: Li,
        bundleType: 0,
        version: "18.3.1",
        rendererPackageName: "react-dom"
    },
    Mk = {
        bundleType: Io.bundleType,
        version: Io.version,
        rendererPackageName: Io.rendererPackageName,
        rendererConfig: Io.rendererConfig,
        overrideHookState: null,
        overrideHookStateDeletePath: null,
        overrideHookStateRenamePath: null,
        overrideProps: null,
        overridePropsDeletePath: null,
        overridePropsRenamePath: null,
        setErrorHandler: null,
        setSuspenseHandler: null,
        scheduleUpdate: null,
        currentDispatcherRef: Lr.ReactCurrentDispatcher,
        findHostInstanceByFiber: function(e) {
            return e = Sx(e), e === null ? null : e.stateNode
        },
        findFiberByHostInstance: Io.findFiberByHostInstance || jk,
        findHostInstancesForRefresh: null,
        scheduleRefresh: null,
        scheduleRoot: null,
        setRefreshHandler: null,
        getCurrentFiber: null,
        reconcilerVersion: "18.3.1-next-f1338f8080-20240426"
    };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var Yl = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!Yl.isDisabled && Yl.supportsFiber) try {
        Ec = Yl.inject(Mk), rr = Yl
    } catch {}
}
vn.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Lk;
vn.createPortal = function(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!hm(t)) throw Error(I(200));
    return Dk(e, t, null, n)
};
vn.createRoot = function(e, t) {
    if (!hm(e)) throw Error(I(299));
    var n = !1,
        r = "",
        i = ew;
    return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (i = t.onRecoverableError)), t = cm(e, 1, !1, null, null, n, !1, r, i), e[Pr] = t.current, Aa(e.nodeType === 8 ? e.parentNode : e), new dm(t)
};
vn.findDOMNode = function(e) {
    if (e == null) return null;
    if (e.nodeType === 1) return e;
    var t = e._reactInternals;
    if (t === void 0) throw typeof e.render == "function" ? Error(I(188)) : (e = Object.keys(e).join(","), Error(I(268, e)));
    return e = Sx(t), e = e === null ? null : e.stateNode, e
};
vn.flushSync = function(e) {
    return Zi(e)
};
vn.hydrate = function(e, t, n) {
    if (!Ic(t)) throw Error(I(200));
    return Vc(null, e, t, !0, n)
};
vn.hydrateRoot = function(e, t, n) {
    if (!hm(e)) throw Error(I(405));
    var r = n != null && n.hydratedSources || null,
        i = !1,
        s = "",
        o = ew;
    if (n != null && (n.unstable_strictMode === !0 && (i = !0), n.identifierPrefix !== void 0 && (s = n.identifierPrefix), n.onRecoverableError !== void 0 && (o = n.onRecoverableError)), t = Z_(t, null, e, 1, n ? ? null, i, !1, s, o), e[Pr] = t.current, Aa(e), r)
        for (e = 0; e < r.length; e++) n = r[e], i = n._getVersion, i = i(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, i] : t.mutableSourceEagerHydrationData.push(n, i);
    return new Fc(t)
};
vn.render = function(e, t, n) {
    if (!Ic(t)) throw Error(I(200));
    return Vc(null, e, t, !1, n)
};
vn.unmountComponentAtNode = function(e) {
    if (!Ic(e)) throw Error(I(40));
    return e._reactRootContainer ? (Zi(function() {
        Vc(null, null, e, !1, function() {
            e._reactRootContainer = null, e[Pr] = null
        })
    }), !0) : !1
};
vn.unstable_batchedUpdates = om;
vn.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!Ic(n)) throw Error(I(200));
    if (e == null || e._reactInternals === void 0) throw Error(I(38));
    return Vc(e, t, n, !1, r)
};
vn.version = "18.3.1-next-f1338f8080-20240426";

function tw() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(tw)
    } catch (e) {
        console.error(e)
    }
}
tw(), tx.exports = vn;
var pm = tx.exports;
const Nk = z1(pm),
    Fk = U1({
        __proto__: null,
        default: Nk
    }, [pm]);
var t0 = pm;
jd.createRoot = t0.createRoot, jd.hydrateRoot = t0.hydrateRoot;
const Ik = "modulepreload",
    Vk = function(e) {
        return "/" + e
    },
    n0 = {},
    ce = function(t, n, r) {
        let i = Promise.resolve();
        if (n && n.length > 0) {
            document.getElementsByTagName("link");
            const o = document.querySelector("meta[property=csp-nonce]"),
                a = (o == null ? void 0 : o.nonce) || (o == null ? void 0 : o.getAttribute("nonce"));
            i = Promise.allSettled(n.map(l => {
                if (l = Vk(l), l in n0) return;
                n0[l] = !0;
                const u = l.endsWith(".css"),
                    c = u ? '[rel="stylesheet"]' : "";
                if (document.querySelector(`link[href="${l}"]${c}`)) return;
                const f = document.createElement("link");
                if (f.rel = u ? "stylesheet" : Ik, u || (f.as = "script"), f.crossOrigin = "", f.href = l, a && f.setAttribute("nonce", a), document.head.appendChild(f), u) return new Promise((d, p) => {
                    f.addEventListener("load", d), f.addEventListener("error", () => p(new Error(`Unable to preload CSS for ${l}`)))
                })
            }))
        }

        function s(o) {
            const a = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (a.payload = o, window.dispatchEvent(a), !a.defaultPrevented) throw o
        }
        return i.then(o => {
            for (const a of o || []) a.status === "rejected" && s(a.reason);
            return t().catch(s)
        })
    };
/**
 * @remix-run/router v1.22.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function Oe() {
    return Oe = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, Oe.apply(this, arguments)
}
var rt;
(function(e) {
    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
})(rt || (rt = {}));
const r0 = "popstate";

function Bk(e) {
    e === void 0 && (e = {});

    function t(r, i) {
        let {
            pathname: s,
            search: o,
            hash: a
        } = r.location;
        return Va("", {
            pathname: s,
            search: o,
            hash: a
        }, i.state && i.state.usr || null, i.state && i.state.key || "default")
    }

    function n(r, i) {
        return typeof i == "string" ? i : es(i)
    }
    return Uk(t, n, null, e)
}

function se(e, t) {
    if (e === !1 || e === null || typeof e > "u") throw new Error(t)
}

function io(e, t) {
    if (!e) {
        typeof console < "u" && console.warn(t);
        try {
            throw new Error(t)
        } catch {}
    }
}

function zk() {
    return Math.random().toString(36).substr(2, 8)
}

function i0(e, t) {
    return {
        usr: e.state,
        key: e.key,
        idx: t
    }
}

function Va(e, t, n, r) {
    return n === void 0 && (n = null), Oe({
        pathname: typeof e == "string" ? e : e.pathname,
        search: "",
        hash: ""
    }, typeof t == "string" ? yi(t) : t, {
        state: n,
        key: t && t.key || r || zk()
    })
}

function es(e) {
    let {
        pathname: t = "/",
        search: n = "",
        hash: r = ""
    } = e;
    return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t
}

function yi(e) {
    let t = {};
    if (e) {
        let n = e.indexOf("#");
        n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
        let r = e.indexOf("?");
        r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
    }
    return t
}

function Uk(e, t, n, r) {
    r === void 0 && (r = {});
    let {
        window: i = document.defaultView,
        v5Compat: s = !1
    } = r, o = i.history, a = rt.Pop, l = null, u = c();
    u == null && (u = 0, o.replaceState(Oe({}, o.state, {
        idx: u
    }), ""));

    function c() {
        return (o.state || {
            idx: null
        }).idx
    }

    function f() {
        a = rt.Pop;
        let _ = c(),
            v = _ == null ? null : _ - u;
        u = _, l && l({
            action: a,
            location: h.location,
            delta: v
        })
    }

    function d(_, v) {
        a = rt.Push;
        let y = Va(h.location, _, v);
        u = c() + 1;
        let x = i0(y, u),
            T = h.createHref(y);
        try {
            o.pushState(x, "", T)
        } catch (E) {
            if (E instanceof DOMException && E.name === "DataCloneError") throw E;
            i.location.assign(T)
        }
        s && l && l({
            action: a,
            location: h.location,
            delta: 1
        })
    }

    function p(_, v) {
        a = rt.Replace;
        let y = Va(h.location, _, v);
        u = c();
        let x = i0(y, u),
            T = h.createHref(y);
        o.replaceState(x, "", T), s && l && l({
            action: a,
            location: h.location,
            delta: 0
        })
    }

    function m(_) {
        let v = i.location.origin !== "null" ? i.location.origin : i.location.href,
            y = typeof _ == "string" ? _ : es(_);
        return y = y.replace(/ $/, "%20"), se(v, "No window.location.(origin|href) available to create URL for href: " + y), new URL(y, v)
    }
    let h = {
        get action() {
            return a
        },
        get location() {
            return e(i, o)
        },
        listen(_) {
            if (l) throw new Error("A history only accepts one active listener");
            return i.addEventListener(r0, f), l = _, () => {
                i.removeEventListener(r0, f), l = null
            }
        },
        createHref(_) {
            return t(i, _)
        },
        createURL: m,
        encodeLocation(_) {
            let v = m(_);
            return {
                pathname: v.pathname,
                search: v.search,
                hash: v.hash
            }
        },
        push: d,
        replace: p,
        go(_) {
            return o.go(_)
        }
    };
    return h
}
var ye;
(function(e) {
    e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
})(ye || (ye = {}));
const $k = new Set(["lazy", "caseSensitive", "path", "id", "index", "children"]);

function Wk(e) {
    return e.index === !0
}

function tc(e, t, n, r) {
    return n === void 0 && (n = []), r === void 0 && (r = {}), e.map((i, s) => {
        let o = [...n, String(s)],
            a = typeof i.id == "string" ? i.id : o.join("-");
        if (se(i.index !== !0 || !i.children, "Cannot specify children on an index route"), se(!r[a], 'Found a route id collision on id "' + a + `".  Route id's must be globally unique within Data Router usages`), Wk(i)) {
            let l = Oe({}, i, t(i), {
                id: a
            });
            return r[a] = l, l
        } else {
            let l = Oe({}, i, t(i), {
                id: a,
                children: void 0
            });
            return r[a] = l, i.children && (l.children = tc(i.children, t, o, r)), l
        }
    })
}

function Di(e, t, n) {
    return n === void 0 && (n = "/"), yu(e, t, n, !1)
}

function yu(e, t, n, r) {
    let i = typeof t == "string" ? yi(t) : t,
        s = Rr(i.pathname || "/", n);
    if (s == null) return null;
    let o = nw(e);
    Kk(o);
    let a = null;
    for (let l = 0; a == null && l < o.length; ++l) {
        let u = rb(s);
        a = tb(o[l], u, r)
    }
    return a
}

function Hk(e, t) {
    let {
        route: n,
        pathname: r,
        params: i
    } = e;
    return {
        id: n.id,
        pathname: r,
        params: i,
        data: t[n.id],
        handle: n.handle
    }
}

function nw(e, t, n, r) {
    t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
    let i = (s, o, a) => {
        let l = {
            relativePath: a === void 0 ? s.path || "" : a,
            caseSensitive: s.caseSensitive === !0,
            childrenIndex: o,
            route: s
        };
        l.relativePath.startsWith("/") && (se(l.relativePath.startsWith(r), 'Absolute route path "' + l.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), l.relativePath = l.relativePath.slice(r.length));
        let u = Sr([r, l.relativePath]),
            c = n.concat(l);
        s.children && s.children.length > 0 && (se(s.index !== !0, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + u + '".')), nw(s.children, t, c, u)), !(s.path == null && !s.index) && t.push({
            path: u,
            score: Zk(u, s.index),
            routesMeta: c
        })
    };
    return e.forEach((s, o) => {
        var a;
        if (s.path === "" || !((a = s.path) != null && a.includes("?"))) i(s, o);
        else
            for (let l of rw(s.path)) i(s, o, l)
    }), t
}

function rw(e) {
    let t = e.split("/");
    if (t.length === 0) return [];
    let [n, ...r] = t, i = n.endsWith("?"), s = n.replace(/\?$/, "");
    if (r.length === 0) return i ? [s, ""] : [s];
    let o = rw(r.join("/")),
        a = [];
    return a.push(...o.map(l => l === "" ? s : [s, l].join("/"))), i && a.push(...o), a.map(l => e.startsWith("/") && l === "" ? "/" : l)
}

function Kk(e) {
    e.sort((t, n) => t.score !== n.score ? n.score - t.score : eb(t.routesMeta.map(r => r.childrenIndex), n.routesMeta.map(r => r.childrenIndex)))
}
const Gk = /^:[\w-]+$/,
    Yk = 3,
    Xk = 2,
    qk = 1,
    Qk = 10,
    Jk = -2,
    s0 = e => e === "*";

function Zk(e, t) {
    let n = e.split("/"),
        r = n.length;
    return n.some(s0) && (r += Jk), t && (r += Xk), n.filter(i => !s0(i)).reduce((i, s) => i + (Gk.test(s) ? Yk : s === "" ? qk : Qk), r)
}

function eb(e, t) {
    return e.length === t.length && e.slice(0, -1).every((r, i) => r === t[i]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function tb(e, t, n) {
    n === void 0 && (n = !1);
    let {
        routesMeta: r
    } = e, i = {}, s = "/", o = [];
    for (let a = 0; a < r.length; ++a) {
        let l = r[a],
            u = a === r.length - 1,
            c = s === "/" ? t : t.slice(s.length) || "/",
            f = nc({
                path: l.relativePath,
                caseSensitive: l.caseSensitive,
                end: u
            }, c),
            d = l.route;
        if (!f && u && n && !r[r.length - 1].route.index && (f = nc({
                path: l.relativePath,
                caseSensitive: l.caseSensitive,
                end: !1
            }, c)), !f) return null;
        Object.assign(i, f.params), o.push({
            params: i,
            pathname: Sr([s, f.pathname]),
            pathnameBase: ob(Sr([s, f.pathnameBase])),
            route: d
        }), f.pathnameBase !== "/" && (s = Sr([s, f.pathnameBase]))
    }
    return o
}

function nc(e, t) {
    typeof e == "string" && (e = {
        path: e,
        caseSensitive: !1,
        end: !0
    });
    let [n, r] = nb(e.path, e.caseSensitive, e.end), i = t.match(n);
    if (!i) return null;
    let s = i[0],
        o = s.replace(/(.)\/+$/, "$1"),
        a = i.slice(1);
    return {
        params: r.reduce((u, c, f) => {
            let {
                paramName: d,
                isOptional: p
            } = c;
            if (d === "*") {
                let h = a[f] || "";
                o = s.slice(0, s.length - h.length).replace(/(.)\/+$/, "$1")
            }
            const m = a[f];
            return p && !m ? u[d] = void 0 : u[d] = (m || "").replace(/%2F/g, "/"), u
        }, {}),
        pathname: s,
        pathnameBase: o,
        pattern: e
    }
}

function nb(e, t, n) {
    t === void 0 && (t = !1), n === void 0 && (n = !0), io(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
    let r = [],
        i = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (o, a, l) => (r.push({
            paramName: a,
            isOptional: l != null
        }), l ? "/?([^\\/]+)?" : "/([^\\/]+)"));
    return e.endsWith("*") ? (r.push({
        paramName: "*"
    }), i += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? i += "\\/*$" : e !== "" && e !== "/" && (i += "(?:(?=\\/|$))"), [new RegExp(i, t ? void 0 : "i"), r]
}

function rb(e) {
    try {
        return e.split("/").map(t => decodeURIComponent(t).replace(/\//g, "%2F")).join("/")
    } catch (t) {
        return io(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e
    }
}

function Rr(e, t) {
    if (t === "/") return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = t.endsWith("/") ? t.length - 1 : t.length,
        r = e.charAt(n);
    return r && r !== "/" ? null : e.slice(n) || "/"
}

function ib(e, t) {
    t === void 0 && (t = "/");
    let {
        pathname: n,
        search: r = "",
        hash: i = ""
    } = typeof e == "string" ? yi(e) : e;
    return {
        pathname: n ? n.startsWith("/") ? n : sb(n, t) : t,
        search: ab(r),
        hash: lb(i)
    }
}

function sb(e, t) {
    let n = t.replace(/\/+$/, "").split("/");
    return e.split("/").forEach(i => {
        i === ".." ? n.length > 1 && n.pop() : i !== "." && n.push(i)
    }), n.length > 1 ? n.join("/") : "/"
}

function ed(e, t, n, r) {
    return "Cannot include a '" + e + "' character in a manually specified " + ("`to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the ") + ("`to." + n + "` field. Alternatively you may provide the full path as ") + 'a string in <Link to="..."> and the router will parse it for you.'
}

function iw(e) {
    return e.filter((t, n) => n === 0 || t.route.path && t.route.path.length > 0)
}

function mm(e, t) {
    let n = iw(e);
    return t ? n.map((r, i) => i === n.length - 1 ? r.pathname : r.pathnameBase) : n.map(r => r.pathnameBase)
}

function gm(e, t, n, r) {
    r === void 0 && (r = !1);
    let i;
    typeof e == "string" ? i = yi(e) : (i = Oe({}, e), se(!i.pathname || !i.pathname.includes("?"), ed("?", "pathname", "search", i)), se(!i.pathname || !i.pathname.includes("#"), ed("#", "pathname", "hash", i)), se(!i.search || !i.search.includes("#"), ed("#", "search", "hash", i)));
    let s = e === "" || i.pathname === "",
        o = s ? "/" : i.pathname,
        a;
    if (o == null) a = n;
    else {
        let f = t.length - 1;
        if (!r && o.startsWith("..")) {
            let d = o.split("/");
            for (; d[0] === "..";) d.shift(), f -= 1;
            i.pathname = d.join("/")
        }
        a = f >= 0 ? t[f] : "/"
    }
    let l = ib(i, a),
        u = o && o !== "/" && o.endsWith("/"),
        c = (s || o === ".") && n.endsWith("/");
    return !l.pathname.endsWith("/") && (u || c) && (l.pathname += "/"), l
}
const Sr = e => e.join("/").replace(/\/\/+/g, "/"),
    ob = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
    ab = e => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e,
    lb = e => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e;
class rc {
    constructor(t, n, r, i) {
        i === void 0 && (i = !1), this.status = t, this.statusText = n || "", this.internal = i, r instanceof Error ? (this.data = r.toString(), this.error = r) : this.data = r
    }
}

function Ba(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e
}
const sw = ["post", "put", "patch", "delete"],
    ub = new Set(sw),
    cb = ["get", ...sw],
    fb = new Set(cb),
    db = new Set([301, 302, 303, 307, 308]),
    hb = new Set([307, 308]),
    td = {
        state: "idle",
        location: void 0,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    },
    pb = {
        state: "idle",
        data: void 0,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    },
    Vo = {
        state: "unblocked",
        proceed: void 0,
        reset: void 0,
        location: void 0
    },
    ym = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
    mb = e => ({
        hasErrorBoundary: !!e.hasErrorBoundary
    }),
    ow = "remix-router-transitions";

function gb(e) {
    const t = e.window ? e.window : typeof window < "u" ? window : void 0,
        n = typeof t < "u" && typeof t.document < "u" && typeof t.document.createElement < "u",
        r = !n;
    se(e.routes.length > 0, "You must provide a non-empty routes array to createRouter");
    let i;
    if (e.mapRouteProperties) i = e.mapRouteProperties;
    else if (e.detectErrorBoundary) {
        let b = e.detectErrorBoundary;
        i = R => ({
            hasErrorBoundary: b(R)
        })
    } else i = mb;
    let s = {},
        o = tc(e.routes, i, void 0, s),
        a, l = e.basename || "/",
        u = e.dataStrategy || _b,
        c = e.patchRoutesOnNavigation,
        f = Oe({
            v7_fetcherPersist: !1,
            v7_normalizeFormMethod: !1,
            v7_partialHydration: !1,
            v7_prependBasename: !1,
            v7_relativeSplatPath: !1,
            v7_skipActionErrorRevalidation: !1
        }, e.future),
        d = null,
        p = new Set,
        m = null,
        h = null,
        _ = null,
        v = e.hydrationData != null,
        y = Di(o, e.history.location, l),
        x = !1,
        T = null;
    if (y == null && !c) {
        let b = zt(404, {
                pathname: e.history.location.pathname
            }),
            {
                matches: R,
                route: D
            } = g0(o);
        y = R, T = {
            [D.id]: b
        }
    }
    y && !e.hydrationData && bl(y, o, e.history.location.pathname).active && (y = null);
    let E;
    if (y)
        if (y.some(b => b.route.lazy)) E = !1;
        else if (!y.some(b => b.route.loader)) E = !0;
    else if (f.v7_partialHydration) {
        let b = e.hydrationData ? e.hydrationData.loaderData : null,
            R = e.hydrationData ? e.hydrationData.errors : null;
        if (R) {
            let D = y.findIndex(N => R[N.route.id] !== void 0);
            E = y.slice(0, D + 1).every(N => !Ph(N.route, b, R))
        } else E = y.every(D => !Ph(D.route, b, R))
    } else E = e.hydrationData != null;
    else if (E = !1, y = [], f.v7_partialHydration) {
        let b = bl(null, o, e.history.location.pathname);
        b.active && b.matches && (x = !0, y = b.matches)
    }
    let k, S = {
            historyAction: e.history.action,
            location: e.history.location,
            matches: y,
            initialized: E,
            navigation: td,
            restoreScrollPosition: e.hydrationData != null ? !1 : null,
            preventScrollReset: !1,
            revalidation: "idle",
            loaderData: e.hydrationData && e.hydrationData.loaderData || {},
            actionData: e.hydrationData && e.hydrationData.actionData || null,
            errors: e.hydrationData && e.hydrationData.errors || T,
            fetchers: new Map,
            blockers: new Map
        },
        P = rt.Pop,
        A = !1,
        w, O = !1,
        F = new Map,
        V = null,
        W = !1,
        Z = !1,
        re = [],
        q = new Set,
        M = new Map,
        B = 0,
        H = -1,
        ie = new Map,
        ne = new Set,
        St = new Map,
        xe = new Map,
        ke = new Set,
        ct = new Map,
        Lt = new Map,
        _n;

    function wi() {
        if (d = e.history.listen(b => {
                let {
                    action: R,
                    location: D,
                    delta: N
                } = b;
                if (_n) {
                    _n(), _n = void 0;
                    return
                }
                io(Lt.size === 0 || N != null, "You are trying to use a blocker on a POP navigation to a location that was not created by @remix-run/router. This will fail silently in production. This can happen if you are navigating outside the router via `window.history.pushState`/`window.location.hash` instead of using router navigation APIs.  This can also happen if you are using createHashRouter and the user manually changes the URL.");
                let z = $g({
                    currentLocation: S.location,
                    nextLocation: D,
                    historyAction: R
                });
                if (z && N != null) {
                    let Y = new Promise(ee => {
                        _n = ee
                    });
                    e.history.go(N * -1), kl(z, {
                        state: "blocked",
                        location: D,
                        proceed() {
                            kl(z, {
                                state: "proceeding",
                                proceed: void 0,
                                reset: void 0,
                                location: D
                            }), Y.then(() => e.history.go(N))
                        },
                        reset() {
                            let ee = new Map(S.blockers);
                            ee.set(z, Vo), ft({
                                blockers: ee
                            })
                        }
                    });
                    return
                }
                return Ne(R, D)
            }), n) {
            Lb(t, F);
            let b = () => Mb(t, F);
            t.addEventListener("pagehide", b), V = () => t.removeEventListener("pagehide", b)
        }
        return S.initialized || Ne(rt.Pop, S.location, {
            initialHydration: !0
        }), k
    }

    function us() {
        d && d(), V && V(), p.clear(), w && w.abort(), S.fetchers.forEach((b, R) => Pl(R)), S.blockers.forEach((b, R) => Ug(R))
    }

    function Cl(b) {
        return p.add(b), () => p.delete(b)
    }

    function ft(b, R) {
        R === void 0 && (R = {}), S = Oe({}, S, b);
        let D = [],
            N = [];
        f.v7_fetcherPersist && S.fetchers.forEach((z, Y) => {
            z.state === "idle" && (ke.has(Y) ? N.push(Y) : D.push(Y))
        }), ke.forEach(z => {
            !S.fetchers.has(z) && !M.has(z) && N.push(z)
        }), [...p].forEach(z => z(S, {
            deletedFetchers: N,
            viewTransitionOpts: R.viewTransitionOpts,
            flushSync: R.flushSync === !0
        })), f.v7_fetcherPersist ? (D.forEach(z => S.fetchers.delete(z)), N.forEach(z => Pl(z))) : N.forEach(z => ke.delete(z))
    }

    function Hn(b, R, D) {
        var N, z;
        let {
            flushSync: Y
        } = D === void 0 ? {} : D, ee = S.actionData != null && S.navigation.formMethod != null && Vn(S.navigation.formMethod) && S.navigation.state === "loading" && ((N = b.state) == null ? void 0 : N._isRedirect) !== !0, K;
        R.actionData ? Object.keys(R.actionData).length > 0 ? K = R.actionData : K = null : ee ? K = S.actionData : K = null;
        let G = R.loaderData ? p0(S.loaderData, R.loaderData, R.matches || [], R.errors) : S.loaderData,
            $ = S.blockers;
        $.size > 0 && ($ = new Map($), $.forEach((ue, mt) => $.set(mt, Vo)));
        let X = A === !0 || S.navigation.formMethod != null && Vn(S.navigation.formMethod) && ((z = b.state) == null ? void 0 : z._isRedirect) !== !0;
        a && (o = a, a = void 0), W || P === rt.Pop || (P === rt.Push ? e.history.push(b, b.state) : P === rt.Replace && e.history.replace(b, b.state));
        let oe;
        if (P === rt.Pop) {
            let ue = F.get(S.location.pathname);
            ue && ue.has(b.pathname) ? oe = {
                currentLocation: S.location,
                nextLocation: b
            } : F.has(b.pathname) && (oe = {
                currentLocation: b,
                nextLocation: S.location
            })
        } else if (O) {
            let ue = F.get(S.location.pathname);
            ue ? ue.add(b.pathname) : (ue = new Set([b.pathname]), F.set(S.location.pathname, ue)), oe = {
                currentLocation: S.location,
                nextLocation: b
            }
        }
        ft(Oe({}, R, {
            actionData: K,
            loaderData: G,
            historyAction: P,
            location: b,
            initialized: !0,
            navigation: td,
            revalidation: "idle",
            restoreScrollPosition: Hg(b, R.matches || S.matches),
            preventScrollReset: X,
            blockers: $
        }), {
            viewTransitionOpts: oe,
            flushSync: Y === !0
        }), P = rt.Pop, A = !1, O = !1, W = !1, Z = !1, re = []
    }
    async function J(b, R) {
        if (typeof b == "number") {
            e.history.go(b);
            return
        }
        let D = Eh(S.location, S.matches, l, f.v7_prependBasename, b, f.v7_relativeSplatPath, R == null ? void 0 : R.fromRouteId, R == null ? void 0 : R.relative),
            {
                path: N,
                submission: z,
                error: Y
            } = o0(f.v7_normalizeFormMethod, !1, D, R),
            ee = S.location,
            K = Va(S.location, N, R && R.state);
        K = Oe({}, K, e.history.encodeLocation(K));
        let G = R && R.replace != null ? R.replace : void 0,
            $ = rt.Push;
        G === !0 ? $ = rt.Replace : G === !1 || z != null && Vn(z.formMethod) && z.formAction === S.location.pathname + S.location.search && ($ = rt.Replace);
        let X = R && "preventScrollReset" in R ? R.preventScrollReset === !0 : void 0,
            oe = (R && R.flushSync) === !0,
            ue = $g({
                currentLocation: ee,
                nextLocation: K,
                historyAction: $
            });
        if (ue) {
            kl(ue, {
                state: "blocked",
                location: K,
                proceed() {
                    kl(ue, {
                        state: "proceeding",
                        proceed: void 0,
                        reset: void 0,
                        location: K
                    }), J(b, R)
                },
                reset() {
                    let mt = new Map(S.blockers);
                    mt.set(ue, Vo), ft({
                        blockers: mt
                    })
                }
            });
            return
        }
        return await Ne($, K, {
            submission: z,
            pendingError: Y,
            preventScrollReset: X,
            replace: R && R.replace,
            enableViewTransition: R && R.viewTransition,
            flushSync: oe
        })
    }

    function be() {
        if (Tf(), ft({
                revalidation: "loading"
            }), S.navigation.state !== "submitting") {
            if (S.navigation.state === "idle") {
                Ne(S.historyAction, S.location, {
                    startUninterruptedRevalidation: !0
                });
                return
            }
            Ne(P || S.historyAction, S.navigation.location, {
                overrideNavigation: S.navigation,
                enableViewTransition: O === !0
            })
        }
    }
    async function Ne(b, R, D) {
        w && w.abort(), w = null, P = b, W = (D && D.startUninterruptedRevalidation) === !0, aE(S.location, S.matches), A = (D && D.preventScrollReset) === !0, O = (D && D.enableViewTransition) === !0;
        let N = a || o,
            z = D && D.overrideNavigation,
            Y = D != null && D.initialHydration && S.matches && S.matches.length > 0 && !x ? S.matches : Di(N, R, l),
            ee = (D && D.flushSync) === !0,
            K = bl(Y, N, R.pathname);
        if (K.active && K.matches && (Y = K.matches), !Y) {
            let {
                error: Te,
                notFoundMatches: he,
                route: $e
            } = Ef(R.pathname);
            Hn(R, {
                matches: he,
                loaderData: {},
                errors: {
                    [$e.id]: Te
                }
            }, {
                flushSync: ee
            });
            return
        }
        if (S.initialized && !Z && Pb(S.location, R) && !(D && D.submission && Vn(D.submission.formMethod))) {
            Hn(R, {
                matches: Y
            }, {
                flushSync: ee
            });
            return
        }
        w = new AbortController;
        let G = ps(e.history, R, w.signal, D && D.submission),
            $;
        if (D && D.pendingError) $ = [ji(Y).route.id, {
            type: ye.error,
            error: D.pendingError
        }];
        else if (D && D.submission && Vn(D.submission.formMethod)) {
            let Te = await Ln(G, R, D.submission, Y, K.active, {
                replace: D.replace,
                flushSync: ee
            });
            if (Te.shortCircuited) return;
            if (Te.pendingActionResult) {
                let [he, $e] = Te.pendingActionResult;
                if (nn($e) && Ba($e.error) && $e.error.status === 404) {
                    w = null, Hn(R, {
                        matches: Te.matches,
                        loaderData: {},
                        errors: {
                            [he]: $e.error
                        }
                    });
                    return
                }
            }
            Y = Te.matches || Y, $ = Te.pendingActionResult, z = nd(R, D.submission), ee = !1, K.active = !1, G = ps(e.history, G.url, G.signal)
        }
        let {
            shortCircuited: X,
            matches: oe,
            loaderData: ue,
            errors: mt
        } = await Tl(G, R, Y, K.active, z, D && D.submission, D && D.fetcherSubmission, D && D.replace, D && D.initialHydration === !0, ee, $);
        X || (w = null, Hn(R, Oe({
            matches: oe || Y
        }, m0($), {
            loaderData: ue,
            errors: mt
        })))
    }
    async function Ln(b, R, D, N, z, Y) {
        Y === void 0 && (Y = {}), Tf();
        let ee = jb(R, D);
        if (ft({
                navigation: ee
            }, {
                flushSync: Y.flushSync === !0
            }), z) {
            let $ = await Rl(N, R.pathname, b.signal);
            if ($.type === "aborted") return {
                shortCircuited: !0
            };
            if ($.type === "error") {
                let X = ji($.partialMatches).route.id;
                return {
                    matches: $.partialMatches,
                    pendingActionResult: [X, {
                        type: ye.error,
                        error: $.error
                    }]
                }
            } else if ($.matches) N = $.matches;
            else {
                let {
                    notFoundMatches: X,
                    error: oe,
                    route: ue
                } = Ef(R.pathname);
                return {
                    matches: X,
                    pendingActionResult: [ue.id, {
                        type: ye.error,
                        error: oe
                    }]
                }
            }
        }
        let K, G = Qo(N, R);
        if (!G.route.action && !G.route.lazy) K = {
            type: ye.error,
            error: zt(405, {
                method: b.method,
                pathname: R.pathname,
                routeId: G.route.id
            })
        };
        else if (K = (await ko("action", S, b, [G], N, null))[G.route.id], b.signal.aborted) return {
            shortCircuited: !0
        };
        if (Fi(K)) {
            let $;
            return Y && Y.replace != null ? $ = Y.replace : $ = f0(K.response.headers.get("Location"), new URL(b.url), l) === S.location.pathname + S.location.search, await Si(b, K, !0, {
                submission: D,
                replace: $
            }), {
                shortCircuited: !0
            }
        }
        if (Gr(K)) throw zt(400, {
            type: "defer-action"
        });
        if (nn(K)) {
            let $ = ji(N, G.route.id);
            return (Y && Y.replace) !== !0 && (P = rt.Push), {
                matches: N,
                pendingActionResult: [$.route.id, K]
            }
        }
        return {
            matches: N,
            pendingActionResult: [G.route.id, K]
        }
    }
    async function Tl(b, R, D, N, z, Y, ee, K, G, $, X) {
        let oe = z || nd(R, Y),
            ue = Y || ee || v0(oe),
            mt = !W && (!f.v7_partialHydration || !G);
        if (N) {
            if (mt) {
                let We = El(X);
                ft(Oe({
                    navigation: oe
                }, We !== void 0 ? {
                    actionData: We
                } : {}), {
                    flushSync: $
                })
            }
            let de = await Rl(D, R.pathname, b.signal);
            if (de.type === "aborted") return {
                shortCircuited: !0
            };
            if (de.type === "error") {
                let We = ji(de.partialMatches).route.id;
                return {
                    matches: de.partialMatches,
                    loaderData: {},
                    errors: {
                        [We]: de.error
                    }
                }
            } else if (de.matches) D = de.matches;
            else {
                let {
                    error: We,
                    notFoundMatches: fs,
                    route: Ao
                } = Ef(R.pathname);
                return {
                    matches: fs,
                    loaderData: {},
                    errors: {
                        [Ao.id]: We
                    }
                }
            }
        }
        let Te = a || o,
            [he, $e] = l0(e.history, S, D, ue, R, f.v7_partialHydration && G === !0, f.v7_skipActionErrorRevalidation, Z, re, q, ke, St, ne, Te, l, X);
        if (Pf(de => !(D && D.some(We => We.route.id === de)) || he && he.some(We => We.route.id === de)), H = ++B, he.length === 0 && $e.length === 0) {
            let de = Bg();
            return Hn(R, Oe({
                matches: D,
                loaderData: {},
                errors: X && nn(X[1]) ? {
                    [X[0]]: X[1].error
                } : null
            }, m0(X), de ? {
                fetchers: new Map(S.fetchers)
            } : {}), {
                flushSync: $
            }), {
                shortCircuited: !0
            }
        }
        if (mt) {
            let de = {};
            if (!N) {
                de.navigation = oe;
                let We = El(X);
                We !== void 0 && (de.actionData = We)
            }
            $e.length > 0 && (de.fetchers = eE($e)), ft(de, {
                flushSync: $
            })
        }
        $e.forEach(de => {
            Fr(de.key), de.controller && M.set(de.key, de.controller)
        });
        let cs = () => $e.forEach(de => Fr(de.key));
        w && w.signal.addEventListener("abort", cs);
        let {
            loaderResults: bo,
            fetcherResults: dr
        } = await Fg(S, D, he, $e, b);
        if (b.signal.aborted) return {
            shortCircuited: !0
        };
        w && w.signal.removeEventListener("abort", cs), $e.forEach(de => M.delete(de.key));
        let Kn = Xl(bo);
        if (Kn) return await Si(b, Kn.result, !0, {
            replace: K
        }), {
            shortCircuited: !0
        };
        if (Kn = Xl(dr), Kn) return ne.add(Kn.key), await Si(b, Kn.result, !0, {
            replace: K
        }), {
            shortCircuited: !0
        };
        let {
            loaderData: kf,
            errors: Ro
        } = h0(S, D, bo, X, $e, dr, ct);
        ct.forEach((de, We) => {
            de.subscribe(fs => {
                (fs || de.done) && ct.delete(We)
            })
        }), f.v7_partialHydration && G && S.errors && (Ro = Oe({}, S.errors, Ro));
        let Ci = Bg(),
            Al = zg(H),
            Dl = Ci || Al || $e.length > 0;
        return Oe({
            matches: D,
            loaderData: kf,
            errors: Ro
        }, Dl ? {
            fetchers: new Map(S.fetchers)
        } : {})
    }

    function El(b) {
        if (b && !nn(b[1])) return {
            [b[0]]: b[1].data
        };
        if (S.actionData) return Object.keys(S.actionData).length === 0 ? null : S.actionData
    }

    function eE(b) {
        return b.forEach(R => {
            let D = S.fetchers.get(R.key),
                N = Bo(void 0, D ? D.data : void 0);
            S.fetchers.set(R.key, N)
        }), new Map(S.fetchers)
    }

    function tE(b, R, D, N) {
        if (r) throw new Error("router.fetch() was called during the server render, but it shouldn't be. You are likely calling a useFetcher() method in the body of your component. Try moving it to a useEffect or a callback.");
        Fr(b);
        let z = (N && N.flushSync) === !0,
            Y = a || o,
            ee = Eh(S.location, S.matches, l, f.v7_prependBasename, D, f.v7_relativeSplatPath, R, N == null ? void 0 : N.relative),
            K = Di(Y, ee, l),
            G = bl(K, Y, ee);
        if (G.active && G.matches && (K = G.matches), !K) {
            fr(b, R, zt(404, {
                pathname: ee
            }), {
                flushSync: z
            });
            return
        }
        let {
            path: $,
            submission: X,
            error: oe
        } = o0(f.v7_normalizeFormMethod, !0, ee, N);
        if (oe) {
            fr(b, R, oe, {
                flushSync: z
            });
            return
        }
        let ue = Qo(K, $),
            mt = (N && N.preventScrollReset) === !0;
        if (X && Vn(X.formMethod)) {
            nE(b, R, $, ue, K, G.active, z, mt, X);
            return
        }
        St.set(b, {
            routeId: R,
            path: $
        }), rE(b, R, $, ue, K, G.active, z, mt, X)
    }
    async function nE(b, R, D, N, z, Y, ee, K, G) {
        Tf(), St.delete(b);

        function $(nt) {
            if (!nt.route.action && !nt.route.lazy) {
                let ds = zt(405, {
                    method: G.formMethod,
                    pathname: D,
                    routeId: R
                });
                return fr(b, R, ds, {
                    flushSync: ee
                }), !0
            }
            return !1
        }
        if (!Y && $(N)) return;
        let X = S.fetchers.get(b);
        Nr(b, Ob(G, X), {
            flushSync: ee
        });
        let oe = new AbortController,
            ue = ps(e.history, D, oe.signal, G);
        if (Y) {
            let nt = await Rl(z, new URL(ue.url).pathname, ue.signal);
            if (nt.type === "aborted") return;
            if (nt.type === "error") {
                fr(b, R, nt.error, {
                    flushSync: ee
                });
                return
            } else if (nt.matches) {
                if (z = nt.matches, N = Qo(z, D), $(N)) return
            } else {
                fr(b, R, zt(404, {
                    pathname: D
                }), {
                    flushSync: ee
                });
                return
            }
        }
        M.set(b, oe);
        let mt = B,
            he = (await ko("action", S, ue, [N], z, b))[N.route.id];
        if (ue.signal.aborted) {
            M.get(b) === oe && M.delete(b);
            return
        }
        if (f.v7_fetcherPersist && ke.has(b)) {
            if (Fi(he) || nn(he)) {
                Nr(b, Vr(void 0));
                return
            }
        } else {
            if (Fi(he))
                if (M.delete(b), H > mt) {
                    Nr(b, Vr(void 0));
                    return
                } else return ne.add(b), Nr(b, Bo(G)), Si(ue, he, !1, {
                    fetcherSubmission: G,
                    preventScrollReset: K
                });
            if (nn(he)) {
                fr(b, R, he.error);
                return
            }
        }
        if (Gr(he)) throw zt(400, {
            type: "defer-action"
        });
        let $e = S.navigation.location || S.location,
            cs = ps(e.history, $e, oe.signal),
            bo = a || o,
            dr = S.navigation.state !== "idle" ? Di(bo, S.navigation.location, l) : S.matches;
        se(dr, "Didn't find any matches after fetcher action");
        let Kn = ++B;
        ie.set(b, Kn);
        let kf = Bo(G, he.data);
        S.fetchers.set(b, kf);
        let [Ro, Ci] = l0(e.history, S, dr, G, $e, !1, f.v7_skipActionErrorRevalidation, Z, re, q, ke, St, ne, bo, l, [N.route.id, he]);
        Ci.filter(nt => nt.key !== b).forEach(nt => {
            let ds = nt.key,
                Kg = S.fetchers.get(ds),
                cE = Bo(void 0, Kg ? Kg.data : void 0);
            S.fetchers.set(ds, cE), Fr(ds), nt.controller && M.set(ds, nt.controller)
        }), ft({
            fetchers: new Map(S.fetchers)
        });
        let Al = () => Ci.forEach(nt => Fr(nt.key));
        oe.signal.addEventListener("abort", Al);
        let {
            loaderResults: Dl,
            fetcherResults: de
        } = await Fg(S, dr, Ro, Ci, cs);
        if (oe.signal.aborted) return;
        oe.signal.removeEventListener("abort", Al), ie.delete(b), M.delete(b), Ci.forEach(nt => M.delete(nt.key));
        let We = Xl(Dl);
        if (We) return Si(cs, We.result, !1, {
            preventScrollReset: K
        });
        if (We = Xl(de), We) return ne.add(We.key), Si(cs, We.result, !1, {
            preventScrollReset: K
        });
        let {
            loaderData: fs,
            errors: Ao
        } = h0(S, dr, Dl, void 0, Ci, de, ct);
        if (S.fetchers.has(b)) {
            let nt = Vr(he.data);
            S.fetchers.set(b, nt)
        }
        zg(Kn), S.navigation.state === "loading" && Kn > H ? (se(P, "Expected pending action"), w && w.abort(), Hn(S.navigation.location, {
            matches: dr,
            loaderData: fs,
            errors: Ao,
            fetchers: new Map(S.fetchers)
        })) : (ft({
            errors: Ao,
            loaderData: p0(S.loaderData, fs, dr, Ao),
            fetchers: new Map(S.fetchers)
        }), Z = !1)
    }
    async function rE(b, R, D, N, z, Y, ee, K, G) {
        let $ = S.fetchers.get(b);
        Nr(b, Bo(G, $ ? $.data : void 0), {
            flushSync: ee
        });
        let X = new AbortController,
            oe = ps(e.history, D, X.signal);
        if (Y) {
            let he = await Rl(z, new URL(oe.url).pathname, oe.signal);
            if (he.type === "aborted") return;
            if (he.type === "error") {
                fr(b, R, he.error, {
                    flushSync: ee
                });
                return
            } else if (he.matches) z = he.matches, N = Qo(z, D);
            else {
                fr(b, R, zt(404, {
                    pathname: D
                }), {
                    flushSync: ee
                });
                return
            }
        }
        M.set(b, X);
        let ue = B,
            Te = (await ko("loader", S, oe, [N], z, b))[N.route.id];
        if (Gr(Te) && (Te = await vm(Te, oe.signal, !0) || Te), M.get(b) === X && M.delete(b), !oe.signal.aborted) {
            if (ke.has(b)) {
                Nr(b, Vr(void 0));
                return
            }
            if (Fi(Te))
                if (H > ue) {
                    Nr(b, Vr(void 0));
                    return
                } else {
                    ne.add(b), await Si(oe, Te, !1, {
                        preventScrollReset: K
                    });
                    return
                }
            if (nn(Te)) {
                fr(b, R, Te.error);
                return
            }
            se(!Gr(Te), "Unhandled fetcher deferred data"), Nr(b, Vr(Te.data))
        }
    }
    async function Si(b, R, D, N) {
        let {
            submission: z,
            fetcherSubmission: Y,
            preventScrollReset: ee,
            replace: K
        } = N === void 0 ? {} : N;
        R.response.headers.has("X-Remix-Revalidate") && (Z = !0);
        let G = R.response.headers.get("Location");
        se(G, "Expected a Location header on the redirect Response"), G = f0(G, new URL(b.url), l);
        let $ = Va(S.location, G, {
            _isRedirect: !0
        });
        if (n) {
            let he = !1;
            if (R.response.headers.has("X-Remix-Reload-Document")) he = !0;
            else if (ym.test(G)) {
                const $e = e.history.createURL(G);
                he = $e.origin !== t.location.origin || Rr($e.pathname, l) == null
            }
            if (he) {
                K ? t.location.replace(G) : t.location.assign(G);
                return
            }
        }
        w = null;
        let X = K === !0 || R.response.headers.has("X-Remix-Replace") ? rt.Replace : rt.Push,
            {
                formMethod: oe,
                formAction: ue,
                formEncType: mt
            } = S.navigation;
        !z && !Y && oe && ue && mt && (z = v0(S.navigation));
        let Te = z || Y;
        if (hb.has(R.response.status) && Te && Vn(Te.formMethod)) await Ne(X, $, {
            submission: Oe({}, Te, {
                formAction: G
            }),
            preventScrollReset: ee || A,
            enableViewTransition: D ? O : void 0
        });
        else {
            let he = nd($, z);
            await Ne(X, $, {
                overrideNavigation: he,
                fetcherSubmission: Y,
                preventScrollReset: ee || A,
                enableViewTransition: D ? O : void 0
            })
        }
    }
    async function ko(b, R, D, N, z, Y) {
        let ee, K = {};
        try {
            ee = await wb(u, b, R, D, N, z, Y, s, i)
        } catch (G) {
            return N.forEach($ => {
                K[$.route.id] = {
                    type: ye.error,
                    error: G
                }
            }), K
        }
        for (let [G, $] of Object.entries(ee))
            if (kb($)) {
                let X = $.result;
                K[G] = {
                    type: ye.redirect,
                    response: Tb(X, D, G, z, l, f.v7_relativeSplatPath)
                }
            } else K[G] = await Cb($);
        return K
    }
    async function Fg(b, R, D, N, z) {
        let Y = b.matches,
            ee = ko("loader", b, z, D, R, null),
            K = Promise.all(N.map(async X => {
                if (X.matches && X.match && X.controller) {
                    let ue = (await ko("loader", b, ps(e.history, X.path, X.controller.signal), [X.match], X.matches, X.key))[X.match.route.id];
                    return {
                        [X.key]: ue
                    }
                } else return Promise.resolve({
                    [X.key]: {
                        type: ye.error,
                        error: zt(404, {
                            pathname: X.path
                        })
                    }
                })
            })),
            G = await ee,
            $ = (await K).reduce((X, oe) => Object.assign(X, oe), {});
        return await Promise.all([Ab(R, G, z.signal, Y, b.loaderData), Db(R, $, N)]), {
            loaderResults: G,
            fetcherResults: $
        }
    }

    function Tf() {
        Z = !0, re.push(...Pf()), St.forEach((b, R) => {
            M.has(R) && q.add(R), Fr(R)
        })
    }

    function Nr(b, R, D) {
        D === void 0 && (D = {}), S.fetchers.set(b, R), ft({
            fetchers: new Map(S.fetchers)
        }, {
            flushSync: (D && D.flushSync) === !0
        })
    }

    function fr(b, R, D, N) {
        N === void 0 && (N = {});
        let z = ji(S.matches, R);
        Pl(b), ft({
            errors: {
                [z.route.id]: D
            },
            fetchers: new Map(S.fetchers)
        }, {
            flushSync: (N && N.flushSync) === !0
        })
    }

    function Ig(b) {
        return xe.set(b, (xe.get(b) || 0) + 1), ke.has(b) && ke.delete(b), S.fetchers.get(b) || pb
    }

    function Pl(b) {
        let R = S.fetchers.get(b);
        M.has(b) && !(R && R.state === "loading" && ie.has(b)) && Fr(b), St.delete(b), ie.delete(b), ne.delete(b), f.v7_fetcherPersist && ke.delete(b), q.delete(b), S.fetchers.delete(b)
    }

    function iE(b) {
        let R = (xe.get(b) || 0) - 1;
        R <= 0 ? (xe.delete(b), ke.add(b), f.v7_fetcherPersist || Pl(b)) : xe.set(b, R), ft({
            fetchers: new Map(S.fetchers)
        })
    }

    function Fr(b) {
        let R = M.get(b);
        R && (R.abort(), M.delete(b))
    }

    function Vg(b) {
        for (let R of b) {
            let D = Ig(R),
                N = Vr(D.data);
            S.fetchers.set(R, N)
        }
    }

    function Bg() {
        let b = [],
            R = !1;
        for (let D of ne) {
            let N = S.fetchers.get(D);
            se(N, "Expected fetcher: " + D), N.state === "loading" && (ne.delete(D), b.push(D), R = !0)
        }
        return Vg(b), R
    }

    function zg(b) {
        let R = [];
        for (let [D, N] of ie)
            if (N < b) {
                let z = S.fetchers.get(D);
                se(z, "Expected fetcher: " + D), z.state === "loading" && (Fr(D), ie.delete(D), R.push(D))
            }
        return Vg(R), R.length > 0
    }

    function sE(b, R) {
        let D = S.blockers.get(b) || Vo;
        return Lt.get(b) !== R && Lt.set(b, R), D
    }

    function Ug(b) {
        S.blockers.delete(b), Lt.delete(b)
    }

    function kl(b, R) {
        let D = S.blockers.get(b) || Vo;
        se(D.state === "unblocked" && R.state === "blocked" || D.state === "blocked" && R.state === "blocked" || D.state === "blocked" && R.state === "proceeding" || D.state === "blocked" && R.state === "unblocked" || D.state === "proceeding" && R.state === "unblocked", "Invalid blocker state transition: " + D.state + " -> " + R.state);
        let N = new Map(S.blockers);
        N.set(b, R), ft({
            blockers: N
        })
    }

    function $g(b) {
        let {
            currentLocation: R,
            nextLocation: D,
            historyAction: N
        } = b;
        if (Lt.size === 0) return;
        Lt.size > 1 && io(!1, "A router only supports one blocker at a time");
        let z = Array.from(Lt.entries()),
            [Y, ee] = z[z.length - 1],
            K = S.blockers.get(Y);
        if (!(K && K.state === "proceeding") && ee({
                currentLocation: R,
                nextLocation: D,
                historyAction: N
            })) return Y
    }

    function Ef(b) {
        let R = zt(404, {
                pathname: b
            }),
            D = a || o,
            {
                matches: N,
                route: z
            } = g0(D);
        return Pf(), {
            notFoundMatches: N,
            route: z,
            error: R
        }
    }

    function Pf(b) {
        let R = [];
        return ct.forEach((D, N) => {
            (!b || b(N)) && (D.cancel(), R.push(N), ct.delete(N))
        }), R
    }

    function oE(b, R, D) {
        if (m = b, _ = R, h = D || null, !v && S.navigation === td) {
            v = !0;
            let N = Hg(S.location, S.matches);
            N != null && ft({
                restoreScrollPosition: N
            })
        }
        return () => {
            m = null, _ = null, h = null
        }
    }

    function Wg(b, R) {
        return h && h(b, R.map(N => Hk(N, S.loaderData))) || b.key
    }

    function aE(b, R) {
        if (m && _) {
            let D = Wg(b, R);
            m[D] = _()
        }
    }

    function Hg(b, R) {
        if (m) {
            let D = Wg(b, R),
                N = m[D];
            if (typeof N == "number") return N
        }
        return null
    }

    function bl(b, R, D) {
        if (c)
            if (b) {
                if (Object.keys(b[0].params).length > 0) return {
                    active: !0,
                    matches: yu(R, D, l, !0)
                }
            } else return {
                active: !0,
                matches: yu(R, D, l, !0) || []
            };
        return {
            active: !1,
            matches: null
        }
    }
    async function Rl(b, R, D) {
        if (!c) return {
            type: "success",
            matches: b
        };
        let N = b;
        for (;;) {
            let z = a == null,
                Y = a || o,
                ee = s;
            try {
                await c({
                    signal: D,
                    path: R,
                    matches: N,
                    patch: ($, X) => {
                        D.aborted || c0($, X, Y, ee, i)
                    }
                })
            } catch ($) {
                return {
                    type: "error",
                    error: $,
                    partialMatches: N
                }
            } finally {
                z && !D.aborted && (o = [...o])
            }
            if (D.aborted) return {
                type: "aborted"
            };
            let K = Di(Y, R, l);
            if (K) return {
                type: "success",
                matches: K
            };
            let G = yu(Y, R, l, !0);
            if (!G || N.length === G.length && N.every(($, X) => $.route.id === G[X].route.id)) return {
                type: "success",
                matches: null
            };
            N = G
        }
    }

    function lE(b) {
        s = {}, a = tc(b, i, void 0, s)
    }

    function uE(b, R) {
        let D = a == null;
        c0(b, R, a || o, s, i), D && (o = [...o], ft({}))
    }
    return k = {
        get basename() {
            return l
        },
        get future() {
            return f
        },
        get state() {
            return S
        },
        get routes() {
            return o
        },
        get window() {
            return t
        },
        initialize: wi,
        subscribe: Cl,
        enableScrollRestoration: oE,
        navigate: J,
        fetch: tE,
        revalidate: be,
        createHref: b => e.history.createHref(b),
        encodeLocation: b => e.history.encodeLocation(b),
        getFetcher: Ig,
        deleteFetcher: iE,
        dispose: us,
        getBlocker: sE,
        deleteBlocker: Ug,
        patchRoutes: uE,
        _internalFetchControllers: M,
        _internalActiveDeferreds: ct,
        _internalSetRoutes: lE
    }, k
}

function yb(e) {
    return e != null && ("formData" in e && e.formData != null || "body" in e && e.body !== void 0)
}

function Eh(e, t, n, r, i, s, o, a) {
    let l, u;
    if (o) {
        l = [];
        for (let f of t)
            if (l.push(f), f.route.id === o) {
                u = f;
                break
            }
    } else l = t, u = t[t.length - 1];
    let c = gm(i || ".", mm(l, s), Rr(e.pathname, n) || e.pathname, a === "path");
    if (i == null && (c.search = e.search, c.hash = e.hash), (i == null || i === "" || i === ".") && u) {
        let f = xm(c.search);
        if (u.route.index && !f) c.search = c.search ? c.search.replace(/^\?/, "?index&") : "?index";
        else if (!u.route.index && f) {
            let d = new URLSearchParams(c.search),
                p = d.getAll("index");
            d.delete("index"), p.filter(h => h).forEach(h => d.append("index", h));
            let m = d.toString();
            c.search = m ? "?" + m : ""
        }
    }
    return r && n !== "/" && (c.pathname = c.pathname === "/" ? n : Sr([n, c.pathname])), es(c)
}

function o0(e, t, n, r) {
    if (!r || !yb(r)) return {
        path: n
    };
    if (r.formMethod && !Rb(r.formMethod)) return {
        path: n,
        error: zt(405, {
            method: r.formMethod
        })
    };
    let i = () => ({
            path: n,
            error: zt(400, {
                type: "invalid-body"
            })
        }),
        s = r.formMethod || "get",
        o = e ? s.toUpperCase() : s.toLowerCase(),
        a = uw(n);
    if (r.body !== void 0) {
        if (r.formEncType === "text/plain") {
            if (!Vn(o)) return i();
            let d = typeof r.body == "string" ? r.body : r.body instanceof FormData || r.body instanceof URLSearchParams ? Array.from(r.body.entries()).reduce((p, m) => {
                let [h, _] = m;
                return "" + p + h + "=" + _ + `
`
            }, "") : String(r.body);
            return {
                path: n,
                submission: {
                    formMethod: o,
                    formAction: a,
                    formEncType: r.formEncType,
                    formData: void 0,
                    json: void 0,
                    text: d
                }
            }
        } else if (r.formEncType === "application/json") {
            if (!Vn(o)) return i();
            try {
                let d = typeof r.body == "string" ? JSON.parse(r.body) : r.body;
                return {
                    path: n,
                    submission: {
                        formMethod: o,
                        formAction: a,
                        formEncType: r.formEncType,
                        formData: void 0,
                        json: d,
                        text: void 0
                    }
                }
            } catch {
                return i()
            }
        }
    }
    se(typeof FormData == "function", "FormData is not available in this environment");
    let l, u;
    if (r.formData) l = kh(r.formData), u = r.formData;
    else if (r.body instanceof FormData) l = kh(r.body), u = r.body;
    else if (r.body instanceof URLSearchParams) l = r.body, u = d0(l);
    else if (r.body == null) l = new URLSearchParams, u = new FormData;
    else try {
        l = new URLSearchParams(r.body), u = d0(l)
    } catch {
        return i()
    }
    let c = {
        formMethod: o,
        formAction: a,
        formEncType: r && r.formEncType || "application/x-www-form-urlencoded",
        formData: u,
        json: void 0,
        text: void 0
    };
    if (Vn(c.formMethod)) return {
        path: n,
        submission: c
    };
    let f = yi(n);
    return t && f.search && xm(f.search) && l.append("index", ""), f.search = "?" + l, {
        path: es(f),
        submission: c
    }
}

function a0(e, t, n) {
    n === void 0 && (n = !1);
    let r = e.findIndex(i => i.route.id === t);
    return r >= 0 ? e.slice(0, n ? r + 1 : r) : e
}

function l0(e, t, n, r, i, s, o, a, l, u, c, f, d, p, m, h) {
    let _ = h ? nn(h[1]) ? h[1].error : h[1].data : void 0,
        v = e.createURL(t.location),
        y = e.createURL(i),
        x = n;
    s && t.errors ? x = a0(n, Object.keys(t.errors)[0], !0) : h && nn(h[1]) && (x = a0(n, h[0]));
    let T = h ? h[1].statusCode : void 0,
        E = o && T && T >= 400,
        k = x.filter((P, A) => {
            let {
                route: w
            } = P;
            if (w.lazy) return !0;
            if (w.loader == null) return !1;
            if (s) return Ph(w, t.loaderData, t.errors);
            if (vb(t.loaderData, t.matches[A], P) || l.some(V => V === P.route.id)) return !0;
            let O = t.matches[A],
                F = P;
            return u0(P, Oe({
                currentUrl: v,
                currentParams: O.params,
                nextUrl: y,
                nextParams: F.params
            }, r, {
                actionResult: _,
                actionStatus: T,
                defaultShouldRevalidate: E ? !1 : a || v.pathname + v.search === y.pathname + y.search || v.search !== y.search || aw(O, F)
            }))
        }),
        S = [];
    return f.forEach((P, A) => {
        if (s || !n.some(W => W.route.id === P.routeId) || c.has(A)) return;
        let w = Di(p, P.path, m);
        if (!w) {
            S.push({
                key: A,
                routeId: P.routeId,
                path: P.path,
                matches: null,
                match: null,
                controller: null
            });
            return
        }
        let O = t.fetchers.get(A),
            F = Qo(w, P.path),
            V = !1;
        d.has(A) ? V = !1 : u.has(A) ? (u.delete(A), V = !0) : O && O.state !== "idle" && O.data === void 0 ? V = a : V = u0(F, Oe({
            currentUrl: v,
            currentParams: t.matches[t.matches.length - 1].params,
            nextUrl: y,
            nextParams: n[n.length - 1].params
        }, r, {
            actionResult: _,
            actionStatus: T,
            defaultShouldRevalidate: E ? !1 : a
        })), V && S.push({
            key: A,
            routeId: P.routeId,
            path: P.path,
            matches: w,
            match: F,
            controller: new AbortController
        })
    }), [k, S]
}

function Ph(e, t, n) {
    if (e.lazy) return !0;
    if (!e.loader) return !1;
    let r = t != null && t[e.id] !== void 0,
        i = n != null && n[e.id] !== void 0;
    return !r && i ? !1 : typeof e.loader == "function" && e.loader.hydrate === !0 ? !0 : !r && !i
}

function vb(e, t, n) {
    let r = !t || n.route.id !== t.route.id,
        i = e[n.route.id] === void 0;
    return r || i
}

function aw(e, t) {
    let n = e.route.path;
    return e.pathname !== t.pathname || n != null && n.endsWith("*") && e.params["*"] !== t.params["*"]
}

function u0(e, t) {
    if (e.route.shouldRevalidate) {
        let n = e.route.shouldRevalidate(t);
        if (typeof n == "boolean") return n
    }
    return t.defaultShouldRevalidate
}

function c0(e, t, n, r, i) {
    var s;
    let o;
    if (e) {
        let u = r[e];
        se(u, "No route found to patch children into: routeId = " + e), u.children || (u.children = []), o = u.children
    } else o = n;
    let a = t.filter(u => !o.some(c => lw(u, c))),
        l = tc(a, i, [e || "_", "patch", String(((s = o) == null ? void 0 : s.length) || "0")], r);
    o.push(...l)
}

function lw(e, t) {
    return "id" in e && "id" in t && e.id === t.id ? !0 : e.index === t.index && e.path === t.path && e.caseSensitive === t.caseSensitive ? (!e.children || e.children.length === 0) && (!t.children || t.children.length === 0) ? !0 : e.children.every((n, r) => {
        var i;
        return (i = t.children) == null ? void 0 : i.some(s => lw(n, s))
    }) : !1
}
async function xb(e, t, n) {
    if (!e.lazy) return;
    let r = await e.lazy();
    if (!e.lazy) return;
    let i = n[e.id];
    se(i, "No route found in manifest");
    let s = {};
    for (let o in r) {
        let l = i[o] !== void 0 && o !== "hasErrorBoundary";
        io(!l, 'Route "' + i.id + '" has a static property "' + o + '" defined but its lazy function is also returning a value for this property. ' + ('The lazy route property "' + o + '" will be ignored.')), !l && !$k.has(o) && (s[o] = r[o])
    }
    Object.assign(i, s), Object.assign(i, Oe({}, t(i), {
        lazy: void 0
    }))
}
async function _b(e) {
    let {
        matches: t
    } = e, n = t.filter(i => i.shouldLoad);
    return (await Promise.all(n.map(i => i.resolve()))).reduce((i, s, o) => Object.assign(i, {
        [n[o].route.id]: s
    }), {})
}
async function wb(e, t, n, r, i, s, o, a, l, u) {
    let c = s.map(p => p.route.lazy ? xb(p.route, l, a) : void 0),
        f = s.map((p, m) => {
            let h = c[m],
                _ = i.some(y => y.route.id === p.route.id);
            return Oe({}, p, {
                shouldLoad: _,
                resolve: async y => (y && r.method === "GET" && (p.route.lazy || p.route.loader) && (_ = !0), _ ? Sb(t, r, p, h, y, u) : Promise.resolve({
                    type: ye.data,
                    result: void 0
                }))
            })
        }),
        d = await e({
            matches: f,
            request: r,
            params: s[0].params,
            fetcherKey: o,
            context: u
        });
    try {
        await Promise.all(c)
    } catch {}
    return d
}
async function Sb(e, t, n, r, i, s) {
    let o, a, l = u => {
        let c, f = new Promise((m, h) => c = h);
        a = () => c(), t.signal.addEventListener("abort", a);
        let d = m => typeof u != "function" ? Promise.reject(new Error("You cannot call the handler for a route which defines a boolean " + ('"' + e + '" [routeId: ' + n.route.id + "]"))) : u({
                request: t,
                params: n.params,
                context: s
            }, ...m !== void 0 ? [m] : []),
            p = (async () => {
                try {
                    return {
                        type: "data",
                        result: await (i ? i(h => d(h)) : d())
                    }
                } catch (m) {
                    return {
                        type: "error",
                        result: m
                    }
                }
            })();
        return Promise.race([p, f])
    };
    try {
        let u = n.route[e];
        if (r)
            if (u) {
                let c, [f] = await Promise.all([l(u).catch(d => {
                    c = d
                }), r]);
                if (c !== void 0) throw c;
                o = f
            } else if (await r, u = n.route[e], u) o = await l(u);
        else if (e === "action") {
            let c = new URL(t.url),
                f = c.pathname + c.search;
            throw zt(405, {
                method: t.method,
                pathname: f,
                routeId: n.route.id
            })
        } else return {
            type: ye.data,
            result: void 0
        };
        else if (u) o = await l(u);
        else {
            let c = new URL(t.url),
                f = c.pathname + c.search;
            throw zt(404, {
                pathname: f
            })
        }
        se(o.result !== void 0, "You defined " + (e === "action" ? "an action" : "a loader") + " for route " + ('"' + n.route.id + "\" but didn't return anything from your `" + e + "` ") + "function. Please return a value or `null`.")
    } catch (u) {
        return {
            type: ye.error,
            result: u
        }
    } finally {
        a && t.signal.removeEventListener("abort", a)
    }
    return o
}
async function Cb(e) {
    let {
        result: t,
        type: n
    } = e;
    if (cw(t)) {
        let f;
        try {
            let d = t.headers.get("Content-Type");
            d && /\bapplication\/json\b/.test(d) ? t.body == null ? f = null : f = await t.json() : f = await t.text()
        } catch (d) {
            return {
                type: ye.error,
                error: d
            }
        }
        return n === ye.error ? {
            type: ye.error,
            error: new rc(t.status, t.statusText, f),
            statusCode: t.status,
            headers: t.headers
        } : {
            type: ye.data,
            data: f,
            statusCode: t.status,
            headers: t.headers
        }
    }
    if (n === ye.error) {
        if (y0(t)) {
            var r, i;
            if (t.data instanceof Error) {
                var s, o;
                return {
                    type: ye.error,
                    error: t.data,
                    statusCode: (s = t.init) == null ? void 0 : s.status,
                    headers: (o = t.init) != null && o.headers ? new Headers(t.init.headers) : void 0
                }
            }
            return {
                type: ye.error,
                error: new rc(((r = t.init) == null ? void 0 : r.status) || 500, void 0, t.data),
                statusCode: Ba(t) ? t.status : void 0,
                headers: (i = t.init) != null && i.headers ? new Headers(t.init.headers) : void 0
            }
        }
        return {
            type: ye.error,
            error: t,
            statusCode: Ba(t) ? t.status : void 0
        }
    }
    if (bb(t)) {
        var a, l;
        return {
            type: ye.deferred,
            deferredData: t,
            statusCode: (a = t.init) == null ? void 0 : a.status,
            headers: ((l = t.init) == null ? void 0 : l.headers) && new Headers(t.init.headers)
        }
    }
    if (y0(t)) {
        var u, c;
        return {
            type: ye.data,
            data: t.data,
            statusCode: (u = t.init) == null ? void 0 : u.status,
            headers: (c = t.init) != null && c.headers ? new Headers(t.init.headers) : void 0
        }
    }
    return {
        type: ye.data,
        data: t
    }
}

function Tb(e, t, n, r, i, s) {
    let o = e.headers.get("Location");
    if (se(o, "Redirects returned/thrown from loaders/actions must have a Location header"), !ym.test(o)) {
        let a = r.slice(0, r.findIndex(l => l.route.id === n) + 1);
        o = Eh(new URL(t.url), a, i, !0, o, s), e.headers.set("Location", o)
    }
    return e
}

function f0(e, t, n) {
    if (ym.test(e)) {
        let r = e,
            i = r.startsWith("//") ? new URL(t.protocol + r) : new URL(r),
            s = Rr(i.pathname, n) != null;
        if (i.origin === t.origin && s) return i.pathname + i.search + i.hash
    }
    return e
}

function ps(e, t, n, r) {
    let i = e.createURL(uw(t)).toString(),
        s = {
            signal: n
        };
    if (r && Vn(r.formMethod)) {
        let {
            formMethod: o,
            formEncType: a
        } = r;
        s.method = o.toUpperCase(), a === "application/json" ? (s.headers = new Headers({
            "Content-Type": a
        }), s.body = JSON.stringify(r.json)) : a === "text/plain" ? s.body = r.text : a === "application/x-www-form-urlencoded" && r.formData ? s.body = kh(r.formData) : s.body = r.formData
    }
    return new Request(i, s)
}

function kh(e) {
    let t = new URLSearchParams;
    for (let [n, r] of e.entries()) t.append(n, typeof r == "string" ? r : r.name);
    return t
}

function d0(e) {
    let t = new FormData;
    for (let [n, r] of e.entries()) t.append(n, r);
    return t
}

function Eb(e, t, n, r, i) {
    let s = {},
        o = null,
        a, l = !1,
        u = {},
        c = n && nn(n[1]) ? n[1].error : void 0;
    return e.forEach(f => {
        if (!(f.route.id in t)) return;
        let d = f.route.id,
            p = t[d];
        if (se(!Fi(p), "Cannot handle redirect results in processLoaderData"), nn(p)) {
            let m = p.error;
            c !== void 0 && (m = c, c = void 0), o = o || {}; {
                let h = ji(e, d);
                o[h.route.id] == null && (o[h.route.id] = m)
            }
            s[d] = void 0, l || (l = !0, a = Ba(p.error) ? p.error.status : 500), p.headers && (u[d] = p.headers)
        } else Gr(p) ? (r.set(d, p.deferredData), s[d] = p.deferredData.data, p.statusCode != null && p.statusCode !== 200 && !l && (a = p.statusCode), p.headers && (u[d] = p.headers)) : (s[d] = p.data, p.statusCode && p.statusCode !== 200 && !l && (a = p.statusCode), p.headers && (u[d] = p.headers))
    }), c !== void 0 && n && (o = {
        [n[0]]: c
    }, s[n[0]] = void 0), {
        loaderData: s,
        errors: o,
        statusCode: a || 200,
        loaderHeaders: u
    }
}

function h0(e, t, n, r, i, s, o) {
    let {
        loaderData: a,
        errors: l
    } = Eb(t, n, r, o);
    return i.forEach(u => {
        let {
            key: c,
            match: f,
            controller: d
        } = u, p = s[c];
        if (se(p, "Did not find corresponding fetcher result"), !(d && d.signal.aborted))
            if (nn(p)) {
                let m = ji(e.matches, f == null ? void 0 : f.route.id);
                l && l[m.route.id] || (l = Oe({}, l, {
                    [m.route.id]: p.error
                })), e.fetchers.delete(c)
            } else if (Fi(p)) se(!1, "Unhandled fetcher revalidation redirect");
        else if (Gr(p)) se(!1, "Unhandled fetcher deferred data");
        else {
            let m = Vr(p.data);
            e.fetchers.set(c, m)
        }
    }), {
        loaderData: a,
        errors: l
    }
}

function p0(e, t, n, r) {
    let i = Oe({}, t);
    for (let s of n) {
        let o = s.route.id;
        if (t.hasOwnProperty(o) ? t[o] !== void 0 && (i[o] = t[o]) : e[o] !== void 0 && s.route.loader && (i[o] = e[o]), r && r.hasOwnProperty(o)) break
    }
    return i
}

function m0(e) {
    return e ? nn(e[1]) ? {
        actionData: {}
    } : {
        actionData: {
            [e[0]]: e[1].data
        }
    } : {}
}

function ji(e, t) {
    return (t ? e.slice(0, e.findIndex(r => r.route.id === t) + 1) : [...e]).reverse().find(r => r.route.hasErrorBoundary === !0) || e[0]
}

function g0(e) {
    let t = e.length === 1 ? e[0] : e.find(n => n.index || !n.path || n.path === "/") || {
        id: "__shim-error-route__"
    };
    return {
        matches: [{
            params: {},
            pathname: "",
            pathnameBase: "",
            route: t
        }],
        route: t
    }
}

function zt(e, t) {
    let {
        pathname: n,
        routeId: r,
        method: i,
        type: s,
        message: o
    } = t === void 0 ? {} : t, a = "Unknown Server Error", l = "Unknown @remix-run/router error";
    return e === 400 ? (a = "Bad Request", i && n && r ? l = "You made a " + i + ' request to "' + n + '" but ' + ('did not provide a `loader` for route "' + r + '", ') + "so there is no way to handle the request." : s === "defer-action" ? l = "defer() is not supported in actions" : s === "invalid-body" && (l = "Unable to encode submission body")) : e === 403 ? (a = "Forbidden", l = 'Route "' + r + '" does not match URL "' + n + '"') : e === 404 ? (a = "Not Found", l = 'No route matches URL "' + n + '"') : e === 405 && (a = "Method Not Allowed", i && n && r ? l = "You made a " + i.toUpperCase() + ' request to "' + n + '" but ' + ('did not provide an `action` for route "' + r + '", ') + "so there is no way to handle the request." : i && (l = 'Invalid request method "' + i.toUpperCase() + '"')), new rc(e || 500, a, new Error(l), !0)
}

function Xl(e) {
    let t = Object.entries(e);
    for (let n = t.length - 1; n >= 0; n--) {
        let [r, i] = t[n];
        if (Fi(i)) return {
            key: r,
            result: i
        }
    }
}

function uw(e) {
    let t = typeof e == "string" ? yi(e) : e;
    return es(Oe({}, t, {
        hash: ""
    }))
}

function Pb(e, t) {
    return e.pathname !== t.pathname || e.search !== t.search ? !1 : e.hash === "" ? t.hash !== "" : e.hash === t.hash ? !0 : t.hash !== ""
}

function kb(e) {
    return cw(e.result) && db.has(e.result.status)
}

function Gr(e) {
    return e.type === ye.deferred
}

function nn(e) {
    return e.type === ye.error
}

function Fi(e) {
    return (e && e.type) === ye.redirect
}

function y0(e) {
    return typeof e == "object" && e != null && "type" in e && "data" in e && "init" in e && e.type === "DataWithResponseInit"
}

function bb(e) {
    let t = e;
    return t && typeof t == "object" && typeof t.data == "object" && typeof t.subscribe == "function" && typeof t.cancel == "function" && typeof t.resolveData == "function"
}

function cw(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.headers == "object" && typeof e.body < "u"
}

function Rb(e) {
    return fb.has(e.toLowerCase())
}

function Vn(e) {
    return ub.has(e.toLowerCase())
}
async function Ab(e, t, n, r, i) {
    let s = Object.entries(t);
    for (let o = 0; o < s.length; o++) {
        let [a, l] = s[o], u = e.find(d => (d == null ? void 0 : d.route.id) === a);
        if (!u) continue;
        let c = r.find(d => d.route.id === u.route.id),
            f = c != null && !aw(c, u) && (i && i[u.route.id]) !== void 0;
        Gr(l) && f && await vm(l, n, !1).then(d => {
            d && (t[a] = d)
        })
    }
}
async function Db(e, t, n) {
    for (let r = 0; r < n.length; r++) {
        let {
            key: i,
            routeId: s,
            controller: o
        } = n[r], a = t[i];
        e.find(u => (u == null ? void 0 : u.route.id) === s) && Gr(a) && (se(o, "Expected an AbortController for revalidating fetcher deferred result"), await vm(a, o.signal, !0).then(u => {
            u && (t[i] = u)
        }))
    }
}
async function vm(e, t, n) {
    if (n === void 0 && (n = !1), !await e.deferredData.resolveData(t)) {
        if (n) try {
            return {
                type: ye.data,
                data: e.deferredData.unwrappedData
            }
        } catch (i) {
            return {
                type: ye.error,
                error: i
            }
        }
        return {
            type: ye.data,
            data: e.deferredData.data
        }
    }
}

function xm(e) {
    return new URLSearchParams(e).getAll("index").some(t => t === "")
}

function Qo(e, t) {
    let n = typeof t == "string" ? yi(t).search : t.search;
    if (e[e.length - 1].route.index && xm(n || "")) return e[e.length - 1];
    let r = iw(e);
    return r[r.length - 1]
}

function v0(e) {
    let {
        formMethod: t,
        formAction: n,
        formEncType: r,
        text: i,
        formData: s,
        json: o
    } = e;
    if (!(!t || !n || !r)) {
        if (i != null) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: void 0,
            json: void 0,
            text: i
        };
        if (s != null) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: s,
            json: void 0,
            text: void 0
        };
        if (o !== void 0) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: void 0,
            json: o,
            text: void 0
        }
    }
}

function nd(e, t) {
    return t ? {
        state: "loading",
        location: e,
        formMethod: t.formMethod,
        formAction: t.formAction,
        formEncType: t.formEncType,
        formData: t.formData,
        json: t.json,
        text: t.text
    } : {
        state: "loading",
        location: e,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    }
}

function jb(e, t) {
    return {
        state: "submitting",
        location: e,
        formMethod: t.formMethod,
        formAction: t.formAction,
        formEncType: t.formEncType,
        formData: t.formData,
        json: t.json,
        text: t.text
    }
}

function Bo(e, t) {
    return e ? {
        state: "loading",
        formMethod: e.formMethod,
        formAction: e.formAction,
        formEncType: e.formEncType,
        formData: e.formData,
        json: e.json,
        text: e.text,
        data: t
    } : {
        state: "loading",
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0,
        data: t
    }
}

function Ob(e, t) {
    return {
        state: "submitting",
        formMethod: e.formMethod,
        formAction: e.formAction,
        formEncType: e.formEncType,
        formData: e.formData,
        json: e.json,
        text: e.text,
        data: t ? t.data : void 0
    }
}

function Vr(e) {
    return {
        state: "idle",
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0,
        data: e
    }
}

function Lb(e, t) {
    try {
        let n = e.sessionStorage.getItem(ow);
        if (n) {
            let r = JSON.parse(n);
            for (let [i, s] of Object.entries(r || {})) s && Array.isArray(s) && t.set(i, new Set(s || []))
        }
    } catch {}
}

function Mb(e, t) {
    if (t.size > 0) {
        let n = {};
        for (let [r, i] of t) n[r] = [...i];
        try {
            e.sessionStorage.setItem(ow, JSON.stringify(n))
        } catch (r) {
            io(!1, "Failed to save applied view transitions in sessionStorage (" + r + ").")
        }
    }
}
/**
 * React Router v6.29.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function ic() {
    return ic = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, ic.apply(this, arguments)
}
const fl = C.createContext(null),
    _m = C.createContext(null),
    vi = C.createContext(null),
    wm = C.createContext(null),
    Mr = C.createContext({
        outlet: null,
        matches: [],
        isDataRoute: !1
    }),
    fw = C.createContext(null);

function Nb(e, t) {
    let {
        relative: n
    } = t === void 0 ? {} : t;
    dl() || se(!1);
    let {
        basename: r,
        navigator: i
    } = C.useContext(vi), {
        hash: s,
        pathname: o,
        search: a
    } = Bc(e, {
        relative: n
    }), l = o;
    return r !== "/" && (l = o === "/" ? r : Sr([r, o])), i.createHref({
        pathname: l,
        search: a,
        hash: s
    })
}

function dl() {
    return C.useContext(wm) != null
}

function os() {
    return dl() || se(!1), C.useContext(wm).location
}

function dw(e) {
    C.useContext(vi).static || C.useLayoutEffect(e)
}

function Sm() {
    let {
        isDataRoute: e
    } = C.useContext(Mr);
    return e ? Qb() : Fb()
}

function Fb() {
    dl() || se(!1);
    let e = C.useContext(fl),
        {
            basename: t,
            future: n,
            navigator: r
        } = C.useContext(vi),
        {
            matches: i
        } = C.useContext(Mr),
        {
            pathname: s
        } = os(),
        o = JSON.stringify(mm(i, n.v7_relativeSplatPath)),
        a = C.useRef(!1);
    return dw(() => {
        a.current = !0
    }), C.useCallback(function(u, c) {
        if (c === void 0 && (c = {}), !a.current) return;
        if (typeof u == "number") {
            r.go(u);
            return
        }
        let f = gm(u, JSON.parse(o), s, c.relative === "path");
        e == null && t !== "/" && (f.pathname = f.pathname === "/" ? t : Sr([t, f.pathname])), (c.replace ? r.replace : r.push)(f, c.state, c)
    }, [t, r, o, s, e])
}
const Ib = C.createContext(null);

function Vb(e) {
    let t = C.useContext(Mr).outlet;
    return t && C.createElement(Ib.Provider, {
        value: e
    }, t)
}

function Bb() {
    let {
        matches: e
    } = C.useContext(Mr), t = e[e.length - 1];
    return t ? t.params : {}
}

function Bc(e, t) {
    let {
        relative: n
    } = t === void 0 ? {} : t, {
        future: r
    } = C.useContext(vi), {
        matches: i
    } = C.useContext(Mr), {
        pathname: s
    } = os(), o = JSON.stringify(mm(i, r.v7_relativeSplatPath));
    return C.useMemo(() => gm(e, JSON.parse(o), s, n === "path"), [e, o, s, n])
}

function zb(e, t, n, r) {
    dl() || se(!1);
    let {
        navigator: i,
        static: s
    } = C.useContext(vi), {
        matches: o
    } = C.useContext(Mr), a = o[o.length - 1], l = a ? a.params : {};
    a && a.pathname;
    let u = a ? a.pathnameBase : "/";
    a && a.route;
    let c = os(),
        f;
    f = c;
    let d = f.pathname || "/",
        p = d;
    if (u !== "/") {
        let _ = u.replace(/^\//, "").split("/");
        p = "/" + d.replace(/^\//, "").split("/").slice(_.length).join("/")
    }
    let m = !s && n && n.matches && n.matches.length > 0 ? n.matches : Di(e, {
        pathname: p
    });
    return Kb(m && m.map(_ => Object.assign({}, _, {
        params: Object.assign({}, l, _.params),
        pathname: Sr([u, i.encodeLocation ? i.encodeLocation(_.pathname).pathname : _.pathname]),
        pathnameBase: _.pathnameBase === "/" ? u : Sr([u, i.encodeLocation ? i.encodeLocation(_.pathnameBase).pathname : _.pathnameBase])
    })), o, n, r)
}

function Ub() {
    let e = qb(),
        t = Ba(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
        n = e instanceof Error ? e.stack : null,
        i = {
            padding: "0.5rem",
            backgroundColor: "rgba(200,200,200, 0.5)"
        };
    return C.createElement(C.Fragment, null, C.createElement("h2", null, "Unexpected Application Error!"), C.createElement("h3", {
        style: {
            fontStyle: "italic"
        }
    }, t), n ? C.createElement("pre", {
        style: i
    }, n) : null, null)
}
const $b = C.createElement(Ub, null);
class Wb extends C.Component {
    constructor(t) {
        super(t), this.state = {
            location: t.location,
            revalidation: t.revalidation,
            error: t.error
        }
    }
    static getDerivedStateFromError(t) {
        return {
            error: t
        }
    }
    static getDerivedStateFromProps(t, n) {
        return n.location !== t.location || n.revalidation !== "idle" && t.revalidation === "idle" ? {
            error: t.error,
            location: t.location,
            revalidation: t.revalidation
        } : {
            error: t.error !== void 0 ? t.error : n.error,
            location: n.location,
            revalidation: t.revalidation || n.revalidation
        }
    }
    componentDidCatch(t, n) {
        console.error("React Router caught the following error during render", t, n)
    }
    render() {
        return this.state.error !== void 0 ? C.createElement(Mr.Provider, {
            value: this.props.routeContext
        }, C.createElement(fw.Provider, {
            value: this.state.error,
            children: this.props.component
        })) : this.props.children
    }
}

function Hb(e) {
    let {
        routeContext: t,
        match: n,
        children: r
    } = e, i = C.useContext(fl);
    return i && i.static && i.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (i.staticContext._deepestRenderedBoundaryId = n.route.id), C.createElement(Mr.Provider, {
        value: t
    }, r)
}

function Kb(e, t, n, r) {
    var i;
    if (t === void 0 && (t = []), n === void 0 && (n = null), r === void 0 && (r = null), e == null) {
        var s;
        if (!n) return null;
        if (n.errors) e = n.matches;
        else if ((s = r) != null && s.v7_partialHydration && t.length === 0 && !n.initialized && n.matches.length > 0) e = n.matches;
        else return null
    }
    let o = e,
        a = (i = n) == null ? void 0 : i.errors;
    if (a != null) {
        let c = o.findIndex(f => f.route.id && (a == null ? void 0 : a[f.route.id]) !== void 0);
        c >= 0 || se(!1), o = o.slice(0, Math.min(o.length, c + 1))
    }
    let l = !1,
        u = -1;
    if (n && r && r.v7_partialHydration)
        for (let c = 0; c < o.length; c++) {
            let f = o[c];
            if ((f.route.HydrateFallback || f.route.hydrateFallbackElement) && (u = c), f.route.id) {
                let {
                    loaderData: d,
                    errors: p
                } = n, m = f.route.loader && d[f.route.id] === void 0 && (!p || p[f.route.id] === void 0);
                if (f.route.lazy || m) {
                    l = !0, u >= 0 ? o = o.slice(0, u + 1) : o = [o[0]];
                    break
                }
            }
        }
    return o.reduceRight((c, f, d) => {
        let p, m = !1,
            h = null,
            _ = null;
        n && (p = a && f.route.id ? a[f.route.id] : void 0, h = f.route.errorElement || $b, l && (u < 0 && d === 0 ? (Jb("route-fallback"), m = !0, _ = null) : u === d && (m = !0, _ = f.route.hydrateFallbackElement || null)));
        let v = t.concat(o.slice(0, d + 1)),
            y = () => {
                let x;
                return p ? x = h : m ? x = _ : f.route.Component ? x = C.createElement(f.route.Component, null) : f.route.element ? x = f.route.element : x = c, C.createElement(Hb, {
                    match: f,
                    routeContext: {
                        outlet: c,
                        matches: v,
                        isDataRoute: n != null
                    },
                    children: x
                })
            };
        return n && (f.route.ErrorBoundary || f.route.errorElement || d === 0) ? C.createElement(Wb, {
            location: n.location,
            revalidation: n.revalidation,
            component: h,
            error: p,
            children: y(),
            routeContext: {
                outlet: null,
                matches: v,
                isDataRoute: !0
            }
        }) : y()
    }, null)
}
var hw = function(e) {
        return e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e
    }(hw || {}),
    pw = function(e) {
        return e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId", e
    }(pw || {});

function Gb(e) {
    let t = C.useContext(fl);
    return t || se(!1), t
}

function Yb(e) {
    let t = C.useContext(_m);
    return t || se(!1), t
}

function Xb(e) {
    let t = C.useContext(Mr);
    return t || se(!1), t
}

function mw(e) {
    let t = Xb(),
        n = t.matches[t.matches.length - 1];
    return n.route.id || se(!1), n.route.id
}

function qb() {
    var e;
    let t = C.useContext(fw),
        n = Yb(),
        r = mw();
    return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r]
}

function Qb() {
    let {
        router: e
    } = Gb(hw.UseNavigateStable), t = mw(pw.UseNavigateStable), n = C.useRef(!1);
    return dw(() => {
        n.current = !0
    }), C.useCallback(function(i, s) {
        s === void 0 && (s = {}), n.current && (typeof i == "number" ? e.navigate(i) : e.navigate(i, ic({
            fromRouteId: t
        }, s)))
    }, [e, t])
}
const x0 = {};

function Jb(e, t, n) {
    x0[e] || (x0[e] = !0)
}

function Zb(e, t) {
    e == null || e.v7_startTransition, (e == null ? void 0 : e.v7_relativeSplatPath) === void 0 && (!t || t.v7_relativeSplatPath), t && (t.v7_fetcherPersist, t.v7_normalizeFormMethod, t.v7_partialHydration, t.v7_skipActionErrorRevalidation)
}

function eR(e) {
    return Vb(e.context)
}

function tR(e) {
    let {
        basename: t = "/",
        children: n = null,
        location: r,
        navigationType: i = rt.Pop,
        navigator: s,
        static: o = !1,
        future: a
    } = e;
    dl() && se(!1);
    let l = t.replace(/^\/*/, "/"),
        u = C.useMemo(() => ({
            basename: l,
            navigator: s,
            static: o,
            future: ic({
                v7_relativeSplatPath: !1
            }, a)
        }), [l, a, s, o]);
    typeof r == "string" && (r = yi(r));
    let {
        pathname: c = "/",
        search: f = "",
        hash: d = "",
        state: p = null,
        key: m = "default"
    } = r, h = C.useMemo(() => {
        let _ = Rr(c, l);
        return _ == null ? null : {
            location: {
                pathname: _,
                search: f,
                hash: d,
                state: p,
                key: m
            },
            navigationType: i
        }
    }, [l, c, f, d, p, m, i]);
    return h == null ? null : C.createElement(vi.Provider, {
        value: u
    }, C.createElement(wm.Provider, {
        children: n,
        value: h
    }))
}
new Promise(() => {});

function nR(e) {
    let t = {
        hasErrorBoundary: e.ErrorBoundary != null || e.errorElement != null
    };
    return e.Component && Object.assign(t, {
        element: C.createElement(e.Component),
        Component: void 0
    }), e.HydrateFallback && Object.assign(t, {
        hydrateFallbackElement: C.createElement(e.HydrateFallback),
        HydrateFallback: void 0
    }), e.ErrorBoundary && Object.assign(t, {
        errorElement: C.createElement(e.ErrorBoundary),
        ErrorBoundary: void 0
    }), t
}
/**
 * React Router DOM v6.29.0
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function so() {
    return so = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, so.apply(this, arguments)
}

function gw(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        i, s;
    for (s = 0; s < r.length; s++) i = r[s], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
    return n
}

function rR(e) {
    return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
}

function iR(e, t) {
    return e.button === 0 && (!t || t === "_self") && !rR(e)
}
const sR = ["onClick", "relative", "reloadDocument", "replace", "state", "target", "to", "preventScrollReset", "viewTransition"],
    oR = ["aria-current", "caseSensitive", "className", "end", "style", "to", "viewTransition", "children"],
    aR = "6";
try {
    window.__reactRouterVersion = aR
} catch {}

function lR(e, t) {
    return gb({
        basename: void 0,
        future: so({}, void 0, {
            v7_prependBasename: !0
        }),
        history: Bk({
            window: void 0
        }),
        hydrationData: uR(),
        routes: e,
        mapRouteProperties: nR,
        dataStrategy: void 0,
        patchRoutesOnNavigation: void 0,
        window: void 0
    }).initialize()
}

function uR() {
    var e;
    let t = (e = window) == null ? void 0 : e.__staticRouterHydrationData;
    return t && t.errors && (t = so({}, t, {
        errors: cR(t.errors)
    })), t
}

function cR(e) {
    if (!e) return null;
    let t = Object.entries(e),
        n = {};
    for (let [r, i] of t)
        if (i && i.__type === "RouteErrorResponse") n[r] = new rc(i.status, i.statusText, i.data, i.internal === !0);
        else if (i && i.__type === "Error") {
        if (i.__subType) {
            let s = window[i.__subType];
            if (typeof s == "function") try {
                let o = new s(i.message);
                o.stack = "", n[r] = o
            } catch {}
        }
        if (n[r] == null) {
            let s = new Error(i.message);
            s.stack = "", n[r] = s
        }
    } else n[r] = i;
    return n
}
const yw = C.createContext({
        isTransitioning: !1
    }),
    fR = C.createContext(new Map),
    dR = "startTransition",
    _0 = Dd[dR],
    hR = "flushSync",
    w0 = Fk[hR];

function pR(e) {
    _0 ? _0(e) : e()
}

function zo(e) {
    w0 ? w0(e) : e()
}
class mR {
    constructor() {
        this.status = "pending", this.promise = new Promise((t, n) => {
            this.resolve = r => {
                this.status === "pending" && (this.status = "resolved", t(r))
            }, this.reject = r => {
                this.status === "pending" && (this.status = "rejected", n(r))
            }
        })
    }
}

function gR(e) {
    let {
        fallbackElement: t,
        router: n,
        future: r
    } = e, [i, s] = C.useState(n.state), [o, a] = C.useState(), [l, u] = C.useState({
        isTransitioning: !1
    }), [c, f] = C.useState(), [d, p] = C.useState(), [m, h] = C.useState(), _ = C.useRef(new Map), {
        v7_startTransition: v
    } = r || {}, y = C.useCallback(P => {
        v ? pR(P) : P()
    }, [v]), x = C.useCallback((P, A) => {
        let {
            deletedFetchers: w,
            flushSync: O,
            viewTransitionOpts: F
        } = A;
        P.fetchers.forEach((W, Z) => {
            W.data !== void 0 && _.current.set(Z, W.data)
        }), w.forEach(W => _.current.delete(W));
        let V = n.window == null || n.window.document == null || typeof n.window.document.startViewTransition != "function";
        if (!F || V) {
            O ? zo(() => s(P)) : y(() => s(P));
            return
        }
        if (O) {
            zo(() => {
                d && (c && c.resolve(), d.skipTransition()), u({
                    isTransitioning: !0,
                    flushSync: !0,
                    currentLocation: F.currentLocation,
                    nextLocation: F.nextLocation
                })
            });
            let W = n.window.document.startViewTransition(() => {
                zo(() => s(P))
            });
            W.finished.finally(() => {
                zo(() => {
                    f(void 0), p(void 0), a(void 0), u({
                        isTransitioning: !1
                    })
                })
            }), zo(() => p(W));
            return
        }
        d ? (c && c.resolve(), d.skipTransition(), h({
            state: P,
            currentLocation: F.currentLocation,
            nextLocation: F.nextLocation
        })) : (a(P), u({
            isTransitioning: !0,
            flushSync: !1,
            currentLocation: F.currentLocation,
            nextLocation: F.nextLocation
        }))
    }, [n.window, d, c, _, y]);
    C.useLayoutEffect(() => n.subscribe(x), [n, x]), C.useEffect(() => {
        l.isTransitioning && !l.flushSync && f(new mR)
    }, [l]), C.useEffect(() => {
        if (c && o && n.window) {
            let P = o,
                A = c.promise,
                w = n.window.document.startViewTransition(async () => {
                    y(() => s(P)), await A
                });
            w.finished.finally(() => {
                f(void 0), p(void 0), a(void 0), u({
                    isTransitioning: !1
                })
            }), p(w)
        }
    }, [y, o, c, n.window]), C.useEffect(() => {
        c && o && i.location.key === o.location.key && c.resolve()
    }, [c, d, i.location, o]), C.useEffect(() => {
        !l.isTransitioning && m && (a(m.state), u({
            isTransitioning: !0,
            flushSync: !1,
            currentLocation: m.currentLocation,
            nextLocation: m.nextLocation
        }), h(void 0))
    }, [l.isTransitioning, m]), C.useEffect(() => {}, []);
    let T = C.useMemo(() => ({
            createHref: n.createHref,
            encodeLocation: n.encodeLocation,
            go: P => n.navigate(P),
            push: (P, A, w) => n.navigate(P, {
                state: A,
                preventScrollReset: w == null ? void 0 : w.preventScrollReset
            }),
            replace: (P, A, w) => n.navigate(P, {
                replace: !0,
                state: A,
                preventScrollReset: w == null ? void 0 : w.preventScrollReset
            })
        }), [n]),
        E = n.basename || "/",
        k = C.useMemo(() => ({
            router: n,
            navigator: T,
            static: !1,
            basename: E
        }), [n, T, E]),
        S = C.useMemo(() => ({
            v7_relativeSplatPath: n.future.v7_relativeSplatPath
        }), [n.future.v7_relativeSplatPath]);
    return C.useEffect(() => Zb(r, n.future), [r, n.future]), C.createElement(C.Fragment, null, C.createElement(fl.Provider, {
        value: k
    }, C.createElement(_m.Provider, {
        value: i
    }, C.createElement(fR.Provider, {
        value: _.current
    }, C.createElement(yw.Provider, {
        value: l
    }, C.createElement(tR, {
        basename: E,
        location: i.location,
        navigationType: i.historyAction,
        navigator: T,
        future: S
    }, i.initialized || n.future.v7_partialHydration ? C.createElement(yR, {
        routes: n.routes,
        future: n.future,
        state: i
    }) : t))))), null)
}
const yR = C.memo(vR);

function vR(e) {
    let {
        routes: t,
        future: n,
        state: r
    } = e;
    return zb(t, void 0, r, n)
}
const xR = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u",
    _R = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
    Jo = C.forwardRef(function(t, n) {
        let {
            onClick: r,
            relative: i,
            reloadDocument: s,
            replace: o,
            state: a,
            target: l,
            to: u,
            preventScrollReset: c,
            viewTransition: f
        } = t, d = gw(t, sR), {
            basename: p
        } = C.useContext(vi), m, h = !1;
        if (typeof u == "string" && _R.test(u) && (m = u, xR)) try {
            let x = new URL(window.location.href),
                T = u.startsWith("//") ? new URL(x.protocol + u) : new URL(u),
                E = Rr(T.pathname, p);
            T.origin === x.origin && E != null ? u = E + T.search + T.hash : h = !0
        } catch {}
        let _ = Nb(u, {
                relative: i
            }),
            v = SR(u, {
                replace: o,
                state: a,
                target: l,
                preventScrollReset: c,
                relative: i,
                viewTransition: f
            });

        function y(x) {
            r && r(x), x.defaultPrevented || v(x)
        }
        return C.createElement("a", so({}, d, {
            href: m || _,
            onClick: h || s ? r : y,
            ref: n,
            target: l
        }))
    }),
    je = C.forwardRef(function(t, n) {
        let {
            "aria-current": r = "page",
            caseSensitive: i = !1,
            className: s = "",
            end: o = !1,
            style: a,
            to: l,
            viewTransition: u,
            children: c
        } = t, f = gw(t, oR), d = Bc(l, {
            relative: f.relative
        }), p = os(), m = C.useContext(_m), {
            navigator: h,
            basename: _
        } = C.useContext(vi), v = m != null && CR(d) && u === !0, y = h.encodeLocation ? h.encodeLocation(d).pathname : d.pathname, x = p.pathname, T = m && m.navigation && m.navigation.location ? m.navigation.location.pathname : null;
        i || (x = x.toLowerCase(), T = T ? T.toLowerCase() : null, y = y.toLowerCase()), T && _ && (T = Rr(T, _) || T);
        const E = y !== "/" && y.endsWith("/") ? y.length - 1 : y.length;
        let k = x === y || !o && x.startsWith(y) && x.charAt(E) === "/",
            S = T != null && (T === y || !o && T.startsWith(y) && T.charAt(y.length) === "/"),
            P = {
                isActive: k,
                isPending: S,
                isTransitioning: v
            },
            A = k ? r : void 0,
            w;
        typeof s == "function" ? w = s(P) : w = [s, k ? "active" : null, S ? "pending" : null, v ? "transitioning" : null].filter(Boolean).join(" ");
        let O = typeof a == "function" ? a(P) : a;
        return C.createElement(Jo, so({}, f, {
            "aria-current": A,
            className: w,
            ref: n,
            style: O,
            to: l,
            viewTransition: u
        }), typeof c == "function" ? c(P) : c)
    });
var bh;
(function(e) {
    e.UseScrollRestoration = "useScrollRestoration", e.UseSubmit = "useSubmit", e.UseSubmitFetcher = "useSubmitFetcher", e.UseFetcher = "useFetcher", e.useViewTransitionState = "useViewTransitionState"
})(bh || (bh = {}));
var S0;
(function(e) {
    e.UseFetcher = "useFetcher", e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration"
})(S0 || (S0 = {}));

function wR(e) {
    let t = C.useContext(fl);
    return t || se(!1), t
}

function SR(e, t) {
    let {
        target: n,
        replace: r,
        state: i,
        preventScrollReset: s,
        relative: o,
        viewTransition: a
    } = t === void 0 ? {} : t, l = Sm(), u = os(), c = Bc(e, {
        relative: o
    });
    return C.useCallback(f => {
        if (iR(f, n)) {
            f.preventDefault();
            let d = r !== void 0 ? r : es(u) === es(c);
            l(e, {
                replace: d,
                state: i,
                preventScrollReset: s,
                relative: o,
                viewTransition: a
            })
        }
    }, [u, l, c, r, i, n, e, s, o, a])
}

function CR(e, t) {
    t === void 0 && (t = {});
    let n = C.useContext(yw);
    n == null && se(!1);
    let {
        basename: r
    } = wR(bh.useViewTransitionState), i = Bc(e, {
        relative: t.relative
    });
    if (!n.isTransitioning) return !1;
    let s = Rr(n.currentLocation.pathname, r) || n.currentLocation.pathname,
        o = Rr(n.nextLocation.pathname, r) || n.nextLocation.pathname;
    return nc(i.pathname, o) != null || nc(i.pathname, s) != null
}
const TR = e => (C.useEffect(() => {
        {
            if (window.adsbygoogle = window.adsbygoogle || [], !document.querySelector('script[src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"]')) {
                const r = document.createElement("script");
                r.async = !0, r.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9796833231647897", r.crossOrigin = "anonymous", document.head.appendChild(r)
            }
            const n = setTimeout(() => {
                try {
                    window.adsbygoogle && window.adsbygoogle.push({})
                } catch (r) {
                    console.error("AdSense error:", r)
                }
            }, 500);
            return () => clearTimeout(n)
        }
    }, []), g.jsx("div", {
        style: {
            width: "100%",
            maxHeight: "200px",
            overflow: "hidden"
        },
        children: g.jsx("ins", {
            className: "adsbygoogle",
            style: {
                display: "block",
                width: "100%",
                minWidth: "300px",
                maxHeight: "100%",
                background: e.background || "#fff",
                textAlign: "center"
            },
            "data-ad-format": "autorelaxed",
            "data-ad-client": "ca-pub-9796833231647897",
            "data-ad-slot": "4571350183",
            "data-full-width-responsive": "true"
        })
    })),
    ER = () => g.jsx(g.Fragment, {
        children: g.jsx("div", {
            className: "main-container",
            children: g.jsxs("div", {
                className: "inner-main-container",
                children: [g.jsx("footer", {
                    className: "body-footer",
                    children: g.jsx("div", {
                        className: "mian-footer-body",
                        children: g.jsxs("div", {
                            className: "second-footer-section",
                            children: [g.jsx("ul", {
                                children: g.jsx("h3", {
                                    className: "footor-update-title",
                                    children: "New Updates"
                                })
                            }), g.jsxs("ul", {
                                children: [g.jsx("h3", {
                                    className: "footor-departments-title",
                                    children: "Content"
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Question Papers"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Note"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Syllabus"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Books"
                                    })
                                })]
                            }), g.jsxs("ul", {
                                children: [g.jsx("h3", {
                                    className: "footor-papers-title",
                                    children: "Papers"
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Integrated B.Ed"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Honors"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Elective"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Compulsory"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "E&V"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Pg Papers"
                                    })
                                }), g.jsx("li", {
                                    children: g.jsx(je, {
                                        to: "#",
                                        children: "Ug Papers"
                                    })
                                })]
                            }), g.jsxs("ul", {
                                children: [g.jsx("h3", {
                                    className: "footor-contact-box-title",
                                    children: "Conact Us"
                                }), g.jsxs("p", {
                                    children: ["WQH8+X8Odisha, 757003, India", g.jsx("br", {}), "Takatpur, Baripada, Mayurbhanj, Baripada "]
                                }), g.jsx("p", {
                                    children: "Email : studyvaultteam@gmail.com"
                                }), g.jsx("h4", {
                                    children: "StudyVault Pvt. Ltd."
                                }), g.jsxs("div", {
                                    className: "sosial-media-link",
                                    children: [g.jsx("div", {
                                        className: "social-media-icon",
                                        children: g.jsx("a", {
                                            href: "https://www.instagram.com/akash_bindhani_/",
                                            target: "__blank",
                                            children: g.jsx("i", {
                                                className: "fa-brands fa-instagram"
                                            })
                                        })
                                    }), g.jsx("div", {
                                        className: "social-media-icon",
                                        children: g.jsx("a", {
                                            href: "https://x.com/AKASHBIN814",
                                            target: "__blank",
                                            children: g.jsx("i", {
                                                className: "fa-brands fa-square-twitter"
                                            })
                                        })
                                    }), g.jsx("div", {
                                        className: "social-media-icon",
                                        children: g.jsx("a", {
                                            href: "https://www.linkedin.com/in/akash-bindhani-7b71b9311/",
                                            target: "__blank",
                                            children: g.jsx("i", {
                                                className: "fa-brands fa-linkedin"
                                            })
                                        })
                                    }), g.jsx("div", {
                                        className: "social-media-icon",
                                        children: g.jsx("a", {
                                            href: "https://github.com/coderakashmain",
                                            children: g.jsx("i", {
                                                className: "fa-brands fa-github",
                                                target: "__blank"
                                            })
                                        })
                                    })]
                                })]
                            })]
                        })
                    })
                }), g.jsxs("footer", {
                    className: "finalFooter",
                    children: [g.jsxs("aside", {
                        className: "lastfooter-left",
                        children: [g.jsxs("div", {
                            children: [g.jsx(je, {
                                to: "/About-us",
                                children: "About Us"
                            }), g.jsx(je, {
                                to: "/Contact-Us",
                                children: "Contact Us"
                            })]
                        }), g.jsxs("div", {
                            children: [g.jsx(je, {
                                to: "/Privacy-Policy",
                                children: "Privacy Policy"
                            }), g.jsx(je, {
                                to: "/Terms-Conditions",
                                children: "Terms & Conditions"
                            })]
                        })]
                    }), g.jsx("aside", {
                        className: "lastfooter-right",
                        children: g.jsx("p", {
                            children: "© Copyright StudyVault  All Rights Reserved "
                        })
                    })]
                })]
            })
        })
    }),
    PR = ({
        pdfUrl: e,
        papertitle: t,
        onClose: n
    }) => {
        const r = l => {
                var u;
                return l.includes("drive.google.com/file/d/") ? `https://drive.google.com/file/d/${(u=l.split("/d/")[1])==null?void 0:u.split("/")[0]}/preview` : l
            },
            i = l => {
                var u;
                return l.includes("drive.google.com/file/d/") ? `https://drive.google.com/uc?export=download&id=${(u=l.split("/d/")[1])==null?void 0:u.split("/")[0]}` : l
            },
            s = r(e),
            o = i(e),
            a = () => {
                if (o) {
                    const l = document.createElement("a");
                    l.href = o, l.download = t || "DownloadedFile.pdf", document.body.appendChild(l), l.click(), document.body.removeChild(l)
                } else alert("Invalid Google Drive URL")
            };
        return g.jsxs("div", {
            style: {
                position: "fixed",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(0, 0, 0, 0.8)",
                zIndex: 1e4
            },
            children: [g.jsxs("div", {
                style: {
                    height: "5rem ",
                    width: "100%",
                    padding: "1rem 1rem",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexDirection: "row"
                },
                children: [g.jsxs("div", {
                    children: [g.jsx("div", {
                        style: {
                            display: "inline-block",
                            padding: "0.5rem 1rem",
                            backgroundColor: "red",
                            color: "#fff",
                            borderRadius: "0.2rem",
                            fontWeight: "600",
                            fontSize: "1rem"
                        },
                        children: "PDF"
                    }), g.jsx("span", {
                        style: {
                            color: "#fff",
                            margin: "0rem 0.5rem",
                            fontSize: "1rem",
                            fontWeight: "600"
                        },
                        children: "STUDYVAULT"
                    })]
                }), g.jsxs("div", {
                    style: {},
                    children: [g.jsx("button", {
                        onClick: a,
                        style: {
                            backgroundColor: "rgba(0, 0, 0, 0)",
                            border: "none",
                            padding: "10px 20px",
                            color: "#fff",
                            fontSize: "1rem",
                            borderRadius: "0.1rem",
                            cursor: "pointer",
                            zIndex: 1001,
                            margin: "0rem 1rem"
                        },
                        className: "active",
                        children: g.jsx("i", {
                            className: "fa-solid fa-download",
                            style: {
                                color: "#fff",
                                fontSize: "1.3rem"
                            }
                        })
                    }), g.jsx("button", {
                        onClick: n,
                        style: {
                            backgroundColor: "red",
                            border: "none",
                            padding: "0.5rem 1rem",
                            color: "#fff",
                            fontSize: "1rem",
                            borderRadius: "0.1rem",
                            cursor: "pointer",
                            zIndex: 1001,
                            fontWeight: "600"
                        },
                        children: "Close"
                    })]
                })]
            }), g.jsx("iframe", {
                src: s,
                title: "PDF Viewer",
                style: {
                    width: "100%",
                    height: "100%",
                    border: "none"
                }
            })]
        })
    },
    kR = e => (C.useEffect(() => {
        {
            if (window.adsbygoogle = window.adsbygoogle || [], !document.querySelector('script[src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"]')) {
                const r = document.createElement("script");
                r.async = !0, r.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9796833231647897", r.crossOrigin = "anonymous", document.head.appendChild(r)
            }
            const n = setTimeout(() => {
                try {
                    window.adsbygoogle && window.adsbygoogle.push({})
                } catch (r) {
                    console.error("AdSense error:", r)
                }
            }, 500);
            return () => clearTimeout(n)
        }
    }, []), g.jsx("div", {
        style: {
            width: "100%",
            overflow: "hidden"
        },
        children: g.jsx("ins", {
            className: "adsbygoogle",
            style: {
                display: "block",
                textAlign: "center",
                width: "100vw",
                minWidth: "250px ",
                background: e.background || "var( --notificationbackcolor )"
            },
            "data-ad-layout": "in-article",
            "data-ad-format": "fluid",
            "data-ad-client": "ca-pub-9796833231647897",
            "data-ad-slot": "9011527763"
        })
    })),
    bR = e => {
        const t = Sm(),
            {
                pdfName: n
            } = Bb(),
            r = os(),
            [i, s] = C.useState([]),
            o = C.useRef(),
            [a, l] = C.useState(!1),
            [u, c] = C.useState(""),
            [f, d] = C.useState(!1),
            [p, m] = C.useState(0),
            [h, _] = C.useState(!1),
            [v, y] = C.useState(!1),
            {
                data: x
            } = r.state || {
                data: []
            },
            [T, E] = C.useState(null),
            [k, S] = C.useState(!1),
            [P, A] = C.useState(""),
            [w, O] = C.useState(""),
            [F, V] = C.useState(!1);
        C.useEffect(() => {
            const B = setTimeout(() => {
                y(!0)
            }, 1e4);
            return () => clearTimeout(B)
        }, [f]), C.useEffect(() => {
            x ? (s(x), d(!0)) : (s([{
                id: "error",
                title: "Error loading papers, please try again later."
            }]), d(!0))
        }, []);
        const W = i.filter(B => B.title.toLowerCase().includes(u.toLowerCase())),
            Z = () => {
                a ? (o.current.style.transform = "translateY(-100%) scale(0)", o.current.style.margin = " 0rem 0", o.current.style.opacity = "0", l(!a)) : (o.current.style.transform = "translate(0%) scale(1)", o.current.style.margin = " 1rem 0 2rem 0", o.current.style.opacity = " 1", l(!a))
            };
        C.useEffect(() => {
            window.scrollTo(0, 0)
        }, []);
        const re = () => {
                t(-1)
            },
            q = B => {
                if (m(H => H + 1), (p + 1) % 2 === 0) {
                    _(!0), A(`/Downloadpdf/${B.title}`), O(B.url), V(!1);
                    const H = setTimeout(() => {
                        V(ie => (E(ne => !ne && !ie && F ? (t(`/Downloadpdf/${B.title}`), B.url) : ne), ie)), _(!1)
                    }, 5e3);
                    return () => clearTimeout(H)
                } else t(`/Downloadpdf/${B.title}`), E(B.url)
            },
            M = () => {
                A(""), O(""), V(!0), E(null), t(-1)
            };
        return C.useEffect(() => {
            const B = H => {
                E(null)
            };
            return window.addEventListener("popstate", B), () => {
                window.removeEventListener("popstate", B)
            }
        }, [t]), C.useEffect(() => {
            T ? document.body.style.overflow = "hidden" : document.body.style.overflowY = "scroll"
        }, [T]), C.useEffect(() => {
            if (!sessionStorage.getItem("donationpopup")) {
                const H = setTimeout(() => {
                    S(!0), sessionStorage.setItem("donationpopup", "true")
                }, 3e4);
                return () => clearTimeout(H)
            }
        }, []), g.jsxs(g.Fragment, {
            children: [g.jsxs("div", {
                id: "download-pdf",
                children: [g.jsxs("header", {
                    children: [g.jsx("div", {
                        className: "back-to-filter active",
                        onClick: re,
                        children: g.jsx("i", {
                            className: "fa-solid fa-arrow-left"
                        })
                    }), g.jsxs("h1", {
                        children: ["StudyVault", g.jsx("sub", {
                            children: "Downloads"
                        })]
                    }), g.jsx("div", {
                        className: "search-resources back-to-filter active",
                        onClick: Z,
                        children: g.jsx("i", {
                            className: "fa-solid fa-magnifying-glass"
                        })
                    })]
                }), g.jsxs("div", {
                    className: "download-box",
                    children: [g.jsx("div", {
                        className: "search-resuorces",
                        ref: o,
                        children: g.jsx("input", {
                            type: "text",
                            name: "search",
                            id: "search",
                            placeholder: "Search Core / Paper Name",
                            value: u,
                            onChange: B => c(B.target.value)
                        })
                    }), g.jsx("h2", {
                        children: "RESULTS"
                    }), f ? g.jsx("div", {
                        className: "download-data",
                        children: W.length > 0 && W ? W.map(B => g.jsx("li", {
                            onClick: () => q(B),
                            children: g.jsxs("div", {
                                className: "each-paper-box",
                                children: [B.title, g.jsx("div", {
                                    className: "paper-downlon-button",
                                    children: g.jsx("i", {
                                        className: "fa-solid fa-download"
                                    })
                                })]
                            })
                        }, B.id)) : g.jsx("div", {
                            children: g.jsx("p", {
                                style: {
                                    color: "#000",
                                    fontSize: "1.2rem",
                                    fontWeight: "500"
                                },
                                children: "Not Available"
                            })
                        })
                    }) : g.jsxs("div", {
                        className: "download-data",
                        children: [g.jsxs("p", {
                            style: {
                                color: "#000",
                                fontSize: "1rem",
                                fontWeight: "500",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center"
                            },
                            children: [" ", g.jsx("box-icon", {
                                name: "loader",
                                flip: "vertical",
                                animation: "spin",
                                color: "#000"
                            }), "  Loading..."]
                        }), v && !f && g.jsxs("p", {
                            style: {
                                padding: "5rem 0 0",
                                color: "#000"
                            },
                            children: ["Slow Network", g.jsx("i", {
                                className: "fa-solid fa-wifi",
                                style: {
                                    padding: "0rem 1rem",
                                    color: "red",
                                    fontSize: "1rem"
                                }
                            })]
                        })]
                    }), g.jsx(TR, {
                        background: "rgb(242 244 246)"
                    }), h && g.jsxs("div", {
                        style: {
                            position: "fixed",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%",
                            backgroundColor: "rgba(0, 0, 0, 0.8)",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            color: "white",
                            zIndex: 999999999999
                        },
                        children: [g.jsx("button", {
                            style: {
                                position: "absolute",
                                top: "1rem",
                                right: "1rem",
                                color: "white",
                                background: "transparent",
                                border: "none",
                                fontSize: "1.5rem",
                                cursor: "pointer"
                            },
                            onClick: () => {
                                _(!1), t(P), E(w)
                            },
                            children: "×"
                        }), g.jsx("div", {
                            children: g.jsx(kR, {})
                        })]
                    }), x.length > 0 ? g.jsxs("div", {
                        className: "name-instruction",
                        children: [g.jsx("h3", {
                            children: "INSTRUCTION :)"
                        }), g.jsx("p", {
                            style: {
                                fontWeight: "500"
                            },
                            children: "If  you don't understand the naming system then i will guide you to understand. Here is the decode..."
                        }), g.jsx("p", {
                            style: {
                                padding: "0rem 0 0 1rem",
                                color: "black",
                                fontSize: "0.9rem"
                            },
                            children: "Department Name / Paper Name _Student Year _ which Semester _ Core paper Name _ sem / mid _ Ug/Pg _ Session."
                        }), g.jsx("p", {
                            style: {
                                margin: "4rem 0",
                                color: "#000",
                                fontWeight: "600"
                            },
                            children: "Don't Forgate to give feedback."
                        })]
                    }) : g.jsxs("div", {
                        className: "name-instruction",
                        children: [g.jsx("h3", {
                            children: "Sorry we don't have  resources that you need. "
                        }), g.jsx("p", {
                            children: "We shall try to upload as soon as possible."
                        }), g.jsxs("p", {
                            children: ["Or you can enter session as ", g.jsx("strong", {
                                style: {
                                    fontWeight: "600",
                                    fontStyle: "italic"
                                },
                                children: "2020-2025"
                            }), " so if their are any resources present during those session, you can get."]
                        }), g.jsx("p", {
                            children: "Check  you have entered correct Department name. If your enter name and search suggestion name aren't same then you can not get any results;"
                        })]
                    })]
                })]
            }), g.jsx(ER, {}), T && g.jsx(PR, {
                pdfUrl: T,
                papertitle: P,
                onClose: M
            }), k && W.length > 0 && g.jsx("div", {
                className: "donation-popup",
                children: g.jsxs("div", {
                    className: "donation-popup-box",
                    children: [g.jsxs("h1", {
                        children: ["Hey Dear User, ", g.jsx("br", {}), " Support our growth by Donating to us!"]
                    }), g.jsx("span", {
                        children: "This website is running on our own funds, and we're unsure how far we can take it.  Your support can help us sustain and expand StudyVault to benefit more students!"
                    }), g.jsx("button", {
                        className: "active",
                        onClick: () => t("/payment-donate-us"),
                        children: "Donate Us"
                    }), g.jsx("p", {
                        onClick: () => S(!1),
                        children: " I do it later"
                    })]
                })
            })]
        })
    },
    vw = C.createContext(),
    RR = e => {
        const n = ["Computer Science", "Bca", "Botany", "Chemistry", "Data Science", "Geology", "BBA", "Itm", "Mathmatics", "Physics", "Sericalture", "Statistics", "Zoology", "Commerce", "Anthropology", "Economics", "Education", "English", "Geography", "Hindi", "History", "Sociology", "Odia", "Philosophy", "Political Science", "Psychology", "Sanskrit", "Santali", "MBA", "MCA", "Micro Biology", "Bio Chemistry", "MSW", "PUB ADM", "Enviromental Economics", "Industrial Chemistry", "Integrated B.Ed"].sort((r, i) => r.localeCompare(i));
        return g.jsx(vw.Provider, {
            value: n,
            children: e.children
        })
    },
    Cm = C.createContext(),
    AR = ({
        children: e
    }) => {
        const [t, n] = C.useState(null);
        return g.jsx(Cm.Provider, {
            value: {
                usernav: t,
                setUsernav: n
            },
            children: e
        })
    },
    xw = C.createContext(),
    DR = ({
        children: e
    }) => {
        const [t, n] = C.useState(null);
        return g.jsx(xw.Provider, {
            value: {
                filtersection: t,
                setFiltersection: n
            },
            children: e
        })
    },
    jR = C.createContext(),
    OR = e => g.jsx(jR.Provider, {
        value: {
            jituemailAddress: "jitpradhan856@gmail.com",
            akashemailAddress: "akashbindhani8144@gmail.com"
        },
        children: e.children
    });

function _w(e, t) {
    return function() {
        return e.apply(t, arguments)
    }
}
const {
    toString: LR
} = Object.prototype, {
    getPrototypeOf: Tm
} = Object, zc = (e => t => {
    const n = LR.call(t);
    return e[n] || (e[n] = n.slice(8, -1).toLowerCase())
})(Object.create(null)), Wn = e => (e = e.toLowerCase(), t => zc(t) === e), Uc = e => t => typeof t === e, {
    isArray: So
} = Array, za = Uc("undefined");

function MR(e) {
    return e !== null && !za(e) && e.constructor !== null && !za(e.constructor) && cn(e.constructor.isBuffer) && e.constructor.isBuffer(e)
}
const ww = Wn("ArrayBuffer");

function NR(e) {
    let t;
    return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? t = ArrayBuffer.isView(e) : t = e && e.buffer && ww(e.buffer), t
}
const FR = Uc("string"),
    cn = Uc("function"),
    Sw = Uc("number"),
    $c = e => e !== null && typeof e == "object",
    IR = e => e === !0 || e === !1,
    vu = e => {
        if (zc(e) !== "object") return !1;
        const t = Tm(e);
        return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
    },
    VR = Wn("Date"),
    BR = Wn("File"),
    zR = Wn("Blob"),
    UR = Wn("FileList"),
    $R = e => $c(e) && cn(e.pipe),
    WR = e => {
        let t;
        return e && (typeof FormData == "function" && e instanceof FormData || cn(e.append) && ((t = zc(e)) === "formdata" || t === "object" && cn(e.toString) && e.toString() === "[object FormData]"))
    },
    HR = Wn("URLSearchParams"),
    [KR, GR, YR, XR] = ["ReadableStream", "Request", "Response", "Headers"].map(Wn),
    qR = e => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");

function hl(e, t, {
    allOwnKeys: n = !1
} = {}) {
    if (e === null || typeof e > "u") return;
    let r, i;
    if (typeof e != "object" && (e = [e]), So(e))
        for (r = 0, i = e.length; r < i; r++) t.call(null, e[r], r, e);
    else {
        const s = n ? Object.getOwnPropertyNames(e) : Object.keys(e),
            o = s.length;
        let a;
        for (r = 0; r < o; r++) a = s[r], t.call(null, e[a], a, e)
    }
}

function Cw(e, t) {
    t = t.toLowerCase();
    const n = Object.keys(e);
    let r = n.length,
        i;
    for (; r-- > 0;)
        if (i = n[r], t === i.toLowerCase()) return i;
    return null
}
const Ii = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : global,
    Tw = e => !za(e) && e !== Ii;

function Rh() {
    const {
        caseless: e
    } = Tw(this) && this || {}, t = {}, n = (r, i) => {
        const s = e && Cw(t, i) || i;
        vu(t[s]) && vu(r) ? t[s] = Rh(t[s], r) : vu(r) ? t[s] = Rh({}, r) : So(r) ? t[s] = r.slice() : t[s] = r
    };
    for (let r = 0, i = arguments.length; r < i; r++) arguments[r] && hl(arguments[r], n);
    return t
}
const QR = (e, t, n, {
        allOwnKeys: r
    } = {}) => (hl(t, (i, s) => {
        n && cn(i) ? e[s] = _w(i, n) : e[s] = i
    }, {
        allOwnKeys: r
    }), e),
    JR = e => (e.charCodeAt(0) === 65279 && (e = e.slice(1)), e),
    ZR = (e, t, n, r) => {
        e.prototype = Object.create(t.prototype, r), e.prototype.constructor = e, Object.defineProperty(e, "super", {
            value: t.prototype
        }), n && Object.assign(e.prototype, n)
    },
    e2 = (e, t, n, r) => {
        let i, s, o;
        const a = {};
        if (t = t || {}, e == null) return t;
        do {
            for (i = Object.getOwnPropertyNames(e), s = i.length; s-- > 0;) o = i[s], (!r || r(o, e, t)) && !a[o] && (t[o] = e[o], a[o] = !0);
            e = n !== !1 && Tm(e)
        } while (e && (!n || n(e, t)) && e !== Object.prototype);
        return t
    },
    t2 = (e, t, n) => {
        e = String(e), (n === void 0 || n > e.length) && (n = e.length), n -= t.length;
        const r = e.indexOf(t, n);
        return r !== -1 && r === n
    },
    n2 = e => {
        if (!e) return null;
        if (So(e)) return e;
        let t = e.length;
        if (!Sw(t)) return null;
        const n = new Array(t);
        for (; t-- > 0;) n[t] = e[t];
        return n
    },
    r2 = (e => t => e && t instanceof e)(typeof Uint8Array < "u" && Tm(Uint8Array)),
    i2 = (e, t) => {
        const r = (e && e[Symbol.iterator]).call(e);
        let i;
        for (;
            (i = r.next()) && !i.done;) {
            const s = i.value;
            t.call(e, s[0], s[1])
        }
    },
    s2 = (e, t) => {
        let n;
        const r = [];
        for (;
            (n = e.exec(t)) !== null;) r.push(n);
        return r
    },
    o2 = Wn("HTMLFormElement"),
    a2 = e => e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(n, r, i) {
        return r.toUpperCase() + i
    }),
    C0 = (({
        hasOwnProperty: e
    }) => (t, n) => e.call(t, n))(Object.prototype),
    l2 = Wn("RegExp"),
    Ew = (e, t) => {
        const n = Object.getOwnPropertyDescriptors(e),
            r = {};
        hl(n, (i, s) => {
            let o;
            (o = t(i, s, e)) !== !1 && (r[s] = o || i)
        }), Object.defineProperties(e, r)
    },
    u2 = e => {
        Ew(e, (t, n) => {
            if (cn(e) && ["arguments", "caller", "callee"].indexOf(n) !== -1) return !1;
            const r = e[n];
            if (cn(r)) {
                if (t.enumerable = !1, "writable" in t) {
                    t.writable = !1;
                    return
                }
                t.set || (t.set = () => {
                    throw Error("Can not rewrite read-only method '" + n + "'")
                })
            }
        })
    },
    c2 = (e, t) => {
        const n = {},
            r = i => {
                i.forEach(s => {
                    n[s] = !0
                })
            };
        return So(e) ? r(e) : r(String(e).split(t)), n
    },
    f2 = () => {},
    d2 = (e, t) => e != null && Number.isFinite(e = +e) ? e : t,
    rd = "abcdefghijklmnopqrstuvwxyz",
    T0 = "0123456789",
    Pw = {
        DIGIT: T0,
        ALPHA: rd,
        ALPHA_DIGIT: rd + rd.toUpperCase() + T0
    },
    h2 = (e = 16, t = Pw.ALPHA_DIGIT) => {
        let n = "";
        const {
            length: r
        } = t;
        for (; e--;) n += t[Math.random() * r | 0];
        return n
    };

function p2(e) {
    return !!(e && cn(e.append) && e[Symbol.toStringTag] === "FormData" && e[Symbol.iterator])
}
const m2 = e => {
        const t = new Array(10),
            n = (r, i) => {
                if ($c(r)) {
                    if (t.indexOf(r) >= 0) return;
                    if (!("toJSON" in r)) {
                        t[i] = r;
                        const s = So(r) ? [] : {};
                        return hl(r, (o, a) => {
                            const l = n(o, i + 1);
                            !za(l) && (s[a] = l)
                        }), t[i] = void 0, s
                    }
                }
                return r
            };
        return n(e, 0)
    },
    g2 = Wn("AsyncFunction"),
    y2 = e => e && ($c(e) || cn(e)) && cn(e.then) && cn(e.catch),
    kw = ((e, t) => e ? setImmediate : t ? ((n, r) => (Ii.addEventListener("message", ({
        source: i,
        data: s
    }) => {
        i === Ii && s === n && r.length && r.shift()()
    }, !1), i => {
        r.push(i), Ii.postMessage(n, "*")
    }))(`axios@${Math.random()}`, []) : n => setTimeout(n))(typeof setImmediate == "function", cn(Ii.postMessage)),
    v2 = typeof queueMicrotask < "u" ? queueMicrotask.bind(Ii) : typeof process < "u" && process.nextTick || kw,
    j = {
        isArray: So,
        isArrayBuffer: ww,
        isBuffer: MR,
        isFormData: WR,
        isArrayBufferView: NR,
        isString: FR,
        isNumber: Sw,
        isBoolean: IR,
        isObject: $c,
        isPlainObject: vu,
        isReadableStream: KR,
        isRequest: GR,
        isResponse: YR,
        isHeaders: XR,
        isUndefined: za,
        isDate: VR,
        isFile: BR,
        isBlob: zR,
        isRegExp: l2,
        isFunction: cn,
        isStream: $R,
        isURLSearchParams: HR,
        isTypedArray: r2,
        isFileList: UR,
        forEach: hl,
        merge: Rh,
        extend: QR,
        trim: qR,
        stripBOM: JR,
        inherits: ZR,
        toFlatObject: e2,
        kindOf: zc,
        kindOfTest: Wn,
        endsWith: t2,
        toArray: n2,
        forEachEntry: i2,
        matchAll: s2,
        isHTMLForm: o2,
        hasOwnProperty: C0,
        hasOwnProp: C0,
        reduceDescriptors: Ew,
        freezeMethods: u2,
        toObjectSet: c2,
        toCamelCase: a2,
        noop: f2,
        toFiniteNumber: d2,
        findKey: Cw,
        global: Ii,
        isContextDefined: Tw,
        ALPHABET: Pw,
        generateString: h2,
        isSpecCompliantForm: p2,
        toJSONObject: m2,
        isAsyncFn: g2,
        isThenable: y2,
        setImmediate: kw,
        asap: v2
    };

function te(e, t, n, r, i) {
    Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack, this.message = e, this.name = "AxiosError", t && (this.code = t), n && (this.config = n), r && (this.request = r), i && (this.response = i, this.status = i.status ? i.status : null)
}
j.inherits(te, Error, {
    toJSON: function() {
        return {
            message: this.message,
            name: this.name,
            description: this.description,
            number: this.number,
            fileName: this.fileName,
            lineNumber: this.lineNumber,
            columnNumber: this.columnNumber,
            stack: this.stack,
            config: j.toJSONObject(this.config),
            code: this.code,
            status: this.status
        }
    }
});
const bw = te.prototype,
    Rw = {};
["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach(e => {
    Rw[e] = {
        value: e
    }
});
Object.defineProperties(te, Rw);
Object.defineProperty(bw, "isAxiosError", {
    value: !0
});
te.from = (e, t, n, r, i, s) => {
    const o = Object.create(bw);
    return j.toFlatObject(e, o, function(l) {
        return l !== Error.prototype
    }, a => a !== "isAxiosError"), te.call(o, e.message, t, n, r, i), o.cause = e, o.name = e.name, s && Object.assign(o, s), o
};
const x2 = null;

function Ah(e) {
    return j.isPlainObject(e) || j.isArray(e)
}

function Aw(e) {
    return j.endsWith(e, "[]") ? e.slice(0, -2) : e
}

function E0(e, t, n) {
    return e ? e.concat(t).map(function(i, s) {
        return i = Aw(i), !n && s ? "[" + i + "]" : i
    }).join(n ? "." : "") : t
}

function _2(e) {
    return j.isArray(e) && !e.some(Ah)
}
const w2 = j.toFlatObject(j, {}, null, function(t) {
    return /^is[A-Z]/.test(t)
});

function Wc(e, t, n) {
    if (!j.isObject(e)) throw new TypeError("target must be an object");
    t = t || new FormData, n = j.toFlatObject(n, {
        metaTokens: !0,
        dots: !1,
        indexes: !1
    }, !1, function(h, _) {
        return !j.isUndefined(_[h])
    });
    const r = n.metaTokens,
        i = n.visitor || c,
        s = n.dots,
        o = n.indexes,
        l = (n.Blob || typeof Blob < "u" && Blob) && j.isSpecCompliantForm(t);
    if (!j.isFunction(i)) throw new TypeError("visitor must be a function");

    function u(m) {
        if (m === null) return "";
        if (j.isDate(m)) return m.toISOString();
        if (!l && j.isBlob(m)) throw new te("Blob is not supported. Use a Buffer instead.");
        return j.isArrayBuffer(m) || j.isTypedArray(m) ? l && typeof Blob == "function" ? new Blob([m]) : Buffer.from(m) : m
    }

    function c(m, h, _) {
        let v = m;
        if (m && !_ && typeof m == "object") {
            if (j.endsWith(h, "{}")) h = r ? h : h.slice(0, -2), m = JSON.stringify(m);
            else if (j.isArray(m) && _2(m) || (j.isFileList(m) || j.endsWith(h, "[]")) && (v = j.toArray(m))) return h = Aw(h), v.forEach(function(x, T) {
                !(j.isUndefined(x) || x === null) && t.append(o === !0 ? E0([h], T, s) : o === null ? h : h + "[]", u(x))
            }), !1
        }
        return Ah(m) ? !0 : (t.append(E0(_, h, s), u(m)), !1)
    }
    const f = [],
        d = Object.assign(w2, {
            defaultVisitor: c,
            convertValue: u,
            isVisitable: Ah
        });

    function p(m, h) {
        if (!j.isUndefined(m)) {
            if (f.indexOf(m) !== -1) throw Error("Circular reference detected in " + h.join("."));
            f.push(m), j.forEach(m, function(v, y) {
                (!(j.isUndefined(v) || v === null) && i.call(t, v, j.isString(y) ? y.trim() : y, h, d)) === !0 && p(v, h ? h.concat(y) : [y])
            }), f.pop()
        }
    }
    if (!j.isObject(e)) throw new TypeError("data must be an object");
    return p(e), t
}

function P0(e) {
    const t = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
    };
    return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, function(r) {
        return t[r]
    })
}

function Em(e, t) {
    this._pairs = [], e && Wc(e, this, t)
}
const Dw = Em.prototype;
Dw.append = function(t, n) {
    this._pairs.push([t, n])
};
Dw.toString = function(t) {
    const n = t ? function(r) {
        return t.call(this, r, P0)
    } : P0;
    return this._pairs.map(function(i) {
        return n(i[0]) + "=" + n(i[1])
    }, "").join("&")
};

function S2(e) {
    return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
}

function jw(e, t, n) {
    if (!t) return e;
    const r = n && n.encode || S2;
    j.isFunction(n) && (n = {
        serialize: n
    });
    const i = n && n.serialize;
    let s;
    if (i ? s = i(t, n) : s = j.isURLSearchParams(t) ? t.toString() : new Em(t, n).toString(r), s) {
        const o = e.indexOf("#");
        o !== -1 && (e = e.slice(0, o)), e += (e.indexOf("?") === -1 ? "?" : "&") + s
    }
    return e
}
class k0 {
    constructor() {
        this.handlers = []
    }
    use(t, n, r) {
        return this.handlers.push({
            fulfilled: t,
            rejected: n,
            synchronous: r ? r.synchronous : !1,
            runWhen: r ? r.runWhen : null
        }), this.handlers.length - 1
    }
    eject(t) {
        this.handlers[t] && (this.handlers[t] = null)
    }
    clear() {
        this.handlers && (this.handlers = [])
    }
    forEach(t) {
        j.forEach(this.handlers, function(r) {
            r !== null && t(r)
        })
    }
}
const Ow = {
        silentJSONParsing: !0,
        forcedJSONParsing: !0,
        clarifyTimeoutError: !1
    },
    C2 = typeof URLSearchParams < "u" ? URLSearchParams : Em,
    T2 = typeof FormData < "u" ? FormData : null,
    E2 = typeof Blob < "u" ? Blob : null,
    P2 = {
        isBrowser: !0,
        classes: {
            URLSearchParams: C2,
            FormData: T2,
            Blob: E2
        },
        protocols: ["http", "https", "file", "blob", "url", "data"]
    },
    Pm = typeof window < "u" && typeof document < "u",
    Dh = typeof navigator == "object" && navigator || void 0,
    k2 = Pm && (!Dh || ["ReactNative", "NativeScript", "NS"].indexOf(Dh.product) < 0),
    b2 = typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope && typeof self.importScripts == "function",
    R2 = Pm && window.location.href || "http://localhost",
    A2 = Object.freeze(Object.defineProperty({
        __proto__: null,
        hasBrowserEnv: Pm,
        hasStandardBrowserEnv: k2,
        hasStandardBrowserWebWorkerEnv: b2,
        navigator: Dh,
        origin: R2
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    bt = { ...A2,
        ...P2
    };

function D2(e, t) {
    return Wc(e, new bt.classes.URLSearchParams, Object.assign({
        visitor: function(n, r, i, s) {
            return bt.isNode && j.isBuffer(n) ? (this.append(r, n.toString("base64")), !1) : s.defaultVisitor.apply(this, arguments)
        }
    }, t))
}

function j2(e) {
    return j.matchAll(/\w+|\[(\w*)]/g, e).map(t => t[0] === "[]" ? "" : t[1] || t[0])
}

function O2(e) {
    const t = {},
        n = Object.keys(e);
    let r;
    const i = n.length;
    let s;
    for (r = 0; r < i; r++) s = n[r], t[s] = e[s];
    return t
}

function Lw(e) {
    function t(n, r, i, s) {
        let o = n[s++];
        if (o === "__proto__") return !0;
        const a = Number.isFinite(+o),
            l = s >= n.length;
        return o = !o && j.isArray(i) ? i.length : o, l ? (j.hasOwnProp(i, o) ? i[o] = [i[o], r] : i[o] = r, !a) : ((!i[o] || !j.isObject(i[o])) && (i[o] = []), t(n, r, i[o], s) && j.isArray(i[o]) && (i[o] = O2(i[o])), !a)
    }
    if (j.isFormData(e) && j.isFunction(e.entries)) {
        const n = {};
        return j.forEachEntry(e, (r, i) => {
            t(j2(r), i, n, 0)
        }), n
    }
    return null
}

function L2(e, t, n) {
    if (j.isString(e)) try {
        return (t || JSON.parse)(e), j.trim(e)
    } catch (r) {
        if (r.name !== "SyntaxError") throw r
    }
    return (n || JSON.stringify)(e)
}
const pl = {
    transitional: Ow,
    adapter: ["xhr", "http", "fetch"],
    transformRequest: [function(t, n) {
        const r = n.getContentType() || "",
            i = r.indexOf("application/json") > -1,
            s = j.isObject(t);
        if (s && j.isHTMLForm(t) && (t = new FormData(t)), j.isFormData(t)) return i ? JSON.stringify(Lw(t)) : t;
        if (j.isArrayBuffer(t) || j.isBuffer(t) || j.isStream(t) || j.isFile(t) || j.isBlob(t) || j.isReadableStream(t)) return t;
        if (j.isArrayBufferView(t)) return t.buffer;
        if (j.isURLSearchParams(t)) return n.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), t.toString();
        let a;
        if (s) {
            if (r.indexOf("application/x-www-form-urlencoded") > -1) return D2(t, this.formSerializer).toString();
            if ((a = j.isFileList(t)) || r.indexOf("multipart/form-data") > -1) {
                const l = this.env && this.env.FormData;
                return Wc(a ? {
                    "files[]": t
                } : t, l && new l, this.formSerializer)
            }
        }
        return s || i ? (n.setContentType("application/json", !1), L2(t)) : t
    }],
    transformResponse: [function(t) {
        const n = this.transitional || pl.transitional,
            r = n && n.forcedJSONParsing,
            i = this.responseType === "json";
        if (j.isResponse(t) || j.isReadableStream(t)) return t;
        if (t && j.isString(t) && (r && !this.responseType || i)) {
            const o = !(n && n.silentJSONParsing) && i;
            try {
                return JSON.parse(t)
            } catch (a) {
                if (o) throw a.name === "SyntaxError" ? te.from(a, te.ERR_BAD_RESPONSE, this, null, this.response) : a
            }
        }
        return t
    }],
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
        FormData: bt.classes.FormData,
        Blob: bt.classes.Blob
    },
    validateStatus: function(t) {
        return t >= 200 && t < 300
    },
    headers: {
        common: {
            Accept: "application/json, text/plain, */*",
            "Content-Type": void 0
        }
    }
};
j.forEach(["delete", "get", "head", "post", "put", "patch"], e => {
    pl.headers[e] = {}
});
const M2 = j.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]),
    N2 = e => {
        const t = {};
        let n, r, i;
        return e && e.split(`
`).forEach(function(o) {
            i = o.indexOf(":"), n = o.substring(0, i).trim().toLowerCase(), r = o.substring(i + 1).trim(), !(!n || t[n] && M2[n]) && (n === "set-cookie" ? t[n] ? t[n].push(r) : t[n] = [r] : t[n] = t[n] ? t[n] + ", " + r : r)
        }), t
    },
    b0 = Symbol("internals");

function Uo(e) {
    return e && String(e).trim().toLowerCase()
}

function xu(e) {
    return e === !1 || e == null ? e : j.isArray(e) ? e.map(xu) : String(e)
}

function F2(e) {
    const t = Object.create(null),
        n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let r;
    for (; r = n.exec(e);) t[r[1]] = r[2];
    return t
}
const I2 = e => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());

function id(e, t, n, r, i) {
    if (j.isFunction(r)) return r.call(this, t, n);
    if (i && (t = n), !!j.isString(t)) {
        if (j.isString(r)) return t.indexOf(r) !== -1;
        if (j.isRegExp(r)) return r.test(t)
    }
}

function V2(e) {
    return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (t, n, r) => n.toUpperCase() + r)
}

function B2(e, t) {
    const n = j.toCamelCase(" " + t);
    ["get", "set", "has"].forEach(r => {
        Object.defineProperty(e, r + n, {
            value: function(i, s, o) {
                return this[r].call(this, t, i, s, o)
            },
            configurable: !0
        })
    })
}
let Gt = class {
    constructor(t) {
        t && this.set(t)
    }
    set(t, n, r) {
        const i = this;

        function s(a, l, u) {
            const c = Uo(l);
            if (!c) throw new Error("header name must be a non-empty string");
            const f = j.findKey(i, c);
            (!f || i[f] === void 0 || u === !0 || u === void 0 && i[f] !== !1) && (i[f || l] = xu(a))
        }
        const o = (a, l) => j.forEach(a, (u, c) => s(u, c, l));
        if (j.isPlainObject(t) || t instanceof this.constructor) o(t, n);
        else if (j.isString(t) && (t = t.trim()) && !I2(t)) o(N2(t), n);
        else if (j.isHeaders(t))
            for (const [a, l] of t.entries()) s(l, a, r);
        else t != null && s(n, t, r);
        return this
    }
    get(t, n) {
        if (t = Uo(t), t) {
            const r = j.findKey(this, t);
            if (r) {
                const i = this[r];
                if (!n) return i;
                if (n === !0) return F2(i);
                if (j.isFunction(n)) return n.call(this, i, r);
                if (j.isRegExp(n)) return n.exec(i);
                throw new TypeError("parser must be boolean|regexp|function")
            }
        }
    }
    has(t, n) {
        if (t = Uo(t), t) {
            const r = j.findKey(this, t);
            return !!(r && this[r] !== void 0 && (!n || id(this, this[r], r, n)))
        }
        return !1
    }
    delete(t, n) {
        const r = this;
        let i = !1;

        function s(o) {
            if (o = Uo(o), o) {
                const a = j.findKey(r, o);
                a && (!n || id(r, r[a], a, n)) && (delete r[a], i = !0)
            }
        }
        return j.isArray(t) ? t.forEach(s) : s(t), i
    }
    clear(t) {
        const n = Object.keys(this);
        let r = n.length,
            i = !1;
        for (; r--;) {
            const s = n[r];
            (!t || id(this, this[s], s, t, !0)) && (delete this[s], i = !0)
        }
        return i
    }
    normalize(t) {
        const n = this,
            r = {};
        return j.forEach(this, (i, s) => {
            const o = j.findKey(r, s);
            if (o) {
                n[o] = xu(i), delete n[s];
                return
            }
            const a = t ? V2(s) : String(s).trim();
            a !== s && delete n[s], n[a] = xu(i), r[a] = !0
        }), this
    }
    concat(...t) {
        return this.constructor.concat(this, ...t)
    }
    toJSON(t) {
        const n = Object.create(null);
        return j.forEach(this, (r, i) => {
            r != null && r !== !1 && (n[i] = t && j.isArray(r) ? r.join(", ") : r)
        }), n
    }[Symbol.iterator]() {
        return Object.entries(this.toJSON())[Symbol.iterator]()
    }
    toString() {
        return Object.entries(this.toJSON()).map(([t, n]) => t + ": " + n).join(`
`)
    }
    get[Symbol.toStringTag]() {
        return "AxiosHeaders"
    }
    static from(t) {
        return t instanceof this ? t : new this(t)
    }
    static concat(t, ...n) {
        const r = new this(t);
        return n.forEach(i => r.set(i)), r
    }
    static accessor(t) {
        const r = (this[b0] = this[b0] = {
                accessors: {}
            }).accessors,
            i = this.prototype;

        function s(o) {
            const a = Uo(o);
            r[a] || (B2(i, o), r[a] = !0)
        }
        return j.isArray(t) ? t.forEach(s) : s(t), this
    }
};
Gt.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
j.reduceDescriptors(Gt.prototype, ({
    value: e
}, t) => {
    let n = t[0].toUpperCase() + t.slice(1);
    return {
        get: () => e,
        set(r) {
            this[n] = r
        }
    }
});
j.freezeMethods(Gt);

function sd(e, t) {
    const n = this || pl,
        r = t || n,
        i = Gt.from(r.headers);
    let s = r.data;
    return j.forEach(e, function(a) {
        s = a.call(n, s, i.normalize(), t ? t.status : void 0)
    }), i.normalize(), s
}

function Mw(e) {
    return !!(e && e.__CANCEL__)
}

function Co(e, t, n) {
    te.call(this, e ? ? "canceled", te.ERR_CANCELED, t, n), this.name = "CanceledError"
}
j.inherits(Co, te, {
    __CANCEL__: !0
});

function Nw(e, t, n) {
    const r = n.config.validateStatus;
    !n.status || !r || r(n.status) ? e(n) : t(new te("Request failed with status code " + n.status, [te.ERR_BAD_REQUEST, te.ERR_BAD_RESPONSE][Math.floor(n.status / 100) - 4], n.config, n.request, n))
}

function z2(e) {
    const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
    return t && t[1] || ""
}

function U2(e, t) {
    e = e || 10;
    const n = new Array(e),
        r = new Array(e);
    let i = 0,
        s = 0,
        o;
    return t = t !== void 0 ? t : 1e3,
        function(l) {
            const u = Date.now(),
                c = r[s];
            o || (o = u), n[i] = l, r[i] = u;
            let f = s,
                d = 0;
            for (; f !== i;) d += n[f++], f = f % e;
            if (i = (i + 1) % e, i === s && (s = (s + 1) % e), u - o < t) return;
            const p = c && u - c;
            return p ? Math.round(d * 1e3 / p) : void 0
        }
}

function $2(e, t) {
    let n = 0,
        r = 1e3 / t,
        i, s;
    const o = (u, c = Date.now()) => {
        n = c, i = null, s && (clearTimeout(s), s = null), e.apply(null, u)
    };
    return [(...u) => {
        const c = Date.now(),
            f = c - n;
        f >= r ? o(u, c) : (i = u, s || (s = setTimeout(() => {
            s = null, o(i)
        }, r - f)))
    }, () => i && o(i)]
}
const sc = (e, t, n = 3) => {
        let r = 0;
        const i = U2(50, 250);
        return $2(s => {
            const o = s.loaded,
                a = s.lengthComputable ? s.total : void 0,
                l = o - r,
                u = i(l),
                c = o <= a;
            r = o;
            const f = {
                loaded: o,
                total: a,
                progress: a ? o / a : void 0,
                bytes: l,
                rate: u || void 0,
                estimated: u && a && c ? (a - o) / u : void 0,
                event: s,
                lengthComputable: a != null,
                [t ? "download" : "upload"]: !0
            };
            e(f)
        }, n)
    },
    R0 = (e, t) => {
        const n = e != null;
        return [r => t[0]({
            lengthComputable: n,
            total: e,
            loaded: r
        }), t[1]]
    },
    A0 = e => (...t) => j.asap(() => e(...t)),
    W2 = bt.hasStandardBrowserEnv ? ((e, t) => n => (n = new URL(n, bt.origin), e.protocol === n.protocol && e.host === n.host && (t || e.port === n.port)))(new URL(bt.origin), bt.navigator && /(msie|trident)/i.test(bt.navigator.userAgent)) : () => !0,
    H2 = bt.hasStandardBrowserEnv ? {
        write(e, t, n, r, i, s) {
            const o = [e + "=" + encodeURIComponent(t)];
            j.isNumber(n) && o.push("expires=" + new Date(n).toGMTString()), j.isString(r) && o.push("path=" + r), j.isString(i) && o.push("domain=" + i), s === !0 && o.push("secure"), document.cookie = o.join("; ")
        },
        read(e) {
            const t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
            return t ? decodeURIComponent(t[3]) : null
        },
        remove(e) {
            this.write(e, "", Date.now() - 864e5)
        }
    } : {
        write() {},
        read() {
            return null
        },
        remove() {}
    };

function K2(e) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e)
}

function G2(e, t) {
    return t ? e.replace(/\/?\/$/, "") + "/" + t.replace(/^\/+/, "") : e
}

function Fw(e, t) {
    return e && !K2(t) ? G2(e, t) : t
}
const D0 = e => e instanceof Gt ? { ...e
} : e;

function ts(e, t) {
    t = t || {};
    const n = {};

    function r(u, c, f, d) {
        return j.isPlainObject(u) && j.isPlainObject(c) ? j.merge.call({
            caseless: d
        }, u, c) : j.isPlainObject(c) ? j.merge({}, c) : j.isArray(c) ? c.slice() : c
    }

    function i(u, c, f, d) {
        if (j.isUndefined(c)) {
            if (!j.isUndefined(u)) return r(void 0, u, f, d)
        } else return r(u, c, f, d)
    }

    function s(u, c) {
        if (!j.isUndefined(c)) return r(void 0, c)
    }

    function o(u, c) {
        if (j.isUndefined(c)) {
            if (!j.isUndefined(u)) return r(void 0, u)
        } else return r(void 0, c)
    }

    function a(u, c, f) {
        if (f in t) return r(u, c);
        if (f in e) return r(void 0, u)
    }
    const l = {
        url: s,
        method: s,
        data: s,
        baseURL: o,
        transformRequest: o,
        transformResponse: o,
        paramsSerializer: o,
        timeout: o,
        timeoutMessage: o,
        withCredentials: o,
        withXSRFToken: o,
        adapter: o,
        responseType: o,
        xsrfCookieName: o,
        xsrfHeaderName: o,
        onUploadProgress: o,
        onDownloadProgress: o,
        decompress: o,
        maxContentLength: o,
        maxBodyLength: o,
        beforeRedirect: o,
        transport: o,
        httpAgent: o,
        httpsAgent: o,
        cancelToken: o,
        socketPath: o,
        responseEncoding: o,
        validateStatus: a,
        headers: (u, c, f) => i(D0(u), D0(c), f, !0)
    };
    return j.forEach(Object.keys(Object.assign({}, e, t)), function(c) {
        const f = l[c] || i,
            d = f(e[c], t[c], c);
        j.isUndefined(d) && f !== a || (n[c] = d)
    }), n
}
const Iw = e => {
        const t = ts({}, e);
        let {
            data: n,
            withXSRFToken: r,
            xsrfHeaderName: i,
            xsrfCookieName: s,
            headers: o,
            auth: a
        } = t;
        t.headers = o = Gt.from(o), t.url = jw(Fw(t.baseURL, t.url), e.params, e.paramsSerializer), a && o.set("Authorization", "Basic " + btoa((a.username || "") + ":" + (a.password ? unescape(encodeURIComponent(a.password)) : "")));
        let l;
        if (j.isFormData(n)) {
            if (bt.hasStandardBrowserEnv || bt.hasStandardBrowserWebWorkerEnv) o.setContentType(void 0);
            else if ((l = o.getContentType()) !== !1) {
                const [u, ...c] = l ? l.split(";").map(f => f.trim()).filter(Boolean) : [];
                o.setContentType([u || "multipart/form-data", ...c].join("; "))
            }
        }
        if (bt.hasStandardBrowserEnv && (r && j.isFunction(r) && (r = r(t)), r || r !== !1 && W2(t.url))) {
            const u = i && s && H2.read(s);
            u && o.set(i, u)
        }
        return t
    },
    Y2 = typeof XMLHttpRequest < "u",
    X2 = Y2 && function(e) {
        return new Promise(function(n, r) {
            const i = Iw(e);
            let s = i.data;
            const o = Gt.from(i.headers).normalize();
            let {
                responseType: a,
                onUploadProgress: l,
                onDownloadProgress: u
            } = i, c, f, d, p, m;

            function h() {
                p && p(), m && m(), i.cancelToken && i.cancelToken.unsubscribe(c), i.signal && i.signal.removeEventListener("abort", c)
            }
            let _ = new XMLHttpRequest;
            _.open(i.method.toUpperCase(), i.url, !0), _.timeout = i.timeout;

            function v() {
                if (!_) return;
                const x = Gt.from("getAllResponseHeaders" in _ && _.getAllResponseHeaders()),
                    E = {
                        data: !a || a === "text" || a === "json" ? _.responseText : _.response,
                        status: _.status,
                        statusText: _.statusText,
                        headers: x,
                        config: e,
                        request: _
                    };
                Nw(function(S) {
                    n(S), h()
                }, function(S) {
                    r(S), h()
                }, E), _ = null
            }
            "onloadend" in _ ? _.onloadend = v : _.onreadystatechange = function() {
                !_ || _.readyState !== 4 || _.status === 0 && !(_.responseURL && _.responseURL.indexOf("file:") === 0) || setTimeout(v)
            }, _.onabort = function() {
                _ && (r(new te("Request aborted", te.ECONNABORTED, e, _)), _ = null)
            }, _.onerror = function() {
                r(new te("Network Error", te.ERR_NETWORK, e, _)), _ = null
            }, _.ontimeout = function() {
                let T = i.timeout ? "timeout of " + i.timeout + "ms exceeded" : "timeout exceeded";
                const E = i.transitional || Ow;
                i.timeoutErrorMessage && (T = i.timeoutErrorMessage), r(new te(T, E.clarifyTimeoutError ? te.ETIMEDOUT : te.ECONNABORTED, e, _)), _ = null
            }, s === void 0 && o.setContentType(null), "setRequestHeader" in _ && j.forEach(o.toJSON(), function(T, E) {
                _.setRequestHeader(E, T)
            }), j.isUndefined(i.withCredentials) || (_.withCredentials = !!i.withCredentials), a && a !== "json" && (_.responseType = i.responseType), u && ([d, m] = sc(u, !0), _.addEventListener("progress", d)), l && _.upload && ([f, p] = sc(l), _.upload.addEventListener("progress", f), _.upload.addEventListener("loadend", p)), (i.cancelToken || i.signal) && (c = x => {
                _ && (r(!x || x.type ? new Co(null, e, _) : x), _.abort(), _ = null)
            }, i.cancelToken && i.cancelToken.subscribe(c), i.signal && (i.signal.aborted ? c() : i.signal.addEventListener("abort", c)));
            const y = z2(i.url);
            if (y && bt.protocols.indexOf(y) === -1) {
                r(new te("Unsupported protocol " + y + ":", te.ERR_BAD_REQUEST, e));
                return
            }
            _.send(s || null)
        })
    },
    q2 = (e, t) => {
        const {
            length: n
        } = e = e ? e.filter(Boolean) : [];
        if (t || n) {
            let r = new AbortController,
                i;
            const s = function(u) {
                if (!i) {
                    i = !0, a();
                    const c = u instanceof Error ? u : this.reason;
                    r.abort(c instanceof te ? c : new Co(c instanceof Error ? c.message : c))
                }
            };
            let o = t && setTimeout(() => {
                o = null, s(new te(`timeout ${t} of ms exceeded`, te.ETIMEDOUT))
            }, t);
            const a = () => {
                e && (o && clearTimeout(o), o = null, e.forEach(u => {
                    u.unsubscribe ? u.unsubscribe(s) : u.removeEventListener("abort", s)
                }), e = null)
            };
            e.forEach(u => u.addEventListener("abort", s));
            const {
                signal: l
            } = r;
            return l.unsubscribe = () => j.asap(a), l
        }
    },
    Q2 = function*(e, t) {
        let n = e.byteLength;
        if (n < t) {
            yield e;
            return
        }
        let r = 0,
            i;
        for (; r < n;) i = r + t, yield e.slice(r, i), r = i
    },
    J2 = async function*(e, t) {
        for await (const n of Z2(e)) yield* Q2(n, t)
    },
    Z2 = async function*(e) {
        if (e[Symbol.asyncIterator]) {
            yield* e;
            return
        }
        const t = e.getReader();
        try {
            for (;;) {
                const {
                    done: n,
                    value: r
                } = await t.read();
                if (n) break;
                yield r
            }
        } finally {
            await t.cancel()
        }
    },
    j0 = (e, t, n, r) => {
        const i = J2(e, t);
        let s = 0,
            o, a = l => {
                o || (o = !0, r && r(l))
            };
        return new ReadableStream({
            async pull(l) {
                try {
                    const {
                        done: u,
                        value: c
                    } = await i.next();
                    if (u) {
                        a(), l.close();
                        return
                    }
                    let f = c.byteLength;
                    if (n) {
                        let d = s += f;
                        n(d)
                    }
                    l.enqueue(new Uint8Array(c))
                } catch (u) {
                    throw a(u), u
                }
            },
            cancel(l) {
                return a(l), i.return()
            }
        }, {
            highWaterMark: 2
        })
    },
    Hc = typeof fetch == "function" && typeof Request == "function" && typeof Response == "function",
    Vw = Hc && typeof ReadableStream == "function",
    eA = Hc && (typeof TextEncoder == "function" ? (e => t => e.encode(t))(new TextEncoder) : async e => new Uint8Array(await new Response(e).arrayBuffer())),
    Bw = (e, ...t) => {
        try {
            return !!e(...t)
        } catch {
            return !1
        }
    },
    tA = Vw && Bw(() => {
        let e = !1;
        const t = new Request(bt.origin, {
            body: new ReadableStream,
            method: "POST",
            get duplex() {
                return e = !0, "half"
            }
        }).headers.has("Content-Type");
        return e && !t
    }),
    O0 = 64 * 1024,
    jh = Vw && Bw(() => j.isReadableStream(new Response("").body)),
    oc = {
        stream: jh && (e => e.body)
    };
Hc && (e => {
    ["text", "arrayBuffer", "blob", "formData", "stream"].forEach(t => {
        !oc[t] && (oc[t] = j.isFunction(e[t]) ? n => n[t]() : (n, r) => {
            throw new te(`Response type '${t}' is not supported`, te.ERR_NOT_SUPPORT, r)
        })
    })
})(new Response);
const nA = async e => {
        if (e == null) return 0;
        if (j.isBlob(e)) return e.size;
        if (j.isSpecCompliantForm(e)) return (await new Request(bt.origin, {
            method: "POST",
            body: e
        }).arrayBuffer()).byteLength;
        if (j.isArrayBufferView(e) || j.isArrayBuffer(e)) return e.byteLength;
        if (j.isURLSearchParams(e) && (e = e + ""), j.isString(e)) return (await eA(e)).byteLength
    },
    rA = async (e, t) => {
        const n = j.toFiniteNumber(e.getContentLength());
        return n ? ? nA(t)
    },
    iA = Hc && (async e => {
        let {
            url: t,
            method: n,
            data: r,
            signal: i,
            cancelToken: s,
            timeout: o,
            onDownloadProgress: a,
            onUploadProgress: l,
            responseType: u,
            headers: c,
            withCredentials: f = "same-origin",
            fetchOptions: d
        } = Iw(e);
        u = u ? (u + "").toLowerCase() : "text";
        let p = q2([i, s && s.toAbortSignal()], o),
            m;
        const h = p && p.unsubscribe && (() => {
            p.unsubscribe()
        });
        let _;
        try {
            if (l && tA && n !== "get" && n !== "head" && (_ = await rA(c, r)) !== 0) {
                let E = new Request(t, {
                        method: "POST",
                        body: r,
                        duplex: "half"
                    }),
                    k;
                if (j.isFormData(r) && (k = E.headers.get("content-type")) && c.setContentType(k), E.body) {
                    const [S, P] = R0(_, sc(A0(l)));
                    r = j0(E.body, O0, S, P)
                }
            }
            j.isString(f) || (f = f ? "include" : "omit");
            const v = "credentials" in Request.prototype;
            m = new Request(t, { ...d,
                signal: p,
                method: n.toUpperCase(),
                headers: c.normalize().toJSON(),
                body: r,
                duplex: "half",
                credentials: v ? f : void 0
            });
            let y = await fetch(m);
            const x = jh && (u === "stream" || u === "response");
            if (jh && (a || x && h)) {
                const E = {};
                ["status", "statusText", "headers"].forEach(A => {
                    E[A] = y[A]
                });
                const k = j.toFiniteNumber(y.headers.get("content-length")),
                    [S, P] = a && R0(k, sc(A0(a), !0)) || [];
                y = new Response(j0(y.body, O0, S, () => {
                    P && P(), h && h()
                }), E)
            }
            u = u || "text";
            let T = await oc[j.findKey(oc, u) || "text"](y, e);
            return !x && h && h(), await new Promise((E, k) => {
                Nw(E, k, {
                    data: T,
                    headers: Gt.from(y.headers),
                    status: y.status,
                    statusText: y.statusText,
                    config: e,
                    request: m
                })
            })
        } catch (v) {
            throw h && h(), v && v.name === "TypeError" && /fetch/i.test(v.message) ? Object.assign(new te("Network Error", te.ERR_NETWORK, e, m), {
                cause: v.cause || v
            }) : te.from(v, v && v.code, e, m)
        }
    }),
    Oh = {
        http: x2,
        xhr: X2,
        fetch: iA
    };
j.forEach(Oh, (e, t) => {
    if (e) {
        try {
            Object.defineProperty(e, "name", {
                value: t
            })
        } catch {}
        Object.defineProperty(e, "adapterName", {
            value: t
        })
    }
});
const L0 = e => `- ${e}`,
    sA = e => j.isFunction(e) || e === null || e === !1,
    zw = {
        getAdapter: e => {
            e = j.isArray(e) ? e : [e];
            const {
                length: t
            } = e;
            let n, r;
            const i = {};
            for (let s = 0; s < t; s++) {
                n = e[s];
                let o;
                if (r = n, !sA(n) && (r = Oh[(o = String(n)).toLowerCase()], r === void 0)) throw new te(`Unknown adapter '${o}'`);
                if (r) break;
                i[o || "#" + s] = r
            }
            if (!r) {
                const s = Object.entries(i).map(([a, l]) => `adapter ${a} ` + (l === !1 ? "is not supported by the environment" : "is not available in the build"));
                let o = t ? s.length > 1 ? `since :
` + s.map(L0).join(`
`) : " " + L0(s[0]) : "as no adapter specified";
                throw new te("There is no suitable adapter to dispatch the request " + o, "ERR_NOT_SUPPORT")
            }
            return r
        },
        adapters: Oh
    };

function od(e) {
    if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted) throw new Co(null, e)
}

function M0(e) {
    return od(e), e.headers = Gt.from(e.headers), e.data = sd.call(e, e.transformRequest), ["post", "put", "patch"].indexOf(e.method) !== -1 && e.headers.setContentType("application/x-www-form-urlencoded", !1), zw.getAdapter(e.adapter || pl.adapter)(e).then(function(r) {
        return od(e), r.data = sd.call(e, e.transformResponse, r), r.headers = Gt.from(r.headers), r
    }, function(r) {
        return Mw(r) || (od(e), r && r.response && (r.response.data = sd.call(e, e.transformResponse, r.response), r.response.headers = Gt.from(r.response.headers))), Promise.reject(r)
    })
}
const Uw = "1.7.9",
    Kc = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach((e, t) => {
    Kc[e] = function(r) {
        return typeof r === e || "a" + (t < 1 ? "n " : " ") + e
    }
});
const N0 = {};
Kc.transitional = function(t, n, r) {
    function i(s, o) {
        return "[Axios v" + Uw + "] Transitional option '" + s + "'" + o + (r ? ". " + r : "")
    }
    return (s, o, a) => {
        if (t === !1) throw new te(i(o, " has been removed" + (n ? " in " + n : "")), te.ERR_DEPRECATED);
        return n && !N0[o] && (N0[o] = !0, console.warn(i(o, " has been deprecated since v" + n + " and will be removed in the near future"))), t ? t(s, o, a) : !0
    }
};
Kc.spelling = function(t) {
    return (n, r) => (console.warn(`${r} is likely a misspelling of ${t}`), !0)
};

function oA(e, t, n) {
    if (typeof e != "object") throw new te("options must be an object", te.ERR_BAD_OPTION_VALUE);
    const r = Object.keys(e);
    let i = r.length;
    for (; i-- > 0;) {
        const s = r[i],
            o = t[s];
        if (o) {
            const a = e[s],
                l = a === void 0 || o(a, s, e);
            if (l !== !0) throw new te("option " + s + " must be " + l, te.ERR_BAD_OPTION_VALUE);
            continue
        }
        if (n !== !0) throw new te("Unknown option " + s, te.ERR_BAD_OPTION)
    }
}
const _u = {
        assertOptions: oA,
        validators: Kc
    },
    Yn = _u.validators;
let $i = class {
    constructor(t) {
        this.defaults = t, this.interceptors = {
            request: new k0,
            response: new k0
        }
    }
    async request(t, n) {
        try {
            return await this._request(t, n)
        } catch (r) {
            if (r instanceof Error) {
                let i = {};
                Error.captureStackTrace ? Error.captureStackTrace(i) : i = new Error;
                const s = i.stack ? i.stack.replace(/^.+\n/, "") : "";
                try {
                    r.stack ? s && !String(r.stack).endsWith(s.replace(/^.+\n.+\n/, "")) && (r.stack += `
` + s) : r.stack = s
                } catch {}
            }
            throw r
        }
    }
    _request(t, n) {
        typeof t == "string" ? (n = n || {}, n.url = t) : n = t || {}, n = ts(this.defaults, n);
        const {
            transitional: r,
            paramsSerializer: i,
            headers: s
        } = n;
        r !== void 0 && _u.assertOptions(r, {
            silentJSONParsing: Yn.transitional(Yn.boolean),
            forcedJSONParsing: Yn.transitional(Yn.boolean),
            clarifyTimeoutError: Yn.transitional(Yn.boolean)
        }, !1), i != null && (j.isFunction(i) ? n.paramsSerializer = {
            serialize: i
        } : _u.assertOptions(i, {
            encode: Yn.function,
            serialize: Yn.function
        }, !0)), _u.assertOptions(n, {
            baseUrl: Yn.spelling("baseURL"),
            withXsrfToken: Yn.spelling("withXSRFToken")
        }, !0), n.method = (n.method || this.defaults.method || "get").toLowerCase();
        let o = s && j.merge(s.common, s[n.method]);
        s && j.forEach(["delete", "get", "head", "post", "put", "patch", "common"], m => {
            delete s[m]
        }), n.headers = Gt.concat(o, s);
        const a = [];
        let l = !0;
        this.interceptors.request.forEach(function(h) {
            typeof h.runWhen == "function" && h.runWhen(n) === !1 || (l = l && h.synchronous, a.unshift(h.fulfilled, h.rejected))
        });
        const u = [];
        this.interceptors.response.forEach(function(h) {
            u.push(h.fulfilled, h.rejected)
        });
        let c, f = 0,
            d;
        if (!l) {
            const m = [M0.bind(this), void 0];
            for (m.unshift.apply(m, a), m.push.apply(m, u), d = m.length, c = Promise.resolve(n); f < d;) c = c.then(m[f++], m[f++]);
            return c
        }
        d = a.length;
        let p = n;
        for (f = 0; f < d;) {
            const m = a[f++],
                h = a[f++];
            try {
                p = m(p)
            } catch (_) {
                h.call(this, _);
                break
            }
        }
        try {
            c = M0.call(this, p)
        } catch (m) {
            return Promise.reject(m)
        }
        for (f = 0, d = u.length; f < d;) c = c.then(u[f++], u[f++]);
        return c
    }
    getUri(t) {
        t = ts(this.defaults, t);
        const n = Fw(t.baseURL, t.url);
        return jw(n, t.params, t.paramsSerializer)
    }
};
j.forEach(["delete", "get", "head", "options"], function(t) {
    $i.prototype[t] = function(n, r) {
        return this.request(ts(r || {}, {
            method: t,
            url: n,
            data: (r || {}).data
        }))
    }
});
j.forEach(["post", "put", "patch"], function(t) {
    function n(r) {
        return function(s, o, a) {
            return this.request(ts(a || {}, {
                method: t,
                headers: r ? {
                    "Content-Type": "multipart/form-data"
                } : {},
                url: s,
                data: o
            }))
        }
    }
    $i.prototype[t] = n(), $i.prototype[t + "Form"] = n(!0)
});
let aA = class $w {
    constructor(t) {
        if (typeof t != "function") throw new TypeError("executor must be a function.");
        let n;
        this.promise = new Promise(function(s) {
            n = s
        });
        const r = this;
        this.promise.then(i => {
            if (!r._listeners) return;
            let s = r._listeners.length;
            for (; s-- > 0;) r._listeners[s](i);
            r._listeners = null
        }), this.promise.then = i => {
            let s;
            const o = new Promise(a => {
                r.subscribe(a), s = a
            }).then(i);
            return o.cancel = function() {
                r.unsubscribe(s)
            }, o
        }, t(function(s, o, a) {
            r.reason || (r.reason = new Co(s, o, a), n(r.reason))
        })
    }
    throwIfRequested() {
        if (this.reason) throw this.reason
    }
    subscribe(t) {
        if (this.reason) {
            t(this.reason);
            return
        }
        this._listeners ? this._listeners.push(t) : this._listeners = [t]
    }
    unsubscribe(t) {
        if (!this._listeners) return;
        const n = this._listeners.indexOf(t);
        n !== -1 && this._listeners.splice(n, 1)
    }
    toAbortSignal() {
        const t = new AbortController,
            n = r => {
                t.abort(r)
            };
        return this.subscribe(n), t.signal.unsubscribe = () => this.unsubscribe(n), t.signal
    }
    static source() {
        let t;
        return {
            token: new $w(function(i) {
                t = i
            }),
            cancel: t
        }
    }
};

function lA(e) {
    return function(n) {
        return e.apply(null, n)
    }
}

function uA(e) {
    return j.isObject(e) && e.isAxiosError === !0
}
const Lh = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511
};
Object.entries(Lh).forEach(([e, t]) => {
    Lh[t] = e
});

function Ww(e) {
    const t = new $i(e),
        n = _w($i.prototype.request, t);
    return j.extend(n, $i.prototype, t, {
        allOwnKeys: !0
    }), j.extend(n, t, null, {
        allOwnKeys: !0
    }), n.create = function(i) {
        return Ww(ts(e, i))
    }, n
}
const et = Ww(pl);
et.Axios = $i;
et.CanceledError = Co;
et.CancelToken = aA;
et.isCancel = Mw;
et.VERSION = Uw;
et.toFormData = Wc;
et.AxiosError = te;
et.Cancel = et.CanceledError;
et.all = function(t) {
    return Promise.all(t)
};
et.spread = lA;
et.isAxiosError = uA;
et.mergeConfig = ts;
et.AxiosHeaders = Gt;
et.formToJSON = e => Lw(j.isHTMLForm(e) ? new FormData(e) : e);
et.getAdapter = zw.getAdapter;
et.HttpStatusCode = Lh;
et.default = et;
const {
    Axios: m3,
    AxiosError: g3,
    CanceledError: y3,
    isCancel: v3,
    CancelToken: x3,
    VERSION: _3,
    all: w3,
    Cancel: S3,
    isAxiosError: C3,
    spread: T3,
    toFormData: E3,
    AxiosHeaders: P3,
    HttpStatusCode: k3,
    formToJSON: b3,
    getAdapter: R3,
    mergeConfig: A3
} = et, Hw = C.createContext(), cA = e => {
    const {
        usernav: t
    } = C.useContext(Cm), [n, r] = C.useState(null), i = sessionStorage.getItem("isLoggedIn");
    return C.useEffect(() => {
        r(i || null)
    }, [t]), g.jsx(Hw.Provider, {
        value: {
            loginCheck: n,
            setLoginCheck: r
        },
        children: e.children
    })
}, fA = C.createContext(), dA = ({
    children: e
}) => {
    const [t, n] = C.useState([]);
    return g.jsx(fA.Provider, {
        value: {
            paperList: t,
            setPaperList: n
        },
        children: e
    })
}, Kw = C.createContext(), hA = e => {
    const [t, n] = C.useState("");
    return g.jsx(Kw.Provider, {
        value: {
            check: t,
            setCheck: n
        },
        children: e.children
    })
}, pA = C.createContext(), mA = e => {
    const [t, n] = C.useState("");
    return g.jsx(pA.Provider, {
        value: {
            heading: t,
            setHeading: n
        },
        children: e.children
    })
};

function mr(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function Gw(e, t) {
    e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
}
/*!
 * GSAP 3.12.7
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license or for
 * Club GSAP members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var fn = {
        autoSleep: 120,
        force3D: "auto",
        nullTargetWarn: 1,
        units: {
            lineHeight: ""
        }
    },
    oo = {
        duration: .5,
        overwrite: !1,
        delay: 0
    },
    km, _t, Me, sr = 1e8,
    At = 1 / sr,
    Mh = Math.PI * 2,
    gA = Mh / 4,
    yA = 0,
    Yw = Math.sqrt,
    vA = Math.cos,
    xA = Math.sin,
    pt = function(t) {
        return typeof t == "string"
    },
    Xe = function(t) {
        return typeof t == "function"
    },
    Ar = function(t) {
        return typeof t == "number"
    },
    bm = function(t) {
        return typeof t > "u"
    },
    cr = function(t) {
        return typeof t == "object"
    },
    Yt = function(t) {
        return t !== !1
    },
    Rm = function() {
        return typeof window < "u"
    },
    ql = function(t) {
        return Xe(t) || pt(t)
    },
    Xw = typeof ArrayBuffer == "function" && ArrayBuffer.isView || function() {},
    jt = Array.isArray,
    Nh = /(?:-?\.?\d|\.)+/gi,
    qw = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,
    Os = /[-+=.]*\d+[.e-]*\d*[a-z%]*/g,
    ad = /[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,
    Qw = /[+-]=-?[.\d]+/,
    Jw = /[^,'"\[\]\s]+/gi,
    _A = /^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i,
    Ie, Qn, Fh, Am, gn = {},
    ac = {},
    Zw, eS = function(t) {
        return (ac = ao(t, gn)) && Jt
    },
    Dm = function(t, n) {
        return console.warn("Invalid property", t, "set to", n, "Missing plugin? gsap.registerPlugin()")
    },
    Ua = function(t, n) {
        return !n && console.warn(t)
    },
    tS = function(t, n) {
        return t && (gn[t] = n) && ac && (ac[t] = n) || gn
    },
    $a = function() {
        return 0
    },
    wA = {
        suppressEvents: !0,
        isStart: !0,
        kill: !1
    },
    wu = {
        suppressEvents: !0,
        kill: !1
    },
    SA = {
        suppressEvents: !0
    },
    jm = {},
    si = [],
    Ih = {},
    nS, rn = {},
    ld = {},
    F0 = 30,
    Su = [],
    Om = "",
    Lm = function(t) {
        var n = t[0],
            r, i;
        if (cr(n) || Xe(n) || (t = [t]), !(r = (n._gsap || {}).harness)) {
            for (i = Su.length; i-- && !Su[i].targetTest(n););
            r = Su[i]
        }
        for (i = t.length; i--;) t[i] && (t[i]._gsap || (t[i]._gsap = new PS(t[i], r))) || t.splice(i, 1);
        return t
    },
    Wi = function(t) {
        return t._gsap || Lm(bn(t))[0]._gsap
    },
    rS = function(t, n, r) {
        return (r = t[n]) && Xe(r) ? t[n]() : bm(r) && t.getAttribute && t.getAttribute(n) || r
    },
    Xt = function(t, n) {
        return (t = t.split(",")).forEach(n) || t
    },
    Je = function(t) {
        return Math.round(t * 1e5) / 1e5 || 0
    },
    st = function(t) {
        return Math.round(t * 1e7) / 1e7 || 0
    },
    Ks = function(t, n) {
        var r = n.charAt(0),
            i = parseFloat(n.substr(2));
        return t = parseFloat(t), r === "+" ? t + i : r === "-" ? t - i : r === "*" ? t * i : t / i
    },
    CA = function(t, n) {
        for (var r = n.length, i = 0; t.indexOf(n[i]) < 0 && ++i < r;);
        return i < r
    },
    lc = function() {
        var t = si.length,
            n = si.slice(0),
            r, i;
        for (Ih = {}, si.length = 0, r = 0; r < t; r++) i = n[r], i && i._lazy && (i.render(i._lazy[0], i._lazy[1], !0)._lazy = 0)
    },
    iS = function(t, n, r, i) {
        si.length && !_t && lc(), t.render(n, r, _t && n < 0 && (t._initted || t._startAt)), si.length && !_t && lc()
    },
    sS = function(t) {
        var n = parseFloat(t);
        return (n || n === 0) && (t + "").match(Jw).length < 2 ? n : pt(t) ? t.trim() : t
    },
    oS = function(t) {
        return t
    },
    yn = function(t, n) {
        for (var r in n) r in t || (t[r] = n[r]);
        return t
    },
    TA = function(t) {
        return function(n, r) {
            for (var i in r) i in n || i === "duration" && t || i === "ease" || (n[i] = r[i])
        }
    },
    ao = function(t, n) {
        for (var r in n) t[r] = n[r];
        return t
    },
    I0 = function e(t, n) {
        for (var r in n) r !== "__proto__" && r !== "constructor" && r !== "prototype" && (t[r] = cr(n[r]) ? e(t[r] || (t[r] = {}), n[r]) : n[r]);
        return t
    },
    uc = function(t, n) {
        var r = {},
            i;
        for (i in t) i in n || (r[i] = t[i]);
        return r
    },
    pa = function(t) {
        var n = t.parent || Ie,
            r = t.keyframes ? TA(jt(t.keyframes)) : yn;
        if (Yt(t.inherit))
            for (; n;) r(t, n.vars.defaults), n = n.parent || n._dp;
        return t
    },
    EA = function(t, n) {
        for (var r = t.length, i = r === n.length; i && r-- && t[r] === n[r];);
        return r < 0
    },
    aS = function(t, n, r, i, s) {
        var o = t[i],
            a;
        if (s)
            for (a = n[s]; o && o[s] > a;) o = o._prev;
        return o ? (n._next = o._next, o._next = n) : (n._next = t[r], t[r] = n), n._next ? n._next._prev = n : t[i] = n, n._prev = o, n.parent = n._dp = t, n
    },
    Gc = function(t, n, r, i) {
        r === void 0 && (r = "_first"), i === void 0 && (i = "_last");
        var s = n._prev,
            o = n._next;
        s ? s._next = o : t[r] === n && (t[r] = o), o ? o._prev = s : t[i] === n && (t[i] = s), n._next = n._prev = n.parent = null
    },
    ui = function(t, n) {
        t.parent && (!n || t.parent.autoRemoveChildren) && t.parent.remove && t.parent.remove(t), t._act = 0
    },
    Hi = function(t, n) {
        if (t && (!n || n._end > t._dur || n._start < 0))
            for (var r = t; r;) r._dirty = 1, r = r.parent;
        return t
    },
    PA = function(t) {
        for (var n = t.parent; n && n.parent;) n._dirty = 1, n.totalDuration(), n = n.parent;
        return t
    },
    Vh = function(t, n, r, i) {
        return t._startAt && (_t ? t._startAt.revert(wu) : t.vars.immediateRender && !t.vars.autoRevert || t._startAt.render(n, !0, i))
    },
    kA = function e(t) {
        return !t || t._ts && e(t.parent)
    },
    V0 = function(t) {
        return t._repeat ? lo(t._tTime, t = t.duration() + t._rDelay) * t : 0
    },
    lo = function(t, n) {
        var r = Math.floor(t = st(t / n));
        return t && r === t ? r - 1 : r
    },
    cc = function(t, n) {
        return (t - n._start) * n._ts + (n._ts >= 0 ? 0 : n._dirty ? n.totalDuration() : n._tDur)
    },
    Yc = function(t) {
        return t._end = st(t._start + (t._tDur / Math.abs(t._ts || t._rts || At) || 0))
    },
    Xc = function(t, n) {
        var r = t._dp;
        return r && r.smoothChildTiming && t._ts && (t._start = st(r._time - (t._ts > 0 ? n / t._ts : ((t._dirty ? t.totalDuration() : t._tDur) - n) / -t._ts)), Yc(t), r._dirty || Hi(r, t)), t
    },
    lS = function(t, n) {
        var r;
        if ((n._time || !n._dur && n._initted || n._start < t._time && (n._dur || !n.add)) && (r = cc(t.rawTime(), n), (!n._dur || ml(0, n.totalDuration(), r) - n._tTime > At) && n.render(r, !0)), Hi(t, n)._dp && t._initted && t._time >= t._dur && t._ts) {
            if (t._dur < t.duration())
                for (r = t; r._dp;) r.rawTime() >= 0 && r.totalTime(r._tTime), r = r._dp;
            t._zTime = -1e-8
        }
    },
    tr = function(t, n, r, i) {
        return n.parent && ui(n), n._start = st((Ar(r) ? r : r || t !== Ie ? Sn(t, r, n) : t._time) + n._delay), n._end = st(n._start + (n.totalDuration() / Math.abs(n.timeScale()) || 0)), aS(t, n, "_first", "_last", t._sort ? "_start" : 0), Bh(n) || (t._recent = n), i || lS(t, n), t._ts < 0 && Xc(t, t._tTime), t
    },
    uS = function(t, n) {
        return (gn.ScrollTrigger || Dm("scrollTrigger", n)) && gn.ScrollTrigger.create(n, t)
    },
    cS = function(t, n, r, i, s) {
        if (Nm(t, n, s), !t._initted) return 1;
        if (!r && t._pt && !_t && (t._dur && t.vars.lazy !== !1 || !t._dur && t.vars.lazy) && nS !== sn.frame) return si.push(t), t._lazy = [s, i], 1
    },
    bA = function e(t) {
        var n = t.parent;
        return n && n._ts && n._initted && !n._lock && (n.rawTime() < 0 || e(n))
    },
    Bh = function(t) {
        var n = t.data;
        return n === "isFromStart" || n === "isStart"
    },
    RA = function(t, n, r, i) {
        var s = t.ratio,
            o = n < 0 || !n && (!t._start && bA(t) && !(!t._initted && Bh(t)) || (t._ts < 0 || t._dp._ts < 0) && !Bh(t)) ? 0 : 1,
            a = t._rDelay,
            l = 0,
            u, c, f;
        if (a && t._repeat && (l = ml(0, t._tDur, n), c = lo(l, a), t._yoyo && c & 1 && (o = 1 - o), c !== lo(t._tTime, a) && (s = 1 - o, t.vars.repeatRefresh && t._initted && t.invalidate())), o !== s || _t || i || t._zTime === At || !n && t._zTime) {
            if (!t._initted && cS(t, n, i, r, l)) return;
            for (f = t._zTime, t._zTime = n || (r ? At : 0), r || (r = n && !f), t.ratio = o, t._from && (o = 1 - o), t._time = 0, t._tTime = l, u = t._pt; u;) u.r(o, u.d), u = u._next;
            n < 0 && Vh(t, n, r, !0), t._onUpdate && !r && ln(t, "onUpdate"), l && t._repeat && !r && t.parent && ln(t, "onRepeat"), (n >= t._tDur || n < 0) && t.ratio === o && (o && ui(t, 1), !r && !_t && (ln(t, o ? "onComplete" : "onReverseComplete", !0), t._prom && t._prom()))
        } else t._zTime || (t._zTime = n)
    },
    AA = function(t, n, r) {
        var i;
        if (r > n)
            for (i = t._first; i && i._start <= r;) {
                if (i.data === "isPause" && i._start > n) return i;
                i = i._next
            } else
                for (i = t._last; i && i._start >= r;) {
                    if (i.data === "isPause" && i._start < n) return i;
                    i = i._prev
                }
    },
    uo = function(t, n, r, i) {
        var s = t._repeat,
            o = st(n) || 0,
            a = t._tTime / t._tDur;
        return a && !i && (t._time *= o / t._dur), t._dur = o, t._tDur = s ? s < 0 ? 1e10 : st(o * (s + 1) + t._rDelay * s) : o, a > 0 && !i && Xc(t, t._tTime = t._tDur * a), t.parent && Yc(t), r || Hi(t.parent, t), t
    },
    B0 = function(t) {
        return t instanceof Nt ? Hi(t) : uo(t, t._dur)
    },
    DA = {
        _start: 0,
        endTime: $a,
        totalDuration: $a
    },
    Sn = function e(t, n, r) {
        var i = t.labels,
            s = t._recent || DA,
            o = t.duration() >= sr ? s.endTime(!1) : t._dur,
            a, l, u;
        return pt(n) && (isNaN(n) || n in i) ? (l = n.charAt(0), u = n.substr(-1) === "%", a = n.indexOf("="), l === "<" || l === ">" ? (a >= 0 && (n = n.replace(/=/, "")), (l === "<" ? s._start : s.endTime(s._repeat >= 0)) + (parseFloat(n.substr(1)) || 0) * (u ? (a < 0 ? s : r).totalDuration() / 100 : 1)) : a < 0 ? (n in i || (i[n] = o), i[n]) : (l = parseFloat(n.charAt(a - 1) + n.substr(a + 1)), u && r && (l = l / 100 * (jt(r) ? r[0] : r).totalDuration()), a > 1 ? e(t, n.substr(0, a - 1), r) + l : o + l)) : n == null ? o : +n
    },
    ma = function(t, n, r) {
        var i = Ar(n[1]),
            s = (i ? 2 : 1) + (t < 2 ? 0 : 1),
            o = n[s],
            a, l;
        if (i && (o.duration = n[1]), o.parent = r, t) {
            for (a = o, l = r; l && !("immediateRender" in a);) a = l.vars.defaults || {}, l = Yt(l.vars.inherit) && l.parent;
            o.immediateRender = Yt(a.immediateRender), t < 2 ? o.runBackwards = 1 : o.startAt = n[s - 1]
        }
        return new it(n[0], o, n[s + 1])
    },
    xi = function(t, n) {
        return t || t === 0 ? n(t) : n
    },
    ml = function(t, n, r) {
        return r < t ? t : r > n ? n : r
    },
    Rt = function(t, n) {
        return !pt(t) || !(n = _A.exec(t)) ? "" : n[1]
    },
    jA = function(t, n, r) {
        return xi(r, function(i) {
            return ml(t, n, i)
        })
    },
    zh = [].slice,
    fS = function(t, n) {
        return t && cr(t) && "length" in t && (!n && !t.length || t.length - 1 in t && cr(t[0])) && !t.nodeType && t !== Qn
    },
    OA = function(t, n, r) {
        return r === void 0 && (r = []), t.forEach(function(i) {
            var s;
            return pt(i) && !n || fS(i, 1) ? (s = r).push.apply(s, bn(i)) : r.push(i)
        }) || r
    },
    bn = function(t, n, r) {
        return Me && !n && Me.selector ? Me.selector(t) : pt(t) && !r && (Fh || !co()) ? zh.call((n || Am).querySelectorAll(t), 0) : jt(t) ? OA(t, r) : fS(t) ? zh.call(t, 0) : t ? [t] : []
    },
    Uh = function(t) {
        return t = bn(t)[0] || Ua("Invalid scope") || {},
            function(n) {
                var r = t.current || t.nativeElement || t;
                return bn(n, r.querySelectorAll ? r : r === t ? Ua("Invalid scope") || Am.createElement("div") : t)
            }
    },
    dS = function(t) {
        return t.sort(function() {
            return .5 - Math.random()
        })
    },
    hS = function(t) {
        if (Xe(t)) return t;
        var n = cr(t) ? t : {
                each: t
            },
            r = Ki(n.ease),
            i = n.from || 0,
            s = parseFloat(n.base) || 0,
            o = {},
            a = i > 0 && i < 1,
            l = isNaN(i) || a,
            u = n.axis,
            c = i,
            f = i;
        return pt(i) ? c = f = {
                center: .5,
                edges: .5,
                end: 1
            }[i] || 0 : !a && l && (c = i[0], f = i[1]),
            function(d, p, m) {
                var h = (m || n).length,
                    _ = o[h],
                    v, y, x, T, E, k, S, P, A;
                if (!_) {
                    if (A = n.grid === "auto" ? 0 : (n.grid || [1, sr])[1], !A) {
                        for (S = -1e8; S < (S = m[A++].getBoundingClientRect().left) && A < h;);
                        A < h && A--
                    }
                    for (_ = o[h] = [], v = l ? Math.min(A, h) * c - .5 : i % A, y = A === sr ? 0 : l ? h * f / A - .5 : i / A | 0, S = 0, P = sr, k = 0; k < h; k++) x = k % A - v, T = y - (k / A | 0), _[k] = E = u ? Math.abs(u === "y" ? T : x) : Yw(x * x + T * T), E > S && (S = E), E < P && (P = E);
                    i === "random" && dS(_), _.max = S - P, _.min = P, _.v = h = (parseFloat(n.amount) || parseFloat(n.each) * (A > h ? h - 1 : u ? u === "y" ? h / A : A : Math.max(A, h / A)) || 0) * (i === "edges" ? -1 : 1), _.b = h < 0 ? s - h : s, _.u = Rt(n.amount || n.each) || 0, r = r && h < 0 ? CS(r) : r
                }
                return h = (_[d] - _.min) / _.max || 0, st(_.b + (r ? r(h) : h) * _.v) + _.u
            }
    },
    $h = function(t) {
        var n = Math.pow(10, ((t + "").split(".")[1] || "").length);
        return function(r) {
            var i = st(Math.round(parseFloat(r) / t) * t * n);
            return (i - i % 1) / n + (Ar(r) ? 0 : Rt(r))
        }
    },
    pS = function(t, n) {
        var r = jt(t),
            i, s;
        return !r && cr(t) && (i = r = t.radius || sr, t.values ? (t = bn(t.values), (s = !Ar(t[0])) && (i *= i)) : t = $h(t.increment)), xi(n, r ? Xe(t) ? function(o) {
            return s = t(o), Math.abs(s - o) <= i ? s : o
        } : function(o) {
            for (var a = parseFloat(s ? o.x : o), l = parseFloat(s ? o.y : 0), u = sr, c = 0, f = t.length, d, p; f--;) s ? (d = t[f].x - a, p = t[f].y - l, d = d * d + p * p) : d = Math.abs(t[f] - a), d < u && (u = d, c = f);
            return c = !i || u <= i ? t[c] : o, s || c === o || Ar(o) ? c : c + Rt(o)
        } : $h(t))
    },
    mS = function(t, n, r, i) {
        return xi(jt(t) ? !n : r === !0 ? !!(r = 0) : !i, function() {
            return jt(t) ? t[~~(Math.random() * t.length)] : (r = r || 1e-5) && (i = r < 1 ? Math.pow(10, (r + "").length - 2) : 1) && Math.floor(Math.round((t - r / 2 + Math.random() * (n - t + r * .99)) / r) * r * i) / i
        })
    },
    LA = function() {
        for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
        return function(i) {
            return n.reduce(function(s, o) {
                return o(s)
            }, i)
        }
    },
    MA = function(t, n) {
        return function(r) {
            return t(parseFloat(r)) + (n || Rt(r))
        }
    },
    NA = function(t, n, r) {
        return yS(t, n, 0, 1, r)
    },
    gS = function(t, n, r) {
        return xi(r, function(i) {
            return t[~~n(i)]
        })
    },
    FA = function e(t, n, r) {
        var i = n - t;
        return jt(t) ? gS(t, e(0, t.length), n) : xi(r, function(s) {
            return (i + (s - t) % i) % i + t
        })
    },
    IA = function e(t, n, r) {
        var i = n - t,
            s = i * 2;
        return jt(t) ? gS(t, e(0, t.length - 1), n) : xi(r, function(o) {
            return o = (s + (o - t) % s) % s || 0, t + (o > i ? s - o : o)
        })
    },
    Wa = function(t) {
        for (var n = 0, r = "", i, s, o, a; ~(i = t.indexOf("random(", n));) o = t.indexOf(")", i), a = t.charAt(i + 7) === "[", s = t.substr(i + 7, o - i - 7).match(a ? Jw : Nh), r += t.substr(n, i - n) + mS(a ? s : +s[0], a ? 0 : +s[1], +s[2] || 1e-5), n = o + 1;
        return r + t.substr(n, t.length - n)
    },
    yS = function(t, n, r, i, s) {
        var o = n - t,
            a = i - r;
        return xi(s, function(l) {
            return r + ((l - t) / o * a || 0)
        })
    },
    VA = function e(t, n, r, i) {
        var s = isNaN(t + n) ? 0 : function(p) {
            return (1 - p) * t + p * n
        };
        if (!s) {
            var o = pt(t),
                a = {},
                l, u, c, f, d;
            if (r === !0 && (i = 1) && (r = null), o) t = {
                p: t
            }, n = {
                p: n
            };
            else if (jt(t) && !jt(n)) {
                for (c = [], f = t.length, d = f - 2, u = 1; u < f; u++) c.push(e(t[u - 1], t[u]));
                f--, s = function(m) {
                    m *= f;
                    var h = Math.min(d, ~~m);
                    return c[h](m - h)
                }, r = n
            } else i || (t = ao(jt(t) ? [] : {}, t));
            if (!c) {
                for (l in n) Mm.call(a, t, l, "get", n[l]);
                s = function(m) {
                    return Vm(m, a) || (o ? t.p : t)
                }
            }
        }
        return xi(r, s)
    },
    z0 = function(t, n, r) {
        var i = t.labels,
            s = sr,
            o, a, l;
        for (o in i) a = i[o] - n, a < 0 == !!r && a && s > (a = Math.abs(a)) && (l = o, s = a);
        return l
    },
    ln = function(t, n, r) {
        var i = t.vars,
            s = i[n],
            o = Me,
            a = t._ctx,
            l, u, c;
        if (s) return l = i[n + "Params"], u = i.callbackScope || t, r && si.length && lc(), a && (Me = a), c = l ? s.apply(u, l) : s.call(u), Me = o, c
    },
    Zo = function(t) {
        return ui(t), t.scrollTrigger && t.scrollTrigger.kill(!!_t), t.progress() < 1 && ln(t, "onInterrupt"), t
    },
    Ls, vS = [],
    xS = function(t) {
        if (t)
            if (t = !t.name && t.default || t, Rm() || t.headless) {
                var n = t.name,
                    r = Xe(t),
                    i = n && !r && t.init ? function() {
                        this._props = []
                    } : t,
                    s = {
                        init: $a,
                        render: Vm,
                        add: Mm,
                        kill: tD,
                        modifier: eD,
                        rawVars: 0
                    },
                    o = {
                        targetTest: 0,
                        get: 0,
                        getSetter: Im,
                        aliases: {},
                        register: 0
                    };
                if (co(), t !== i) {
                    if (rn[n]) return;
                    yn(i, yn(uc(t, s), o)), ao(i.prototype, ao(s, uc(t, o))), rn[i.prop = n] = i, t.targetTest && (Su.push(i), jm[n] = 1), n = (n === "css" ? "CSS" : n.charAt(0).toUpperCase() + n.substr(1)) + "Plugin"
                }
                tS(n, i), t.register && t.register(Jt, i, qt)
            } else vS.push(t)
    },
    Se = 255,
    ea = {
        aqua: [0, Se, Se],
        lime: [0, Se, 0],
        silver: [192, 192, 192],
        black: [0, 0, 0],
        maroon: [128, 0, 0],
        teal: [0, 128, 128],
        blue: [0, 0, Se],
        navy: [0, 0, 128],
        white: [Se, Se, Se],
        olive: [128, 128, 0],
        yellow: [Se, Se, 0],
        orange: [Se, 165, 0],
        gray: [128, 128, 128],
        purple: [128, 0, 128],
        green: [0, 128, 0],
        red: [Se, 0, 0],
        pink: [Se, 192, 203],
        cyan: [0, Se, Se],
        transparent: [Se, Se, Se, 0]
    },
    ud = function(t, n, r) {
        return t += t < 0 ? 1 : t > 1 ? -1 : 0, (t * 6 < 1 ? n + (r - n) * t * 6 : t < .5 ? r : t * 3 < 2 ? n + (r - n) * (2 / 3 - t) * 6 : n) * Se + .5 | 0
    },
    _S = function(t, n, r) {
        var i = t ? Ar(t) ? [t >> 16, t >> 8 & Se, t & Se] : 0 : ea.black,
            s, o, a, l, u, c, f, d, p, m;
        if (!i) {
            if (t.substr(-1) === "," && (t = t.substr(0, t.length - 1)), ea[t]) i = ea[t];
            else if (t.charAt(0) === "#") {
                if (t.length < 6 && (s = t.charAt(1), o = t.charAt(2), a = t.charAt(3), t = "#" + s + s + o + o + a + a + (t.length === 5 ? t.charAt(4) + t.charAt(4) : "")), t.length === 9) return i = parseInt(t.substr(1, 6), 16), [i >> 16, i >> 8 & Se, i & Se, parseInt(t.substr(7), 16) / 255];
                t = parseInt(t.substr(1), 16), i = [t >> 16, t >> 8 & Se, t & Se]
            } else if (t.substr(0, 3) === "hsl") {
                if (i = m = t.match(Nh), !n) l = +i[0] % 360 / 360, u = +i[1] / 100, c = +i[2] / 100, o = c <= .5 ? c * (u + 1) : c + u - c * u, s = c * 2 - o, i.length > 3 && (i[3] *= 1), i[0] = ud(l + 1 / 3, s, o), i[1] = ud(l, s, o), i[2] = ud(l - 1 / 3, s, o);
                else if (~t.indexOf("=")) return i = t.match(qw), r && i.length < 4 && (i[3] = 1), i
            } else i = t.match(Nh) || ea.transparent;
            i = i.map(Number)
        }
        return n && !m && (s = i[0] / Se, o = i[1] / Se, a = i[2] / Se, f = Math.max(s, o, a), d = Math.min(s, o, a), c = (f + d) / 2, f === d ? l = u = 0 : (p = f - d, u = c > .5 ? p / (2 - f - d) : p / (f + d), l = f === s ? (o - a) / p + (o < a ? 6 : 0) : f === o ? (a - s) / p + 2 : (s - o) / p + 4, l *= 60), i[0] = ~~(l + .5), i[1] = ~~(u * 100 + .5), i[2] = ~~(c * 100 + .5)), r && i.length < 4 && (i[3] = 1), i
    },
    wS = function(t) {
        var n = [],
            r = [],
            i = -1;
        return t.split(oi).forEach(function(s) {
            var o = s.match(Os) || [];
            n.push.apply(n, o), r.push(i += o.length + 1)
        }), n.c = r, n
    },
    U0 = function(t, n, r) {
        var i = "",
            s = (t + i).match(oi),
            o = n ? "hsla(" : "rgba(",
            a = 0,
            l, u, c, f;
        if (!s) return t;
        if (s = s.map(function(d) {
                return (d = _S(d, n, 1)) && o + (n ? d[0] + "," + d[1] + "%," + d[2] + "%," + d[3] : d.join(",")) + ")"
            }), r && (c = wS(t), l = r.c, l.join(i) !== c.c.join(i)))
            for (u = t.replace(oi, "1").split(Os), f = u.length - 1; a < f; a++) i += u[a] + (~l.indexOf(a) ? s.shift() || o + "0,0,0,0)" : (c.length ? c : s.length ? s : r).shift());
        if (!u)
            for (u = t.split(oi), f = u.length - 1; a < f; a++) i += u[a] + s[a];
        return i + u[f]
    },
    oi = function() {
        var e = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b",
            t;
        for (t in ea) e += "|" + t + "\\b";
        return new RegExp(e + ")", "gi")
    }(),
    BA = /hsl[a]?\(/,
    SS = function(t) {
        var n = t.join(" "),
            r;
        if (oi.lastIndex = 0, oi.test(n)) return r = BA.test(n), t[1] = U0(t[1], r), t[0] = U0(t[0], r, wS(t[1])), !0
    },
    Ha, sn = function() {
        var e = Date.now,
            t = 500,
            n = 33,
            r = e(),
            i = r,
            s = 1e3 / 240,
            o = s,
            a = [],
            l, u, c, f, d, p, m = function h(_) {
                var v = e() - i,
                    y = _ === !0,
                    x, T, E, k;
                if ((v > t || v < 0) && (r += v - n), i += v, E = i - r, x = E - o, (x > 0 || y) && (k = ++f.frame, d = E - f.time * 1e3, f.time = E = E / 1e3, o += x + (x >= s ? 4 : s - x), T = 1), y || (l = u(h)), T)
                    for (p = 0; p < a.length; p++) a[p](E, d, k, _)
            };
        return f = {
            time: 0,
            frame: 0,
            tick: function() {
                m(!0)
            },
            deltaRatio: function(_) {
                return d / (1e3 / (_ || 60))
            },
            wake: function() {
                Zw && (!Fh && Rm() && (Qn = Fh = window, Am = Qn.document || {}, gn.gsap = Jt, (Qn.gsapVersions || (Qn.gsapVersions = [])).push(Jt.version), eS(ac || Qn.GreenSockGlobals || !Qn.gsap && Qn || {}), vS.forEach(xS)), c = typeof requestAnimationFrame < "u" && requestAnimationFrame, l && f.sleep(), u = c || function(_) {
                    return setTimeout(_, o - f.time * 1e3 + 1 | 0)
                }, Ha = 1, m(2))
            },
            sleep: function() {
                (c ? cancelAnimationFrame : clearTimeout)(l), Ha = 0, u = $a
            },
            lagSmoothing: function(_, v) {
                t = _ || 1 / 0, n = Math.min(v || 33, t)
            },
            fps: function(_) {
                s = 1e3 / (_ || 240), o = f.time * 1e3 + s
            },
            add: function(_, v, y) {
                var x = v ? function(T, E, k, S) {
                    _(T, E, k, S), f.remove(x)
                } : _;
                return f.remove(_), a[y ? "unshift" : "push"](x), co(), x
            },
            remove: function(_, v) {
                ~(v = a.indexOf(_)) && a.splice(v, 1) && p >= v && p--
            },
            _listeners: a
        }, f
    }(),
    co = function() {
        return !Ha && sn.wake()
    },
    le = {},
    zA = /^[\d.\-M][\d.\-,\s]/,
    UA = /["']/g,
    $A = function(t) {
        for (var n = {}, r = t.substr(1, t.length - 3).split(":"), i = r[0], s = 1, o = r.length, a, l, u; s < o; s++) l = r[s], a = s !== o - 1 ? l.lastIndexOf(",") : l.length, u = l.substr(0, a), n[i] = isNaN(u) ? u.replace(UA, "").trim() : +u, i = l.substr(a + 1).trim();
        return n
    },
    WA = function(t) {
        var n = t.indexOf("(") + 1,
            r = t.indexOf(")"),
            i = t.indexOf("(", n);
        return t.substring(n, ~i && i < r ? t.indexOf(")", r + 1) : r)
    },
    HA = function(t) {
        var n = (t + "").split("("),
            r = le[n[0]];
        return r && n.length > 1 && r.config ? r.config.apply(null, ~t.indexOf("{") ? [$A(n[1])] : WA(t).split(",").map(sS)) : le._CE && zA.test(t) ? le._CE("", t) : r
    },
    CS = function(t) {
        return function(n) {
            return 1 - t(1 - n)
        }
    },
    TS = function e(t, n) {
        for (var r = t._first, i; r;) r instanceof Nt ? e(r, n) : r.vars.yoyoEase && (!r._yoyo || !r._repeat) && r._yoyo !== n && (r.timeline ? e(r.timeline, n) : (i = r._ease, r._ease = r._yEase, r._yEase = i, r._yoyo = n)), r = r._next
    },
    Ki = function(t, n) {
        return t && (Xe(t) ? t : le[t] || HA(t)) || n
    },
    as = function(t, n, r, i) {
        r === void 0 && (r = function(l) {
            return 1 - n(1 - l)
        }), i === void 0 && (i = function(l) {
            return l < .5 ? n(l * 2) / 2 : 1 - n((1 - l) * 2) / 2
        });
        var s = {
                easeIn: n,
                easeOut: r,
                easeInOut: i
            },
            o;
        return Xt(t, function(a) {
            le[a] = gn[a] = s, le[o = a.toLowerCase()] = r;
            for (var l in s) le[o + (l === "easeIn" ? ".in" : l === "easeOut" ? ".out" : ".inOut")] = le[a + "." + l] = s[l]
        }), s
    },
    ES = function(t) {
        return function(n) {
            return n < .5 ? (1 - t(1 - n * 2)) / 2 : .5 + t((n - .5) * 2) / 2
        }
    },
    cd = function e(t, n, r) {
        var i = n >= 1 ? n : 1,
            s = (r || (t ? .3 : .45)) / (n < 1 ? n : 1),
            o = s / Mh * (Math.asin(1 / i) || 0),
            a = function(c) {
                return c === 1 ? 1 : i * Math.pow(2, -10 * c) * xA((c - o) * s) + 1
            },
            l = t === "out" ? a : t === "in" ? function(u) {
                return 1 - a(1 - u)
            } : ES(a);
        return s = Mh / s, l.config = function(u, c) {
            return e(t, u, c)
        }, l
    },
    fd = function e(t, n) {
        n === void 0 && (n = 1.70158);
        var r = function(o) {
                return o ? --o * o * ((n + 1) * o + n) + 1 : 0
            },
            i = t === "out" ? r : t === "in" ? function(s) {
                return 1 - r(1 - s)
            } : ES(r);
        return i.config = function(s) {
            return e(t, s)
        }, i
    };
Xt("Linear,Quad,Cubic,Quart,Quint,Strong", function(e, t) {
    var n = t < 5 ? t + 1 : t;
    as(e + ",Power" + (n - 1), t ? function(r) {
        return Math.pow(r, n)
    } : function(r) {
        return r
    }, function(r) {
        return 1 - Math.pow(1 - r, n)
    }, function(r) {
        return r < .5 ? Math.pow(r * 2, n) / 2 : 1 - Math.pow((1 - r) * 2, n) / 2
    })
});
le.Linear.easeNone = le.none = le.Linear.easeIn;
as("Elastic", cd("in"), cd("out"), cd());
(function(e, t) {
    var n = 1 / t,
        r = 2 * n,
        i = 2.5 * n,
        s = function(a) {
            return a < n ? e * a * a : a < r ? e * Math.pow(a - 1.5 / t, 2) + .75 : a < i ? e * (a -= 2.25 / t) * a + .9375 : e * Math.pow(a - 2.625 / t, 2) + .984375
        };
    as("Bounce", function(o) {
        return 1 - s(1 - o)
    }, s)
})(7.5625, 2.75);
as("Expo", function(e) {
    return Math.pow(2, 10 * (e - 1)) * e + e * e * e * e * e * e * (1 - e)
});
as("Circ", function(e) {
    return -(Yw(1 - e * e) - 1)
});
as("Sine", function(e) {
    return e === 1 ? 1 : -vA(e * gA) + 1
});
as("Back", fd("in"), fd("out"), fd());
le.SteppedEase = le.steps = gn.SteppedEase = {
    config: function(t, n) {
        t === void 0 && (t = 1);
        var r = 1 / t,
            i = t + (n ? 0 : 1),
            s = n ? 1 : 0,
            o = 1 - At;
        return function(a) {
            return ((i * ml(0, o, a) | 0) + s) * r
        }
    }
};
oo.ease = le["quad.out"];
Xt("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt", function(e) {
    return Om += e + "," + e + "Params,"
});
var PS = function(t, n) {
        this.id = yA++, t._gsap = this, this.target = t, this.harness = n, this.get = n ? n.get : rS, this.set = n ? n.getSetter : Im
    },
    Ka = function() {
        function e(n) {
            this.vars = n, this._delay = +n.delay || 0, (this._repeat = n.repeat === 1 / 0 ? -2 : n.repeat || 0) && (this._rDelay = n.repeatDelay || 0, this._yoyo = !!n.yoyo || !!n.yoyoEase), this._ts = 1, uo(this, +n.duration, 1, 1), this.data = n.data, Me && (this._ctx = Me, Me.data.push(this)), Ha || sn.wake()
        }
        var t = e.prototype;
        return t.delay = function(r) {
            return r || r === 0 ? (this.parent && this.parent.smoothChildTiming && this.startTime(this._start + r - this._delay), this._delay = r, this) : this._delay
        }, t.duration = function(r) {
            return arguments.length ? this.totalDuration(this._repeat > 0 ? r + (r + this._rDelay) * this._repeat : r) : this.totalDuration() && this._dur
        }, t.totalDuration = function(r) {
            return arguments.length ? (this._dirty = 0, uo(this, this._repeat < 0 ? r : (r - this._repeat * this._rDelay) / (this._repeat + 1))) : this._tDur
        }, t.totalTime = function(r, i) {
            if (co(), !arguments.length) return this._tTime;
            var s = this._dp;
            if (s && s.smoothChildTiming && this._ts) {
                for (Xc(this, r), !s._dp || s.parent || lS(s, this); s && s.parent;) s.parent._time !== s._start + (s._ts >= 0 ? s._tTime / s._ts : (s.totalDuration() - s._tTime) / -s._ts) && s.totalTime(s._tTime, !0), s = s.parent;
                !this.parent && this._dp.autoRemoveChildren && (this._ts > 0 && r < this._tDur || this._ts < 0 && r > 0 || !this._tDur && !r) && tr(this._dp, this, this._start - this._delay)
            }
            return (this._tTime !== r || !this._dur && !i || this._initted && Math.abs(this._zTime) === At || !r && !this._initted && (this.add || this._ptLookup)) && (this._ts || (this._pTime = r), iS(this, r, i)), this
        }, t.time = function(r, i) {
            return arguments.length ? this.totalTime(Math.min(this.totalDuration(), r + V0(this)) % (this._dur + this._rDelay) || (r ? this._dur : 0), i) : this._time
        }, t.totalProgress = function(r, i) {
            return arguments.length ? this.totalTime(this.totalDuration() * r, i) : this.totalDuration() ? Math.min(1, this._tTime / this._tDur) : this.rawTime() >= 0 && this._initted ? 1 : 0
        }, t.progress = function(r, i) {
            return arguments.length ? this.totalTime(this.duration() * (this._yoyo && !(this.iteration() & 1) ? 1 - r : r) + V0(this), i) : this.duration() ? Math.min(1, this._time / this._dur) : this.rawTime() > 0 ? 1 : 0
        }, t.iteration = function(r, i) {
            var s = this.duration() + this._rDelay;
            return arguments.length ? this.totalTime(this._time + (r - 1) * s, i) : this._repeat ? lo(this._tTime, s) + 1 : 1
        }, t.timeScale = function(r, i) {
            if (!arguments.length) return this._rts === -1e-8 ? 0 : this._rts;
            if (this._rts === r) return this;
            var s = this.parent && this._ts ? cc(this.parent._time, this) : this._tTime;
            return this._rts = +r || 0, this._ts = this._ps || r === -1e-8 ? 0 : this._rts, this.totalTime(ml(-Math.abs(this._delay), this._tDur, s), i !== !1), Yc(this), PA(this)
        }, t.paused = function(r) {
            return arguments.length ? (this._ps !== r && (this._ps = r, r ? (this._pTime = this._tTime || Math.max(-this._delay, this.rawTime()), this._ts = this._act = 0) : (co(), this._ts = this._rts, this.totalTime(this.parent && !this.parent.smoothChildTiming ? this.rawTime() : this._tTime || this._pTime, this.progress() === 1 && Math.abs(this._zTime) !== At && (this._tTime -= At)))), this) : this._ps
        }, t.startTime = function(r) {
            if (arguments.length) {
                this._start = r;
                var i = this.parent || this._dp;
                return i && (i._sort || !this.parent) && tr(i, this, r - this._delay), this
            }
            return this._start
        }, t.endTime = function(r) {
            return this._start + (Yt(r) ? this.totalDuration() : this.duration()) / Math.abs(this._ts || 1)
        }, t.rawTime = function(r) {
            var i = this.parent || this._dp;
            return i ? r && (!this._ts || this._repeat && this._time && this.totalProgress() < 1) ? this._tTime % (this._dur + this._rDelay) : this._ts ? cc(i.rawTime(r), this) : this._tTime : this._tTime
        }, t.revert = function(r) {
            r === void 0 && (r = SA);
            var i = _t;
            return _t = r, (this._initted || this._startAt) && (this.timeline && this.timeline.revert(r), this.totalTime(-.01, r.suppressEvents)), this.data !== "nested" && r.kill !== !1 && this.kill(), _t = i, this
        }, t.globalTime = function(r) {
            for (var i = this, s = arguments.length ? r : i.rawTime(); i;) s = i._start + s / (Math.abs(i._ts) || 1), i = i._dp;
            return !this.parent && this._sat ? this._sat.globalTime(r) : s
        }, t.repeat = function(r) {
            return arguments.length ? (this._repeat = r === 1 / 0 ? -2 : r, B0(this)) : this._repeat === -2 ? 1 / 0 : this._repeat
        }, t.repeatDelay = function(r) {
            if (arguments.length) {
                var i = this._time;
                return this._rDelay = r, B0(this), i ? this.time(i) : this
            }
            return this._rDelay
        }, t.yoyo = function(r) {
            return arguments.length ? (this._yoyo = r, this) : this._yoyo
        }, t.seek = function(r, i) {
            return this.totalTime(Sn(this, r), Yt(i))
        }, t.restart = function(r, i) {
            return this.play().totalTime(r ? -this._delay : 0, Yt(i)), this._dur || (this._zTime = -1e-8), this
        }, t.play = function(r, i) {
            return r != null && this.seek(r, i), this.reversed(!1).paused(!1)
        }, t.reverse = function(r, i) {
            return r != null && this.seek(r || this.totalDuration(), i), this.reversed(!0).paused(!1)
        }, t.pause = function(r, i) {
            return r != null && this.seek(r, i), this.paused(!0)
        }, t.resume = function() {
            return this.paused(!1)
        }, t.reversed = function(r) {
            return arguments.length ? (!!r !== this.reversed() && this.timeScale(-this._rts || (r ? -1e-8 : 0)), this) : this._rts < 0
        }, t.invalidate = function() {
            return this._initted = this._act = 0, this._zTime = -1e-8, this
        }, t.isActive = function() {
            var r = this.parent || this._dp,
                i = this._start,
                s;
            return !!(!r || this._ts && this._initted && r.isActive() && (s = r.rawTime(!0)) >= i && s < this.endTime(!0) - At)
        }, t.eventCallback = function(r, i, s) {
            var o = this.vars;
            return arguments.length > 1 ? (i ? (o[r] = i, s && (o[r + "Params"] = s), r === "onUpdate" && (this._onUpdate = i)) : delete o[r], this) : o[r]
        }, t.then = function(r) {
            var i = this;
            return new Promise(function(s) {
                var o = Xe(r) ? r : oS,
                    a = function() {
                        var u = i.then;
                        i.then = null, Xe(o) && (o = o(i)) && (o.then || o === i) && (i.then = u), s(o), i.then = u
                    };
                i._initted && i.totalProgress() === 1 && i._ts >= 0 || !i._tTime && i._ts < 0 ? a() : i._prom = a
            })
        }, t.kill = function() {
            Zo(this)
        }, e
    }();
yn(Ka.prototype, {
    _time: 0,
    _start: 0,
    _end: 0,
    _tTime: 0,
    _tDur: 0,
    _dirty: 0,
    _repeat: 0,
    _yoyo: !1,
    parent: null,
    _initted: !1,
    _rDelay: 0,
    _ts: 1,
    _dp: 0,
    ratio: 0,
    _zTime: -1e-8,
    _prom: 0,
    _ps: !1,
    _rts: 1
});
var Nt = function(e) {
    Gw(t, e);

    function t(r, i) {
        var s;
        return r === void 0 && (r = {}), s = e.call(this, r) || this, s.labels = {}, s.smoothChildTiming = !!r.smoothChildTiming, s.autoRemoveChildren = !!r.autoRemoveChildren, s._sort = Yt(r.sortChildren), Ie && tr(r.parent || Ie, mr(s), i), r.reversed && s.reverse(), r.paused && s.paused(!0), r.scrollTrigger && uS(mr(s), r.scrollTrigger), s
    }
    var n = t.prototype;
    return n.to = function(i, s, o) {
        return ma(0, arguments, this), this
    }, n.from = function(i, s, o) {
        return ma(1, arguments, this), this
    }, n.fromTo = function(i, s, o, a) {
        return ma(2, arguments, this), this
    }, n.set = function(i, s, o) {
        return s.duration = 0, s.parent = this, pa(s).repeatDelay || (s.repeat = 0), s.immediateRender = !!s.immediateRender, new it(i, s, Sn(this, o), 1), this
    }, n.call = function(i, s, o) {
        return tr(this, it.delayedCall(0, i, s), o)
    }, n.staggerTo = function(i, s, o, a, l, u, c) {
        return o.duration = s, o.stagger = o.stagger || a, o.onComplete = u, o.onCompleteParams = c, o.parent = this, new it(i, o, Sn(this, l)), this
    }, n.staggerFrom = function(i, s, o, a, l, u, c) {
        return o.runBackwards = 1, pa(o).immediateRender = Yt(o.immediateRender), this.staggerTo(i, s, o, a, l, u, c)
    }, n.staggerFromTo = function(i, s, o, a, l, u, c, f) {
        return a.startAt = o, pa(a).immediateRender = Yt(a.immediateRender), this.staggerTo(i, s, a, l, u, c, f)
    }, n.render = function(i, s, o) {
        var a = this._time,
            l = this._dirty ? this.totalDuration() : this._tDur,
            u = this._dur,
            c = i <= 0 ? 0 : st(i),
            f = this._zTime < 0 != i < 0 && (this._initted || !u),
            d, p, m, h, _, v, y, x, T, E, k, S;
        if (this !== Ie && c > l && i >= 0 && (c = l), c !== this._tTime || o || f) {
            if (a !== this._time && u && (c += this._time - a, i += this._time - a), d = c, T = this._start, x = this._ts, v = !x, f && (u || (a = this._zTime), (i || !s) && (this._zTime = i)), this._repeat) {
                if (k = this._yoyo, _ = u + this._rDelay, this._repeat < -1 && i < 0) return this.totalTime(_ * 100 + i, s, o);
                if (d = st(c % _), c === l ? (h = this._repeat, d = u) : (E = st(c / _), h = ~~E, h && h === E && (d = u, h--), d > u && (d = u)), E = lo(this._tTime, _), !a && this._tTime && E !== h && this._tTime - E * _ - this._dur <= 0 && (E = h), k && h & 1 && (d = u - d, S = 1), h !== E && !this._lock) {
                    var P = k && E & 1,
                        A = P === (k && h & 1);
                    if (h < E && (P = !P), a = P ? 0 : c % u ? u : c, this._lock = 1, this.render(a || (S ? 0 : st(h * _)), s, !u)._lock = 0, this._tTime = c, !s && this.parent && ln(this, "onRepeat"), this.vars.repeatRefresh && !S && (this.invalidate()._lock = 1), a && a !== this._time || v !== !this._ts || this.vars.onRepeat && !this.parent && !this._act) return this;
                    if (u = this._dur, l = this._tDur, A && (this._lock = 2, a = P ? u : -1e-4, this.render(a, !0), this.vars.repeatRefresh && !S && this.invalidate()), this._lock = 0, !this._ts && !v) return this;
                    TS(this, S)
                }
            }
            if (this._hasPause && !this._forcing && this._lock < 2 && (y = AA(this, st(a), st(d)), y && (c -= d - (d = y._start))), this._tTime = c, this._time = d, this._act = !x, this._initted || (this._onUpdate = this.vars.onUpdate, this._initted = 1, this._zTime = i, a = 0), !a && d && !s && !h && (ln(this, "onStart"), this._tTime !== c)) return this;
            if (d >= a && i >= 0)
                for (p = this._first; p;) {
                    if (m = p._next, (p._act || d >= p._start) && p._ts && y !== p) {
                        if (p.parent !== this) return this.render(i, s, o);
                        if (p.render(p._ts > 0 ? (d - p._start) * p._ts : (p._dirty ? p.totalDuration() : p._tDur) + (d - p._start) * p._ts, s, o), d !== this._time || !this._ts && !v) {
                            y = 0, m && (c += this._zTime = -1e-8);
                            break
                        }
                    }
                    p = m
                } else {
                    p = this._last;
                    for (var w = i < 0 ? i : d; p;) {
                        if (m = p._prev, (p._act || w <= p._end) && p._ts && y !== p) {
                            if (p.parent !== this) return this.render(i, s, o);
                            if (p.render(p._ts > 0 ? (w - p._start) * p._ts : (p._dirty ? p.totalDuration() : p._tDur) + (w - p._start) * p._ts, s, o || _t && (p._initted || p._startAt)), d !== this._time || !this._ts && !v) {
                                y = 0, m && (c += this._zTime = w ? -1e-8 : At);
                                break
                            }
                        }
                        p = m
                    }
                }
            if (y && !s && (this.pause(), y.render(d >= a ? 0 : -1e-8)._zTime = d >= a ? 1 : -1, this._ts)) return this._start = T, Yc(this), this.render(i, s, o);
            this._onUpdate && !s && ln(this, "onUpdate", !0), (c === l && this._tTime >= this.totalDuration() || !c && a) && (T === this._start || Math.abs(x) !== Math.abs(this._ts)) && (this._lock || ((i || !u) && (c === l && this._ts > 0 || !c && this._ts < 0) && ui(this, 1), !s && !(i < 0 && !a) && (c || a || !l) && (ln(this, c === l && i >= 0 ? "onComplete" : "onReverseComplete", !0), this._prom && !(c < l && this.timeScale() > 0) && this._prom())))
        }
        return this
    }, n.add = function(i, s) {
        var o = this;
        if (Ar(s) || (s = Sn(this, s, i)), !(i instanceof Ka)) {
            if (jt(i)) return i.forEach(function(a) {
                return o.add(a, s)
            }), this;
            if (pt(i)) return this.addLabel(i, s);
            if (Xe(i)) i = it.delayedCall(0, i);
            else return this
        }
        return this !== i ? tr(this, i, s) : this
    }, n.getChildren = function(i, s, o, a) {
        i === void 0 && (i = !0), s === void 0 && (s = !0), o === void 0 && (o = !0), a === void 0 && (a = -1e8);
        for (var l = [], u = this._first; u;) u._start >= a && (u instanceof it ? s && l.push(u) : (o && l.push(u), i && l.push.apply(l, u.getChildren(!0, s, o)))), u = u._next;
        return l
    }, n.getById = function(i) {
        for (var s = this.getChildren(1, 1, 1), o = s.length; o--;)
            if (s[o].vars.id === i) return s[o]
    }, n.remove = function(i) {
        return pt(i) ? this.removeLabel(i) : Xe(i) ? this.killTweensOf(i) : (i.parent === this && Gc(this, i), i === this._recent && (this._recent = this._last), Hi(this))
    }, n.totalTime = function(i, s) {
        return arguments.length ? (this._forcing = 1, !this._dp && this._ts && (this._start = st(sn.time - (this._ts > 0 ? i / this._ts : (this.totalDuration() - i) / -this._ts))), e.prototype.totalTime.call(this, i, s), this._forcing = 0, this) : this._tTime
    }, n.addLabel = function(i, s) {
        return this.labels[i] = Sn(this, s), this
    }, n.removeLabel = function(i) {
        return delete this.labels[i], this
    }, n.addPause = function(i, s, o) {
        var a = it.delayedCall(0, s || $a, o);
        return a.data = "isPause", this._hasPause = 1, tr(this, a, Sn(this, i))
    }, n.removePause = function(i) {
        var s = this._first;
        for (i = Sn(this, i); s;) s._start === i && s.data === "isPause" && ui(s), s = s._next
    }, n.killTweensOf = function(i, s, o) {
        for (var a = this.getTweensOf(i, o), l = a.length; l--;) Yr !== a[l] && a[l].kill(i, s);
        return this
    }, n.getTweensOf = function(i, s) {
        for (var o = [], a = bn(i), l = this._first, u = Ar(s), c; l;) l instanceof it ? CA(l._targets, a) && (u ? (!Yr || l._initted && l._ts) && l.globalTime(0) <= s && l.globalTime(l.totalDuration()) > s : !s || l.isActive()) && o.push(l) : (c = l.getTweensOf(a, s)).length && o.push.apply(o, c), l = l._next;
        return o
    }, n.tweenTo = function(i, s) {
        s = s || {};
        var o = this,
            a = Sn(o, i),
            l = s,
            u = l.startAt,
            c = l.onStart,
            f = l.onStartParams,
            d = l.immediateRender,
            p, m = it.to(o, yn({
                ease: s.ease || "none",
                lazy: !1,
                immediateRender: !1,
                time: a,
                overwrite: "auto",
                duration: s.duration || Math.abs((a - (u && "time" in u ? u.time : o._time)) / o.timeScale()) || At,
                onStart: function() {
                    if (o.pause(), !p) {
                        var _ = s.duration || Math.abs((a - (u && "time" in u ? u.time : o._time)) / o.timeScale());
                        m._dur !== _ && uo(m, _, 0, 1).render(m._time, !0, !0), p = 1
                    }
                    c && c.apply(m, f || [])
                }
            }, s));
        return d ? m.render(0) : m
    }, n.tweenFromTo = function(i, s, o) {
        return this.tweenTo(s, yn({
            startAt: {
                time: Sn(this, i)
            }
        }, o))
    }, n.recent = function() {
        return this._recent
    }, n.nextLabel = function(i) {
        return i === void 0 && (i = this._time), z0(this, Sn(this, i))
    }, n.previousLabel = function(i) {
        return i === void 0 && (i = this._time), z0(this, Sn(this, i), 1)
    }, n.currentLabel = function(i) {
        return arguments.length ? this.seek(i, !0) : this.previousLabel(this._time + At)
    }, n.shiftChildren = function(i, s, o) {
        o === void 0 && (o = 0);
        for (var a = this._first, l = this.labels, u; a;) a._start >= o && (a._start += i, a._end += i), a = a._next;
        if (s)
            for (u in l) l[u] >= o && (l[u] += i);
        return Hi(this)
    }, n.invalidate = function(i) {
        var s = this._first;
        for (this._lock = 0; s;) s.invalidate(i), s = s._next;
        return e.prototype.invalidate.call(this, i)
    }, n.clear = function(i) {
        i === void 0 && (i = !0);
        for (var s = this._first, o; s;) o = s._next, this.remove(s), s = o;
        return this._dp && (this._time = this._tTime = this._pTime = 0), i && (this.labels = {}), Hi(this)
    }, n.totalDuration = function(i) {
        var s = 0,
            o = this,
            a = o._last,
            l = sr,
            u, c, f;
        if (arguments.length) return o.timeScale((o._repeat < 0 ? o.duration() : o.totalDuration()) / (o.reversed() ? -i : i));
        if (o._dirty) {
            for (f = o.parent; a;) u = a._prev, a._dirty && a.totalDuration(), c = a._start, c > l && o._sort && a._ts && !o._lock ? (o._lock = 1, tr(o, a, c - a._delay, 1)._lock = 0) : l = c, c < 0 && a._ts && (s -= c, (!f && !o._dp || f && f.smoothChildTiming) && (o._start += c / o._ts, o._time -= c, o._tTime -= c), o.shiftChildren(-c, !1, -1 / 0), l = 0), a._end > s && a._ts && (s = a._end), a = u;
            uo(o, o === Ie && o._time > s ? o._time : s, 1, 1), o._dirty = 0
        }
        return o._tDur
    }, t.updateRoot = function(i) {
        if (Ie._ts && (iS(Ie, cc(i, Ie)), nS = sn.frame), sn.frame >= F0) {
            F0 += fn.autoSleep || 120;
            var s = Ie._first;
            if ((!s || !s._ts) && fn.autoSleep && sn._listeners.length < 2) {
                for (; s && !s._ts;) s = s._next;
                s || sn.sleep()
            }
        }
    }, t
}(Ka);
yn(Nt.prototype, {
    _lock: 0,
    _hasPause: 0,
    _forcing: 0
});
var KA = function(t, n, r, i, s, o, a) {
        var l = new qt(this._pt, t, n, 0, 1, jS, null, s),
            u = 0,
            c = 0,
            f, d, p, m, h, _, v, y;
        for (l.b = r, l.e = i, r += "", i += "", (v = ~i.indexOf("random(")) && (i = Wa(i)), o && (y = [r, i], o(y, t, n), r = y[0], i = y[1]), d = r.match(ad) || []; f = ad.exec(i);) m = f[0], h = i.substring(u, f.index), p ? p = (p + 1) % 5 : h.substr(-5) === "rgba(" && (p = 1), m !== d[c++] && (_ = parseFloat(d[c - 1]) || 0, l._pt = {
            _next: l._pt,
            p: h || c === 1 ? h : ",",
            s: _,
            c: m.charAt(1) === "=" ? Ks(_, m) - _ : parseFloat(m) - _,
            m: p && p < 4 ? Math.round : 0
        }, u = ad.lastIndex);
        return l.c = u < i.length ? i.substring(u, i.length) : "", l.fp = a, (Qw.test(i) || v) && (l.e = 0), this._pt = l, l
    },
    Mm = function(t, n, r, i, s, o, a, l, u, c) {
        Xe(i) && (i = i(s || 0, t, o));
        var f = t[n],
            d = r !== "get" ? r : Xe(f) ? u ? t[n.indexOf("set") || !Xe(t["get" + n.substr(3)]) ? n : "get" + n.substr(3)](u) : t[n]() : f,
            p = Xe(f) ? u ? QA : AS : Fm,
            m;
        if (pt(i) && (~i.indexOf("random(") && (i = Wa(i)), i.charAt(1) === "=" && (m = Ks(d, i) + (Rt(d) || 0), (m || m === 0) && (i = m))), !c || d !== i || Wh) return !isNaN(d * i) && i !== "" ? (m = new qt(this._pt, t, n, +d || 0, i - (d || 0), typeof f == "boolean" ? ZA : DS, 0, p), u && (m.fp = u), a && m.modifier(a, this, t), this._pt = m) : (!f && !(n in t) && Dm(n, i), KA.call(this, t, n, d, i, p, l || fn.stringFilter, u))
    },
    GA = function(t, n, r, i, s) {
        if (Xe(t) && (t = ga(t, s, n, r, i)), !cr(t) || t.style && t.nodeType || jt(t) || Xw(t)) return pt(t) ? ga(t, s, n, r, i) : t;
        var o = {},
            a;
        for (a in t) o[a] = ga(t[a], s, n, r, i);
        return o
    },
    kS = function(t, n, r, i, s, o) {
        var a, l, u, c;
        if (rn[t] && (a = new rn[t]).init(s, a.rawVars ? n[t] : GA(n[t], i, s, o, r), r, i, o) !== !1 && (r._pt = l = new qt(r._pt, s, t, 0, 1, a.render, a, 0, a.priority), r !== Ls))
            for (u = r._ptLookup[r._targets.indexOf(s)], c = a._props.length; c--;) u[a._props[c]] = l;
        return a
    },
    Yr, Wh, Nm = function e(t, n, r) {
        var i = t.vars,
            s = i.ease,
            o = i.startAt,
            a = i.immediateRender,
            l = i.lazy,
            u = i.onUpdate,
            c = i.runBackwards,
            f = i.yoyoEase,
            d = i.keyframes,
            p = i.autoRevert,
            m = t._dur,
            h = t._startAt,
            _ = t._targets,
            v = t.parent,
            y = v && v.data === "nested" ? v.vars.targets : _,
            x = t._overwrite === "auto" && !km,
            T = t.timeline,
            E, k, S, P, A, w, O, F, V, W, Z, re, q;
        if (T && (!d || !s) && (s = "none"), t._ease = Ki(s, oo.ease), t._yEase = f ? CS(Ki(f === !0 ? s : f, oo.ease)) : 0, f && t._yoyo && !t._repeat && (f = t._yEase, t._yEase = t._ease, t._ease = f), t._from = !T && !!i.runBackwards, !T || d && !i.stagger) {
            if (F = _[0] ? Wi(_[0]).harness : 0, re = F && i[F.prop], E = uc(i, jm), h && (h._zTime < 0 && h.progress(1), n < 0 && c && a && !p ? h.render(-1, !0) : h.revert(c && m ? wu : wA), h._lazy = 0), o) {
                if (ui(t._startAt = it.set(_, yn({
                        data: "isStart",
                        overwrite: !1,
                        parent: v,
                        immediateRender: !0,
                        lazy: !h && Yt(l),
                        startAt: null,
                        delay: 0,
                        onUpdate: u && function() {
                            return ln(t, "onUpdate")
                        },
                        stagger: 0
                    }, o))), t._startAt._dp = 0, t._startAt._sat = t, n < 0 && (_t || !a && !p) && t._startAt.revert(wu), a && m && n <= 0 && r <= 0) {
                    n && (t._zTime = n);
                    return
                }
            } else if (c && m && !h) {
                if (n && (a = !1), S = yn({
                        overwrite: !1,
                        data: "isFromStart",
                        lazy: a && !h && Yt(l),
                        immediateRender: a,
                        stagger: 0,
                        parent: v
                    }, E), re && (S[F.prop] = re), ui(t._startAt = it.set(_, S)), t._startAt._dp = 0, t._startAt._sat = t, n < 0 && (_t ? t._startAt.revert(wu) : t._startAt.render(-1, !0)), t._zTime = n, !a) e(t._startAt, At, At);
                else if (!n) return
            }
            for (t._pt = t._ptCache = 0, l = m && Yt(l) || l && !m, k = 0; k < _.length; k++) {
                if (A = _[k], O = A._gsap || Lm(_)[k]._gsap, t._ptLookup[k] = W = {}, Ih[O.id] && si.length && lc(), Z = y === _ ? k : y.indexOf(A), F && (V = new F).init(A, re || E, t, Z, y) !== !1 && (t._pt = P = new qt(t._pt, A, V.name, 0, 1, V.render, V, 0, V.priority), V._props.forEach(function(M) {
                        W[M] = P
                    }), V.priority && (w = 1)), !F || re)
                    for (S in E) rn[S] && (V = kS(S, E, t, Z, A, y)) ? V.priority && (w = 1) : W[S] = P = Mm.call(t, A, S, "get", E[S], Z, y, 0, i.stringFilter);
                t._op && t._op[k] && t.kill(A, t._op[k]), x && t._pt && (Yr = t, Ie.killTweensOf(A, W, t.globalTime(n)), q = !t.parent, Yr = 0), t._pt && l && (Ih[O.id] = 1)
            }
            w && OS(t), t._onInit && t._onInit(t)
        }
        t._onUpdate = u, t._initted = (!t._op || t._pt) && !q, d && n <= 0 && T.render(sr, !0, !0)
    },
    YA = function(t, n, r, i, s, o, a, l) {
        var u = (t._pt && t._ptCache || (t._ptCache = {}))[n],
            c, f, d, p;
        if (!u)
            for (u = t._ptCache[n] = [], d = t._ptLookup, p = t._targets.length; p--;) {
                if (c = d[p][n], c && c.d && c.d._pt)
                    for (c = c.d._pt; c && c.p !== n && c.fp !== n;) c = c._next;
                if (!c) return Wh = 1, t.vars[n] = "+=0", Nm(t, a), Wh = 0, l ? Ua(n + " not eligible for reset") : 1;
                u.push(c)
            }
        for (p = u.length; p--;) f = u[p], c = f._pt || f, c.s = (i || i === 0) && !s ? i : c.s + (i || 0) + o * c.c, c.c = r - c.s, f.e && (f.e = Je(r) + Rt(f.e)), f.b && (f.b = c.s + Rt(f.b))
    },
    XA = function(t, n) {
        var r = t[0] ? Wi(t[0]).harness : 0,
            i = r && r.aliases,
            s, o, a, l;
        if (!i) return n;
        s = ao({}, n);
        for (o in i)
            if (o in s)
                for (l = i[o].split(","), a = l.length; a--;) s[l[a]] = s[o];
        return s
    },
    qA = function(t, n, r, i) {
        var s = n.ease || i || "power1.inOut",
            o, a;
        if (jt(n)) a = r[t] || (r[t] = []), n.forEach(function(l, u) {
            return a.push({
                t: u / (n.length - 1) * 100,
                v: l,
                e: s
            })
        });
        else
            for (o in n) a = r[o] || (r[o] = []), o === "ease" || a.push({
                t: parseFloat(t),
                v: n[o],
                e: s
            })
    },
    ga = function(t, n, r, i, s) {
        return Xe(t) ? t.call(n, r, i, s) : pt(t) && ~t.indexOf("random(") ? Wa(t) : t
    },
    bS = Om + "repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,autoRevert",
    RS = {};
Xt(bS + ",id,stagger,delay,duration,paused,scrollTrigger", function(e) {
    return RS[e] = 1
});
var it = function(e) {
    Gw(t, e);

    function t(r, i, s, o) {
        var a;
        typeof i == "number" && (s.duration = i, i = s, s = null), a = e.call(this, o ? i : pa(i)) || this;
        var l = a.vars,
            u = l.duration,
            c = l.delay,
            f = l.immediateRender,
            d = l.stagger,
            p = l.overwrite,
            m = l.keyframes,
            h = l.defaults,
            _ = l.scrollTrigger,
            v = l.yoyoEase,
            y = i.parent || Ie,
            x = (jt(r) || Xw(r) ? Ar(r[0]) : "length" in i) ? [r] : bn(r),
            T, E, k, S, P, A, w, O;
        if (a._targets = x.length ? Lm(x) : Ua("GSAP target " + r + " not found. https://gsap.com", !fn.nullTargetWarn) || [], a._ptLookup = [], a._overwrite = p, m || d || ql(u) || ql(c)) {
            if (i = a.vars, T = a.timeline = new Nt({
                    data: "nested",
                    defaults: h || {},
                    targets: y && y.data === "nested" ? y.vars.targets : x
                }), T.kill(), T.parent = T._dp = mr(a), T._start = 0, d || ql(u) || ql(c)) {
                if (S = x.length, w = d && hS(d), cr(d))
                    for (P in d) ~bS.indexOf(P) && (O || (O = {}), O[P] = d[P]);
                for (E = 0; E < S; E++) k = uc(i, RS), k.stagger = 0, v && (k.yoyoEase = v), O && ao(k, O), A = x[E], k.duration = +ga(u, mr(a), E, A, x), k.delay = (+ga(c, mr(a), E, A, x) || 0) - a._delay, !d && S === 1 && k.delay && (a._delay = c = k.delay, a._start += c, k.delay = 0), T.to(A, k, w ? w(E, A, x) : 0), T._ease = le.none;
                T.duration() ? u = c = 0 : a.timeline = 0
            } else if (m) {
                pa(yn(T.vars.defaults, {
                    ease: "none"
                })), T._ease = Ki(m.ease || i.ease || "none");
                var F = 0,
                    V, W, Z;
                if (jt(m)) m.forEach(function(re) {
                    return T.to(x, re, ">")
                }), T.duration();
                else {
                    k = {};
                    for (P in m) P === "ease" || P === "easeEach" || qA(P, m[P], k, m.easeEach);
                    for (P in k)
                        for (V = k[P].sort(function(re, q) {
                                return re.t - q.t
                            }), F = 0, E = 0; E < V.length; E++) W = V[E], Z = {
                            ease: W.e,
                            duration: (W.t - (E ? V[E - 1].t : 0)) / 100 * u
                        }, Z[P] = W.v, T.to(x, Z, F), F += Z.duration;
                    T.duration() < u && T.to({}, {
                        duration: u - T.duration()
                    })
                }
            }
            u || a.duration(u = T.duration())
        } else a.timeline = 0;
        return p === !0 && !km && (Yr = mr(a), Ie.killTweensOf(x), Yr = 0), tr(y, mr(a), s), i.reversed && a.reverse(), i.paused && a.paused(!0), (f || !u && !m && a._start === st(y._time) && Yt(f) && kA(mr(a)) && y.data !== "nested") && (a._tTime = -1e-8, a.render(Math.max(0, -c) || 0)), _ && uS(mr(a), _), a
    }
    var n = t.prototype;
    return n.render = function(i, s, o) {
        var a = this._time,
            l = this._tDur,
            u = this._dur,
            c = i < 0,
            f = i > l - At && !c ? l : i < At ? 0 : i,
            d, p, m, h, _, v, y, x, T;
        if (!u) RA(this, i, s, o);
        else if (f !== this._tTime || !i || o || !this._initted && this._tTime || this._startAt && this._zTime < 0 !== c || this._lazy) {
            if (d = f, x = this.timeline, this._repeat) {
                if (h = u + this._rDelay, this._repeat < -1 && c) return this.totalTime(h * 100 + i, s, o);
                if (d = st(f % h), f === l ? (m = this._repeat, d = u) : (_ = st(f / h), m = ~~_, m && m === _ ? (d = u, m--) : d > u && (d = u)), v = this._yoyo && m & 1, v && (T = this._yEase, d = u - d), _ = lo(this._tTime, h), d === a && !o && this._initted && m === _) return this._tTime = f, this;
                m !== _ && (x && this._yEase && TS(x, v), this.vars.repeatRefresh && !v && !this._lock && d !== h && this._initted && (this._lock = o = 1, this.render(st(h * m), !0).invalidate()._lock = 0))
            }
            if (!this._initted) {
                if (cS(this, c ? i : d, o, s, f)) return this._tTime = 0, this;
                if (a !== this._time && !(o && this.vars.repeatRefresh && m !== _)) return this;
                if (u !== this._dur) return this.render(i, s, o)
            }
            if (this._tTime = f, this._time = d, !this._act && this._ts && (this._act = 1, this._lazy = 0), this.ratio = y = (T || this._ease)(d / u), this._from && (this.ratio = y = 1 - y), d && !a && !s && !m && (ln(this, "onStart"), this._tTime !== f)) return this;
            for (p = this._pt; p;) p.r(y, p.d), p = p._next;
            x && x.render(i < 0 ? i : x._dur * x._ease(d / this._dur), s, o) || this._startAt && (this._zTime = i), this._onUpdate && !s && (c && Vh(this, i, s, o), ln(this, "onUpdate")), this._repeat && m !== _ && this.vars.onRepeat && !s && this.parent && ln(this, "onRepeat"), (f === this._tDur || !f) && this._tTime === f && (c && !this._onUpdate && Vh(this, i, !0, !0), (i || !u) && (f === this._tDur && this._ts > 0 || !f && this._ts < 0) && ui(this, 1), !s && !(c && !a) && (f || a || v) && (ln(this, f === l ? "onComplete" : "onReverseComplete", !0), this._prom && !(f < l && this.timeScale() > 0) && this._prom()))
        }
        return this
    }, n.targets = function() {
        return this._targets
    }, n.invalidate = function(i) {
        return (!i || !this.vars.runBackwards) && (this._startAt = 0), this._pt = this._op = this._onUpdate = this._lazy = this.ratio = 0, this._ptLookup = [], this.timeline && this.timeline.invalidate(i), e.prototype.invalidate.call(this, i)
    }, n.resetTo = function(i, s, o, a, l) {
        Ha || sn.wake(), this._ts || this.play();
        var u = Math.min(this._dur, (this._dp._time - this._start) * this._ts),
            c;
        return this._initted || Nm(this, u), c = this._ease(u / this._dur), YA(this, i, s, o, a, c, u, l) ? this.resetTo(i, s, o, a, 1) : (Xc(this, 0), this.parent || aS(this._dp, this, "_first", "_last", this._dp._sort ? "_start" : 0), this.render(0))
    }, n.kill = function(i, s) {
        if (s === void 0 && (s = "all"), !i && (!s || s === "all")) return this._lazy = this._pt = 0, this.parent ? Zo(this) : this.scrollTrigger && this.scrollTrigger.kill(!!_t), this;
        if (this.timeline) {
            var o = this.timeline.totalDuration();
            return this.timeline.killTweensOf(i, s, Yr && Yr.vars.overwrite !== !0)._first || Zo(this), this.parent && o !== this.timeline.totalDuration() && uo(this, this._dur * this.timeline._tDur / o, 0, 1), this
        }
        var a = this._targets,
            l = i ? bn(i) : a,
            u = this._ptLookup,
            c = this._pt,
            f, d, p, m, h, _, v;
        if ((!s || s === "all") && EA(a, l)) return s === "all" && (this._pt = 0), Zo(this);
        for (f = this._op = this._op || [], s !== "all" && (pt(s) && (h = {}, Xt(s, function(y) {
                return h[y] = 1
            }), s = h), s = XA(a, s)), v = a.length; v--;)
            if (~l.indexOf(a[v])) {
                d = u[v], s === "all" ? (f[v] = s, m = d, p = {}) : (p = f[v] = f[v] || {}, m = s);
                for (h in m) _ = d && d[h], _ && ((!("kill" in _.d) || _.d.kill(h) === !0) && Gc(this, _, "_pt"), delete d[h]), p !== "all" && (p[h] = 1)
            }
        return this._initted && !this._pt && c && Zo(this), this
    }, t.to = function(i, s) {
        return new t(i, s, arguments[2])
    }, t.from = function(i, s) {
        return ma(1, arguments)
    }, t.delayedCall = function(i, s, o, a) {
        return new t(s, 0, {
            immediateRender: !1,
            lazy: !1,
            overwrite: !1,
            delay: i,
            onComplete: s,
            onReverseComplete: s,
            onCompleteParams: o,
            onReverseCompleteParams: o,
            callbackScope: a
        })
    }, t.fromTo = function(i, s, o) {
        return ma(2, arguments)
    }, t.set = function(i, s) {
        return s.duration = 0, s.repeatDelay || (s.repeat = 0), new t(i, s)
    }, t.killTweensOf = function(i, s, o) {
        return Ie.killTweensOf(i, s, o)
    }, t
}(Ka);
yn(it.prototype, {
    _targets: [],
    _lazy: 0,
    _startAt: 0,
    _op: 0,
    _onInit: 0
});
Xt("staggerTo,staggerFrom,staggerFromTo", function(e) {
    it[e] = function() {
        var t = new Nt,
            n = zh.call(arguments, 0);
        return n.splice(e === "staggerFromTo" ? 5 : 4, 0, 0), t[e].apply(t, n)
    }
});
var Fm = function(t, n, r) {
        return t[n] = r
    },
    AS = function(t, n, r) {
        return t[n](r)
    },
    QA = function(t, n, r, i) {
        return t[n](i.fp, r)
    },
    JA = function(t, n, r) {
        return t.setAttribute(n, r)
    },
    Im = function(t, n) {
        return Xe(t[n]) ? AS : bm(t[n]) && t.setAttribute ? JA : Fm
    },
    DS = function(t, n) {
        return n.set(n.t, n.p, Math.round((n.s + n.c * t) * 1e6) / 1e6, n)
    },
    ZA = function(t, n) {
        return n.set(n.t, n.p, !!(n.s + n.c * t), n)
    },
    jS = function(t, n) {
        var r = n._pt,
            i = "";
        if (!t && n.b) i = n.b;
        else if (t === 1 && n.e) i = n.e;
        else {
            for (; r;) i = r.p + (r.m ? r.m(r.s + r.c * t) : Math.round((r.s + r.c * t) * 1e4) / 1e4) + i, r = r._next;
            i += n.c
        }
        n.set(n.t, n.p, i, n)
    },
    Vm = function(t, n) {
        for (var r = n._pt; r;) r.r(t, r.d), r = r._next
    },
    eD = function(t, n, r, i) {
        for (var s = this._pt, o; s;) o = s._next, s.p === i && s.modifier(t, n, r), s = o
    },
    tD = function(t) {
        for (var n = this._pt, r, i; n;) i = n._next, n.p === t && !n.op || n.op === t ? Gc(this, n, "_pt") : n.dep || (r = 1), n = i;
        return !r
    },
    nD = function(t, n, r, i) {
        i.mSet(t, n, i.m.call(i.tween, r, i.mt), i)
    },
    OS = function(t) {
        for (var n = t._pt, r, i, s, o; n;) {
            for (r = n._next, i = s; i && i.pr > n.pr;) i = i._next;
            (n._prev = i ? i._prev : o) ? n._prev._next = n: s = n, (n._next = i) ? i._prev = n : o = n, n = r
        }
        t._pt = s
    },
    qt = function() {
        function e(n, r, i, s, o, a, l, u, c) {
            this.t = r, this.s = s, this.c = o, this.p = i, this.r = a || DS, this.d = l || this, this.set = u || Fm, this.pr = c || 0, this._next = n, n && (n._prev = this)
        }
        var t = e.prototype;
        return t.modifier = function(r, i, s) {
            this.mSet = this.mSet || this.set, this.set = nD, this.m = r, this.mt = s, this.tween = i
        }, e
    }();
Xt(Om + "parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger", function(e) {
    return jm[e] = 1
});
gn.TweenMax = gn.TweenLite = it;
gn.TimelineLite = gn.TimelineMax = Nt;
Ie = new Nt({
    sortChildren: !1,
    defaults: oo,
    autoRemoveChildren: !0,
    id: "root",
    smoothChildTiming: !0
});
fn.stringFilter = SS;
var Gi = [],
    Cu = {},
    rD = [],
    $0 = 0,
    iD = 0,
    dd = function(t) {
        return (Cu[t] || rD).map(function(n) {
            return n()
        })
    },
    Hh = function() {
        var t = Date.now(),
            n = [];
        t - $0 > 2 && (dd("matchMediaInit"), Gi.forEach(function(r) {
            var i = r.queries,
                s = r.conditions,
                o, a, l, u;
            for (a in i) o = Qn.matchMedia(i[a]).matches, o && (l = 1), o !== s[a] && (s[a] = o, u = 1);
            u && (r.revert(), l && n.push(r))
        }), dd("matchMediaRevert"), n.forEach(function(r) {
            return r.onMatch(r, function(i) {
                return r.add(null, i)
            })
        }), $0 = t, dd("matchMedia"))
    },
    LS = function() {
        function e(n, r) {
            this.selector = r && Uh(r), this.data = [], this._r = [], this.isReverted = !1, this.id = iD++, n && this.add(n)
        }
        var t = e.prototype;
        return t.add = function(r, i, s) {
            Xe(r) && (s = i, i = r, r = Xe);
            var o = this,
                a = function() {
                    var u = Me,
                        c = o.selector,
                        f;
                    return u && u !== o && u.data.push(o), s && (o.selector = Uh(s)), Me = o, f = i.apply(o, arguments), Xe(f) && o._r.push(f), Me = u, o.selector = c, o.isReverted = !1, f
                };
            return o.last = a, r === Xe ? a(o, function(l) {
                return o.add(null, l)
            }) : r ? o[r] = a : a
        }, t.ignore = function(r) {
            var i = Me;
            Me = null, r(this), Me = i
        }, t.getTweens = function() {
            var r = [];
            return this.data.forEach(function(i) {
                return i instanceof e ? r.push.apply(r, i.getTweens()) : i instanceof it && !(i.parent && i.parent.data === "nested") && r.push(i)
            }), r
        }, t.clear = function() {
            this._r.length = this.data.length = 0
        }, t.kill = function(r, i) {
            var s = this;
            if (r ? function() {
                    for (var a = s.getTweens(), l = s.data.length, u; l--;) u = s.data[l], u.data === "isFlip" && (u.revert(), u.getChildren(!0, !0, !1).forEach(function(c) {
                        return a.splice(a.indexOf(c), 1)
                    }));
                    for (a.map(function(c) {
                            return {
                                g: c._dur || c._delay || c._sat && !c._sat.vars.immediateRender ? c.globalTime(0) : -1 / 0,
                                t: c
                            }
                        }).sort(function(c, f) {
                            return f.g - c.g || -1 / 0
                        }).forEach(function(c) {
                            return c.t.revert(r)
                        }), l = s.data.length; l--;) u = s.data[l], u instanceof Nt ? u.data !== "nested" && (u.scrollTrigger && u.scrollTrigger.revert(), u.kill()) : !(u instanceof it) && u.revert && u.revert(r);
                    s._r.forEach(function(c) {
                        return c(r, s)
                    }), s.isReverted = !0
                }() : this.data.forEach(function(a) {
                    return a.kill && a.kill()
                }), this.clear(), i)
                for (var o = Gi.length; o--;) Gi[o].id === this.id && Gi.splice(o, 1)
        }, t.revert = function(r) {
            this.kill(r || {})
        }, e
    }(),
    sD = function() {
        function e(n) {
            this.contexts = [], this.scope = n, Me && Me.data.push(this)
        }
        var t = e.prototype;
        return t.add = function(r, i, s) {
            cr(r) || (r = {
                matches: r
            });
            var o = new LS(0, s || this.scope),
                a = o.conditions = {},
                l, u, c;
            Me && !o.selector && (o.selector = Me.selector), this.contexts.push(o), i = o.add("onMatch", i), o.queries = r;
            for (u in r) u === "all" ? c = 1 : (l = Qn.matchMedia(r[u]), l && (Gi.indexOf(o) < 0 && Gi.push(o), (a[u] = l.matches) && (c = 1), l.addListener ? l.addListener(Hh) : l.addEventListener("change", Hh)));
            return c && i(o, function(f) {
                return o.add(null, f)
            }), this
        }, t.revert = function(r) {
            this.kill(r || {})
        }, t.kill = function(r) {
            this.contexts.forEach(function(i) {
                return i.kill(r, !0)
            })
        }, e
    }(),
    fc = {
        registerPlugin: function() {
            for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
            n.forEach(function(i) {
                return xS(i)
            })
        },
        timeline: function(t) {
            return new Nt(t)
        },
        getTweensOf: function(t, n) {
            return Ie.getTweensOf(t, n)
        },
        getProperty: function(t, n, r, i) {
            pt(t) && (t = bn(t)[0]);
            var s = Wi(t || {}).get,
                o = r ? oS : sS;
            return r === "native" && (r = ""), t && (n ? o((rn[n] && rn[n].get || s)(t, n, r, i)) : function(a, l, u) {
                return o((rn[a] && rn[a].get || s)(t, a, l, u))
            })
        },
        quickSetter: function(t, n, r) {
            if (t = bn(t), t.length > 1) {
                var i = t.map(function(c) {
                        return Jt.quickSetter(c, n, r)
                    }),
                    s = i.length;
                return function(c) {
                    for (var f = s; f--;) i[f](c)
                }
            }
            t = t[0] || {};
            var o = rn[n],
                a = Wi(t),
                l = a.harness && (a.harness.aliases || {})[n] || n,
                u = o ? function(c) {
                    var f = new o;
                    Ls._pt = 0, f.init(t, r ? c + r : c, Ls, 0, [t]), f.render(1, f), Ls._pt && Vm(1, Ls)
                } : a.set(t, l);
            return o ? u : function(c) {
                return u(t, l, r ? c + r : c, a, 1)
            }
        },
        quickTo: function(t, n, r) {
            var i, s = Jt.to(t, yn((i = {}, i[n] = "+=0.1", i.paused = !0, i.stagger = 0, i), r || {})),
                o = function(l, u, c) {
                    return s.resetTo(n, l, u, c)
                };
            return o.tween = s, o
        },
        isTweening: function(t) {
            return Ie.getTweensOf(t, !0).length > 0
        },
        defaults: function(t) {
            return t && t.ease && (t.ease = Ki(t.ease, oo.ease)), I0(oo, t || {})
        },
        config: function(t) {
            return I0(fn, t || {})
        },
        registerEffect: function(t) {
            var n = t.name,
                r = t.effect,
                i = t.plugins,
                s = t.defaults,
                o = t.extendTimeline;
            (i || "").split(",").forEach(function(a) {
                return a && !rn[a] && !gn[a] && Ua(n + " effect requires " + a + " plugin.")
            }), ld[n] = function(a, l, u) {
                return r(bn(a), yn(l || {}, s), u)
            }, o && (Nt.prototype[n] = function(a, l, u) {
                return this.add(ld[n](a, cr(l) ? l : (u = l) && {}, this), u)
            })
        },
        registerEase: function(t, n) {
            le[t] = Ki(n)
        },
        parseEase: function(t, n) {
            return arguments.length ? Ki(t, n) : le
        },
        getById: function(t) {
            return Ie.getById(t)
        },
        exportRoot: function(t, n) {
            t === void 0 && (t = {});
            var r = new Nt(t),
                i, s;
            for (r.smoothChildTiming = Yt(t.smoothChildTiming), Ie.remove(r), r._dp = 0, r._time = r._tTime = Ie._time, i = Ie._first; i;) s = i._next, (n || !(!i._dur && i instanceof it && i.vars.onComplete === i._targets[0])) && tr(r, i, i._start - i._delay), i = s;
            return tr(Ie, r, 0), r
        },
        context: function(t, n) {
            return t ? new LS(t, n) : Me
        },
        matchMedia: function(t) {
            return new sD(t)
        },
        matchMediaRefresh: function() {
            return Gi.forEach(function(t) {
                var n = t.conditions,
                    r, i;
                for (i in n) n[i] && (n[i] = !1, r = 1);
                r && t.revert()
            }) || Hh()
        },
        addEventListener: function(t, n) {
            var r = Cu[t] || (Cu[t] = []);
            ~r.indexOf(n) || r.push(n)
        },
        removeEventListener: function(t, n) {
            var r = Cu[t],
                i = r && r.indexOf(n);
            i >= 0 && r.splice(i, 1)
        },
        utils: {
            wrap: FA,
            wrapYoyo: IA,
            distribute: hS,
            random: mS,
            snap: pS,
            normalize: NA,
            getUnit: Rt,
            clamp: jA,
            splitColor: _S,
            toArray: bn,
            selector: Uh,
            mapRange: yS,
            pipe: LA,
            unitize: MA,
            interpolate: VA,
            shuffle: dS
        },
        install: eS,
        effects: ld,
        ticker: sn,
        updateRoot: Nt.updateRoot,
        plugins: rn,
        globalTimeline: Ie,
        core: {
            PropTween: qt,
            globals: tS,
            Tween: it,
            Timeline: Nt,
            Animation: Ka,
            getCache: Wi,
            _removeLinkedListItem: Gc,
            reverting: function() {
                return _t
            },
            context: function(t) {
                return t && Me && (Me.data.push(t), t._ctx = Me), Me
            },
            suppressOverwrites: function(t) {
                return km = t
            }
        }
    };
Xt("to,from,fromTo,delayedCall,set,killTweensOf", function(e) {
    return fc[e] = it[e]
});
sn.add(Nt.updateRoot);
Ls = fc.to({}, {
    duration: 0
});
var oD = function(t, n) {
        for (var r = t._pt; r && r.p !== n && r.op !== n && r.fp !== n;) r = r._next;
        return r
    },
    aD = function(t, n) {
        var r = t._targets,
            i, s, o;
        for (i in n)
            for (s = r.length; s--;) o = t._ptLookup[s][i], o && (o = o.d) && (o._pt && (o = oD(o, i)), o && o.modifier && o.modifier(n[i], t, r[s], i))
    },
    hd = function(t, n) {
        return {
            name: t,
            rawVars: 1,
            init: function(i, s, o) {
                o._onInit = function(a) {
                    var l, u;
                    if (pt(s) && (l = {}, Xt(s, function(c) {
                            return l[c] = 1
                        }), s = l), n) {
                        l = {};
                        for (u in s) l[u] = n(s[u]);
                        s = l
                    }
                    aD(a, s)
                }
            }
        }
    },
    Jt = fc.registerPlugin({
        name: "attr",
        init: function(t, n, r, i, s) {
            var o, a, l;
            this.tween = r;
            for (o in n) l = t.getAttribute(o) || "", a = this.add(t, "setAttribute", (l || 0) + "", n[o], i, s, 0, 0, o), a.op = o, a.b = l, this._props.push(o)
        },
        render: function(t, n) {
            for (var r = n._pt; r;) _t ? r.set(r.t, r.p, r.b, r) : r.r(t, r.d), r = r._next
        }
    }, {
        name: "endArray",
        init: function(t, n) {
            for (var r = n.length; r--;) this.add(t, r, t[r] || 0, n[r], 0, 0, 0, 0, 0, 1)
        }
    }, hd("roundProps", $h), hd("modifiers"), hd("snap", pS)) || fc;
it.version = Nt.version = Jt.version = "3.12.7";
Zw = 1;
Rm() && co();
le.Power0;
le.Power1;
le.Power2;
le.Power3;
le.Power4;
le.Linear;
le.Quad;
le.Cubic;
le.Quart;
le.Quint;
le.Strong;
le.Elastic;
le.Back;
le.SteppedEase;
le.Bounce;
le.Sine;
le.Expo;
le.Circ;
/*!
 * CSSPlugin 3.12.7
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license or for
 * Club GSAP members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
var W0, Xr, Gs, Bm, Vi, H0, zm, lD = function() {
        return typeof window < "u"
    },
    Dr = {},
    Ri = 180 / Math.PI,
    Ys = Math.PI / 180,
    ms = Math.atan2,
    K0 = 1e8,
    Um = /([A-Z])/g,
    uD = /(left|right|width|margin|padding|x)/i,
    cD = /[\s,\(]\S/,
    nr = {
        autoAlpha: "opacity,visibility",
        scale: "scaleX,scaleY",
        alpha: "opacity"
    },
    Kh = function(t, n) {
        return n.set(n.t, n.p, Math.round((n.s + n.c * t) * 1e4) / 1e4 + n.u, n)
    },
    fD = function(t, n) {
        return n.set(n.t, n.p, t === 1 ? n.e : Math.round((n.s + n.c * t) * 1e4) / 1e4 + n.u, n)
    },
    dD = function(t, n) {
        return n.set(n.t, n.p, t ? Math.round((n.s + n.c * t) * 1e4) / 1e4 + n.u : n.b, n)
    },
    hD = function(t, n) {
        var r = n.s + n.c * t;
        n.set(n.t, n.p, ~~(r + (r < 0 ? -.5 : .5)) + n.u, n)
    },
    MS = function(t, n) {
        return n.set(n.t, n.p, t ? n.e : n.b, n)
    },
    NS = function(t, n) {
        return n.set(n.t, n.p, t !== 1 ? n.b : n.e, n)
    },
    pD = function(t, n, r) {
        return t.style[n] = r
    },
    mD = function(t, n, r) {
        return t.style.setProperty(n, r)
    },
    gD = function(t, n, r) {
        return t._gsap[n] = r
    },
    yD = function(t, n, r) {
        return t._gsap.scaleX = t._gsap.scaleY = r
    },
    vD = function(t, n, r, i, s) {
        var o = t._gsap;
        o.scaleX = o.scaleY = r, o.renderTransform(s, o)
    },
    xD = function(t, n, r, i, s) {
        var o = t._gsap;
        o[n] = r, o.renderTransform(s, o)
    },
    Ve = "transform",
    Qt = Ve + "Origin",
    _D = function e(t, n) {
        var r = this,
            i = this.target,
            s = i.style,
            o = i._gsap;
        if (t in Dr && s) {
            if (this.tfm = this.tfm || {}, t !== "transform") t = nr[t] || t, ~t.indexOf(",") ? t.split(",").forEach(function(a) {
                return r.tfm[a] = yr(i, a)
            }) : this.tfm[t] = o.x ? o[t] : yr(i, t), t === Qt && (this.tfm.zOrigin = o.zOrigin);
            else return nr.transform.split(",").forEach(function(a) {
                return e.call(r, a, n)
            });
            if (this.props.indexOf(Ve) >= 0) return;
            o.svg && (this.svgo = i.getAttribute("data-svg-origin"), this.props.push(Qt, n, "")), t = Ve
        }(s || n) && this.props.push(t, n, s[t])
    },
    FS = function(t) {
        t.translate && (t.removeProperty("translate"), t.removeProperty("scale"), t.removeProperty("rotate"))
    },
    wD = function() {
        var t = this.props,
            n = this.target,
            r = n.style,
            i = n._gsap,
            s, o;
        for (s = 0; s < t.length; s += 3) t[s + 1] ? t[s + 1] === 2 ? n[t[s]](t[s + 2]) : n[t[s]] = t[s + 2] : t[s + 2] ? r[t[s]] = t[s + 2] : r.removeProperty(t[s].substr(0, 2) === "--" ? t[s] : t[s].replace(Um, "-$1").toLowerCase());
        if (this.tfm) {
            for (o in this.tfm) i[o] = this.tfm[o];
            i.svg && (i.renderTransform(), n.setAttribute("data-svg-origin", this.svgo || "")), s = zm(), (!s || !s.isStart) && !r[Ve] && (FS(r), i.zOrigin && r[Qt] && (r[Qt] += " " + i.zOrigin + "px", i.zOrigin = 0, i.renderTransform()), i.uncache = 1)
        }
    },
    IS = function(t, n) {
        var r = {
            target: t,
            props: [],
            revert: wD,
            save: _D
        };
        return t._gsap || Jt.core.getCache(t), n && t.style && t.nodeType && n.split(",").forEach(function(i) {
            return r.save(i)
        }), r
    },
    VS, Gh = function(t, n) {
        var r = Xr.createElementNS ? Xr.createElementNS((n || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), t) : Xr.createElement(t);
        return r && r.style ? r : Xr.createElement(t)
    },
    or = function e(t, n, r) {
        var i = getComputedStyle(t);
        return i[n] || i.getPropertyValue(n.replace(Um, "-$1").toLowerCase()) || i.getPropertyValue(n) || !r && e(t, fo(n) || n, 1) || ""
    },
    G0 = "O,Moz,ms,Ms,Webkit".split(","),
    fo = function(t, n, r) {
        var i = n || Vi,
            s = i.style,
            o = 5;
        if (t in s && !r) return t;
        for (t = t.charAt(0).toUpperCase() + t.substr(1); o-- && !(G0[o] + t in s););
        return o < 0 ? null : (o === 3 ? "ms" : o >= 0 ? G0[o] : "") + t
    },
    Yh = function() {
        lD() && window.document && (W0 = window, Xr = W0.document, Gs = Xr.documentElement, Vi = Gh("div") || {
            style: {}
        }, Gh("div"), Ve = fo(Ve), Qt = Ve + "Origin", Vi.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0", VS = !!fo("perspective"), zm = Jt.core.reverting, Bm = 1)
    },
    Y0 = function(t) {
        var n = t.ownerSVGElement,
            r = Gh("svg", n && n.getAttribute("xmlns") || "http://www.w3.org/2000/svg"),
            i = t.cloneNode(!0),
            s;
        i.style.display = "block", r.appendChild(i), Gs.appendChild(r);
        try {
            s = i.getBBox()
        } catch {}
        return r.removeChild(i), Gs.removeChild(r), s
    },
    X0 = function(t, n) {
        for (var r = n.length; r--;)
            if (t.hasAttribute(n[r])) return t.getAttribute(n[r])
    },
    BS = function(t) {
        var n, r;
        try {
            n = t.getBBox()
        } catch {
            n = Y0(t), r = 1
        }
        return n && (n.width || n.height) || r || (n = Y0(t)), n && !n.width && !n.x && !n.y ? {
            x: +X0(t, ["x", "cx", "x1"]) || 0,
            y: +X0(t, ["y", "cy", "y1"]) || 0,
            width: 0,
            height: 0
        } : n
    },
    zS = function(t) {
        return !!(t.getCTM && (!t.parentNode || t.ownerSVGElement) && BS(t))
    },
    ns = function(t, n) {
        if (n) {
            var r = t.style,
                i;
            n in Dr && n !== Qt && (n = Ve), r.removeProperty ? (i = n.substr(0, 2), (i === "ms" || n.substr(0, 6) === "webkit") && (n = "-" + n), r.removeProperty(i === "--" ? n : n.replace(Um, "-$1").toLowerCase())) : r.removeAttribute(n)
        }
    },
    qr = function(t, n, r, i, s, o) {
        var a = new qt(t._pt, n, r, 0, 1, o ? NS : MS);
        return t._pt = a, a.b = i, a.e = s, t._props.push(r), a
    },
    q0 = {
        deg: 1,
        rad: 1,
        turn: 1
    },
    SD = {
        grid: 1,
        flex: 1
    },
    ci = function e(t, n, r, i) {
        var s = parseFloat(r) || 0,
            o = (r + "").trim().substr((s + "").length) || "px",
            a = Vi.style,
            l = uD.test(n),
            u = t.tagName.toLowerCase() === "svg",
            c = (u ? "client" : "offset") + (l ? "Width" : "Height"),
            f = 100,
            d = i === "px",
            p = i === "%",
            m, h, _, v;
        if (i === o || !s || q0[i] || q0[o]) return s;
        if (o !== "px" && !d && (s = e(t, n, r, "px")), v = t.getCTM && zS(t), (p || o === "%") && (Dr[n] || ~n.indexOf("adius"))) return m = v ? t.getBBox()[l ? "width" : "height"] : t[c], Je(p ? s / m * f : s / 100 * m);
        if (a[l ? "width" : "height"] = f + (d ? o : i), h = i !== "rem" && ~n.indexOf("adius") || i === "em" && t.appendChild && !u ? t : t.parentNode, v && (h = (t.ownerSVGElement || {}).parentNode), (!h || h === Xr || !h.appendChild) && (h = Xr.body), _ = h._gsap, _ && p && _.width && l && _.time === sn.time && !_.uncache) return Je(s / _.width * f);
        if (p && (n === "height" || n === "width")) {
            var y = t.style[n];
            t.style[n] = f + i, m = t[c], y ? t.style[n] = y : ns(t, n)
        } else(p || o === "%") && !SD[or(h, "display")] && (a.position = or(t, "position")), h === t && (a.position = "static"), h.appendChild(Vi), m = Vi[c], h.removeChild(Vi), a.position = "absolute";
        return l && p && (_ = Wi(h), _.time = sn.time, _.width = h[c]), Je(d ? m * s / f : m && s ? f / m * s : 0)
    },
    yr = function(t, n, r, i) {
        var s;
        return Bm || Yh(), n in nr && n !== "transform" && (n = nr[n], ~n.indexOf(",") && (n = n.split(",")[0])), Dr[n] && n !== "transform" ? (s = Ya(t, i), s = n !== "transformOrigin" ? s[n] : s.svg ? s.origin : hc(or(t, Qt)) + " " + s.zOrigin + "px") : (s = t.style[n], (!s || s === "auto" || i || ~(s + "").indexOf("calc(")) && (s = dc[n] && dc[n](t, n, r) || or(t, n) || rS(t, n) || (n === "opacity" ? 1 : 0))), r && !~(s + "").trim().indexOf(" ") ? ci(t, n, s, r) + r : s
    },
    CD = function(t, n, r, i) {
        if (!r || r === "none") {
            var s = fo(n, t, 1),
                o = s && or(t, s, 1);
            o && o !== r ? (n = s, r = o) : n === "borderColor" && (r = or(t, "borderTopColor"))
        }
        var a = new qt(this._pt, t.style, n, 0, 1, jS),
            l = 0,
            u = 0,
            c, f, d, p, m, h, _, v, y, x, T, E;
        if (a.b = r, a.e = i, r += "", i += "", i === "auto" && (h = t.style[n], t.style[n] = i, i = or(t, n) || i, h ? t.style[n] = h : ns(t, n)), c = [r, i], SS(c), r = c[0], i = c[1], d = r.match(Os) || [], E = i.match(Os) || [], E.length) {
            for (; f = Os.exec(i);) _ = f[0], y = i.substring(l, f.index), m ? m = (m + 1) % 5 : (y.substr(-5) === "rgba(" || y.substr(-5) === "hsla(") && (m = 1), _ !== (h = d[u++] || "") && (p = parseFloat(h) || 0, T = h.substr((p + "").length), _.charAt(1) === "=" && (_ = Ks(p, _) + T), v = parseFloat(_), x = _.substr((v + "").length), l = Os.lastIndex - x.length, x || (x = x || fn.units[n] || T, l === i.length && (i += x, a.e += x)), T !== x && (p = ci(t, n, h, x) || 0), a._pt = {
                _next: a._pt,
                p: y || u === 1 ? y : ",",
                s: p,
                c: v - p,
                m: m && m < 4 || n === "zIndex" ? Math.round : 0
            });
            a.c = l < i.length ? i.substring(l, i.length) : ""
        } else a.r = n === "display" && i === "none" ? NS : MS;
        return Qw.test(i) && (a.e = 0), this._pt = a, a
    },
    Q0 = {
        top: "0%",
        bottom: "100%",
        left: "0%",
        right: "100%",
        center: "50%"
    },
    TD = function(t) {
        var n = t.split(" "),
            r = n[0],
            i = n[1] || "50%";
        return (r === "top" || r === "bottom" || i === "left" || i === "right") && (t = r, r = i, i = t), n[0] = Q0[r] || r, n[1] = Q0[i] || i, n.join(" ")
    },
    ED = function(t, n) {
        if (n.tween && n.tween._time === n.tween._dur) {
            var r = n.t,
                i = r.style,
                s = n.u,
                o = r._gsap,
                a, l, u;
            if (s === "all" || s === !0) i.cssText = "", l = 1;
            else
                for (s = s.split(","), u = s.length; --u > -1;) a = s[u], Dr[a] && (l = 1, a = a === "transformOrigin" ? Qt : Ve), ns(r, a);
            l && (ns(r, Ve), o && (o.svg && r.removeAttribute("transform"), i.scale = i.rotate = i.translate = "none", Ya(r, 1), o.uncache = 1, FS(i)))
        }
    },
    dc = {
        clearProps: function(t, n, r, i, s) {
            if (s.data !== "isFromStart") {
                var o = t._pt = new qt(t._pt, n, r, 0, 0, ED);
                return o.u = i, o.pr = -10, o.tween = s, t._props.push(r), 1
            }
        }
    },
    Ga = [1, 0, 0, 1, 0, 0],
    US = {},
    $S = function(t) {
        return t === "matrix(1, 0, 0, 1, 0, 0)" || t === "none" || !t
    },
    J0 = function(t) {
        var n = or(t, Ve);
        return $S(n) ? Ga : n.substr(7).match(qw).map(Je)
    },
    $m = function(t, n) {
        var r = t._gsap || Wi(t),
            i = t.style,
            s = J0(t),
            o, a, l, u;
        return r.svg && t.getAttribute("transform") ? (l = t.transform.baseVal.consolidate().matrix, s = [l.a, l.b, l.c, l.d, l.e, l.f], s.join(",") === "1,0,0,1,0,0" ? Ga : s) : (s === Ga && !t.offsetParent && t !== Gs && !r.svg && (l = i.display, i.display = "block", o = t.parentNode, (!o || !t.offsetParent && !t.getBoundingClientRect().width) && (u = 1, a = t.nextElementSibling, Gs.appendChild(t)), s = J0(t), l ? i.display = l : ns(t, "display"), u && (a ? o.insertBefore(t, a) : o ? o.appendChild(t) : Gs.removeChild(t))), n && s.length > 6 ? [s[0], s[1], s[4], s[5], s[12], s[13]] : s)
    },
    Xh = function(t, n, r, i, s, o) {
        var a = t._gsap,
            l = s || $m(t, !0),
            u = a.xOrigin || 0,
            c = a.yOrigin || 0,
            f = a.xOffset || 0,
            d = a.yOffset || 0,
            p = l[0],
            m = l[1],
            h = l[2],
            _ = l[3],
            v = l[4],
            y = l[5],
            x = n.split(" "),
            T = parseFloat(x[0]) || 0,
            E = parseFloat(x[1]) || 0,
            k, S, P, A;
        r ? l !== Ga && (S = p * _ - m * h) && (P = T * (_ / S) + E * (-h / S) + (h * y - _ * v) / S, A = T * (-m / S) + E * (p / S) - (p * y - m * v) / S, T = P, E = A) : (k = BS(t), T = k.x + (~x[0].indexOf("%") ? T / 100 * k.width : T), E = k.y + (~(x[1] || x[0]).indexOf("%") ? E / 100 * k.height : E)), i || i !== !1 && a.smooth ? (v = T - u, y = E - c, a.xOffset = f + (v * p + y * h) - v, a.yOffset = d + (v * m + y * _) - y) : a.xOffset = a.yOffset = 0, a.xOrigin = T, a.yOrigin = E, a.smooth = !!i, a.origin = n, a.originIsAbsolute = !!r, t.style[Qt] = "0px 0px", o && (qr(o, a, "xOrigin", u, T), qr(o, a, "yOrigin", c, E), qr(o, a, "xOffset", f, a.xOffset), qr(o, a, "yOffset", d, a.yOffset)), t.setAttribute("data-svg-origin", T + " " + E)
    },
    Ya = function(t, n) {
        var r = t._gsap || new PS(t);
        if ("x" in r && !n && !r.uncache) return r;
        var i = t.style,
            s = r.scaleX < 0,
            o = "px",
            a = "deg",
            l = getComputedStyle(t),
            u = or(t, Qt) || "0",
            c, f, d, p, m, h, _, v, y, x, T, E, k, S, P, A, w, O, F, V, W, Z, re, q, M, B, H, ie, ne, St, xe, ke;
        return c = f = d = h = _ = v = y = x = T = 0, p = m = 1, r.svg = !!(t.getCTM && zS(t)), l.translate && ((l.translate !== "none" || l.scale !== "none" || l.rotate !== "none") && (i[Ve] = (l.translate !== "none" ? "translate3d(" + (l.translate + " 0 0").split(" ").slice(0, 3).join(", ") + ") " : "") + (l.rotate !== "none" ? "rotate(" + l.rotate + ") " : "") + (l.scale !== "none" ? "scale(" + l.scale.split(" ").join(",") + ") " : "") + (l[Ve] !== "none" ? l[Ve] : "")), i.scale = i.rotate = i.translate = "none"), S = $m(t, r.svg), r.svg && (r.uncache ? (M = t.getBBox(), u = r.xOrigin - M.x + "px " + (r.yOrigin - M.y) + "px", q = "") : q = !n && t.getAttribute("data-svg-origin"), Xh(t, q || u, !!q || r.originIsAbsolute, r.smooth !== !1, S)), E = r.xOrigin || 0, k = r.yOrigin || 0, S !== Ga && (O = S[0], F = S[1], V = S[2], W = S[3], c = Z = S[4], f = re = S[5], S.length === 6 ? (p = Math.sqrt(O * O + F * F), m = Math.sqrt(W * W + V * V), h = O || F ? ms(F, O) * Ri : 0, y = V || W ? ms(V, W) * Ri + h : 0, y && (m *= Math.abs(Math.cos(y * Ys))), r.svg && (c -= E - (E * O + k * V), f -= k - (E * F + k * W))) : (ke = S[6], St = S[7], H = S[8], ie = S[9], ne = S[10], xe = S[11], c = S[12], f = S[13], d = S[14], P = ms(ke, ne), _ = P * Ri, P && (A = Math.cos(-P), w = Math.sin(-P), q = Z * A + H * w, M = re * A + ie * w, B = ke * A + ne * w, H = Z * -w + H * A, ie = re * -w + ie * A, ne = ke * -w + ne * A, xe = St * -w + xe * A, Z = q, re = M, ke = B), P = ms(-V, ne), v = P * Ri, P && (A = Math.cos(-P), w = Math.sin(-P), q = O * A - H * w, M = F * A - ie * w, B = V * A - ne * w, xe = W * w + xe * A, O = q, F = M, V = B), P = ms(F, O), h = P * Ri, P && (A = Math.cos(P), w = Math.sin(P), q = O * A + F * w, M = Z * A + re * w, F = F * A - O * w, re = re * A - Z * w, O = q, Z = M), _ && Math.abs(_) + Math.abs(h) > 359.9 && (_ = h = 0, v = 180 - v), p = Je(Math.sqrt(O * O + F * F + V * V)), m = Je(Math.sqrt(re * re + ke * ke)), P = ms(Z, re), y = Math.abs(P) > 2e-4 ? P * Ri : 0, T = xe ? 1 / (xe < 0 ? -xe : xe) : 0), r.svg && (q = t.getAttribute("transform"), r.forceCSS = t.setAttribute("transform", "") || !$S(or(t, Ve)), q && t.setAttribute("transform", q))), Math.abs(y) > 90 && Math.abs(y) < 270 && (s ? (p *= -1, y += h <= 0 ? 180 : -180, h += h <= 0 ? 180 : -180) : (m *= -1, y += y <= 0 ? 180 : -180)), n = n || r.uncache, r.x = c - ((r.xPercent = c && (!n && r.xPercent || (Math.round(t.offsetWidth / 2) === Math.round(-c) ? -50 : 0))) ? t.offsetWidth * r.xPercent / 100 : 0) + o, r.y = f - ((r.yPercent = f && (!n && r.yPercent || (Math.round(t.offsetHeight / 2) === Math.round(-f) ? -50 : 0))) ? t.offsetHeight * r.yPercent / 100 : 0) + o, r.z = d + o, r.scaleX = Je(p), r.scaleY = Je(m), r.rotation = Je(h) + a, r.rotationX = Je(_) + a, r.rotationY = Je(v) + a, r.skewX = y + a, r.skewY = x + a, r.transformPerspective = T + o, (r.zOrigin = parseFloat(u.split(" ")[2]) || !n && r.zOrigin || 0) && (i[Qt] = hc(u)), r.xOffset = r.yOffset = 0, r.force3D = fn.force3D, r.renderTransform = r.svg ? kD : VS ? WS : PD, r.uncache = 0, r
    },
    hc = function(t) {
        return (t = t.split(" "))[0] + " " + t[1]
    },
    pd = function(t, n, r) {
        var i = Rt(n);
        return Je(parseFloat(n) + parseFloat(ci(t, "x", r + "px", i))) + i
    },
    PD = function(t, n) {
        n.z = "0px", n.rotationY = n.rotationX = "0deg", n.force3D = 0, WS(t, n)
    },
    Ti = "0deg",
    $o = "0px",
    Ei = ") ",
    WS = function(t, n) {
        var r = n || this,
            i = r.xPercent,
            s = r.yPercent,
            o = r.x,
            a = r.y,
            l = r.z,
            u = r.rotation,
            c = r.rotationY,
            f = r.rotationX,
            d = r.skewX,
            p = r.skewY,
            m = r.scaleX,
            h = r.scaleY,
            _ = r.transformPerspective,
            v = r.force3D,
            y = r.target,
            x = r.zOrigin,
            T = "",
            E = v === "auto" && t && t !== 1 || v === !0;
        if (x && (f !== Ti || c !== Ti)) {
            var k = parseFloat(c) * Ys,
                S = Math.sin(k),
                P = Math.cos(k),
                A;
            k = parseFloat(f) * Ys, A = Math.cos(k), o = pd(y, o, S * A * -x), a = pd(y, a, -Math.sin(k) * -x), l = pd(y, l, P * A * -x + x)
        }
        _ !== $o && (T += "perspective(" + _ + Ei), (i || s) && (T += "translate(" + i + "%, " + s + "%) "), (E || o !== $o || a !== $o || l !== $o) && (T += l !== $o || E ? "translate3d(" + o + ", " + a + ", " + l + ") " : "translate(" + o + ", " + a + Ei), u !== Ti && (T += "rotate(" + u + Ei), c !== Ti && (T += "rotateY(" + c + Ei), f !== Ti && (T += "rotateX(" + f + Ei), (d !== Ti || p !== Ti) && (T += "skew(" + d + ", " + p + Ei), (m !== 1 || h !== 1) && (T += "scale(" + m + ", " + h + Ei), y.style[Ve] = T || "translate(0, 0)"
    },
    kD = function(t, n) {
        var r = n || this,
            i = r.xPercent,
            s = r.yPercent,
            o = r.x,
            a = r.y,
            l = r.rotation,
            u = r.skewX,
            c = r.skewY,
            f = r.scaleX,
            d = r.scaleY,
            p = r.target,
            m = r.xOrigin,
            h = r.yOrigin,
            _ = r.xOffset,
            v = r.yOffset,
            y = r.forceCSS,
            x = parseFloat(o),
            T = parseFloat(a),
            E, k, S, P, A;
        l = parseFloat(l), u = parseFloat(u), c = parseFloat(c), c && (c = parseFloat(c), u += c, l += c), l || u ? (l *= Ys, u *= Ys, E = Math.cos(l) * f, k = Math.sin(l) * f, S = Math.sin(l - u) * -d, P = Math.cos(l - u) * d, u && (c *= Ys, A = Math.tan(u - c), A = Math.sqrt(1 + A * A), S *= A, P *= A, c && (A = Math.tan(c), A = Math.sqrt(1 + A * A), E *= A, k *= A)), E = Je(E), k = Je(k), S = Je(S), P = Je(P)) : (E = f, P = d, k = S = 0), (x && !~(o + "").indexOf("px") || T && !~(a + "").indexOf("px")) && (x = ci(p, "x", o, "px"), T = ci(p, "y", a, "px")), (m || h || _ || v) && (x = Je(x + m - (m * E + h * S) + _), T = Je(T + h - (m * k + h * P) + v)), (i || s) && (A = p.getBBox(), x = Je(x + i / 100 * A.width), T = Je(T + s / 100 * A.height)), A = "matrix(" + E + "," + k + "," + S + "," + P + "," + x + "," + T + ")", p.setAttribute("transform", A), y && (p.style[Ve] = A)
    },
    bD = function(t, n, r, i, s) {
        var o = 360,
            a = pt(s),
            l = parseFloat(s) * (a && ~s.indexOf("rad") ? Ri : 1),
            u = l - i,
            c = i + u + "deg",
            f, d;
        return a && (f = s.split("_")[1], f === "short" && (u %= o, u !== u % (o / 2) && (u += u < 0 ? o : -360)), f === "cw" && u < 0 ? u = (u + o * K0) % o - ~~(u / o) * o : f === "ccw" && u > 0 && (u = (u - o * K0) % o - ~~(u / o) * o)), t._pt = d = new qt(t._pt, n, r, i, u, fD), d.e = c, d.u = "deg", t._props.push(r), d
    },
    Z0 = function(t, n) {
        for (var r in n) t[r] = n[r];
        return t
    },
    RD = function(t, n, r) {
        var i = Z0({}, r._gsap),
            s = "perspective,force3D,transformOrigin,svgOrigin",
            o = r.style,
            a, l, u, c, f, d, p, m;
        i.svg ? (u = r.getAttribute("transform"), r.setAttribute("transform", ""), o[Ve] = n, a = Ya(r, 1), ns(r, Ve), r.setAttribute("transform", u)) : (u = getComputedStyle(r)[Ve], o[Ve] = n, a = Ya(r, 1), o[Ve] = u);
        for (l in Dr) u = i[l], c = a[l], u !== c && s.indexOf(l) < 0 && (p = Rt(u), m = Rt(c), f = p !== m ? ci(r, l, u, m) : parseFloat(u), d = parseFloat(c), t._pt = new qt(t._pt, a, l, f, d - f, Kh), t._pt.u = m || 0, t._props.push(l));
        Z0(a, i)
    };
Xt("padding,margin,Width,Radius", function(e, t) {
    var n = "Top",
        r = "Right",
        i = "Bottom",
        s = "Left",
        o = (t < 3 ? [n, r, i, s] : [n + s, n + r, i + r, i + s]).map(function(a) {
            return t < 2 ? e + a : "border" + a + e
        });
    dc[t > 1 ? "border" + e : e] = function(a, l, u, c, f) {
        var d, p;
        if (arguments.length < 4) return d = o.map(function(m) {
            return yr(a, m, u)
        }), p = d.join(" "), p.split(d[0]).length === 5 ? d[0] : p;
        d = (c + "").split(" "), p = {}, o.forEach(function(m, h) {
            return p[m] = d[h] = d[h] || d[(h - 1) / 2 | 0]
        }), a.init(l, p, f)
    }
});
var HS = {
    name: "css",
    register: Yh,
    targetTest: function(t) {
        return t.style && t.nodeType
    },
    init: function(t, n, r, i, s) {
        var o = this._props,
            a = t.style,
            l = r.vars.startAt,
            u, c, f, d, p, m, h, _, v, y, x, T, E, k, S, P;
        Bm || Yh(), this.styles = this.styles || IS(t), P = this.styles.props, this.tween = r;
        for (h in n)
            if (h !== "autoRound" && (c = n[h], !(rn[h] && kS(h, n, r, i, t, s)))) {
                if (p = typeof c, m = dc[h], p === "function" && (c = c.call(r, i, t, s), p = typeof c), p === "string" && ~c.indexOf("random(") && (c = Wa(c)), m) m(this, t, h, c, r) && (S = 1);
                else if (h.substr(0, 2) === "--") u = (getComputedStyle(t).getPropertyValue(h) + "").trim(), c += "", oi.lastIndex = 0, oi.test(u) || (_ = Rt(u), v = Rt(c)), v ? _ !== v && (u = ci(t, h, u, v) + v) : _ && (c += _), this.add(a, "setProperty", u, c, i, s, 0, 0, h), o.push(h), P.push(h, 0, a[h]);
                else if (p !== "undefined") {
                    if (l && h in l ? (u = typeof l[h] == "function" ? l[h].call(r, i, t, s) : l[h], pt(u) && ~u.indexOf("random(") && (u = Wa(u)), Rt(u + "") || u === "auto" || (u += fn.units[h] || Rt(yr(t, h)) || ""), (u + "").charAt(1) === "=" && (u = yr(t, h))) : u = yr(t, h), d = parseFloat(u), y = p === "string" && c.charAt(1) === "=" && c.substr(0, 2), y && (c = c.substr(2)), f = parseFloat(c), h in nr && (h === "autoAlpha" && (d === 1 && yr(t, "visibility") === "hidden" && f && (d = 0), P.push("visibility", 0, a.visibility), qr(this, a, "visibility", d ? "inherit" : "hidden", f ? "inherit" : "hidden", !f)), h !== "scale" && h !== "transform" && (h = nr[h], ~h.indexOf(",") && (h = h.split(",")[0]))), x = h in Dr, x) {
                        if (this.styles.save(h), T || (E = t._gsap, E.renderTransform && !n.parseTransform || Ya(t, n.parseTransform), k = n.smoothOrigin !== !1 && E.smooth, T = this._pt = new qt(this._pt, a, Ve, 0, 1, E.renderTransform, E, 0, -1), T.dep = 1), h === "scale") this._pt = new qt(this._pt, E, "scaleY", E.scaleY, (y ? Ks(E.scaleY, y + f) : f) - E.scaleY || 0, Kh), this._pt.u = 0, o.push("scaleY", h), h += "X";
                        else if (h === "transformOrigin") {
                            P.push(Qt, 0, a[Qt]), c = TD(c), E.svg ? Xh(t, c, 0, k, 0, this) : (v = parseFloat(c.split(" ")[2]) || 0, v !== E.zOrigin && qr(this, E, "zOrigin", E.zOrigin, v), qr(this, a, h, hc(u), hc(c)));
                            continue
                        } else if (h === "svgOrigin") {
                            Xh(t, c, 1, k, 0, this);
                            continue
                        } else if (h in US) {
                            bD(this, E, h, d, y ? Ks(d, y + c) : c);
                            continue
                        } else if (h === "smoothOrigin") {
                            qr(this, E, "smooth", E.smooth, c);
                            continue
                        } else if (h === "force3D") {
                            E[h] = c;
                            continue
                        } else if (h === "transform") {
                            RD(this, c, t);
                            continue
                        }
                    } else h in a || (h = fo(h) || h);
                    if (x || (f || f === 0) && (d || d === 0) && !cD.test(c) && h in a) _ = (u + "").substr((d + "").length), f || (f = 0), v = Rt(c) || (h in fn.units ? fn.units[h] : _), _ !== v && (d = ci(t, h, u, v)), this._pt = new qt(this._pt, x ? E : a, h, d, (y ? Ks(d, y + f) : f) - d, !x && (v === "px" || h === "zIndex") && n.autoRound !== !1 ? hD : Kh), this._pt.u = v || 0, _ !== v && v !== "%" && (this._pt.b = u, this._pt.r = dD);
                    else if (h in a) CD.call(this, t, h, u, y ? y + c : c);
                    else if (h in t) this.add(t, h, u || t[h], y ? y + c : c, i, s);
                    else if (h !== "parseTransform") {
                        Dm(h, c);
                        continue
                    }
                    x || (h in a ? P.push(h, 0, a[h]) : typeof t[h] == "function" ? P.push(h, 2, t[h]()) : P.push(h, 1, u || t[h])), o.push(h)
                }
            }
        S && OS(this)
    },
    render: function(t, n) {
        if (n.tween._time || !zm())
            for (var r = n._pt; r;) r.r(t, r.d), r = r._next;
        else n.styles.revert()
    },
    get: yr,
    aliases: nr,
    getSetter: function(t, n, r) {
        var i = nr[n];
        return i && i.indexOf(",") < 0 && (n = i), n in Dr && n !== Qt && (t._gsap.x || yr(t, "x")) ? r && H0 === r ? n === "scale" ? yD : gD : (H0 = r || {}) && (n === "scale" ? vD : xD) : t.style && !bm(t.style[n]) ? pD : ~n.indexOf("-") ? mD : Im(t, n)
    },
    core: {
        _removeProperty: ns,
        _getMatrix: $m
    }
};
Jt.utils.checkPrefix = fo;
Jt.core.getStyleSaver = IS;
(function(e, t, n, r) {
    var i = Xt(e + "," + t + "," + n, function(s) {
        Dr[s] = 1
    });
    Xt(t, function(s) {
        fn.units[s] = "deg", US[s] = 1
    }), nr[i[13]] = e + "," + t, Xt(r, function(s) {
        var o = s.split(":");
        nr[o[1]] = i[o[0]]
    })
})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent", "rotation,rotationX,rotationY,skewX,skewY", "transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", "0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");
Xt("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function(e) {
    fn.units[e] = "px"
});
Jt.registerPlugin(HS);
var Oi = Jt.registerPlugin(HS) || Jt;
Oi.core.Tween;
/*!
 * @gsap/react 2.1.2
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license or for
 * Club GSAP members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
 */
let ev = typeof document < "u" ? C.useLayoutEffect : C.useEffect,
    tv = e => e && !Array.isArray(e) && typeof e == "object",
    Ql = [],
    AD = {},
    KS = Oi;
const pc = (e, t = Ql) => {
    let n = AD;
    tv(e) ? (n = e, e = null, t = "dependencies" in n ? n.dependencies : Ql) : tv(t) && (n = t, t = "dependencies" in n ? n.dependencies : Ql), e && typeof e != "function" && console.warn("First parameter must be a function or config object");
    const {
        scope: r,
        revertOnUpdate: i
    } = n, s = C.useRef(!1), o = C.useRef(KS.context(() => {}, r)), a = C.useRef(u => o.current.add(null, u)), l = t && t.length && !i;
    return l && ev(() => (s.current = !0, () => o.current.revert()), Ql), ev(() => {
        if (e && o.current.add(e, r), !l || !s.current) return () => o.current.revert()
    }, t), {
        context: o.current,
        contextSafe: a.current
    }
};
pc.register = e => {
    KS = e
};
pc.headless = !0;
const GS = C.createContext(""),
    DD = ({
        children: e
    }) => {
        const [t, n] = C.useState(null), r = (i, s, o) => {
            n({
                type: i,
                msg: s,
                state: o
            });
            const a = setTimeout(() => {
                n(null)
            }, 4e3);
            return () => clearTimeout(a)
        };
        return g.jsx(GS.Provider, {
            value: {
                alart: t,
                showAlart: r
            },
            children: e
        })
    };

function YS(e) {
    var t, n, r = "";
    if (typeof e == "string" || typeof e == "number") r += e;
    else if (typeof e == "object")
        if (Array.isArray(e)) {
            var i = e.length;
            for (t = 0; t < i; t++) e[t] && (n = YS(e[t])) && (r && (r += " "), r += n)
        } else
            for (n in e) e[n] && (r && (r += " "), r += n);
    return r
}

function mc() {
    for (var e, t, n = 0, r = "", i = arguments.length; n < i; n++)(e = arguments[n]) && (t = YS(e)) && (r && (r += " "), r += t);
    return r
}

function XS(e, t, n = void 0) {
    const r = {};
    for (const i in e) {
        const s = e[i];
        let o = "",
            a = !0;
        for (let l = 0; l < s.length; l += 1) {
            const u = s[l];
            u && (o += (a === !0 ? "" : " ") + t(u), a = !1, n && n[u] && (o += " " + n[u]))
        }
        r[i] = o
    }
    return r
}

function rs(e, ...t) {
    const n = new URL(`https://mui.com/production-error/?code=${e}`);
    return t.forEach(r => n.searchParams.append("args[]", r)), `Minified MUI error #${e}; visit ${n} for the full message.`
}

function ho(e) {
    if (typeof e != "string") throw new Error(rs(7));
    return e.charAt(0).toUpperCase() + e.slice(1)
}
var qS = {
        exports: {}
    },
    Ce = {};
/**
 * @license React
 * react-is.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Wm = Symbol.for("react.transitional.element"),
    Hm = Symbol.for("react.portal"),
    qc = Symbol.for("react.fragment"),
    Qc = Symbol.for("react.strict_mode"),
    Jc = Symbol.for("react.profiler"),
    Zc = Symbol.for("react.consumer"),
    ef = Symbol.for("react.context"),
    tf = Symbol.for("react.forward_ref"),
    nf = Symbol.for("react.suspense"),
    rf = Symbol.for("react.suspense_list"),
    sf = Symbol.for("react.memo"),
    of = Symbol.for("react.lazy"),
    jD = Symbol.for("react.offscreen"),
    OD = Symbol.for("react.client.reference");

function jn(e) {
    if (typeof e == "object" && e !== null) {
        var t = e.$$typeof;
        switch (t) {
            case Wm:
                switch (e = e.type, e) {
                    case qc:
                    case Jc:
                    case Qc:
                    case nf:
                    case rf:
                        return e;
                    default:
                        switch (e = e && e.$$typeof, e) {
                            case ef:
                            case tf:
                            case of:
                            case sf:
                                return e;
                            case Zc:
                                return e;
                            default:
                                return t
                        }
                }
            case Hm:
                return t
        }
    }
}
Ce.ContextConsumer = Zc;
Ce.ContextProvider = ef;
Ce.Element = Wm;
Ce.ForwardRef = tf;
Ce.Fragment = qc;
Ce.Lazy = of ;
Ce.Memo = sf;
Ce.Portal = Hm;
Ce.Profiler = Jc;
Ce.StrictMode = Qc;
Ce.Suspense = nf;
Ce.SuspenseList = rf;
Ce.isContextConsumer = function(e) {
    return jn(e) === Zc
};
Ce.isContextProvider = function(e) {
    return jn(e) === ef
};
Ce.isElement = function(e) {
    return typeof e == "object" && e !== null && e.$$typeof === Wm
};
Ce.isForwardRef = function(e) {
    return jn(e) === tf
};
Ce.isFragment = function(e) {
    return jn(e) === qc
};
Ce.isLazy = function(e) {
    return jn(e) === of
};
Ce.isMemo = function(e) {
    return jn(e) === sf
};
Ce.isPortal = function(e) {
    return jn(e) === Hm
};
Ce.isProfiler = function(e) {
    return jn(e) === Jc
};
Ce.isStrictMode = function(e) {
    return jn(e) === Qc
};
Ce.isSuspense = function(e) {
    return jn(e) === nf
};
Ce.isSuspenseList = function(e) {
    return jn(e) === rf
};
Ce.isValidElementType = function(e) {
    return typeof e == "string" || typeof e == "function" || e === qc || e === Jc || e === Qc || e === nf || e === rf || e === jD || typeof e == "object" && e !== null && (e.$$typeof === of || e.$$typeof === sf || e.$$typeof === ef || e.$$typeof === Zc || e.$$typeof === tf || e.$$typeof === OD || e.getModuleId !== void 0)
};
Ce.typeOf = jn;
qS.exports = Ce;
var QS = qS.exports;

function vr(e) {
    if (typeof e != "object" || e === null) return !1;
    const t = Object.getPrototypeOf(e);
    return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
}

function JS(e) {
    if (C.isValidElement(e) || QS.isValidElementType(e) || !vr(e)) return e;
    const t = {};
    return Object.keys(e).forEach(n => {
        t[n] = JS(e[n])
    }), t
}

function dn(e, t, n = {
    clone: !0
}) {
    const r = n.clone ? { ...e
    } : e;
    return vr(e) && vr(t) && Object.keys(t).forEach(i => {
        C.isValidElement(t[i]) || QS.isValidElementType(t[i]) ? r[i] = t[i] : vr(t[i]) && Object.prototype.hasOwnProperty.call(e, i) && vr(e[i]) ? r[i] = dn(e[i], t[i], n) : n.clone ? r[i] = vr(t[i]) ? JS(t[i]) : t[i] : r[i] = t[i]
    }), r
}

function ya(e, t) {
    return t ? dn(e, t, {
        clone: !1
    }) : e
}

function LD(e, t) {
    if (!e.containerQueries) return t;
    const n = Object.keys(t).filter(r => r.startsWith("@container")).sort((r, i) => {
        var o, a;
        const s = /min-width:\s*([0-9.]+)/;
        return +(((o = r.match(s)) == null ? void 0 : o[1]) || 0) - +(((a = i.match(s)) == null ? void 0 : a[1]) || 0)
    });
    return n.length ? n.reduce((r, i) => {
        const s = t[i];
        return delete r[i], r[i] = s, r
    }, { ...t
    }) : t
}

function MD(e, t) {
    return t === "@" || t.startsWith("@") && (e.some(n => t.startsWith(`@${n}`)) || !!t.match(/^@\d/))
}

function ND(e, t) {
    const n = t.match(/^@([^/]+)?\/?(.+)?$/);
    if (!n) return null;
    const [, r, i] = n, s = Number.isNaN(+r) ? r || 0 : +r;
    return e.containerQueries(i).up(s)
}

function FD(e) {
    const t = (s, o) => s.replace("@media", o ? `@container ${o}` : "@container");

    function n(s, o) {
        s.up = (...a) => t(e.breakpoints.up(...a), o), s.down = (...a) => t(e.breakpoints.down(...a), o), s.between = (...a) => t(e.breakpoints.between(...a), o), s.only = (...a) => t(e.breakpoints.only(...a), o), s.not = (...a) => {
            const l = t(e.breakpoints.not(...a), o);
            return l.includes("not all and") ? l.replace("not all and ", "").replace("min-width:", "width<").replace("max-width:", "width>").replace("and", "or") : l
        }
    }
    const r = {},
        i = s => (n(r, s), r);
    return n(i), { ...e,
        containerQueries: i
    }
}
const af = {
        xs: 0,
        sm: 600,
        md: 900,
        lg: 1200,
        xl: 1536
    },
    nv = {
        keys: ["xs", "sm", "md", "lg", "xl"],
        up: e => `@media (min-width:${af[e]}px)`
    },
    ID = {
        containerQueries: e => ({
            up: t => {
                let n = typeof t == "number" ? t : af[t] || t;
                return typeof n == "number" && (n = `${n}px`), e ? `@container ${e} (min-width:${n})` : `@container (min-width:${n})`
            }
        })
    };

function jr(e, t, n) {
    const r = e.theme || {};
    if (Array.isArray(t)) {
        const s = r.breakpoints || nv;
        return t.reduce((o, a, l) => (o[s.up(s.keys[l])] = n(t[l]), o), {})
    }
    if (typeof t == "object") {
        const s = r.breakpoints || nv;
        return Object.keys(t).reduce((o, a) => {
            if (MD(s.keys, a)) {
                const l = ND(r.containerQueries ? r : ID, a);
                l && (o[l] = n(t[a], a))
            } else if (Object.keys(s.values || af).includes(a)) {
                const l = s.up(a);
                o[l] = n(t[a], a)
            } else {
                const l = a;
                o[l] = t[l]
            }
            return o
        }, {})
    }
    return n(t)
}

function VD(e = {}) {
    var n;
    return ((n = e.keys) == null ? void 0 : n.reduce((r, i) => {
        const s = e.up(i);
        return r[s] = {}, r
    }, {})) || {}
}

function BD(e, t) {
    return e.reduce((n, r) => {
        const i = n[r];
        return (!i || Object.keys(i).length === 0) && delete n[r], n
    }, t)
}

function lf(e, t, n = !0) {
    if (!t || typeof t != "string") return null;
    if (e && e.vars && n) {
        const r = `vars.${t}`.split(".").reduce((i, s) => i && i[s] ? i[s] : null, e);
        if (r != null) return r
    }
    return t.split(".").reduce((r, i) => r && r[i] != null ? r[i] : null, e)
}

function gc(e, t, n, r = n) {
    let i;
    return typeof e == "function" ? i = e(n) : Array.isArray(e) ? i = e[n] || r : i = lf(e, n) || r, t && (i = t(i, r, e)), i
}

function tt(e) {
    const {
        prop: t,
        cssProperty: n = e.prop,
        themeKey: r,
        transform: i
    } = e, s = o => {
        if (o[t] == null) return null;
        const a = o[t],
            l = o.theme,
            u = lf(l, r) || {};
        return jr(o, a, f => {
            let d = gc(u, i, f);
            return f === d && typeof f == "string" && (d = gc(u, i, `${t}${f==="default"?"":ho(f)}`, f)), n === !1 ? d : {
                [n]: d
            }
        })
    };
    return s.propTypes = {}, s.filterProps = [t], s
}

function zD(e) {
    const t = {};
    return n => (t[n] === void 0 && (t[n] = e(n)), t[n])
}
const UD = {
        m: "margin",
        p: "padding"
    },
    $D = {
        t: "Top",
        r: "Right",
        b: "Bottom",
        l: "Left",
        x: ["Left", "Right"],
        y: ["Top", "Bottom"]
    },
    rv = {
        marginX: "mx",
        marginY: "my",
        paddingX: "px",
        paddingY: "py"
    },
    WD = zD(e => {
        if (e.length > 2)
            if (rv[e]) e = rv[e];
            else return [e];
        const [t, n] = e.split(""), r = UD[t], i = $D[n] || "";
        return Array.isArray(i) ? i.map(s => r + s) : [r + i]
    }),
    Km = ["m", "mt", "mr", "mb", "ml", "mx", "my", "margin", "marginTop", "marginRight", "marginBottom", "marginLeft", "marginX", "marginY", "marginInline", "marginInlineStart", "marginInlineEnd", "marginBlock", "marginBlockStart", "marginBlockEnd"],
    Gm = ["p", "pt", "pr", "pb", "pl", "px", "py", "padding", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft", "paddingX", "paddingY", "paddingInline", "paddingInlineStart", "paddingInlineEnd", "paddingBlock", "paddingBlockStart", "paddingBlockEnd"];
[...Km, ...Gm];

function gl(e, t, n, r) {
    const i = lf(e, t, !0) ? ? n;
    return typeof i == "number" || typeof i == "string" ? s => typeof s == "string" ? s : typeof i == "string" ? `calc(${s} * ${i})` : i * s : Array.isArray(i) ? s => {
        if (typeof s == "string") return s;
        const o = Math.abs(s),
            a = i[o];
        return s >= 0 ? a : typeof a == "number" ? -a : `-${a}`
    } : typeof i == "function" ? i : () => {}
}

function Ym(e) {
    return gl(e, "spacing", 8)
}

function yl(e, t) {
    return typeof t == "string" || t == null ? t : e(t)
}

function HD(e, t) {
    return n => e.reduce((r, i) => (r[i] = yl(t, n), r), {})
}

function KD(e, t, n, r) {
    if (!t.includes(n)) return null;
    const i = WD(n),
        s = HD(i, r),
        o = e[n];
    return jr(e, o, s)
}

function ZS(e, t) {
    const n = Ym(e.theme);
    return Object.keys(e).map(r => KD(e, t, r, n)).reduce(ya, {})
}

function He(e) {
    return ZS(e, Km)
}
He.propTypes = {};
He.filterProps = Km;

function Ke(e) {
    return ZS(e, Gm)
}
Ke.propTypes = {};
Ke.filterProps = Gm;

function uf(...e) {
    const t = e.reduce((r, i) => (i.filterProps.forEach(s => {
            r[s] = i
        }), r), {}),
        n = r => Object.keys(r).reduce((i, s) => t[s] ? ya(i, t[s](r)) : i, {});
    return n.propTypes = {}, n.filterProps = e.reduce((r, i) => r.concat(i.filterProps), []), n
}

function Pn(e) {
    return typeof e != "number" ? e : `${e}px solid`
}

function On(e, t) {
    return tt({
        prop: e,
        themeKey: "borders",
        transform: t
    })
}
const GD = On("border", Pn),
    YD = On("borderTop", Pn),
    XD = On("borderRight", Pn),
    qD = On("borderBottom", Pn),
    QD = On("borderLeft", Pn),
    JD = On("borderColor"),
    ZD = On("borderTopColor"),
    ej = On("borderRightColor"),
    tj = On("borderBottomColor"),
    nj = On("borderLeftColor"),
    rj = On("outline", Pn),
    ij = On("outlineColor"),
    cf = e => {
        if (e.borderRadius !== void 0 && e.borderRadius !== null) {
            const t = gl(e.theme, "shape.borderRadius", 4),
                n = r => ({
                    borderRadius: yl(t, r)
                });
            return jr(e, e.borderRadius, n)
        }
        return null
    };
cf.propTypes = {};
cf.filterProps = ["borderRadius"];
uf(GD, YD, XD, qD, QD, JD, ZD, ej, tj, nj, cf, rj, ij);
const ff = e => {
    if (e.gap !== void 0 && e.gap !== null) {
        const t = gl(e.theme, "spacing", 8),
            n = r => ({
                gap: yl(t, r)
            });
        return jr(e, e.gap, n)
    }
    return null
};
ff.propTypes = {};
ff.filterProps = ["gap"];
const df = e => {
    if (e.columnGap !== void 0 && e.columnGap !== null) {
        const t = gl(e.theme, "spacing", 8),
            n = r => ({
                columnGap: yl(t, r)
            });
        return jr(e, e.columnGap, n)
    }
    return null
};
df.propTypes = {};
df.filterProps = ["columnGap"];
const hf = e => {
    if (e.rowGap !== void 0 && e.rowGap !== null) {
        const t = gl(e.theme, "spacing", 8),
            n = r => ({
                rowGap: yl(t, r)
            });
        return jr(e, e.rowGap, n)
    }
    return null
};
hf.propTypes = {};
hf.filterProps = ["rowGap"];
const sj = tt({
        prop: "gridColumn"
    }),
    oj = tt({
        prop: "gridRow"
    }),
    aj = tt({
        prop: "gridAutoFlow"
    }),
    lj = tt({
        prop: "gridAutoColumns"
    }),
    uj = tt({
        prop: "gridAutoRows"
    }),
    cj = tt({
        prop: "gridTemplateColumns"
    }),
    fj = tt({
        prop: "gridTemplateRows"
    }),
    dj = tt({
        prop: "gridTemplateAreas"
    }),
    hj = tt({
        prop: "gridArea"
    });
uf(ff, df, hf, sj, oj, aj, lj, uj, cj, fj, dj, hj);

function Xs(e, t) {
    return t === "grey" ? t : e
}
const pj = tt({
        prop: "color",
        themeKey: "palette",
        transform: Xs
    }),
    mj = tt({
        prop: "bgcolor",
        cssProperty: "backgroundColor",
        themeKey: "palette",
        transform: Xs
    }),
    gj = tt({
        prop: "backgroundColor",
        themeKey: "palette",
        transform: Xs
    });
uf(pj, mj, gj);

function on(e) {
    return e <= 1 && e !== 0 ? `${e*100}%` : e
}
const yj = tt({
        prop: "width",
        transform: on
    }),
    Xm = e => {
        if (e.maxWidth !== void 0 && e.maxWidth !== null) {
            const t = n => {
                var i, s, o, a, l;
                const r = ((o = (s = (i = e.theme) == null ? void 0 : i.breakpoints) == null ? void 0 : s.values) == null ? void 0 : o[n]) || af[n];
                return r ? ((l = (a = e.theme) == null ? void 0 : a.breakpoints) == null ? void 0 : l.unit) !== "px" ? {
                    maxWidth: `${r}${e.theme.breakpoints.unit}`
                } : {
                    maxWidth: r
                } : {
                    maxWidth: on(n)
                }
            };
            return jr(e, e.maxWidth, t)
        }
        return null
    };
Xm.filterProps = ["maxWidth"];
const vj = tt({
        prop: "minWidth",
        transform: on
    }),
    xj = tt({
        prop: "height",
        transform: on
    }),
    _j = tt({
        prop: "maxHeight",
        transform: on
    }),
    wj = tt({
        prop: "minHeight",
        transform: on
    });
tt({
    prop: "size",
    cssProperty: "width",
    transform: on
});
tt({
    prop: "size",
    cssProperty: "height",
    transform: on
});
const Sj = tt({
    prop: "boxSizing"
});
uf(yj, Xm, vj, xj, _j, wj, Sj);
const pf = {
    border: {
        themeKey: "borders",
        transform: Pn
    },
    borderTop: {
        themeKey: "borders",
        transform: Pn
    },
    borderRight: {
        themeKey: "borders",
        transform: Pn
    },
    borderBottom: {
        themeKey: "borders",
        transform: Pn
    },
    borderLeft: {
        themeKey: "borders",
        transform: Pn
    },
    borderColor: {
        themeKey: "palette"
    },
    borderTopColor: {
        themeKey: "palette"
    },
    borderRightColor: {
        themeKey: "palette"
    },
    borderBottomColor: {
        themeKey: "palette"
    },
    borderLeftColor: {
        themeKey: "palette"
    },
    outline: {
        themeKey: "borders",
        transform: Pn
    },
    outlineColor: {
        themeKey: "palette"
    },
    borderRadius: {
        themeKey: "shape.borderRadius",
        style: cf
    },
    color: {
        themeKey: "palette",
        transform: Xs
    },
    bgcolor: {
        themeKey: "palette",
        cssProperty: "backgroundColor",
        transform: Xs
    },
    backgroundColor: {
        themeKey: "palette",
        transform: Xs
    },
    p: {
        style: Ke
    },
    pt: {
        style: Ke
    },
    pr: {
        style: Ke
    },
    pb: {
        style: Ke
    },
    pl: {
        style: Ke
    },
    px: {
        style: Ke
    },
    py: {
        style: Ke
    },
    padding: {
        style: Ke
    },
    paddingTop: {
        style: Ke
    },
    paddingRight: {
        style: Ke
    },
    paddingBottom: {
        style: Ke
    },
    paddingLeft: {
        style: Ke
    },
    paddingX: {
        style: Ke
    },
    paddingY: {
        style: Ke
    },
    paddingInline: {
        style: Ke
    },
    paddingInlineStart: {
        style: Ke
    },
    paddingInlineEnd: {
        style: Ke
    },
    paddingBlock: {
        style: Ke
    },
    paddingBlockStart: {
        style: Ke
    },
    paddingBlockEnd: {
        style: Ke
    },
    m: {
        style: He
    },
    mt: {
        style: He
    },
    mr: {
        style: He
    },
    mb: {
        style: He
    },
    ml: {
        style: He
    },
    mx: {
        style: He
    },
    my: {
        style: He
    },
    margin: {
        style: He
    },
    marginTop: {
        style: He
    },
    marginRight: {
        style: He
    },
    marginBottom: {
        style: He
    },
    marginLeft: {
        style: He
    },
    marginX: {
        style: He
    },
    marginY: {
        style: He
    },
    marginInline: {
        style: He
    },
    marginInlineStart: {
        style: He
    },
    marginInlineEnd: {
        style: He
    },
    marginBlock: {
        style: He
    },
    marginBlockStart: {
        style: He
    },
    marginBlockEnd: {
        style: He
    },
    displayPrint: {
        cssProperty: !1,
        transform: e => ({
            "@media print": {
                display: e
            }
        })
    },
    display: {},
    overflow: {},
    textOverflow: {},
    visibility: {},
    whiteSpace: {},
    flexBasis: {},
    flexDirection: {},
    flexWrap: {},
    justifyContent: {},
    alignItems: {},
    alignContent: {},
    order: {},
    flex: {},
    flexGrow: {},
    flexShrink: {},
    alignSelf: {},
    justifyItems: {},
    justifySelf: {},
    gap: {
        style: ff
    },
    rowGap: {
        style: hf
    },
    columnGap: {
        style: df
    },
    gridColumn: {},
    gridRow: {},
    gridAutoFlow: {},
    gridAutoColumns: {},
    gridAutoRows: {},
    gridTemplateColumns: {},
    gridTemplateRows: {},
    gridTemplateAreas: {},
    gridArea: {},
    position: {},
    zIndex: {
        themeKey: "zIndex"
    },
    top: {},
    right: {},
    bottom: {},
    left: {},
    boxShadow: {
        themeKey: "shadows"
    },
    width: {
        transform: on
    },
    maxWidth: {
        style: Xm
    },
    minWidth: {
        transform: on
    },
    height: {
        transform: on
    },
    maxHeight: {
        transform: on
    },
    minHeight: {
        transform: on
    },
    boxSizing: {},
    font: {
        themeKey: "font"
    },
    fontFamily: {
        themeKey: "typography"
    },
    fontSize: {
        themeKey: "typography"
    },
    fontStyle: {
        themeKey: "typography"
    },
    fontWeight: {
        themeKey: "typography"
    },
    letterSpacing: {},
    textTransform: {},
    lineHeight: {},
    textAlign: {},
    typography: {
        cssProperty: !1,
        themeKey: "typography"
    }
};

function Cj(...e) {
    const t = e.reduce((r, i) => r.concat(Object.keys(i)), []),
        n = new Set(t);
    return e.every(r => n.size === Object.keys(r).length)
}

function Tj(e, t) {
    return typeof e == "function" ? e(t) : e
}

function Ej() {
    function e(n, r, i, s) {
        const o = {
                [n]: r,
                theme: i
            },
            a = s[n];
        if (!a) return {
            [n]: r
        };
        const {
            cssProperty: l = n,
            themeKey: u,
            transform: c,
            style: f
        } = a;
        if (r == null) return null;
        if (u === "typography" && r === "inherit") return {
            [n]: r
        };
        const d = lf(i, u) || {};
        return f ? f(o) : jr(o, r, m => {
            let h = gc(d, c, m);
            return m === h && typeof m == "string" && (h = gc(d, c, `${n}${m==="default"?"":ho(m)}`, m)), l === !1 ? h : {
                [l]: h
            }
        })
    }

    function t(n) {
        const {
            sx: r,
            theme: i = {}
        } = n || {};
        if (!r) return null;
        const s = i.unstable_sxConfig ? ? pf;

        function o(a) {
            let l = a;
            if (typeof a == "function") l = a(i);
            else if (typeof a != "object") return a;
            if (!l) return null;
            const u = VD(i.breakpoints),
                c = Object.keys(u);
            let f = u;
            return Object.keys(l).forEach(d => {
                const p = Tj(l[d], i);
                if (p != null)
                    if (typeof p == "object")
                        if (s[d]) f = ya(f, e(d, p, i, s));
                        else {
                            const m = jr({
                                theme: i
                            }, p, h => ({
                                [d]: h
                            }));
                            Cj(m, p) ? f[d] = t({
                                sx: p,
                                theme: i
                            }) : f = ya(f, m)
                        }
                else f = ya(f, e(d, p, i, s))
            }), LD(i, BD(c, f))
        }
        return Array.isArray(r) ? r.map(o) : o(r)
    }
    return t
}
const po = Ej();
po.filterProps = ["sx"];

function qh() {
    return qh = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, qh.apply(null, arguments)
}

function Pj(e) {
    if (e.sheet) return e.sheet;
    for (var t = 0; t < document.styleSheets.length; t++)
        if (document.styleSheets[t].ownerNode === e) return document.styleSheets[t]
}

function kj(e) {
    var t = document.createElement("style");
    return t.setAttribute("data-emotion", e.key), e.nonce !== void 0 && t.setAttribute("nonce", e.nonce), t.appendChild(document.createTextNode("")), t.setAttribute("data-s", ""), t
}
var bj = function() {
        function e(n) {
            var r = this;
            this._insertTag = function(i) {
                var s;
                r.tags.length === 0 ? r.insertionPoint ? s = r.insertionPoint.nextSibling : r.prepend ? s = r.container.firstChild : s = r.before : s = r.tags[r.tags.length - 1].nextSibling, r.container.insertBefore(i, s), r.tags.push(i)
            }, this.isSpeedy = n.speedy === void 0 ? !0 : n.speedy, this.tags = [], this.ctr = 0, this.nonce = n.nonce, this.key = n.key, this.container = n.container, this.prepend = n.prepend, this.insertionPoint = n.insertionPoint, this.before = null
        }
        var t = e.prototype;
        return t.hydrate = function(r) {
            r.forEach(this._insertTag)
        }, t.insert = function(r) {
            this.ctr % (this.isSpeedy ? 65e3 : 1) === 0 && this._insertTag(kj(this));
            var i = this.tags[this.tags.length - 1];
            if (this.isSpeedy) {
                var s = Pj(i);
                try {
                    s.insertRule(r, s.cssRules.length)
                } catch {}
            } else i.appendChild(document.createTextNode(r));
            this.ctr++
        }, t.flush = function() {
            this.tags.forEach(function(r) {
                var i;
                return (i = r.parentNode) == null ? void 0 : i.removeChild(r)
            }), this.tags = [], this.ctr = 0
        }, e
    }(),
    Et = "-ms-",
    yc = "-moz-",
    pe = "-webkit-",
    eC = "comm",
    qm = "rule",
    Qm = "decl",
    Rj = "@import",
    tC = "@keyframes",
    Aj = "@layer",
    Dj = Math.abs,
    mf = String.fromCharCode,
    jj = Object.assign;

function Oj(e, t) {
    return vt(e, 0) ^ 45 ? (((t << 2 ^ vt(e, 0)) << 2 ^ vt(e, 1)) << 2 ^ vt(e, 2)) << 2 ^ vt(e, 3) : 0
}

function nC(e) {
    return e.trim()
}

function Lj(e, t) {
    return (e = t.exec(e)) ? e[0] : e
}

function me(e, t, n) {
    return e.replace(t, n)
}

function Qh(e, t) {
    return e.indexOf(t)
}

function vt(e, t) {
    return e.charCodeAt(t) | 0
}

function Xa(e, t, n) {
    return e.slice(t, n)
}

function Jn(e) {
    return e.length
}

function Jm(e) {
    return e.length
}

function Jl(e, t) {
    return t.push(e), e
}

function Mj(e, t) {
    return e.map(t).join("")
}
var gf = 1,
    mo = 1,
    rC = 0,
    Zt = 0,
    ot = 0,
    To = "";

function yf(e, t, n, r, i, s, o) {
    return {
        value: e,
        root: t,
        parent: n,
        type: r,
        props: i,
        children: s,
        line: gf,
        column: mo,
        length: o,
        return: ""
    }
}

function Wo(e, t) {
    return jj(yf("", null, null, "", null, null, 0), e, {
        length: -e.length
    }, t)
}

function Nj() {
    return ot
}

function Fj() {
    return ot = Zt > 0 ? vt(To, --Zt) : 0, mo--, ot === 10 && (mo = 1, gf--), ot
}

function hn() {
    return ot = Zt < rC ? vt(To, Zt++) : 0, mo++, ot === 10 && (mo = 1, gf++), ot
}

function ar() {
    return vt(To, Zt)
}

function Tu() {
    return Zt
}

function vl(e, t) {
    return Xa(To, e, t)
}

function qa(e) {
    switch (e) {
        case 0:
        case 9:
        case 10:
        case 13:
        case 32:
            return 5;
        case 33:
        case 43:
        case 44:
        case 47:
        case 62:
        case 64:
        case 126:
        case 59:
        case 123:
        case 125:
            return 4;
        case 58:
            return 3;
        case 34:
        case 39:
        case 40:
        case 91:
            return 2;
        case 41:
        case 93:
            return 1
    }
    return 0
}

function iC(e) {
    return gf = mo = 1, rC = Jn(To = e), Zt = 0, []
}

function sC(e) {
    return To = "", e
}

function Eu(e) {
    return nC(vl(Zt - 1, Jh(e === 91 ? e + 2 : e === 40 ? e + 1 : e)))
}

function Ij(e) {
    for (;
        (ot = ar()) && ot < 33;) hn();
    return qa(e) > 2 || qa(ot) > 3 ? "" : " "
}

function Vj(e, t) {
    for (; --t && hn() && !(ot < 48 || ot > 102 || ot > 57 && ot < 65 || ot > 70 && ot < 97););
    return vl(e, Tu() + (t < 6 && ar() == 32 && hn() == 32))
}

function Jh(e) {
    for (; hn();) switch (ot) {
        case e:
            return Zt;
        case 34:
        case 39:
            e !== 34 && e !== 39 && Jh(ot);
            break;
        case 40:
            e === 41 && Jh(e);
            break;
        case 92:
            hn();
            break
    }
    return Zt
}

function Bj(e, t) {
    for (; hn() && e + ot !== 57;)
        if (e + ot === 84 && ar() === 47) break;
    return "/*" + vl(t, Zt - 1) + "*" + mf(e === 47 ? e : hn())
}

function zj(e) {
    for (; !qa(ar());) hn();
    return vl(e, Zt)
}

function Uj(e) {
    return sC(Pu("", null, null, null, [""], e = iC(e), 0, [0], e))
}

function Pu(e, t, n, r, i, s, o, a, l) {
    for (var u = 0, c = 0, f = o, d = 0, p = 0, m = 0, h = 1, _ = 1, v = 1, y = 0, x = "", T = i, E = s, k = r, S = x; _;) switch (m = y, y = hn()) {
        case 40:
            if (m != 108 && vt(S, f - 1) == 58) {
                Qh(S += me(Eu(y), "&", "&\f"), "&\f") != -1 && (v = -1);
                break
            }
        case 34:
        case 39:
        case 91:
            S += Eu(y);
            break;
        case 9:
        case 10:
        case 13:
        case 32:
            S += Ij(m);
            break;
        case 92:
            S += Vj(Tu() - 1, 7);
            continue;
        case 47:
            switch (ar()) {
                case 42:
                case 47:
                    Jl($j(Bj(hn(), Tu()), t, n), l);
                    break;
                default:
                    S += "/"
            }
            break;
        case 123 * h:
            a[u++] = Jn(S) * v;
        case 125 * h:
        case 59:
        case 0:
            switch (y) {
                case 0:
                case 125:
                    _ = 0;
                case 59 + c:
                    v == -1 && (S = me(S, /\f/g, "")), p > 0 && Jn(S) - f && Jl(p > 32 ? sv(S + ";", r, n, f - 1) : sv(me(S, " ", "") + ";", r, n, f - 2), l);
                    break;
                case 59:
                    S += ";";
                default:
                    if (Jl(k = iv(S, t, n, u, c, i, a, x, T = [], E = [], f), s), y === 123)
                        if (c === 0) Pu(S, t, k, k, T, s, f, a, E);
                        else switch (d === 99 && vt(S, 3) === 110 ? 100 : d) {
                            case 100:
                            case 108:
                            case 109:
                            case 115:
                                Pu(e, k, k, r && Jl(iv(e, k, k, 0, 0, i, a, x, i, T = [], f), E), i, E, f, a, r ? T : E);
                                break;
                            default:
                                Pu(S, k, k, k, [""], E, 0, a, E)
                        }
            }
            u = c = p = 0, h = v = 1, x = S = "", f = o;
            break;
        case 58:
            f = 1 + Jn(S), p = m;
        default:
            if (h < 1) {
                if (y == 123) --h;
                else if (y == 125 && h++ == 0 && Fj() == 125) continue
            }
            switch (S += mf(y), y * h) {
                case 38:
                    v = c > 0 ? 1 : (S += "\f", -1);
                    break;
                case 44:
                    a[u++] = (Jn(S) - 1) * v, v = 1;
                    break;
                case 64:
                    ar() === 45 && (S += Eu(hn())), d = ar(), c = f = Jn(x = S += zj(Tu())), y++;
                    break;
                case 45:
                    m === 45 && Jn(S) == 2 && (h = 0)
            }
    }
    return s
}

function iv(e, t, n, r, i, s, o, a, l, u, c) {
    for (var f = i - 1, d = i === 0 ? s : [""], p = Jm(d), m = 0, h = 0, _ = 0; m < r; ++m)
        for (var v = 0, y = Xa(e, f + 1, f = Dj(h = o[m])), x = e; v < p; ++v)(x = nC(h > 0 ? d[v] + " " + y : me(y, /&\f/g, d[v]))) && (l[_++] = x);
    return yf(e, t, n, i === 0 ? qm : a, l, u, c)
}

function $j(e, t, n) {
    return yf(e, t, n, eC, mf(Nj()), Xa(e, 2, -2), 0)
}

function sv(e, t, n, r) {
    return yf(e, t, n, Qm, Xa(e, 0, r), Xa(e, r + 1, -1), r)
}

function qs(e, t) {
    for (var n = "", r = Jm(e), i = 0; i < r; i++) n += t(e[i], i, e, t) || "";
    return n
}

function Wj(e, t, n, r) {
    switch (e.type) {
        case Aj:
            if (e.children.length) break;
        case Rj:
        case Qm:
            return e.return = e.return || e.value;
        case eC:
            return "";
        case tC:
            return e.return = e.value + "{" + qs(e.children, r) + "}";
        case qm:
            e.value = e.props.join(",")
    }
    return Jn(n = qs(e.children, r)) ? e.return = e.value + "{" + n + "}" : ""
}

function Hj(e) {
    var t = Jm(e);
    return function(n, r, i, s) {
        for (var o = "", a = 0; a < t; a++) o += e[a](n, r, i, s) || "";
        return o
    }
}

function Kj(e) {
    return function(t) {
        t.root || (t = t.return) && e(t)
    }
}

function oC(e) {
    var t = Object.create(null);
    return function(n) {
        return t[n] === void 0 && (t[n] = e(n)), t[n]
    }
}
var Gj = function(t, n, r) {
        for (var i = 0, s = 0; i = s, s = ar(), i === 38 && s === 12 && (n[r] = 1), !qa(s);) hn();
        return vl(t, Zt)
    },
    Yj = function(t, n) {
        var r = -1,
            i = 44;
        do switch (qa(i)) {
            case 0:
                i === 38 && ar() === 12 && (n[r] = 1), t[r] += Gj(Zt - 1, n, r);
                break;
            case 2:
                t[r] += Eu(i);
                break;
            case 4:
                if (i === 44) {
                    t[++r] = ar() === 58 ? "&\f" : "", n[r] = t[r].length;
                    break
                }
            default:
                t[r] += mf(i)
        }
        while (i = hn());
        return t
    },
    Xj = function(t, n) {
        return sC(Yj(iC(t), n))
    },
    ov = new WeakMap,
    qj = function(t) {
        if (!(t.type !== "rule" || !t.parent || t.length < 1)) {
            for (var n = t.value, r = t.parent, i = t.column === r.column && t.line === r.line; r.type !== "rule";)
                if (r = r.parent, !r) return;
            if (!(t.props.length === 1 && n.charCodeAt(0) !== 58 && !ov.get(r)) && !i) {
                ov.set(t, !0);
                for (var s = [], o = Xj(n, s), a = r.props, l = 0, u = 0; l < o.length; l++)
                    for (var c = 0; c < a.length; c++, u++) t.props[u] = s[l] ? o[l].replace(/&\f/g, a[c]) : a[c] + " " + o[l]
            }
        }
    },
    Qj = function(t) {
        if (t.type === "decl") {
            var n = t.value;
            n.charCodeAt(0) === 108 && n.charCodeAt(2) === 98 && (t.return = "", t.value = "")
        }
    };

function aC(e, t) {
    switch (Oj(e, t)) {
        case 5103:
            return pe + "print-" + e + e;
        case 5737:
        case 4201:
        case 3177:
        case 3433:
        case 1641:
        case 4457:
        case 2921:
        case 5572:
        case 6356:
        case 5844:
        case 3191:
        case 6645:
        case 3005:
        case 6391:
        case 5879:
        case 5623:
        case 6135:
        case 4599:
        case 4855:
        case 4215:
        case 6389:
        case 5109:
        case 5365:
        case 5621:
        case 3829:
            return pe + e + e;
        case 5349:
        case 4246:
        case 4810:
        case 6968:
        case 2756:
            return pe + e + yc + e + Et + e + e;
        case 6828:
        case 4268:
            return pe + e + Et + e + e;
        case 6165:
            return pe + e + Et + "flex-" + e + e;
        case 5187:
            return pe + e + me(e, /(\w+).+(:[^]+)/, pe + "box-$1$2" + Et + "flex-$1$2") + e;
        case 5443:
            return pe + e + Et + "flex-item-" + me(e, /flex-|-self/, "") + e;
        case 4675:
            return pe + e + Et + "flex-line-pack" + me(e, /align-content|flex-|-self/, "") + e;
        case 5548:
            return pe + e + Et + me(e, "shrink", "negative") + e;
        case 5292:
            return pe + e + Et + me(e, "basis", "preferred-size") + e;
        case 6060:
            return pe + "box-" + me(e, "-grow", "") + pe + e + Et + me(e, "grow", "positive") + e;
        case 4554:
            return pe + me(e, /([^-])(transform)/g, "$1" + pe + "$2") + e;
        case 6187:
            return me(me(me(e, /(zoom-|grab)/, pe + "$1"), /(image-set)/, pe + "$1"), e, "") + e;
        case 5495:
        case 3959:
            return me(e, /(image-set\([^]*)/, pe + "$1$`$1");
        case 4968:
            return me(me(e, /(.+:)(flex-)?(.*)/, pe + "box-pack:$3" + Et + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + pe + e + e;
        case 4095:
        case 3583:
        case 4068:
        case 2532:
            return me(e, /(.+)-inline(.+)/, pe + "$1$2") + e;
        case 8116:
        case 7059:
        case 5753:
        case 5535:
        case 5445:
        case 5701:
        case 4933:
        case 4677:
        case 5533:
        case 5789:
        case 5021:
        case 4765:
            if (Jn(e) - 1 - t > 6) switch (vt(e, t + 1)) {
                case 109:
                    if (vt(e, t + 4) !== 45) break;
                case 102:
                    return me(e, /(.+:)(.+)-([^]+)/, "$1" + pe + "$2-$3$1" + yc + (vt(e, t + 3) == 108 ? "$3" : "$2-$3")) + e;
                case 115:
                    return ~Qh(e, "stretch") ? aC(me(e, "stretch", "fill-available"), t) + e : e
            }
            break;
        case 4949:
            if (vt(e, t + 1) !== 115) break;
        case 6444:
            switch (vt(e, Jn(e) - 3 - (~Qh(e, "!important") && 10))) {
                case 107:
                    return me(e, ":", ":" + pe) + e;
                case 101:
                    return me(e, /(.+:)([^;!]+)(;|!.+)?/, "$1" + pe + (vt(e, 14) === 45 ? "inline-" : "") + "box$3$1" + pe + "$2$3$1" + Et + "$2box$3") + e
            }
            break;
        case 5936:
            switch (vt(e, t + 11)) {
                case 114:
                    return pe + e + Et + me(e, /[svh]\w+-[tblr]{2}/, "tb") + e;
                case 108:
                    return pe + e + Et + me(e, /[svh]\w+-[tblr]{2}/, "tb-rl") + e;
                case 45:
                    return pe + e + Et + me(e, /[svh]\w+-[tblr]{2}/, "lr") + e
            }
            return pe + e + Et + e + e
    }
    return e
}
var Jj = function(t, n, r, i) {
        if (t.length > -1 && !t.return) switch (t.type) {
            case Qm:
                t.return = aC(t.value, t.length);
                break;
            case tC:
                return qs([Wo(t, {
                    value: me(t.value, "@", "@" + pe)
                })], i);
            case qm:
                if (t.length) return Mj(t.props, function(s) {
                    switch (Lj(s, /(::plac\w+|:read-\w+)/)) {
                        case ":read-only":
                        case ":read-write":
                            return qs([Wo(t, {
                                props: [me(s, /:(read-\w+)/, ":" + yc + "$1")]
                            })], i);
                        case "::placeholder":
                            return qs([Wo(t, {
                                props: [me(s, /:(plac\w+)/, ":" + pe + "input-$1")]
                            }), Wo(t, {
                                props: [me(s, /:(plac\w+)/, ":" + yc + "$1")]
                            }), Wo(t, {
                                props: [me(s, /:(plac\w+)/, Et + "input-$1")]
                            })], i)
                    }
                    return ""
                })
        }
    },
    Zj = [Jj],
    eO = function(t) {
        var n = t.key;
        if (n === "css") {
            var r = document.querySelectorAll("style[data-emotion]:not([data-s])");
            Array.prototype.forEach.call(r, function(h) {
                var _ = h.getAttribute("data-emotion");
                _.indexOf(" ") !== -1 && (document.head.appendChild(h), h.setAttribute("data-s", ""))
            })
        }
        var i = t.stylisPlugins || Zj,
            s = {},
            o, a = [];
        o = t.container || document.head, Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="' + n + ' "]'), function(h) {
            for (var _ = h.getAttribute("data-emotion").split(" "), v = 1; v < _.length; v++) s[_[v]] = !0;
            a.push(h)
        });
        var l, u = [qj, Qj]; {
            var c, f = [Wj, Kj(function(h) {
                    c.insert(h)
                })],
                d = Hj(u.concat(i, f)),
                p = function(_) {
                    return qs(Uj(_), d)
                };
            l = function(_, v, y, x) {
                c = y, p(_ ? _ + "{" + v.styles + "}" : v.styles), x && (m.inserted[v.name] = !0)
            }
        }
        var m = {
            key: n,
            sheet: new bj({
                key: n,
                container: o,
                nonce: t.nonce,
                speedy: t.speedy,
                prepend: t.prepend,
                insertionPoint: t.insertionPoint
            }),
            nonce: t.nonce,
            inserted: s,
            registered: {},
            insert: l
        };
        return m.sheet.hydrate(a), m
    },
    tO = !0;

function nO(e, t, n) {
    var r = "";
    return n.split(" ").forEach(function(i) {
        e[i] !== void 0 ? t.push(e[i] + ";") : i && (r += i + " ")
    }), r
}
var lC = function(t, n, r) {
        var i = t.key + "-" + n.name;
        (r === !1 || tO === !1) && t.registered[i] === void 0 && (t.registered[i] = n.styles)
    },
    rO = function(t, n, r) {
        lC(t, n, r);
        var i = t.key + "-" + n.name;
        if (t.inserted[n.name] === void 0) {
            var s = n;
            do t.insert(n === s ? "." + i : "", s, t.sheet, !0), s = s.next; while (s !== void 0)
        }
    };

function iO(e) {
    for (var t = 0, n, r = 0, i = e.length; i >= 4; ++r, i -= 4) n = e.charCodeAt(r) & 255 | (e.charCodeAt(++r) & 255) << 8 | (e.charCodeAt(++r) & 255) << 16 | (e.charCodeAt(++r) & 255) << 24, n = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16), n ^= n >>> 24, t = (n & 65535) * 1540483477 + ((n >>> 16) * 59797 << 16) ^ (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16);
    switch (i) {
        case 3:
            t ^= (e.charCodeAt(r + 2) & 255) << 16;
        case 2:
            t ^= (e.charCodeAt(r + 1) & 255) << 8;
        case 1:
            t ^= e.charCodeAt(r) & 255, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16)
    }
    return t ^= t >>> 13, t = (t & 65535) * 1540483477 + ((t >>> 16) * 59797 << 16), ((t ^ t >>> 15) >>> 0).toString(36)
}
var sO = {
        animationIterationCount: 1,
        aspectRatio: 1,
        borderImageOutset: 1,
        borderImageSlice: 1,
        borderImageWidth: 1,
        boxFlex: 1,
        boxFlexGroup: 1,
        boxOrdinalGroup: 1,
        columnCount: 1,
        columns: 1,
        flex: 1,
        flexGrow: 1,
        flexPositive: 1,
        flexShrink: 1,
        flexNegative: 1,
        flexOrder: 1,
        gridRow: 1,
        gridRowEnd: 1,
        gridRowSpan: 1,
        gridRowStart: 1,
        gridColumn: 1,
        gridColumnEnd: 1,
        gridColumnSpan: 1,
        gridColumnStart: 1,
        msGridRow: 1,
        msGridRowSpan: 1,
        msGridColumn: 1,
        msGridColumnSpan: 1,
        fontWeight: 1,
        lineHeight: 1,
        opacity: 1,
        order: 1,
        orphans: 1,
        scale: 1,
        tabSize: 1,
        widows: 1,
        zIndex: 1,
        zoom: 1,
        WebkitLineClamp: 1,
        fillOpacity: 1,
        floodOpacity: 1,
        stopOpacity: 1,
        strokeDasharray: 1,
        strokeDashoffset: 1,
        strokeMiterlimit: 1,
        strokeOpacity: 1,
        strokeWidth: 1
    },
    oO = /[A-Z]|^ms/g,
    aO = /_EMO_([^_]+?)_([^]*?)_EMO_/g,
    uC = function(t) {
        return t.charCodeAt(1) === 45
    },
    av = function(t) {
        return t != null && typeof t != "boolean"
    },
    md = oC(function(e) {
        return uC(e) ? e : e.replace(oO, "-$&").toLowerCase()
    }),
    lv = function(t, n) {
        switch (t) {
            case "animation":
            case "animationName":
                if (typeof n == "string") return n.replace(aO, function(r, i, s) {
                    return Zn = {
                        name: i,
                        styles: s,
                        next: Zn
                    }, i
                })
        }
        return sO[t] !== 1 && !uC(t) && typeof n == "number" && n !== 0 ? n + "px" : n
    };

function Qa(e, t, n) {
    if (n == null) return "";
    var r = n;
    if (r.__emotion_styles !== void 0) return r;
    switch (typeof n) {
        case "boolean":
            return "";
        case "object":
            {
                var i = n;
                if (i.anim === 1) return Zn = {
                    name: i.name,
                    styles: i.styles,
                    next: Zn
                }, i.name;
                var s = n;
                if (s.styles !== void 0) {
                    var o = s.next;
                    if (o !== void 0)
                        for (; o !== void 0;) Zn = {
                            name: o.name,
                            styles: o.styles,
                            next: Zn
                        }, o = o.next;
                    var a = s.styles + ";";
                    return a
                }
                return lO(e, t, n)
            }
        case "function":
            {
                if (e !== void 0) {
                    var l = Zn,
                        u = n(e);
                    return Zn = l, Qa(e, t, u)
                }
                break
            }
    }
    var c = n;
    if (t == null) return c;
    var f = t[c];
    return f !== void 0 ? f : c
}

function lO(e, t, n) {
    var r = "";
    if (Array.isArray(n))
        for (var i = 0; i < n.length; i++) r += Qa(e, t, n[i]) + ";";
    else
        for (var s in n) {
            var o = n[s];
            if (typeof o != "object") {
                var a = o;
                t != null && t[a] !== void 0 ? r += s + "{" + t[a] + "}" : av(a) && (r += md(s) + ":" + lv(s, a) + ";")
            } else if (Array.isArray(o) && typeof o[0] == "string" && (t == null || t[o[0]] === void 0))
                for (var l = 0; l < o.length; l++) av(o[l]) && (r += md(s) + ":" + lv(s, o[l]) + ";");
            else {
                var u = Qa(e, t, o);
                switch (s) {
                    case "animation":
                    case "animationName":
                        {
                            r += md(s) + ":" + u + ";";
                            break
                        }
                    default:
                        r += s + "{" + u + "}"
                }
            }
        }
    return r
}
var uv = /label:\s*([^\s;{]+)\s*(;|$)/g,
    Zn;

function cC(e, t, n) {
    if (e.length === 1 && typeof e[0] == "object" && e[0] !== null && e[0].styles !== void 0) return e[0];
    var r = !0,
        i = "";
    Zn = void 0;
    var s = e[0];
    if (s == null || s.raw === void 0) r = !1, i += Qa(n, t, s);
    else {
        var o = s;
        i += o[0]
    }
    for (var a = 1; a < e.length; a++)
        if (i += Qa(n, t, e[a]), r) {
            var l = s;
            i += l[a]
        }
    uv.lastIndex = 0;
    for (var u = "", c;
        (c = uv.exec(i)) !== null;) u += "-" + c[1];
    var f = iO(i) + u;
    return {
        name: f,
        styles: i,
        next: Zn
    }
}
var uO = function(t) {
        return t()
    },
    cO = Dd.useInsertionEffect ? Dd.useInsertionEffect : !1,
    fO = cO || uO,
    fC = C.createContext(typeof HTMLElement < "u" ? eO({
        key: "css"
    }) : null);
fC.Provider;
var dO = function(t) {
        return C.forwardRef(function(n, r) {
            var i = C.useContext(fC);
            return t(n, i, r)
        })
    },
    hO = C.createContext({}),
    pO = /^((children|dangerouslySetInnerHTML|key|ref|autoFocus|defaultValue|defaultChecked|innerHTML|suppressContentEditableWarning|suppressHydrationWarning|valueLink|abbr|accept|acceptCharset|accessKey|action|allow|allowUserMedia|allowPaymentRequest|allowFullScreen|allowTransparency|alt|async|autoComplete|autoPlay|capture|cellPadding|cellSpacing|challenge|charSet|checked|cite|classID|className|cols|colSpan|content|contentEditable|contextMenu|controls|controlsList|coords|crossOrigin|data|dateTime|decoding|default|defer|dir|disabled|disablePictureInPicture|disableRemotePlayback|download|draggable|encType|enterKeyHint|fetchpriority|fetchPriority|form|formAction|formEncType|formMethod|formNoValidate|formTarget|frameBorder|headers|height|hidden|high|href|hrefLang|htmlFor|httpEquiv|id|inputMode|integrity|is|keyParams|keyType|kind|label|lang|list|loading|loop|low|marginHeight|marginWidth|max|maxLength|media|mediaGroup|method|min|minLength|multiple|muted|name|nonce|noValidate|open|optimum|pattern|placeholder|playsInline|poster|preload|profile|radioGroup|readOnly|referrerPolicy|rel|required|reversed|role|rows|rowSpan|sandbox|scope|scoped|scrolling|seamless|selected|shape|size|sizes|slot|span|spellCheck|src|srcDoc|srcLang|srcSet|start|step|style|summary|tabIndex|target|title|translate|type|useMap|value|width|wmode|wrap|about|datatype|inlist|prefix|property|resource|typeof|vocab|autoCapitalize|autoCorrect|autoSave|color|incremental|fallback|inert|itemProp|itemScope|itemType|itemID|itemRef|on|option|results|security|unselectable|accentHeight|accumulate|additive|alignmentBaseline|allowReorder|alphabetic|amplitude|arabicForm|ascent|attributeName|attributeType|autoReverse|azimuth|baseFrequency|baselineShift|baseProfile|bbox|begin|bias|by|calcMode|capHeight|clip|clipPathUnits|clipPath|clipRule|colorInterpolation|colorInterpolationFilters|colorProfile|colorRendering|contentScriptType|contentStyleType|cursor|cx|cy|d|decelerate|descent|diffuseConstant|direction|display|divisor|dominantBaseline|dur|dx|dy|edgeMode|elevation|enableBackground|end|exponent|externalResourcesRequired|fill|fillOpacity|fillRule|filter|filterRes|filterUnits|floodColor|floodOpacity|focusable|fontFamily|fontSize|fontSizeAdjust|fontStretch|fontStyle|fontVariant|fontWeight|format|from|fr|fx|fy|g1|g2|glyphName|glyphOrientationHorizontal|glyphOrientationVertical|glyphRef|gradientTransform|gradientUnits|hanging|horizAdvX|horizOriginX|ideographic|imageRendering|in|in2|intercept|k|k1|k2|k3|k4|kernelMatrix|kernelUnitLength|kerning|keyPoints|keySplines|keyTimes|lengthAdjust|letterSpacing|lightingColor|limitingConeAngle|local|markerEnd|markerMid|markerStart|markerHeight|markerUnits|markerWidth|mask|maskContentUnits|maskUnits|mathematical|mode|numOctaves|offset|opacity|operator|order|orient|orientation|origin|overflow|overlinePosition|overlineThickness|panose1|paintOrder|pathLength|patternContentUnits|patternTransform|patternUnits|pointerEvents|points|pointsAtX|pointsAtY|pointsAtZ|preserveAlpha|preserveAspectRatio|primitiveUnits|r|radius|refX|refY|renderingIntent|repeatCount|repeatDur|requiredExtensions|requiredFeatures|restart|result|rotate|rx|ry|scale|seed|shapeRendering|slope|spacing|specularConstant|specularExponent|speed|spreadMethod|startOffset|stdDeviation|stemh|stemv|stitchTiles|stopColor|stopOpacity|strikethroughPosition|strikethroughThickness|string|stroke|strokeDasharray|strokeDashoffset|strokeLinecap|strokeLinejoin|strokeMiterlimit|strokeOpacity|strokeWidth|surfaceScale|systemLanguage|tableValues|targetX|targetY|textAnchor|textDecoration|textRendering|textLength|to|transform|u1|u2|underlinePosition|underlineThickness|unicode|unicodeBidi|unicodeRange|unitsPerEm|vAlphabetic|vHanging|vIdeographic|vMathematical|values|vectorEffect|version|vertAdvY|vertOriginX|vertOriginY|viewBox|viewTarget|visibility|widths|wordSpacing|writingMode|x|xHeight|x1|x2|xChannelSelector|xlinkActuate|xlinkArcrole|xlinkHref|xlinkRole|xlinkShow|xlinkTitle|xlinkType|xmlBase|xmlns|xmlnsXlink|xmlLang|xmlSpace|y|y1|y2|yChannelSelector|z|zoomAndPan|for|class|autofocus)|(([Dd][Aa][Tt][Aa]|[Aa][Rr][Ii][Aa]|x)-.*))$/,
    mO = oC(function(e) {
        return pO.test(e) || e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) < 91
    }),
    gO = mO,
    yO = function(t) {
        return t !== "theme"
    },
    cv = function(t) {
        return typeof t == "string" && t.charCodeAt(0) > 96 ? gO : yO
    },
    fv = function(t, n, r) {
        var i;
        if (n) {
            var s = n.shouldForwardProp;
            i = t.__emotion_forwardProp && s ? function(o) {
                return t.__emotion_forwardProp(o) && s(o)
            } : s
        }
        return typeof i != "function" && r && (i = t.__emotion_forwardProp), i
    },
    vO = function(t) {
        var n = t.cache,
            r = t.serialized,
            i = t.isStringTag;
        return lC(n, r, i), fO(function() {
            return rO(n, r, i)
        }), null
    },
    xO = function e(t, n) {
        var r = t.__emotion_real === t,
            i = r && t.__emotion_base || t,
            s, o;
        n !== void 0 && (s = n.label, o = n.target);
        var a = fv(t, n, r),
            l = a || cv(i),
            u = !l("as");
        return function() {
            var c = arguments,
                f = r && t.__emotion_styles !== void 0 ? t.__emotion_styles.slice(0) : [];
            if (s !== void 0 && f.push("label:" + s + ";"), c[0] == null || c[0].raw === void 0) f.push.apply(f, c);
            else {
                var d = c[0];
                f.push(d[0]);
                for (var p = c.length, m = 1; m < p; m++) f.push(c[m], d[m])
            }
            var h = dO(function(_, v, y) {
                var x = u && _.as || i,
                    T = "",
                    E = [],
                    k = _;
                if (_.theme == null) {
                    k = {};
                    for (var S in _) k[S] = _[S];
                    k.theme = C.useContext(hO)
                }
                typeof _.className == "string" ? T = nO(v.registered, E, _.className) : _.className != null && (T = _.className + " ");
                var P = cC(f.concat(E), v.registered, k);
                T += v.key + "-" + P.name, o !== void 0 && (T += " " + o);
                var A = u && a === void 0 ? cv(x) : l,
                    w = {};
                for (var O in _) u && O === "as" || A(O) && (w[O] = _[O]);
                return w.className = T, y && (w.ref = y), C.createElement(C.Fragment, null, C.createElement(vO, {
                    cache: v,
                    serialized: P,
                    isStringTag: typeof x == "string"
                }), C.createElement(x, w))
            });
            return h.displayName = s !== void 0 ? s : "Styled(" + (typeof i == "string" ? i : i.displayName || i.name || "Component") + ")", h.defaultProps = t.defaultProps, h.__emotion_real = h, h.__emotion_base = i, h.__emotion_styles = f, h.__emotion_forwardProp = a, Object.defineProperty(h, "toString", {
                value: function() {
                    return "." + o
                }
            }), h.withComponent = function(_, v) {
                var y = e(_, qh({}, n, v, {
                    shouldForwardProp: fv(h, v, !0)
                }));
                return y.apply(void 0, f)
            }, h
        }
    },
    _O = ["a", "abbr", "address", "area", "article", "aside", "audio", "b", "base", "bdi", "bdo", "big", "blockquote", "body", "br", "button", "canvas", "caption", "cite", "code", "col", "colgroup", "data", "datalist", "dd", "del", "details", "dfn", "dialog", "div", "dl", "dt", "em", "embed", "fieldset", "figcaption", "figure", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "iframe", "img", "input", "ins", "kbd", "keygen", "label", "legend", "li", "link", "main", "map", "mark", "marquee", "menu", "menuitem", "meta", "meter", "nav", "noscript", "object", "ol", "optgroup", "option", "output", "p", "param", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "script", "section", "select", "small", "source", "span", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "textarea", "tfoot", "th", "thead", "time", "title", "tr", "track", "u", "ul", "var", "video", "wbr", "circle", "clipPath", "defs", "ellipse", "foreignObject", "g", "image", "line", "linearGradient", "mask", "path", "pattern", "polygon", "polyline", "radialGradient", "rect", "stop", "svg", "text", "tspan"],
    Zh = xO.bind(null);
_O.forEach(function(e) {
    Zh[e] = Zh(e)
});
/**
 * @mui/styled-engine v6.4.3
 *
 * @license MIT
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
function wO(e, t) {
    return Zh(e, t)
}

function SO(e, t) {
    Array.isArray(e.__emotion_styles) && (e.__emotion_styles = t(e.__emotion_styles))
}
const dv = [];

function hv(e) {
    return dv[0] = e, cC(dv)
}
const CO = e => {
    const t = Object.keys(e).map(n => ({
        key: n,
        val: e[n]
    })) || [];
    return t.sort((n, r) => n.val - r.val), t.reduce((n, r) => ({ ...n,
        [r.key]: r.val
    }), {})
};

function TO(e) {
    const {
        values: t = {
            xs: 0,
            sm: 600,
            md: 900,
            lg: 1200,
            xl: 1536
        },
        unit: n = "px",
        step: r = 5,
        ...i
    } = e, s = CO(t), o = Object.keys(s);

    function a(d) {
        return `@media (min-width:${typeof t[d]=="number"?t[d]:d}${n})`
    }

    function l(d) {
        return `@media (max-width:${(typeof t[d]=="number"?t[d]:d)-r/100}${n})`
    }

    function u(d, p) {
        const m = o.indexOf(p);
        return `@media (min-width:${typeof t[d]=="number"?t[d]:d}${n}) and (max-width:${(m!==-1&&typeof t[o[m]]=="number"?t[o[m]]:p)-r/100}${n})`
    }

    function c(d) {
        return o.indexOf(d) + 1 < o.length ? u(d, o[o.indexOf(d) + 1]) : a(d)
    }

    function f(d) {
        const p = o.indexOf(d);
        return p === 0 ? a(o[1]) : p === o.length - 1 ? l(o[p]) : u(d, o[o.indexOf(d) + 1]).replace("@media", "@media not all and")
    }
    return {
        keys: o,
        values: s,
        up: a,
        down: l,
        between: u,
        only: c,
        not: f,
        unit: n,
        ...i
    }
}
const EO = {
    borderRadius: 4
};

function dC(e = 8, t = Ym({
    spacing: e
})) {
    if (e.mui) return e;
    const n = (...r) => (r.length === 0 ? [1] : r).map(s => {
        const o = t(s);
        return typeof o == "number" ? `${o}px` : o
    }).join(" ");
    return n.mui = !0, n
}

function PO(e, t) {
    var r;
    const n = this;
    if (n.vars) {
        if (!((r = n.colorSchemes) != null && r[e]) || typeof n.getColorSchemeSelector != "function") return {};
        let i = n.getColorSchemeSelector(e);
        return i === "&" ? t : ((i.includes("data-") || i.includes(".")) && (i = `*:where(${i.replace(/\s*&$/,"")}) &`), {
            [i]: t
        })
    }
    return n.palette.mode === e ? t : {}
}

function hC(e = {}, ...t) {
    const {
        breakpoints: n = {},
        palette: r = {},
        spacing: i,
        shape: s = {},
        ...o
    } = e, a = TO(n), l = dC(i);
    let u = dn({
        breakpoints: a,
        direction: "ltr",
        components: {},
        palette: {
            mode: "light",
            ...r
        },
        spacing: l,
        shape: { ...EO,
            ...s
        }
    }, o);
    return u = FD(u), u.applyStyles = PO, u = t.reduce((c, f) => dn(c, f), u), u.unstable_sxConfig = { ...pf,
        ...o == null ? void 0 : o.unstable_sxConfig
    }, u.unstable_sx = function(f) {
        return po({
            sx: f,
            theme: this
        })
    }, u
}
const pv = e => e,
    kO = () => {
        let e = pv;
        return {
            configure(t) {
                e = t
            },
            generate(t) {
                return e(t)
            },
            reset() {
                e = pv
            }
        }
    },
    bO = kO(),
    RO = {
        active: "active",
        checked: "checked",
        completed: "completed",
        disabled: "disabled",
        error: "error",
        expanded: "expanded",
        focused: "focused",
        focusVisible: "focusVisible",
        open: "open",
        readOnly: "readOnly",
        required: "required",
        selected: "selected"
    };

function Zm(e, t, n = "Mui") {
    const r = RO[t];
    return r ? `${n}-${r}` : `${bO.generate(e)}-${t}`
}

function pC(e, t, n = "Mui") {
    const r = {};
    return t.forEach(i => {
        r[i] = Zm(e, i, n)
    }), r
}

function mC(e) {
    const {
        variants: t,
        ...n
    } = e, r = {
        variants: t,
        style: hv(n),
        isProcessed: !0
    };
    return r.style === n || t && t.forEach(i => {
        typeof i.style != "function" && (i.style = hv(i.style))
    }), r
}
const AO = hC();

function gd(e) {
    return e !== "ownerState" && e !== "theme" && e !== "sx" && e !== "as"
}

function DO(e) {
    return e ? (t, n) => n[e] : null
}

function jO(e, t, n) {
    e.theme = MO(e.theme) ? n : e.theme[t] || e.theme
}

function ku(e, t) {
    const n = typeof t == "function" ? t(e) : t;
    if (Array.isArray(n)) return n.flatMap(r => ku(e, r));
    if (Array.isArray(n == null ? void 0 : n.variants)) {
        let r;
        if (n.isProcessed) r = n.style;
        else {
            const {
                variants: i,
                ...s
            } = n;
            r = s
        }
        return gC(e, n.variants, [r])
    }
    return n != null && n.isProcessed ? n.style : n
}

function gC(e, t, n = []) {
    var i;
    let r;
    e: for (let s = 0; s < t.length; s += 1) {
        const o = t[s];
        if (typeof o.props == "function") {
            if (r ? ? (r = { ...e,
                    ...e.ownerState,
                    ownerState: e.ownerState
                }), !o.props(r)) continue
        } else
            for (const a in o.props)
                if (e[a] !== o.props[a] && ((i = e.ownerState) == null ? void 0 : i[a]) !== o.props[a]) continue e;
        typeof o.style == "function" ? (r ? ? (r = { ...e,
            ...e.ownerState,
            ownerState: e.ownerState
        }), n.push(o.style(r))) : n.push(o.style)
    }
    return n
}

function OO(e = {}) {
    const {
        themeId: t,
        defaultTheme: n = AO,
        rootShouldForwardProp: r = gd,
        slotShouldForwardProp: i = gd
    } = e;

    function s(a) {
        jO(a, t, n)
    }
    return (a, l = {}) => {
        SO(a, E => E.filter(k => k !== po));
        const {
            name: u,
            slot: c,
            skipVariantsResolver: f,
            skipSx: d,
            overridesResolver: p = DO(FO(c)),
            ...m
        } = l, h = f !== void 0 ? f : c && c !== "Root" && c !== "root" || !1, _ = d || !1;
        let v = gd;
        c === "Root" || c === "root" ? v = r : c ? v = i : NO(a) && (v = void 0);
        const y = wO(a, {
                shouldForwardProp: v,
                label: LO(),
                ...m
            }),
            x = E => {
                if (typeof E == "function" && E.__emotion_real !== E) return function(S) {
                    return ku(S, E)
                };
                if (vr(E)) {
                    const k = mC(E);
                    return k.variants ? function(P) {
                        return ku(P, k)
                    } : k.style
                }
                return E
            },
            T = (...E) => {
                const k = [],
                    S = E.map(x),
                    P = [];
                if (k.push(s), u && p && P.push(function(F) {
                        var re, q;
                        const W = (q = (re = F.theme.components) == null ? void 0 : re[u]) == null ? void 0 : q.styleOverrides;
                        if (!W) return null;
                        const Z = {};
                        for (const M in W) Z[M] = ku(F, W[M]);
                        return p(F, Z)
                    }), u && !h && P.push(function(F) {
                        var Z, re;
                        const V = F.theme,
                            W = (re = (Z = V == null ? void 0 : V.components) == null ? void 0 : Z[u]) == null ? void 0 : re.variants;
                        return W ? gC(F, W) : null
                    }), _ || P.push(po), Array.isArray(S[0])) {
                    const O = S.shift(),
                        F = new Array(k.length).fill(""),
                        V = new Array(P.length).fill("");
                    let W;
                    W = [...F, ...O, ...V], W.raw = [...F, ...O.raw, ...V], k.unshift(W)
                }
                const A = [...k, ...S, ...P],
                    w = y(...A);
                return a.muiName && (w.muiName = a.muiName), w
            };
        return y.withConfig && (T.withConfig = y.withConfig), T
    }
}

function LO(e, t) {
    return void 0
}

function MO(e) {
    for (const t in e) return !1;
    return !0
}

function NO(e) {
    return typeof e == "string" && e.charCodeAt(0) > 96
}

function FO(e) {
    return e && e.charAt(0).toLowerCase() + e.slice(1)
}

function ep(e, t) {
    const n = { ...t
    };
    for (const r in e)
        if (Object.prototype.hasOwnProperty.call(e, r)) {
            const i = r;
            if (i === "components" || i === "slots") n[i] = { ...e[i],
                ...n[i]
            };
            else if (i === "componentsProps" || i === "slotProps") {
                const s = e[i],
                    o = t[i];
                if (!o) n[i] = s || {};
                else if (!s) n[i] = o;
                else {
                    n[i] = { ...o
                    };
                    for (const a in s)
                        if (Object.prototype.hasOwnProperty.call(s, a)) {
                            const l = a;
                            n[i][l] = ep(s[l], o[l])
                        }
                }
            } else n[i] === void 0 && (n[i] = e[i])
        }
    return n
}

function IO(e, t = Number.MIN_SAFE_INTEGER, n = Number.MAX_SAFE_INTEGER) {
    return Math.max(t, Math.min(e, n))
}

function eg(e, t = 0, n = 1) {
    return IO(e, t, n)
}

function VO(e) {
    e = e.slice(1);
    const t = new RegExp(`.{1,${e.length>=6?2:1}}`, "g");
    let n = e.match(t);
    return n && n[0].length === 1 && (n = n.map(r => r + r)), n ? `rgb${n.length===4?"a":""}(${n.map((r,i)=>i<3?parseInt(r,16):Math.round(parseInt(r,16)/255*1e3)/1e3).join(", ")})` : ""
}

function fi(e) {
    if (e.type) return e;
    if (e.charAt(0) === "#") return fi(VO(e));
    const t = e.indexOf("("),
        n = e.substring(0, t);
    if (!["rgb", "rgba", "hsl", "hsla", "color"].includes(n)) throw new Error(rs(9, e));
    let r = e.substring(t + 1, e.length - 1),
        i;
    if (n === "color") {
        if (r = r.split(" "), i = r.shift(), r.length === 4 && r[3].charAt(0) === "/" && (r[3] = r[3].slice(1)), !["srgb", "display-p3", "a98-rgb", "prophoto-rgb", "rec-2020"].includes(i)) throw new Error(rs(10, i))
    } else r = r.split(",");
    return r = r.map(s => parseFloat(s)), {
        type: n,
        values: r,
        colorSpace: i
    }
}
const BO = e => {
        const t = fi(e);
        return t.values.slice(0, 3).map((n, r) => t.type.includes("hsl") && r !== 0 ? `${n}%` : n).join(" ")
    },
    ta = (e, t) => {
        try {
            return BO(e)
        } catch {
            return e
        }
    };

function vf(e) {
    const {
        type: t,
        colorSpace: n
    } = e;
    let {
        values: r
    } = e;
    return t.includes("rgb") ? r = r.map((i, s) => s < 3 ? parseInt(i, 10) : i) : t.includes("hsl") && (r[1] = `${r[1]}%`, r[2] = `${r[2]}%`), t.includes("color") ? r = `${n} ${r.join(" ")}` : r = `${r.join(", ")}`, `${t}(${r})`
}

function yC(e) {
    e = fi(e);
    const {
        values: t
    } = e, n = t[0], r = t[1] / 100, i = t[2] / 100, s = r * Math.min(i, 1 - i), o = (u, c = (u + n / 30) % 12) => i - s * Math.max(Math.min(c - 3, 9 - c, 1), -1);
    let a = "rgb";
    const l = [Math.round(o(0) * 255), Math.round(o(8) * 255), Math.round(o(4) * 255)];
    return e.type === "hsla" && (a += "a", l.push(t[3])), vf({
        type: a,
        values: l
    })
}

function tp(e) {
    e = fi(e);
    let t = e.type === "hsl" || e.type === "hsla" ? fi(yC(e)).values : e.values;
    return t = t.map(n => (e.type !== "color" && (n /= 255), n <= .03928 ? n / 12.92 : ((n + .055) / 1.055) ** 2.4)), Number((.2126 * t[0] + .7152 * t[1] + .0722 * t[2]).toFixed(3))
}

function zO(e, t) {
    const n = tp(e),
        r = tp(t);
    return (Math.max(n, r) + .05) / (Math.min(n, r) + .05)
}

function UO(e, t) {
    return e = fi(e), t = eg(t), (e.type === "rgb" || e.type === "hsl") && (e.type += "a"), e.type === "color" ? e.values[3] = `/${t}` : e.values[3] = t, vf(e)
}

function Zl(e, t, n) {
    try {
        return UO(e, t)
    } catch {
        return e
    }
}

function tg(e, t) {
    if (e = fi(e), t = eg(t), e.type.includes("hsl")) e.values[2] *= 1 - t;
    else if (e.type.includes("rgb") || e.type.includes("color"))
        for (let n = 0; n < 3; n += 1) e.values[n] *= 1 - t;
    return vf(e)
}

function _e(e, t, n) {
    try {
        return tg(e, t)
    } catch {
        return e
    }
}

function ng(e, t) {
    if (e = fi(e), t = eg(t), e.type.includes("hsl")) e.values[2] += (100 - e.values[2]) * t;
    else if (e.type.includes("rgb"))
        for (let n = 0; n < 3; n += 1) e.values[n] += (255 - e.values[n]) * t;
    else if (e.type.includes("color"))
        for (let n = 0; n < 3; n += 1) e.values[n] += (1 - e.values[n]) * t;
    return vf(e)
}

function we(e, t, n) {
    try {
        return ng(e, t)
    } catch {
        return e
    }
}

function $O(e, t = .15) {
    return tp(e) > .5 ? tg(e, t) : ng(e, t)
}

function eu(e, t, n) {
    try {
        return $O(e, t)
    } catch {
        return e
    }
}

function WO(e, t) {
    typeof e == "function" ? e(t) : e && (e.current = t)
}

function HO(...e) {
    return C.useMemo(() => e.every(t => t == null) ? null : t => {
        e.forEach(n => {
            WO(n, t)
        })
    }, e)
}

function KO(e) {
    return typeof e == "string"
}

function GO(e, t, n) {
    return e === void 0 || KO(e) ? t : { ...t,
        ownerState: { ...t.ownerState,
            ...n
        }
    }
}

function YO(e, t = []) {
    if (e === void 0) return {};
    const n = {};
    return Object.keys(e).filter(r => r.match(/^on[A-Z]/) && typeof e[r] == "function" && !t.includes(r)).forEach(r => {
        n[r] = e[r]
    }), n
}

function mv(e) {
    if (e === void 0) return {};
    const t = {};
    return Object.keys(e).filter(n => !(n.match(/^on[A-Z]/) && typeof e[n] == "function")).forEach(n => {
        t[n] = e[n]
    }), t
}

function XO(e) {
    const {
        getSlotProps: t,
        additionalProps: n,
        externalSlotProps: r,
        externalForwardedProps: i,
        className: s
    } = e;
    if (!t) {
        const p = mc(n == null ? void 0 : n.className, s, i == null ? void 0 : i.className, r == null ? void 0 : r.className),
            m = { ...n == null ? void 0 : n.style,
                ...i == null ? void 0 : i.style,
                ...r == null ? void 0 : r.style
            },
            h = { ...n,
                ...i,
                ...r
            };
        return p.length > 0 && (h.className = p), Object.keys(m).length > 0 && (h.style = m), {
            props: h,
            internalRef: void 0
        }
    }
    const o = YO({ ...i,
            ...r
        }),
        a = mv(r),
        l = mv(i),
        u = t(o),
        c = mc(u == null ? void 0 : u.className, n == null ? void 0 : n.className, s, i == null ? void 0 : i.className, r == null ? void 0 : r.className),
        f = { ...u == null ? void 0 : u.style,
            ...n == null ? void 0 : n.style,
            ...i == null ? void 0 : i.style,
            ...r == null ? void 0 : r.style
        },
        d = { ...u,
            ...n,
            ...l,
            ...a
        };
    return c.length > 0 && (d.className = c), Object.keys(f).length > 0 && (d.style = f), {
        props: d,
        internalRef: u.ref
    }
}

function qO(e, t, n) {
    return typeof e == "function" ? e(t, n) : e
}
const QO = C.createContext(void 0);

function JO(e) {
    const {
        theme: t,
        name: n,
        props: r
    } = e;
    if (!t || !t.components || !t.components[n]) return r;
    const i = t.components[n];
    return i.defaultProps ? ep(i.defaultProps, r) : !i.styleOverrides && !i.variants ? ep(i, r) : r
}

function ZO({
    props: e,
    name: t
}) {
    const n = C.useContext(QO);
    return JO({
        props: e,
        name: t,
        theme: {
            components: n
        }
    })
}
const gv = {
    theme: void 0
};

function eL(e) {
    let t, n;
    return function(i) {
        let s = t;
        return (s === void 0 || i.theme !== n) && (gv.theme = i.theme, s = mC(e(gv)), t = s, n = i.theme), s
    }
}

function tL(e = "") {
    function t(...r) {
        if (!r.length) return "";
        const i = r[0];
        return typeof i == "string" && !i.match(/(#|\(|\)|(-?(\d*\.)?\d+)(px|em|%|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc))|^(-?(\d*\.)?\d+)$|(\d+ \d+ \d+)/) ? `, var(--${e?`${e}-`:""}${i}${t(...r.slice(1))})` : `, ${i}`
    }
    return (r, ...i) => `var(--${e?`${e}-`:""}${r}${t(...i)})`
}
const yv = (e, t, n, r = []) => {
        let i = e;
        t.forEach((s, o) => {
            o === t.length - 1 ? Array.isArray(i) ? i[Number(s)] = n : i && typeof i == "object" && (i[s] = n) : i && typeof i == "object" && (i[s] || (i[s] = r.includes(s) ? [] : {}), i = i[s])
        })
    },
    nL = (e, t, n) => {
        function r(i, s = [], o = []) {
            Object.entries(i).forEach(([a, l]) => {
                (!n || n && !n([...s, a])) && l != null && (typeof l == "object" && Object.keys(l).length > 0 ? r(l, [...s, a], Array.isArray(l) ? [...o, a] : o) : t([...s, a], l, o))
            })
        }
        r(e)
    },
    rL = (e, t) => typeof t == "number" ? ["lineHeight", "fontWeight", "opacity", "zIndex"].some(r => e.includes(r)) || e[e.length - 1].toLowerCase().includes("opacity") ? t : `${t}px` : t;

function yd(e, t) {
    const {
        prefix: n,
        shouldSkipGeneratingVar: r
    } = t || {}, i = {}, s = {}, o = {};
    return nL(e, (a, l, u) => {
        if ((typeof l == "string" || typeof l == "number") && (!r || !r(a, l))) {
            const c = `--${n?`${n}-`:""}${a.join("-")}`,
                f = rL(a, l);
            Object.assign(i, {
                [c]: f
            }), yv(s, a, `var(${c})`, u), yv(o, a, `var(${c}, ${f})`, u)
        }
    }, a => a[0] === "vars"), {
        css: i,
        vars: s,
        varsWithDefaults: o
    }
}

function iL(e, t = {}) {
    const {
        getSelector: n = _,
        disableCssColorScheme: r,
        colorSchemeSelector: i
    } = t, {
        colorSchemes: s = {},
        components: o,
        defaultColorScheme: a = "light",
        ...l
    } = e, {
        vars: u,
        css: c,
        varsWithDefaults: f
    } = yd(l, t);
    let d = f;
    const p = {},
        {
            [a]: m,
            ...h
        } = s;
    if (Object.entries(h || {}).forEach(([x, T]) => {
            const {
                vars: E,
                css: k,
                varsWithDefaults: S
            } = yd(T, t);
            d = dn(d, S), p[x] = {
                css: k,
                vars: E
            }
        }), m) {
        const {
            css: x,
            vars: T,
            varsWithDefaults: E
        } = yd(m, t);
        d = dn(d, E), p[a] = {
            css: x,
            vars: T
        }
    }

    function _(x, T) {
        var k, S;
        let E = i;
        if (i === "class" && (E = ".%s"), i === "data" && (E = "[data-%s]"), i != null && i.startsWith("data-") && !i.includes("%s") && (E = `[${i}="%s"]`), x) {
            if (E === "media") return e.defaultColorScheme === x ? ":root" : {
                [`@media (prefers-color-scheme: ${((S=(k=s[x])==null?void 0:k.palette)==null?void 0:S.mode)||x})`]: {
                    ":root": T
                }
            };
            if (E) return e.defaultColorScheme === x ? `:root, ${E.replace("%s",String(x))}` : E.replace("%s", String(x))
        }
        return ":root"
    }
    return {
        vars: d,
        generateThemeVars: () => {
            let x = { ...u
            };
            return Object.entries(p).forEach(([, {
                vars: T
            }]) => {
                x = dn(x, T)
            }), x
        },
        generateStyleSheets: () => {
            var P, A;
            const x = [],
                T = e.defaultColorScheme || "light";

            function E(w, O) {
                Object.keys(O).length && x.push(typeof w == "string" ? {
                    [w]: { ...O
                    }
                } : w)
            }
            E(n(void 0, { ...c
            }), c);
            const {
                [T]: k, ...S
            } = p;
            if (k) {
                const {
                    css: w
                } = k, O = (A = (P = s[T]) == null ? void 0 : P.palette) == null ? void 0 : A.mode, F = !r && O ? {
                    colorScheme: O,
                    ...w
                } : { ...w
                };
                E(n(T, { ...F
                }), F)
            }
            return Object.entries(S).forEach(([w, {
                css: O
            }]) => {
                var W, Z;
                const F = (Z = (W = s[w]) == null ? void 0 : W.palette) == null ? void 0 : Z.mode,
                    V = !r && F ? {
                        colorScheme: F,
                        ...O
                    } : { ...O
                    };
                E(n(w, { ...V
                }), V)
            }), x
        }
    }
}

function sL(e) {
    return function(n) {
        return e === "media" ? `@media (prefers-color-scheme: ${n})` : e ? e.startsWith("data-") && !e.includes("%s") ? `[${e}="${n}"] &` : e === "class" ? `.${n} &` : e === "data" ? `[data-${n}] &` : `${e.replace("%s",n)} &` : "&"
    }
}
const Ja = {
        black: "#000",
        white: "#fff"
    },
    oL = {
        50: "#fafafa",
        100: "#f5f5f5",
        200: "#eeeeee",
        300: "#e0e0e0",
        400: "#bdbdbd",
        500: "#9e9e9e",
        600: "#757575",
        700: "#616161",
        800: "#424242",
        900: "#212121",
        A100: "#f5f5f5",
        A200: "#eeeeee",
        A400: "#bdbdbd",
        A700: "#616161"
    },
    gs = {
        50: "#f3e5f5",
        200: "#ce93d8",
        300: "#ba68c8",
        400: "#ab47bc",
        500: "#9c27b0",
        700: "#7b1fa2"
    },
    ys = {
        300: "#e57373",
        400: "#ef5350",
        500: "#f44336",
        700: "#d32f2f",
        800: "#c62828"
    },
    Ho = {
        300: "#ffb74d",
        400: "#ffa726",
        500: "#ff9800",
        700: "#f57c00",
        900: "#e65100"
    },
    vs = {
        50: "#e3f2fd",
        200: "#90caf9",
        400: "#42a5f5",
        700: "#1976d2",
        800: "#1565c0"
    },
    xs = {
        300: "#4fc3f7",
        400: "#29b6f6",
        500: "#03a9f4",
        700: "#0288d1",
        900: "#01579b"
    },
    _s = {
        300: "#81c784",
        400: "#66bb6a",
        500: "#4caf50",
        700: "#388e3c",
        800: "#2e7d32",
        900: "#1b5e20"
    };

function vC() {
    return {
        text: {
            primary: "rgba(0, 0, 0, 0.87)",
            secondary: "rgba(0, 0, 0, 0.6)",
            disabled: "rgba(0, 0, 0, 0.38)"
        },
        divider: "rgba(0, 0, 0, 0.12)",
        background: {
            paper: Ja.white,
            default: Ja.white
        },
        action: {
            active: "rgba(0, 0, 0, 0.54)",
            hover: "rgba(0, 0, 0, 0.04)",
            hoverOpacity: .04,
            selected: "rgba(0, 0, 0, 0.08)",
            selectedOpacity: .08,
            disabled: "rgba(0, 0, 0, 0.26)",
            disabledBackground: "rgba(0, 0, 0, 0.12)",
            disabledOpacity: .38,
            focus: "rgba(0, 0, 0, 0.12)",
            focusOpacity: .12,
            activatedOpacity: .12
        }
    }
}
const aL = vC();

function xC() {
    return {
        text: {
            primary: Ja.white,
            secondary: "rgba(255, 255, 255, 0.7)",
            disabled: "rgba(255, 255, 255, 0.5)",
            icon: "rgba(255, 255, 255, 0.5)"
        },
        divider: "rgba(255, 255, 255, 0.12)",
        background: {
            paper: "#121212",
            default: "#121212"
        },
        action: {
            active: Ja.white,
            hover: "rgba(255, 255, 255, 0.08)",
            hoverOpacity: .08,
            selected: "rgba(255, 255, 255, 0.16)",
            selectedOpacity: .16,
            disabled: "rgba(255, 255, 255, 0.3)",
            disabledBackground: "rgba(255, 255, 255, 0.12)",
            disabledOpacity: .38,
            focus: "rgba(255, 255, 255, 0.12)",
            focusOpacity: .12,
            activatedOpacity: .24
        }
    }
}
const vv = xC();

function xv(e, t, n, r) {
    const i = r.light || r,
        s = r.dark || r * 1.5;
    e[t] || (e.hasOwnProperty(n) ? e[t] = e[n] : t === "light" ? e.light = ng(e.main, i) : t === "dark" && (e.dark = tg(e.main, s)))
}

function lL(e = "light") {
    return e === "dark" ? {
        main: vs[200],
        light: vs[50],
        dark: vs[400]
    } : {
        main: vs[700],
        light: vs[400],
        dark: vs[800]
    }
}

function uL(e = "light") {
    return e === "dark" ? {
        main: gs[200],
        light: gs[50],
        dark: gs[400]
    } : {
        main: gs[500],
        light: gs[300],
        dark: gs[700]
    }
}

function cL(e = "light") {
    return e === "dark" ? {
        main: ys[500],
        light: ys[300],
        dark: ys[700]
    } : {
        main: ys[700],
        light: ys[400],
        dark: ys[800]
    }
}

function fL(e = "light") {
    return e === "dark" ? {
        main: xs[400],
        light: xs[300],
        dark: xs[700]
    } : {
        main: xs[700],
        light: xs[500],
        dark: xs[900]
    }
}

function dL(e = "light") {
    return e === "dark" ? {
        main: _s[400],
        light: _s[300],
        dark: _s[700]
    } : {
        main: _s[800],
        light: _s[500],
        dark: _s[900]
    }
}

function hL(e = "light") {
    return e === "dark" ? {
        main: Ho[400],
        light: Ho[300],
        dark: Ho[700]
    } : {
        main: "#ed6c02",
        light: Ho[500],
        dark: Ho[900]
    }
}

function rg(e) {
    const {
        mode: t = "light",
        contrastThreshold: n = 3,
        tonalOffset: r = .2,
        ...i
    } = e, s = e.primary || lL(t), o = e.secondary || uL(t), a = e.error || cL(t), l = e.info || fL(t), u = e.success || dL(t), c = e.warning || hL(t);

    function f(h) {
        return zO(h, vv.text.primary) >= n ? vv.text.primary : aL.text.primary
    }
    const d = ({
        color: h,
        name: _,
        mainShade: v = 500,
        lightShade: y = 300,
        darkShade: x = 700
    }) => {
        if (h = { ...h
            }, !h.main && h[v] && (h.main = h[v]), !h.hasOwnProperty("main")) throw new Error(rs(11, _ ? ` (${_})` : "", v));
        if (typeof h.main != "string") throw new Error(rs(12, _ ? ` (${_})` : "", JSON.stringify(h.main)));
        return xv(h, "light", y, r), xv(h, "dark", x, r), h.contrastText || (h.contrastText = f(h.main)), h
    };
    let p;
    return t === "light" ? p = vC() : t === "dark" && (p = xC()), dn({
        common: { ...Ja
        },
        mode: t,
        primary: d({
            color: s,
            name: "primary"
        }),
        secondary: d({
            color: o,
            name: "secondary",
            mainShade: "A400",
            lightShade: "A200",
            darkShade: "A700"
        }),
        error: d({
            color: a,
            name: "error"
        }),
        warning: d({
            color: c,
            name: "warning"
        }),
        info: d({
            color: l,
            name: "info"
        }),
        success: d({
            color: u,
            name: "success"
        }),
        grey: oL,
        contrastThreshold: n,
        getContrastText: f,
        augmentColor: d,
        tonalOffset: r,
        ...p
    }, i)
}

function pL(e) {
    const t = {};
    return Object.entries(e).forEach(r => {
        const [i, s] = r;
        typeof s == "object" && (t[i] = `${s.fontStyle?`${s.fontStyle} `:""}${s.fontVariant?`${s.fontVariant} `:""}${s.fontWeight?`${s.fontWeight} `:""}${s.fontStretch?`${s.fontStretch} `:""}${s.fontSize||""}${s.lineHeight?`/${s.lineHeight} `:""}${s.fontFamily||""}`)
    }), t
}

function mL(e, t) {
    return {
        toolbar: {
            minHeight: 56,
            [e.up("xs")]: {
                "@media (orientation: landscape)": {
                    minHeight: 48
                }
            },
            [e.up("sm")]: {
                minHeight: 64
            }
        },
        ...t
    }
}

function gL(e) {
    return Math.round(e * 1e5) / 1e5
}
const _v = {
        textTransform: "uppercase"
    },
    wv = '"Roboto", "Helvetica", "Arial", sans-serif';

function yL(e, t) {
    const {
        fontFamily: n = wv,
        fontSize: r = 14,
        fontWeightLight: i = 300,
        fontWeightRegular: s = 400,
        fontWeightMedium: o = 500,
        fontWeightBold: a = 700,
        htmlFontSize: l = 16,
        allVariants: u,
        pxToRem: c,
        ...f
    } = typeof t == "function" ? t(e) : t, d = r / 14, p = c || (_ => `${_/l*d}rem`), m = (_, v, y, x, T) => ({
        fontFamily: n,
        fontWeight: _,
        fontSize: p(v),
        lineHeight: y,
        ...n === wv ? {
            letterSpacing: `${gL(x/v)}em`
        } : {},
        ...T,
        ...u
    }), h = {
        h1: m(i, 96, 1.167, -1.5),
        h2: m(i, 60, 1.2, -.5),
        h3: m(s, 48, 1.167, 0),
        h4: m(s, 34, 1.235, .25),
        h5: m(s, 24, 1.334, 0),
        h6: m(o, 20, 1.6, .15),
        subtitle1: m(s, 16, 1.75, .15),
        subtitle2: m(o, 14, 1.57, .1),
        body1: m(s, 16, 1.5, .15),
        body2: m(s, 14, 1.43, .15),
        button: m(o, 14, 1.75, .4, _v),
        caption: m(s, 12, 1.66, .4),
        overline: m(s, 12, 2.66, 1, _v),
        inherit: {
            fontFamily: "inherit",
            fontWeight: "inherit",
            fontSize: "inherit",
            lineHeight: "inherit",
            letterSpacing: "inherit"
        }
    };
    return dn({
        htmlFontSize: l,
        pxToRem: p,
        fontFamily: n,
        fontSize: r,
        fontWeightLight: i,
        fontWeightRegular: s,
        fontWeightMedium: o,
        fontWeightBold: a,
        ...h
    }, f, {
        clone: !1
    })
}
const vL = .2,
    xL = .14,
    _L = .12;

function De(...e) {
    return [`${e[0]}px ${e[1]}px ${e[2]}px ${e[3]}px rgba(0,0,0,${vL})`, `${e[4]}px ${e[5]}px ${e[6]}px ${e[7]}px rgba(0,0,0,${xL})`, `${e[8]}px ${e[9]}px ${e[10]}px ${e[11]}px rgba(0,0,0,${_L})`].join(",")
}
const wL = ["none", De(0, 2, 1, -1, 0, 1, 1, 0, 0, 1, 3, 0), De(0, 3, 1, -2, 0, 2, 2, 0, 0, 1, 5, 0), De(0, 3, 3, -2, 0, 3, 4, 0, 0, 1, 8, 0), De(0, 2, 4, -1, 0, 4, 5, 0, 0, 1, 10, 0), De(0, 3, 5, -1, 0, 5, 8, 0, 0, 1, 14, 0), De(0, 3, 5, -1, 0, 6, 10, 0, 0, 1, 18, 0), De(0, 4, 5, -2, 0, 7, 10, 1, 0, 2, 16, 1), De(0, 5, 5, -3, 0, 8, 10, 1, 0, 3, 14, 2), De(0, 5, 6, -3, 0, 9, 12, 1, 0, 3, 16, 2), De(0, 6, 6, -3, 0, 10, 14, 1, 0, 4, 18, 3), De(0, 6, 7, -4, 0, 11, 15, 1, 0, 4, 20, 3), De(0, 7, 8, -4, 0, 12, 17, 2, 0, 5, 22, 4), De(0, 7, 8, -4, 0, 13, 19, 2, 0, 5, 24, 4), De(0, 7, 9, -4, 0, 14, 21, 2, 0, 5, 26, 4), De(0, 8, 9, -5, 0, 15, 22, 2, 0, 6, 28, 5), De(0, 8, 10, -5, 0, 16, 24, 2, 0, 6, 30, 5), De(0, 8, 11, -5, 0, 17, 26, 2, 0, 6, 32, 5), De(0, 9, 11, -5, 0, 18, 28, 2, 0, 7, 34, 6), De(0, 9, 12, -6, 0, 19, 29, 2, 0, 7, 36, 6), De(0, 10, 13, -6, 0, 20, 31, 3, 0, 8, 38, 7), De(0, 10, 13, -6, 0, 21, 33, 3, 0, 8, 40, 7), De(0, 10, 14, -6, 0, 22, 35, 3, 0, 8, 42, 7), De(0, 11, 14, -7, 0, 23, 36, 3, 0, 9, 44, 8), De(0, 11, 15, -7, 0, 24, 38, 3, 0, 9, 46, 8)],
    SL = {
        easeInOut: "cubic-bezier(0.4, 0, 0.2, 1)",
        easeOut: "cubic-bezier(0.0, 0, 0.2, 1)",
        easeIn: "cubic-bezier(0.4, 0, 1, 1)",
        sharp: "cubic-bezier(0.4, 0, 0.6, 1)"
    },
    CL = {
        shortest: 150,
        shorter: 200,
        short: 250,
        standard: 300,
        complex: 375,
        enteringScreen: 225,
        leavingScreen: 195
    };

function Sv(e) {
    return `${Math.round(e)}ms`
}

function TL(e) {
    if (!e) return 0;
    const t = e / 36;
    return Math.min(Math.round((4 + 15 * t ** .25 + t / 5) * 10), 3e3)
}

function EL(e) {
    const t = { ...SL,
            ...e.easing
        },
        n = { ...CL,
            ...e.duration
        };
    return {
        getAutoHeightDuration: TL,
        create: (i = ["all"], s = {}) => {
            const {
                duration: o = n.standard,
                easing: a = t.easeInOut,
                delay: l = 0,
                ...u
            } = s;
            return (Array.isArray(i) ? i : [i]).map(c => `${c} ${typeof o=="string"?o:Sv(o)} ${a} ${typeof l=="string"?l:Sv(l)}`).join(",")
        },
        ...e,
        easing: t,
        duration: n
    }
}
const PL = {
    mobileStepper: 1e3,
    fab: 1050,
    speedDial: 1050,
    appBar: 1100,
    drawer: 1200,
    modal: 1300,
    snackbar: 1400,
    tooltip: 1500
};

function kL(e) {
    return vr(e) || typeof e > "u" || typeof e == "string" || typeof e == "boolean" || typeof e == "number" || Array.isArray(e)
}

function _C(e = {}) {
    const t = { ...e
    };

    function n(r) {
        const i = Object.entries(r);
        for (let s = 0; s < i.length; s++) {
            const [o, a] = i[s];
            !kL(a) || o.startsWith("unstable_") ? delete r[o] : vr(a) && (r[o] = { ...a
            }, n(r[o]))
        }
    }
    return n(t), `import { unstable_createBreakpoints as createBreakpoints, createTransitions } from '@mui/material/styles';

const theme = ${JSON.stringify(t,null,2)};

theme.breakpoints = createBreakpoints(theme.breakpoints || {});
theme.transitions = createTransitions(theme.transitions || {});

export default theme;`
}

function np(e = {}, ...t) {
    const {
        breakpoints: n,
        mixins: r = {},
        spacing: i,
        palette: s = {},
        transitions: o = {},
        typography: a = {},
        shape: l,
        ...u
    } = e;
    if (e.vars) throw new Error(rs(20));
    const c = rg(s),
        f = hC(e);
    let d = dn(f, {
        mixins: mL(f.breakpoints, r),
        palette: c,
        shadows: wL.slice(),
        typography: yL(c, a),
        transitions: EL(o),
        zIndex: { ...PL
        }
    });
    return d = dn(d, u), d = t.reduce((p, m) => dn(p, m), d), d.unstable_sxConfig = { ...pf,
        ...u == null ? void 0 : u.unstable_sxConfig
    }, d.unstable_sx = function(m) {
        return po({
            sx: m,
            theme: this
        })
    }, d.toRuntimeSource = _C, d
}

function bL(e) {
    let t;
    return e < 1 ? t = 5.11916 * e ** 2 : t = 4.5 * Math.log(e + 1) + 2, Math.round(t * 10) / 1e3
}
const RL = [...Array(25)].map((e, t) => {
    if (t === 0) return "none";
    const n = bL(t);
    return `linear-gradient(rgba(255 255 255 / ${n}), rgba(255 255 255 / ${n}))`
});

function wC(e) {
    return {
        inputPlaceholder: e === "dark" ? .5 : .42,
        inputUnderline: e === "dark" ? .7 : .42,
        switchTrackDisabled: e === "dark" ? .2 : .12,
        switchTrack: e === "dark" ? .3 : .38
    }
}

function SC(e) {
    return e === "dark" ? RL : []
}

function AL(e) {
    const {
        palette: t = {
            mode: "light"
        },
        opacity: n,
        overlays: r,
        ...i
    } = e, s = rg(t);
    return {
        palette: s,
        opacity: { ...wC(s.mode),
            ...n
        },
        overlays: r || SC(s.mode),
        ...i
    }
}

function DL(e) {
    var t;
    return !!e[0].match(/(cssVarPrefix|colorSchemeSelector|rootSelector|typography|mixins|breakpoints|direction|transitions)/) || !!e[0].match(/sxConfig$/) || e[0] === "palette" && !!((t = e[1]) != null && t.match(/(mode|contrastThreshold|tonalOffset)/))
}
const jL = e => [...[...Array(25)].map((t, n) => `--${e?`${e}-`:""}overlays-${n}`), `--${e?`${e}-`:""}palette-AppBar-darkBg`, `--${e?`${e}-`:""}palette-AppBar-darkColor`],
    OL = e => (t, n) => {
        const r = e.rootSelector || ":root",
            i = e.colorSchemeSelector;
        let s = i;
        if (i === "class" && (s = ".%s"), i === "data" && (s = "[data-%s]"), i != null && i.startsWith("data-") && !i.includes("%s") && (s = `[${i}="%s"]`), e.defaultColorScheme === t) {
            if (t === "dark") {
                const o = {};
                return jL(e.cssVarPrefix).forEach(a => {
                    o[a] = n[a], delete n[a]
                }), s === "media" ? {
                    [r]: n,
                    "@media (prefers-color-scheme: dark)": {
                        [r]: o
                    }
                } : s ? {
                    [s.replace("%s", t)]: o,
                    [`${r}, ${s.replace("%s",t)}`]: n
                } : {
                    [r]: { ...n,
                        ...o
                    }
                }
            }
            if (s && s !== "media") return `${r}, ${s.replace("%s",String(t))}`
        } else if (t) {
            if (s === "media") return {
                [`@media (prefers-color-scheme: ${String(t)})`]: {
                    [r]: n
                }
            };
            if (s) return s.replace("%s", String(t))
        }
        return r
    };

function LL(e, t) {
    t.forEach(n => {
        e[n] || (e[n] = {})
    })
}

function L(e, t, n) {
    !e[t] && n && (e[t] = n)
}

function na(e) {
    return typeof e != "string" || !e.startsWith("hsl") ? e : yC(e)
}

function hr(e, t) {
    `${t}Channel` in e || (e[`${t}Channel`] = ta(na(e[t])))
}

function ML(e) {
    return typeof e == "number" ? `${e}px` : typeof e == "string" || typeof e == "function" || Array.isArray(e) ? e : "8px"
}
const Xn = e => {
        try {
            return e()
        } catch {}
    },
    NL = (e = "mui") => tL(e);

function vd(e, t, n, r) {
    if (!t) return;
    t = t === !0 ? {} : t;
    const i = r === "dark" ? "dark" : "light";
    if (!n) {
        e[r] = AL({ ...t,
            palette: {
                mode: i,
                ...t == null ? void 0 : t.palette
            }
        });
        return
    }
    const {
        palette: s,
        ...o
    } = np({ ...n,
        palette: {
            mode: i,
            ...t == null ? void 0 : t.palette
        }
    });
    return e[r] = { ...t,
        palette: s,
        opacity: { ...wC(i),
            ...t == null ? void 0 : t.opacity
        },
        overlays: (t == null ? void 0 : t.overlays) || SC(i)
    }, o
}

function FL(e = {}, ...t) {
    const {
        colorSchemes: n = {
            light: !0
        },
        defaultColorScheme: r,
        disableCssColorScheme: i = !1,
        cssVarPrefix: s = "mui",
        shouldSkipGeneratingVar: o = DL,
        colorSchemeSelector: a = n.light && n.dark ? "media" : void 0,
        rootSelector: l = ":root",
        ...u
    } = e, c = Object.keys(n)[0], f = r || (n.light && c !== "light" ? "light" : c), d = NL(s), {
        [f]: p,
        light: m,
        dark: h,
        ..._
    } = n, v = { ..._
    };
    let y = p;
    if ((f === "dark" && !("dark" in n) || f === "light" && !("light" in n)) && (y = !0), !y) throw new Error(rs(21, f));
    const x = vd(v, y, u, f);
    m && !v.light && vd(v, m, void 0, "light"), h && !v.dark && vd(v, h, void 0, "dark");
    let T = {
        defaultColorScheme: f,
        ...x,
        cssVarPrefix: s,
        colorSchemeSelector: a,
        rootSelector: l,
        getCssVar: d,
        colorSchemes: v,
        font: { ...pL(x.typography),
            ...x.font
        },
        spacing: ML(u.spacing)
    };
    Object.keys(T.colorSchemes).forEach(A => {
        const w = T.colorSchemes[A].palette,
            O = F => {
                const V = F.split("-"),
                    W = V[1],
                    Z = V[2];
                return d(F, w[W][Z])
            };
        if (w.mode === "light" && (L(w.common, "background", "#fff"), L(w.common, "onBackground", "#000")), w.mode === "dark" && (L(w.common, "background", "#000"), L(w.common, "onBackground", "#fff")), LL(w, ["Alert", "AppBar", "Avatar", "Button", "Chip", "FilledInput", "LinearProgress", "Skeleton", "Slider", "SnackbarContent", "SpeedDialAction", "StepConnector", "StepContent", "Switch", "TableCell", "Tooltip"]), w.mode === "light") {
            L(w.Alert, "errorColor", _e(w.error.light, .6)), L(w.Alert, "infoColor", _e(w.info.light, .6)), L(w.Alert, "successColor", _e(w.success.light, .6)), L(w.Alert, "warningColor", _e(w.warning.light, .6)), L(w.Alert, "errorFilledBg", O("palette-error-main")), L(w.Alert, "infoFilledBg", O("palette-info-main")), L(w.Alert, "successFilledBg", O("palette-success-main")), L(w.Alert, "warningFilledBg", O("palette-warning-main")), L(w.Alert, "errorFilledColor", Xn(() => w.getContrastText(w.error.main))), L(w.Alert, "infoFilledColor", Xn(() => w.getContrastText(w.info.main))), L(w.Alert, "successFilledColor", Xn(() => w.getContrastText(w.success.main))), L(w.Alert, "warningFilledColor", Xn(() => w.getContrastText(w.warning.main))), L(w.Alert, "errorStandardBg", we(w.error.light, .9)), L(w.Alert, "infoStandardBg", we(w.info.light, .9)), L(w.Alert, "successStandardBg", we(w.success.light, .9)), L(w.Alert, "warningStandardBg", we(w.warning.light, .9)), L(w.Alert, "errorIconColor", O("palette-error-main")), L(w.Alert, "infoIconColor", O("palette-info-main")), L(w.Alert, "successIconColor", O("palette-success-main")), L(w.Alert, "warningIconColor", O("palette-warning-main")), L(w.AppBar, "defaultBg", O("palette-grey-100")), L(w.Avatar, "defaultBg", O("palette-grey-400")), L(w.Button, "inheritContainedBg", O("palette-grey-300")), L(w.Button, "inheritContainedHoverBg", O("palette-grey-A100")), L(w.Chip, "defaultBorder", O("palette-grey-400")), L(w.Chip, "defaultAvatarColor", O("palette-grey-700")), L(w.Chip, "defaultIconColor", O("palette-grey-700")), L(w.FilledInput, "bg", "rgba(0, 0, 0, 0.06)"), L(w.FilledInput, "hoverBg", "rgba(0, 0, 0, 0.09)"), L(w.FilledInput, "disabledBg", "rgba(0, 0, 0, 0.12)"), L(w.LinearProgress, "primaryBg", we(w.primary.main, .62)), L(w.LinearProgress, "secondaryBg", we(w.secondary.main, .62)), L(w.LinearProgress, "errorBg", we(w.error.main, .62)), L(w.LinearProgress, "infoBg", we(w.info.main, .62)), L(w.LinearProgress, "successBg", we(w.success.main, .62)), L(w.LinearProgress, "warningBg", we(w.warning.main, .62)), L(w.Skeleton, "bg", `rgba(${O("palette-text-primaryChannel")} / 0.11)`), L(w.Slider, "primaryTrack", we(w.primary.main, .62)), L(w.Slider, "secondaryTrack", we(w.secondary.main, .62)), L(w.Slider, "errorTrack", we(w.error.main, .62)), L(w.Slider, "infoTrack", we(w.info.main, .62)), L(w.Slider, "successTrack", we(w.success.main, .62)), L(w.Slider, "warningTrack", we(w.warning.main, .62));
            const F = eu(w.background.default, .8);
            L(w.SnackbarContent, "bg", F), L(w.SnackbarContent, "color", Xn(() => w.getContrastText(F))), L(w.SpeedDialAction, "fabHoverBg", eu(w.background.paper, .15)), L(w.StepConnector, "border", O("palette-grey-400")), L(w.StepContent, "border", O("palette-grey-400")), L(w.Switch, "defaultColor", O("palette-common-white")), L(w.Switch, "defaultDisabledColor", O("palette-grey-100")), L(w.Switch, "primaryDisabledColor", we(w.primary.main, .62)), L(w.Switch, "secondaryDisabledColor", we(w.secondary.main, .62)), L(w.Switch, "errorDisabledColor", we(w.error.main, .62)), L(w.Switch, "infoDisabledColor", we(w.info.main, .62)), L(w.Switch, "successDisabledColor", we(w.success.main, .62)), L(w.Switch, "warningDisabledColor", we(w.warning.main, .62)), L(w.TableCell, "border", we(Zl(w.divider, 1), .88)), L(w.Tooltip, "bg", Zl(w.grey[700], .92))
        }
        if (w.mode === "dark") {
            L(w.Alert, "errorColor", we(w.error.light, .6)), L(w.Alert, "infoColor", we(w.info.light, .6)), L(w.Alert, "successColor", we(w.success.light, .6)), L(w.Alert, "warningColor", we(w.warning.light, .6)), L(w.Alert, "errorFilledBg", O("palette-error-dark")), L(w.Alert, "infoFilledBg", O("palette-info-dark")), L(w.Alert, "successFilledBg", O("palette-success-dark")), L(w.Alert, "warningFilledBg", O("palette-warning-dark")), L(w.Alert, "errorFilledColor", Xn(() => w.getContrastText(w.error.dark))), L(w.Alert, "infoFilledColor", Xn(() => w.getContrastText(w.info.dark))), L(w.Alert, "successFilledColor", Xn(() => w.getContrastText(w.success.dark))), L(w.Alert, "warningFilledColor", Xn(() => w.getContrastText(w.warning.dark))), L(w.Alert, "errorStandardBg", _e(w.error.light, .9)), L(w.Alert, "infoStandardBg", _e(w.info.light, .9)), L(w.Alert, "successStandardBg", _e(w.success.light, .9)), L(w.Alert, "warningStandardBg", _e(w.warning.light, .9)), L(w.Alert, "errorIconColor", O("palette-error-main")), L(w.Alert, "infoIconColor", O("palette-info-main")), L(w.Alert, "successIconColor", O("palette-success-main")), L(w.Alert, "warningIconColor", O("palette-warning-main")), L(w.AppBar, "defaultBg", O("palette-grey-900")), L(w.AppBar, "darkBg", O("palette-background-paper")), L(w.AppBar, "darkColor", O("palette-text-primary")), L(w.Avatar, "defaultBg", O("palette-grey-600")), L(w.Button, "inheritContainedBg", O("palette-grey-800")), L(w.Button, "inheritContainedHoverBg", O("palette-grey-700")), L(w.Chip, "defaultBorder", O("palette-grey-700")), L(w.Chip, "defaultAvatarColor", O("palette-grey-300")), L(w.Chip, "defaultIconColor", O("palette-grey-300")), L(w.FilledInput, "bg", "rgba(255, 255, 255, 0.09)"), L(w.FilledInput, "hoverBg", "rgba(255, 255, 255, 0.13)"), L(w.FilledInput, "disabledBg", "rgba(255, 255, 255, 0.12)"), L(w.LinearProgress, "primaryBg", _e(w.primary.main, .5)), L(w.LinearProgress, "secondaryBg", _e(w.secondary.main, .5)), L(w.LinearProgress, "errorBg", _e(w.error.main, .5)), L(w.LinearProgress, "infoBg", _e(w.info.main, .5)), L(w.LinearProgress, "successBg", _e(w.success.main, .5)), L(w.LinearProgress, "warningBg", _e(w.warning.main, .5)), L(w.Skeleton, "bg", `rgba(${O("palette-text-primaryChannel")} / 0.13)`), L(w.Slider, "primaryTrack", _e(w.primary.main, .5)), L(w.Slider, "secondaryTrack", _e(w.secondary.main, .5)), L(w.Slider, "errorTrack", _e(w.error.main, .5)), L(w.Slider, "infoTrack", _e(w.info.main, .5)), L(w.Slider, "successTrack", _e(w.success.main, .5)), L(w.Slider, "warningTrack", _e(w.warning.main, .5));
            const F = eu(w.background.default, .98);
            L(w.SnackbarContent, "bg", F), L(w.SnackbarContent, "color", Xn(() => w.getContrastText(F))), L(w.SpeedDialAction, "fabHoverBg", eu(w.background.paper, .15)), L(w.StepConnector, "border", O("palette-grey-600")), L(w.StepContent, "border", O("palette-grey-600")), L(w.Switch, "defaultColor", O("palette-grey-300")), L(w.Switch, "defaultDisabledColor", O("palette-grey-600")), L(w.Switch, "primaryDisabledColor", _e(w.primary.main, .55)), L(w.Switch, "secondaryDisabledColor", _e(w.secondary.main, .55)), L(w.Switch, "errorDisabledColor", _e(w.error.main, .55)), L(w.Switch, "infoDisabledColor", _e(w.info.main, .55)), L(w.Switch, "successDisabledColor", _e(w.success.main, .55)), L(w.Switch, "warningDisabledColor", _e(w.warning.main, .55)), L(w.TableCell, "border", _e(Zl(w.divider, 1), .68)), L(w.Tooltip, "bg", Zl(w.grey[700], .92))
        }
        hr(w.background, "default"), hr(w.background, "paper"), hr(w.common, "background"), hr(w.common, "onBackground"), hr(w, "divider"), Object.keys(w).forEach(F => {
            const V = w[F];
            F !== "tonalOffset" && V && typeof V == "object" && (V.main && L(w[F], "mainChannel", ta(na(V.main))), V.light && L(w[F], "lightChannel", ta(na(V.light))), V.dark && L(w[F], "darkChannel", ta(na(V.dark))), V.contrastText && L(w[F], "contrastTextChannel", ta(na(V.contrastText))), F === "text" && (hr(w[F], "primary"), hr(w[F], "secondary")), F === "action" && (V.active && hr(w[F], "active"), V.selected && hr(w[F], "selected")))
        })
    }), T = t.reduce((A, w) => dn(A, w), T);
    const E = {
            prefix: s,
            disableCssColorScheme: i,
            shouldSkipGeneratingVar: o,
            getSelector: OL(T)
        },
        {
            vars: k,
            generateThemeVars: S,
            generateStyleSheets: P
        } = iL(T, E);
    return T.vars = k, Object.entries(T.colorSchemes[T.defaultColorScheme]).forEach(([A, w]) => {
        T[A] = w
    }), T.generateThemeVars = S, T.generateStyleSheets = P, T.generateSpacing = function() {
        return dC(u.spacing, Ym(this))
    }, T.getColorSchemeSelector = sL(a), T.spacing = T.generateSpacing(), T.shouldSkipGeneratingVar = o, T.unstable_sxConfig = { ...pf,
        ...u == null ? void 0 : u.unstable_sxConfig
    }, T.unstable_sx = function(w) {
        return po({
            sx: w,
            theme: this
        })
    }, T.toRuntimeSource = _C, T
}

function Cv(e, t, n) {
    e.colorSchemes && n && (e.colorSchemes[t] = { ...n !== !0 && n,
        palette: rg({ ...n === !0 ? {} : n.palette,
            mode: t
        })
    })
}

function IL(e = {}, ...t) {
    const {
        palette: n,
        cssVariables: r = !1,
        colorSchemes: i = n ? void 0 : {
            light: !0
        },
        defaultColorScheme: s = n == null ? void 0 : n.mode,
        ...o
    } = e, a = s || "light", l = i == null ? void 0 : i[a], u = { ...i,
        ...n ? {
            [a]: { ...typeof l != "boolean" && l,
                palette: n
            }
        } : void 0
    };
    if (r === !1) {
        if (!("colorSchemes" in e)) return np(e, ...t);
        let c = n;
        "palette" in e || u[a] && (u[a] !== !0 ? c = u[a].palette : a === "dark" && (c = {
            mode: "dark"
        }));
        const f = np({ ...e,
            palette: c
        }, ...t);
        return f.defaultColorScheme = a, f.colorSchemes = u, f.palette.mode === "light" && (f.colorSchemes.light = { ...u.light !== !0 && u.light,
            palette: f.palette
        }, Cv(f, "dark", u.dark)), f.palette.mode === "dark" && (f.colorSchemes.dark = { ...u.dark !== !0 && u.dark,
            palette: f.palette
        }, Cv(f, "light", u.light)), f
    }
    return !n && !("light" in u) && a === "light" && (u.light = !0), FL({ ...o,
        colorSchemes: u,
        defaultColorScheme: a,
        ...typeof r != "boolean" && r
    }, ...t)
}
const VL = IL(),
    BL = "$$material";

function zL(e) {
    return e !== "ownerState" && e !== "theme" && e !== "sx" && e !== "as"
}
const UL = e => zL(e) && e !== "classes",
    xf = OO({
        themeId: BL,
        defaultTheme: VL,
        rootShouldForwardProp: UL
    }),
    CC = eL;

function TC(e) {
    return ZO(e)
}

function $L(e) {
    return Zm("MuiSvgIcon", e)
}
pC("MuiSvgIcon", ["root", "colorPrimary", "colorSecondary", "colorAction", "colorError", "colorDisabled", "fontSizeInherit", "fontSizeSmall", "fontSizeMedium", "fontSizeLarge"]);
const WL = e => {
        const {
            color: t,
            fontSize: n,
            classes: r
        } = e, i = {
            root: ["root", t !== "inherit" && `color${ho(t)}`, `fontSize${ho(n)}`]
        };
        return XS(i, $L, r)
    },
    HL = xf("svg", {
        name: "MuiSvgIcon",
        slot: "Root",
        overridesResolver: (e, t) => {
            const {
                ownerState: n
            } = e;
            return [t.root, n.color !== "inherit" && t[`color${ho(n.color)}`], t[`fontSize${ho(n.fontSize)}`]]
        }
    })(CC(({
        theme: e
    }) => {
        var t, n, r, i, s, o, a, l, u, c, f, d, p, m;
        return {
            userSelect: "none",
            width: "1em",
            height: "1em",
            display: "inline-block",
            flexShrink: 0,
            transition: (i = (t = e.transitions) == null ? void 0 : t.create) == null ? void 0 : i.call(t, "fill", {
                duration: (r = (n = (e.vars ? ? e).transitions) == null ? void 0 : n.duration) == null ? void 0 : r.shorter
            }),
            variants: [{
                props: h => !h.hasSvgAsChild,
                style: {
                    fill: "currentColor"
                }
            }, {
                props: {
                    fontSize: "inherit"
                },
                style: {
                    fontSize: "inherit"
                }
            }, {
                props: {
                    fontSize: "small"
                },
                style: {
                    fontSize: ((o = (s = e.typography) == null ? void 0 : s.pxToRem) == null ? void 0 : o.call(s, 20)) || "1.25rem"
                }
            }, {
                props: {
                    fontSize: "medium"
                },
                style: {
                    fontSize: ((l = (a = e.typography) == null ? void 0 : a.pxToRem) == null ? void 0 : l.call(a, 24)) || "1.5rem"
                }
            }, {
                props: {
                    fontSize: "large"
                },
                style: {
                    fontSize: ((c = (u = e.typography) == null ? void 0 : u.pxToRem) == null ? void 0 : c.call(u, 35)) || "2.1875rem"
                }
            }, ...Object.entries((e.vars ? ? e).palette).filter(([, h]) => h && h.main).map(([h]) => {
                var _, v;
                return {
                    props: {
                        color: h
                    },
                    style: {
                        color: (v = (_ = (e.vars ? ? e).palette) == null ? void 0 : _[h]) == null ? void 0 : v.main
                    }
                }
            }), {
                props: {
                    color: "action"
                },
                style: {
                    color: (d = (f = (e.vars ? ? e).palette) == null ? void 0 : f.action) == null ? void 0 : d.active
                }
            }, {
                props: {
                    color: "disabled"
                },
                style: {
                    color: (m = (p = (e.vars ? ? e).palette) == null ? void 0 : p.action) == null ? void 0 : m.disabled
                }
            }, {
                props: {
                    color: "inherit"
                },
                style: {
                    color: void 0
                }
            }]
        }
    })),
    rp = C.forwardRef(function(t, n) {
        const r = TC({
                props: t,
                name: "MuiSvgIcon"
            }),
            {
                children: i,
                className: s,
                color: o = "inherit",
                component: a = "svg",
                fontSize: l = "medium",
                htmlColor: u,
                inheritViewBox: c = !1,
                titleAccess: f,
                viewBox: d = "0 0 24 24",
                ...p
            } = r,
            m = C.isValidElement(i) && i.type === "svg",
            h = { ...r,
                color: o,
                component: a,
                fontSize: l,
                instanceFontSize: t.fontSize,
                inheritViewBox: c,
                viewBox: d,
                hasSvgAsChild: m
            },
            _ = {};
        c || (_.viewBox = d);
        const v = WL(h);
        return g.jsxs(HL, {
            as: a,
            className: mc(v.root, s),
            focusable: "false",
            color: u,
            "aria-hidden": f ? void 0 : !0,
            role: f ? "img" : void 0,
            ref: n,
            ..._,
            ...p,
            ...m && i.props,
            ownerState: h,
            children: [m ? i.props.children : i, f ? g.jsx("title", {
                children: f
            }) : null]
        })
    });
rp.muiName = "SvgIcon";

function KL(e, t) {
    function n(r, i) {
        return g.jsx(rp, {
            "data-testid": `${t}Icon`,
            ref: i,
            ...r,
            children: e
        })
    }
    return n.muiName = rp.muiName, C.memo(C.forwardRef(n))
}
const GL = KL(g.jsx("path", {
    d: "M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"
}), "Person");

function YL(e) {
    return Zm("MuiAvatar", e)
}
pC("MuiAvatar", ["root", "colorDefault", "circular", "rounded", "square", "img", "fallback"]);

function XL(e, t) {
    const {
        className: n,
        elementType: r,
        ownerState: i,
        externalForwardedProps: s,
        internalForwardedProps: o,
        shouldForwardComponentProp: a = !1,
        ...l
    } = t, {
        component: u,
        slots: c = {
            [e]: void 0
        },
        slotProps: f = {
            [e]: void 0
        },
        ...d
    } = s, p = c[e] || r, m = qO(f[e], i), {
        props: {
            component: h,
            ..._
        },
        internalRef: v
    } = XO({
        className: n,
        ...l,
        externalForwardedProps: void 0,
        externalSlotProps: m
    }), y = HO(v, m == null ? void 0 : m.ref, t.ref), x = h, T = GO(p, { ...e === "root",
        ...!c[e] && o,
        ..._,
        ...x && !a && {
            as: x
        },
        ...x && a && {
            component: x
        },
        ref: y
    }, i);
    return [p, T]
}
const qL = e => {
        const {
            classes: t,
            variant: n,
            colorDefault: r
        } = e;
        return XS({
            root: ["root", n, r && "colorDefault"],
            img: ["img"],
            fallback: ["fallback"]
        }, YL, t)
    },
    QL = xf("div", {
        name: "MuiAvatar",
        slot: "Root",
        overridesResolver: (e, t) => {
            const {
                ownerState: n
            } = e;
            return [t.root, t[n.variant], n.colorDefault && t.colorDefault]
        }
    })(CC(({
        theme: e
    }) => ({
        position: "relative",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
        width: 40,
        height: 40,
        fontFamily: e.typography.fontFamily,
        fontSize: e.typography.pxToRem(20),
        lineHeight: 1,
        borderRadius: "50%",
        overflow: "hidden",
        userSelect: "none",
        variants: [{
            props: {
                variant: "rounded"
            },
            style: {
                borderRadius: (e.vars || e).shape.borderRadius
            }
        }, {
            props: {
                variant: "square"
            },
            style: {
                borderRadius: 0
            }
        }, {
            props: {
                colorDefault: !0
            },
            style: {
                color: (e.vars || e).palette.background.default,
                ...e.vars ? {
                    backgroundColor: e.vars.palette.Avatar.defaultBg
                } : {
                    backgroundColor: e.palette.grey[400],
                    ...e.applyStyles("dark", {
                        backgroundColor: e.palette.grey[600]
                    })
                }
            }
        }]
    }))),
    JL = xf("img", {
        name: "MuiAvatar",
        slot: "Img",
        overridesResolver: (e, t) => t.img
    })({
        width: "100%",
        height: "100%",
        textAlign: "center",
        objectFit: "cover",
        color: "transparent",
        textIndent: 1e4
    }),
    ZL = xf(GL, {
        name: "MuiAvatar",
        slot: "Fallback",
        overridesResolver: (e, t) => t.fallback
    })({
        width: "75%",
        height: "75%"
    });

function eM({
    crossOrigin: e,
    referrerPolicy: t,
    src: n,
    srcSet: r
}) {
    const [i, s] = C.useState(!1);
    return C.useEffect(() => {
        if (!n && !r) return;
        s(!1);
        let o = !0;
        const a = new Image;
        return a.onload = () => {
            o && s("loaded")
        }, a.onerror = () => {
            o && s("error")
        }, a.crossOrigin = e, a.referrerPolicy = t, a.src = n, r && (a.srcset = r), () => {
            o = !1
        }
    }, [e, t, n, r]), i
}
const Tv = C.forwardRef(function(t, n) {
        const r = TC({
                props: t,
                name: "MuiAvatar"
            }),
            {
                alt: i,
                children: s,
                className: o,
                component: a = "div",
                slots: l = {},
                slotProps: u = {},
                imgProps: c,
                sizes: f,
                src: d,
                srcSet: p,
                variant: m = "circular",
                ...h
            } = r;
        let _ = null;
        const v = { ...r,
                component: a,
                variant: m
            },
            y = eM({ ...c,
                ...typeof u.img == "function" ? u.img(v) : u.img,
                src: d,
                srcSet: p
            }),
            x = d || p,
            T = x && y !== "error";
        v.colorDefault = !T, delete v.ownerState;
        const E = qL(v),
            [k, S] = XL("img", {
                className: E.img,
                elementType: JL,
                externalForwardedProps: {
                    slots: l,
                    slotProps: {
                        img: { ...c,
                            ...u.img
                        }
                    }
                },
                additionalProps: {
                    alt: i,
                    src: d,
                    srcSet: p,
                    sizes: f
                },
                ownerState: v
            });
        return T ? _ = g.jsx(k, { ...S
        }) : s || s === 0 ? _ = s : x && i ? _ = i[0] : _ = g.jsx(ZL, {
            ownerState: v,
            className: E.fallback
        }), g.jsx(QL, {
            as: a,
            className: mc(E.root, o),
            ref: n,
            ...h,
            ownerState: v,
            children: _
        })
    }),
    Ev = "/assets/weblogo-BK7uZoFB.png",
    tM = e => {
        const {
            usernav: t,
            setUsernav: n
        } = C.useContext(Cm);
        let r = C.useContext(vw);
        const [i, s] = C.useState(""), o = Sm(), a = os(), [l, u] = C.useState(!1), [c, f] = C.useState(!1), [d, p] = C.useState(!1), m = C.useRef(), [h, _] = C.useState(!1), {
            loginCheck: v,
            setCheck: y
        } = C.useContext(Hw), x = C.useRef(), T = C.useRef(), [E, k] = C.useState(!1), [S, P] = C.useState(!1);
        C.useContext(Kw);
        const [A, w] = C.useState(!1), [O, F] = C.useState(!1), V = C.useRef(null), W = C.useRef(null), Z = C.useRef(null), {
            filtersection: re
        } = C.useContext(xw), {
            showAlart: q
        } = C.useContext(GS), [M, B] = C.useState(!1);
        C.useEffect(() => {
            const J = () => {
                window.innerWidth < 500 ? F(!0) : F(!1)
            };
            return J(), window.addEventListener("resize", J), () => window.removeEventListener("resize", J)
        }, []), C.useEffect(() => {
            const J = () => {
                k(!1)
            };
            return window.addEventListener("click", J), () => window.removeEventListener("click", J)
        });
        const H = J => {
                J.stopPropagation(), k(!E)
            },
            ie = sessionStorage.getItem("isLoggedIn"),
            ne = sessionStorage.getItem("isAdminLogin");
        C.useEffect(() => {
            B(!!ie), P(!!ne)
        }, []);
        const St = J => {
                s(J.target.value), _(!0)
            },
            xe = J => {
                s(J), o("Filter", {
                    state: {
                        searchdpt: J
                    }
                }), s("")
            },
            ke = async () => {
                if (confirm("Are you sure want to  log out ?")) try {
                    (await et.post("/api/logOut", {
                        withCredentials: !0
                    })).status === 200 && (u(!1), sessionStorage.removeItem("isLoggedIn"), n(""), B(!1), window.location.href = "/", q("Log out", "Back to main page", "check"))
                } catch {
                    console.error("Error in logout")
                }
            },
            ct = C.useRef(),
            Lt = C.useRef();
        pc(() => {
            const J = Oi.timeline({
                paused: !0
            });
            J.to(".slidebar", {
                left: 0,
                borderRadius: 0,
                duration: .5,
                ease: "power4.inOut"
            }, "same").from(".slidebar-title", {
                x: 200,
                duration: 1.5,
                stagger: .1,
                ease: "power2.out"
            }, "same").from(".cross-icon i", {
                y: -10,
                x: 0,
                opacity: 0,
                duration: .2
            }, "same").from(".copywrite", {
                opacity: 0,
                duration: .15
            }, "same");
            const be = Oi.timeline({
                paused: !0
            });
            be.to(".slidebar", {
                left: "-100%",
                borderRadius: "0%",
                duration: .2,
                ease: "power2.out"
            }, "sameclose"), be.to(".cross-icon i", {
                x: -100,
                opacity: 0,
                duration: .4
            }, "sameclose");
            const Ne = () => {
                J.restart(), Oi.to(".slidebar", {
                    display: "block",
                    duration: .01,
                    ease: "power2.out"
                }), document.body.style.overflow = "hidden"
            };
            ct.current.addEventListener("click", Ne), Lt.current.addEventListener("click", () => {
                be.restart(), document.body.style.overflow = "scroll"
            });
            const Ln = () => {
                    window.scrollTo({
                        top: 0,
                        behavior: "smooth"
                    })
                },
                Tl = document.querySelectorAll(".slidebar-title a ,.slidebar-foot-item a");
            return Tl.forEach(El => {
                El.addEventListener("click", () => {
                    be.restart(), Ln()
                })
            }), () => {
                window.removeEventListener("scroll", Tl)
            }
        });
        const _n = C.useRef();
        C.useEffect(() => {
            const J = () => {
                window.scrollY > 200 ? f(!0) : f(!1)
            };
            window.addEventListener("scroll", J, {
                passive: !0
            });
            let be = window.scrollY;
            const Ne = () => {
                const Ln = window.scrollY;
                Ln > be && Ln >= 100 ? _n.current.style.transform = "translateY(-100%)" : Ln < be && _n.current && (_n.current.style.transform = "translateY(0%)"), be = Ln
            };
            return window.addEventListener("scroll", Ne, {
                passive: !0
            }), () => {
                window.removeEventListener("scroll", J, {
                    passive: !0
                }), window.removeEventListener("scroll", Ne, {
                    passive: !0
                })
            }
        }, []);
        const wi = J => a.pathname === J ? "red" : "";
        C.useEffect(() => {
            const J = () => {
                window.innerWidth <= 600 ? p(!0) : p(!1)
            };
            return J(), window.addEventListener("resize", J, {
                passive: !0
            }), () => {
                window.removeEventListener("resize", J)
            }
        }, []);
        const us = C.useRef();
        C.useEffect(() => {
            window.innerWidth <= 650 ? (a.pathname === "/" || a.pathname === "/Filter" ? us.current.style.display = "flex" : us.current.style.display = "none", w(!0)) : (us.current.style.display = "flex", w(!1))
        }, [a.pathname]);
        const [Cl, ft] = C.useState(!0);
        C.useEffect(() => {
            const J = () => {
                window.scrollY <= 250 ? ft(!0) : ft(!1)
            };
            return window.addEventListener("scroll", J, {
                passive: !0
            }), () => window.removeEventListener("scroll", J, {
                passive: !0
            })
        }, []), C.useEffect(() => {
            const J = be => {
                m.current && !m.current.contains(be.target) && _(!1)
            };
            return document.addEventListener("mousedown", J), () => {
                document.removeEventListener("mousedown", J)
            }
        });
        const Hn = C.useRef();
        return pc(() => {
            const J = Oi.timeline({
                paused: !0
            });
            J.to(V.current, {
                right: 0,
                duration: .3,
                ease: "ease"
            }, "same").to(Hn.current, {
                left: 0,
                duration: .5,
                ease: "ease"
            }, "same");
            const be = Oi.timeline({
                paused: !0
            });
            be.to(V.current, {
                right: "-100%",
                duration: .5,
                ease: "power4.inOut"
            }, "same2").to(Hn.current, {
                left: "-100%",
                duration: .5,
                ease: "power4.inOut"
            }, "same2");
            const Ne = () => {
                    J.restart(), document.body.style.overflow = "hidden"
                },
                Ln = () => {
                    be.restart(), document.body.style.overflowY = "scroll"
                };
            return W.current.addEventListener("click", Ne), Z.current.addEventListener("click", Ln), () => {
                W.current.removeEventListener("click", Ne), Z.current.removeEventListener("click", Ln)
            }
        }), C.useEffect(() => {
            _n.current && e.navrefvalue && e.navrefvalue(_n.current)
        }, [_n.current]), g.jsxs(g.Fragment, {
            children: [g.jsx("div", {
                ref: _n,
                className: `navbar 
         ${c?"home-nav":"black-nav"}
      ${a.pathname===""?c?"home-nav":"black-nav":""}
      ${a.pathname==="/Profile"?"profile-nav":""}
      ${a.pathname==="/Contact-Us"?"contact-nav":""}
      ${a.pathname==="/About-us"?"about-nav":""}
      ${a.pathname==="/LogIn"?"login-nav":""}
        `,
                children: g.jsxs("div", {
                    className: "navber-box",
                    children: [g.jsx("div", {
                        ref: ct,
                        className: "hambargar",
                        children: g.jsx("i", {
                            className: "fa-solid fa-bars"
                        })
                    }), g.jsx("div", {
                        className: "nav-list",
                        children: g.jsxs("ul", {
                            children: [g.jsx(je, {
                                className: wi("/api"),
                                to: "/",
                                children: g.jsx("li", {
                                    children: "Home"
                                })
                            }), g.jsx(je, {
                                className: wi("/Profile"),
                                to: "/Profile",
                                children: g.jsx("li", {
                                    children: "Profile"
                                })
                            }), g.jsx(je, {
                                className: wi("/Contact-Us"),
                                to: "/Contact-Us",
                                children: g.jsx("li", {
                                    children: "Contact Us"
                                })
                            }), g.jsx(je, {
                                className: wi("/About-us"),
                                to: "/About-us",
                                children: g.jsx("li", {
                                    children: "About us"
                                })
                            })]
                        })
                    }), g.jsxs("form", {
                        onSubmit: J => {
                            J.preventDefault(), i ? r.some(Ne => Ne.toLowerCase() === i.trim().toLowerCase()) ? xe(i) : q("Enter a valid department name", "", "cancel") : q("Please Enter Department Name", "", "cancel")
                        },
                        ref: us,
                        className: `filter-switch  ${Cl?"filter-switch-mobile":"filter-switch-mobile-off"}`,
                        children: [g.jsx("input", {
                            type: "text",
                            name: "",
                            id: "searchbox",
                            placeholder: "Search  Department Here",
                            onChange: St,
                            value: i
                        }), g.jsx("label", {
                            htmlFor: "searchbox",
                            onClick: () => {
                                i ? r.some(be => be.toLowerCase() === i.trim().toLowerCase()) ? xe(i) : q("Enter a valid department name", "", "cancel") : q("Please Enter Department Name", "", "cancel")
                            },
                            children: g.jsx("i", {
                                className: "fa-solid fa-magnifying-glass"
                            })
                        }), h && g.jsx("div", {
                            ref: m,
                            className: "search-suggestion",
                            children: i ? r && r.filter(J => {
                                const be = J.toLowerCase(),
                                    Ne = i.toLowerCase();
                                return be.startsWith(Ne)
                            }).length === 0 ? g.jsx("div", {
                                className: "search-item",
                                children: g.jsx("p", {
                                    children: "No Departments available"
                                })
                            }) : r.filter(J => {
                                const be = J.toLowerCase(),
                                    Ne = i.toLowerCase();
                                return be.startsWith(Ne) && be !== Ne
                            }).map((J, be) => g.jsx("div", {
                                onClick: Ne => {
                                    xe(J)
                                },
                                className: "search-item",
                                children: g.jsx("p", {
                                    children: J
                                })
                            }, be)) : null
                        })]
                    }), Cl && A && g.jsx("h2", {
                        style: {
                            marginLeft: "0.2rem"
                        },
                        className: "logo-top-css",
                        children: " STUDYVAULT"
                    }), g.jsxs("div", {
                        className: "location-login",
                        children: [S && g.jsx("div", {
                            className: "admin-short",
                            style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                                marginRight: "0.5rem"
                            },
                            children: g.jsx("i", {
                                className: "fa-solid fa-user-shield",
                                style: {
                                    color: "#fff",
                                    fontSize: "1.6rem",
                                    cursor: "pointer",
                                    paddingLeft: "0.3rem"
                                },
                                onClick: () => o("/Admin")
                            })
                        }), g.jsxs("select", {
                            name: "name",
                            className: `college-name ${O?"":"college-box-home-on"}`,
                            children: [d ? g.jsx("option", {
                                value: "M.P.C autonomous",
                                children: "M.P.C"
                            }) : g.jsx("option", {
                                value: "M.P.C autonomous",
                                children: "M.P.C Autonomous"
                            }), ";"]
                        }), g.jsx("div", {
                            className: "notificatonicon",
                            style: {
                                margin: "0rem 1.3rem 0rem 0.3rem",
                                userSelect: "none",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center"
                            },
                            ref: W,
                            children: g.jsx("i", {
                                className: "fa-solid fa-bell",
                                style: {
                                    color: "#fff",
                                    cursor: "pointer"
                                }
                            })
                        }), M ? g.jsx("div", {
                            className: "log-in",
                            style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center"
                            },
                            children: g.jsx(je, {
                                onClick: ke,
                                alt: "Log Out",
                                children: g.jsx("i", {
                                    className: "fa-solid fa-right-from-bracket",
                                    style: {
                                        margin: "0rem 0 0 0.5rem",
                                        color: "#fff"
                                    }
                                })
                            })
                        }) : g.jsx("div", {
                            className: "log-in",
                            style: {
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center"
                            },
                            children: g.jsx("div", {
                                ref: x,
                                onClick: H,
                                children: g.jsxs("li", {
                                    children: ["Login ", g.jsxs("div", {
                                        className: `adminLogInBox ${E?"open":"close"} `,
                                        ref: T,
                                        children: [g.jsxs(je, {
                                            className: `${wi("/LogIn")} ${E?"big":"small"}`,
                                            to: "/LogIn",
                                            children: [g.jsx("i", {
                                                className: "fa-solid fa-graduation-cap"
                                            }), "Student LogIn "]
                                        }), S ? g.jsxs(je, {
                                            to: "/Admin",
                                            className: `${E?"big":"small"}`,
                                            children: [g.jsx("i", {
                                                className: "fa-solid fa-user-tie"
                                            }), "Admin Page"]
                                        }) : g.jsxs(je, {
                                            to: "/Admin/AdminLogIn",
                                            className: `${E?"big":"small"}`,
                                            children: [g.jsx("i", {
                                                className: "fa-solid fa-user-tie"
                                            }), "Admin LogIn "]
                                        })]
                                    })]
                                })
                            })
                        })]
                    })]
                })
            }), g.jsx("div", {
                className: "navbackcolordiv"
            }), g.jsxs("div", {
                className: "slidebar",
                children: [g.jsx("div", {
                    className: "cross-icon",
                    children: g.jsx("i", {
                        ref: Lt,
                        className: "fa-solid fa-xmark"
                    })
                }), g.jsx("h3", {
                    style: {
                        margin: "2rem 0 0 0 "
                    },
                    children: "NAVIGATION"
                }), g.jsx("hr", {
                    style: {
                        margin: "2rem 0"
                    }
                }), g.jsxs("div", {
                    className: "slidebar-box",
                    children: [g.jsx("h4", {
                        className: "slidebar-title",
                        children: g.jsxs(Jo, {
                            to: "/",
                            onClick: () => {
                                document.body.style.overflow = "scroll"
                            },
                            children: [g.jsx("i", {
                                className: "fa-solid fa-house-chimney"
                            }), "Home"]
                        })
                    }), g.jsx("h4", {
                        className: "slidebar-title",
                        children: g.jsxs(Jo, {
                            to: "/Profile",
                            onClick: () => {
                                document.body.style.overflow = "scroll"
                            },
                            children: [g.jsx("i", {
                                className: "fa-solid fa-user"
                            }), "Profile"]
                        })
                    }), g.jsx("h4", {
                        className: "slidebar-title",
                        children: g.jsxs(Jo, {
                            to: "/About-us",
                            onClick: () => {
                                document.body.style.overflow = "scroll"
                            },
                            children: [g.jsx("i", {
                                className: "fa-solid fa-pen"
                            }), "About Us"]
                        })
                    }), g.jsx("h4", {
                        className: "slidebar-title",
                        children: g.jsxs(Jo, {
                            to: "/Contact-Us",
                            onClick: () => {
                                document.body.style.overflow = "scroll"
                            },
                            children: [g.jsx("i", {
                                className: "fa-solid fa-paper-plane"
                            }), "Contact Us"]
                        })
                    })]
                }), g.jsx("hr", {
                    style: {
                        margin: "2rem 0"
                    }
                }), g.jsxs("div", {
                    className: "copywrite",
                    children: [g.jsx("p", {
                        children: "Copyright 2024 All rights reserved |"
                    }), g.jsx("p", {
                        children: "This website is made by"
                    }), g.jsx("p", {
                        children: "Akash and Jitu  "
                    })]
                }), g.jsxs("div", {
                    className: "slidebar-foot-item",
                    children: [g.jsx(je, {
                        to: "/Privacy-Policy",
                        onClick: () => {
                            document.body.style.overflow = "scroll"
                        },
                        children: " Privacy & Policy"
                    }), g.jsx("p", {
                        children: "V.1.5.3"
                    })]
                })]
            }), g.jsx("aside", {
                ref: Hn,
                id: "full-notification-back",
                children: g.jsxs("aside", {
                    ref: V,
                    id: "notification",
                    children: [g.jsxs("h2", {
                        children: ["Notification ", g.jsx("s", {}), "  ", g.jsx("i", {
                            className: "fa-solid fa-xmark",
                            style: {
                                cursor: "pointer"
                            },
                            ref: Z
                        })]
                    }), g.jsx("h4", {
                        children: "All"
                    }), g.jsx("hr", {
                        style: {
                            margin: "0rem 0rem 1.4rem 0rem"
                        }
                    }), g.jsxs("div", {
                        className: "notification-data",
                        style: {
                            opacity: "1"
                        },
                        children: [g.jsxs("div", {
                            style: {
                                display: "flex",
                                alignItems: "center",
                                gap: "0.6rem"
                            },
                            className: "each-notification",
                            children: [g.jsx(Tv, {
                                alt: "Remy Sharp",
                                src: Ev,
                                sx: {
                                    width: 24,
                                    height: 24,
                                    padding: "0rem 0rem 0 0",
                                    display: "inline-block"
                                }
                            }), g.jsx("h3", {
                                children: "StudyVault Team"
                            })]
                        }), g.jsxs("p", {
                            children: ["Join Our ", g.jsx("b", {
                                style: {
                                    fontWeight: "700"
                                },
                                children: "Whatsapp Channel"
                            }), " to get new updates and type of question uploaded."]
                        })]
                    }), g.jsxs("div", {
                        className: "notification-data",
                        children: [g.jsxs("div", {
                            style: {
                                display: "flex",
                                alignItems: "center",
                                gap: "0.6rem"
                            },
                            className: "each-notification",
                            children: [g.jsx(Tv, {
                                alt: "Remy Sharp",
                                src: Ev,
                                sx: {
                                    width: 24,
                                    height: 24,
                                    padding: "0rem 0rem 0 0",
                                    display: "inline-block"
                                }
                            }), g.jsx("h3", {
                                children: "StudyVault Team"
                            })]
                        }), g.jsxs("p", {
                            children: [" Now you can access all ", g.jsx("b", {
                                style: {
                                    fontWeight: "700"
                                },
                                children: "Questions papers"
                            }), " without login."]
                        })]
                    })]
                })
            })]
        })
    },
    en = () => g.jsx("section", {
        className: "loading-fallback",
        children: g.jsx("div", {})
    });
class ge extends Z1.Component {
    constructor(t) {
        super(t), this.state = {
            hasError: !1,
            error: null,
            errorInfo: null
        }
    }
    static getDerivedStateFromError(t) {
        return {
            hasError: !0,
            error: t
        }
    }
    componentDidCatch(t, n) {
        console.error("ErrorBoundary caught an error:", t, n), this.setState({
            error: t,
            errorInfo: n
        })
    }
    render() {
        var t, n;
        return this.state.hasError ? g.jsxs("div", {
            style: {
                position: "fixed",
                zIndex: "1111111111111111",
                background: "white",
                left: "0",
                top: "0",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                height: "100%",
                width: "100%",
                padding: "2rem"
            },
            children: [g.jsx("h1", {
                style: {
                    textAlign: "center"
                },
                children: "🚨 Something went wrong!"
            }), g.jsx("p", {
                style: {
                    color: "red",
                    fontWeight: "bold"
                },
                children: (t = this.state.error) == null ? void 0 : t.toString()
            }), g.jsx("pre", {
                style: {
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-word",
                    maxHeight: "300px",
                    overflowY: "auto",
                    border: "1px solid #ccc",
                    padding: "1rem",
                    backgroundColor: "#f0f0f0",
                    width: "80%",
                    textAlign: "left"
                },
                children: (n = this.state.errorInfo) == null ? void 0 : n.componentStack
            }), g.jsx("button", {
                onClick: () => window.location.reload(),
                style: {
                    padding: "0.8rem 1.5rem",
                    marginTop: "1rem",
                    fontSize: "1rem",
                    fontWeight: "bold",
                    backgroundColor: "#007bff",
                    color: "#fff",
                    border: "none",
                    borderRadius: "5px",
                    cursor: "pointer"
                },
                children: "🔄 Refresh"
            })]
        }) : this.props.children
    }
}
const nM = C.createContext(),
    rM = ({
        children: e
    }) => {
        const [t, n] = C.useState(localStorage.getItem("theme") || "light"), r = () => {
            const i = t === "light" ? "dark" : "light";
            n(i), localStorage.setItem("theme", i)
        };
        return C.useEffect(() => {
            document.body.className = t
        }, [t]), g.jsx(nM.Provider, {
            value: {
                theme: t,
                toggleTheme: r
            },
            children: e
        })
    },
    iM = () => g.jsx(g.Fragment, {
        children: g.jsx(eR, {})
    }),
    EC = C.createContext({});

function sM(e) {
    const t = C.useRef(null);
    return t.current === null && (t.current = e()), t.current
}
const ig = C.createContext(null),
    PC = C.createContext({
        transformPagePoint: e => e,
        isStatic: !1,
        reducedMotion: "never"
    });

function oM(e = !0) {
    const t = C.useContext(ig);
    if (t === null) return [!0, null];
    const {
        isPresent: n,
        onExitComplete: r,
        register: i
    } = t, s = C.useId();
    C.useEffect(() => {
        e && i(s)
    }, [e]);
    const o = C.useCallback(() => e && r && r(s), [s, r, e]);
    return !n && r ? [!1, o] : [!0]
}
const sg = typeof window < "u",
    aM = sg ? C.useLayoutEffect : C.useEffect,
    pn = e => e;
let kC = pn;

function og(e) {
    let t;
    return () => (t === void 0 && (t = e()), t)
}
const go = (e, t, n) => {
        const r = t - e;
        return r === 0 ? 1 : (n - e) / r
    },
    Cr = e => e * 1e3,
    Tr = e => e / 1e3,
    lM = {
        useManualTiming: !1
    },
    tu = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"],
    Pv = {
        value: null
    };

function uM(e, t) {
    let n = new Set,
        r = new Set,
        i = !1,
        s = !1;
    const o = new WeakSet;
    let a = {
            delta: 0,
            timestamp: 0,
            isProcessing: !1
        },
        l = 0;

    function u(f) {
        o.has(f) && (c.schedule(f), e()), l++, f(a)
    }
    const c = {
        schedule: (f, d = !1, p = !1) => {
            const h = p && i ? n : r;
            return d && o.add(f), h.has(f) || h.add(f), f
        },
        cancel: f => {
            r.delete(f), o.delete(f)
        },
        process: f => {
            if (a = f, i) {
                s = !0;
                return
            }
            i = !0, [n, r] = [r, n], n.forEach(u), t && Pv.value && Pv.value.frameloop[t].push(l), l = 0, n.clear(), i = !1, s && (s = !1, c.process(f))
        }
    };
    return c
}
const cM = 40;

function bC(e, t) {
    let n = !1,
        r = !0;
    const i = {
            delta: 0,
            timestamp: 0,
            isProcessing: !1
        },
        s = () => n = !0,
        o = tu.reduce((v, y) => (v[y] = uM(s, t ? y : void 0), v), {}),
        {
            read: a,
            resolveKeyframes: l,
            update: u,
            preRender: c,
            render: f,
            postRender: d
        } = o,
        p = () => {
            const v = performance.now();
            n = !1, i.delta = r ? 1e3 / 60 : Math.max(Math.min(v - i.timestamp, cM), 1), i.timestamp = v, i.isProcessing = !0, a.process(i), l.process(i), u.process(i), c.process(i), f.process(i), d.process(i), i.isProcessing = !1, n && t && (r = !1, e(p))
        },
        m = () => {
            n = !0, r = !0, i.isProcessing || e(p)
        };
    return {
        schedule: tu.reduce((v, y) => {
            const x = o[y];
            return v[y] = (T, E = !1, k = !1) => (n || m(), x.schedule(T, E, k)), v
        }, {}),
        cancel: v => {
            for (let y = 0; y < tu.length; y++) o[tu[y]].cancel(v)
        },
        state: i,
        steps: o
    }
}
const {
    schedule: Pe,
    cancel: di,
    state: yt,
    steps: xd
} = bC(typeof requestAnimationFrame < "u" ? requestAnimationFrame : pn, !0), RC = C.createContext({
    strict: !1
}), kv = {
    animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
    exit: ["exit"],
    drag: ["drag", "dragControls"],
    focus: ["whileFocus"],
    hover: ["whileHover", "onHoverStart", "onHoverEnd"],
    tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
    pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
    inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
    layout: ["layout", "layoutId"]
}, yo = {};
for (const e in kv) yo[e] = {
    isEnabled: t => kv[e].some(n => !!t[n])
};

function fM(e) {
    for (const t in e) yo[t] = { ...yo[t],
        ...e[t]
    }
}
const dM = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

function vc(e) {
    return e.startsWith("while") || e.startsWith("drag") && e !== "draggable" || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || e.startsWith("onLayout") || dM.has(e)
}
let AC = e => !vc(e);

function hM(e) {
    e && (AC = t => t.startsWith("on") ? !vc(t) : e(t))
}
try {
    hM(require("@emotion/is-prop-valid").default)
} catch {}

function pM(e, t, n) {
    const r = {};
    for (const i in e) i === "values" && typeof e.values == "object" || (AC(i) || n === !0 && vc(i) || !t && !vc(i) || e.draggable && i.startsWith("onDrag")) && (r[i] = e[i]);
    return r
}

function mM(e) {
    if (typeof Proxy > "u") return e;
    const t = new Map,
        n = (...r) => e(...r);
    return new Proxy(n, {
        get: (r, i) => i === "create" ? e : (t.has(i) || t.set(i, e(i)), t.get(i))
    })
}
const _f = C.createContext({});

function wf(e) {
    return e !== null && typeof e == "object" && typeof e.start == "function"
}

function Za(e) {
    return typeof e == "string" || Array.isArray(e)
}
const ag = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
    lg = ["initial", ...ag];

function Sf(e) {
    return wf(e.animate) || lg.some(t => Za(e[t]))
}

function DC(e) {
    return !!(Sf(e) || e.variants)
}

function gM(e, t) {
    if (Sf(e)) {
        const {
            initial: n,
            animate: r
        } = e;
        return {
            initial: n === !1 || Za(n) ? n : void 0,
            animate: Za(r) ? r : void 0
        }
    }
    return e.inherit !== !1 ? t : {}
}

function yM(e) {
    const {
        initial: t,
        animate: n
    } = gM(e, C.useContext(_f));
    return C.useMemo(() => ({
        initial: t,
        animate: n
    }), [bv(t), bv(n)])
}

function bv(e) {
    return Array.isArray(e) ? e.join(" ") : e
}
const vM = Symbol.for("motionComponentSymbol");

function Ms(e) {
    return e && typeof e == "object" && Object.prototype.hasOwnProperty.call(e, "current")
}

function xM(e, t, n) {
    return C.useCallback(r => {
        r && e.onMount && e.onMount(r), t && (r ? t.mount(r) : t.unmount()), n && (typeof n == "function" ? n(r) : Ms(n) && (n.current = r))
    }, [t])
}
const ug = e => e.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
    _M = "framerAppearId",
    jC = "data-" + ug(_M),
    {
        schedule: cg
    } = bC(queueMicrotask, !1),
    OC = C.createContext({});

function wM(e, t, n, r, i) {
    var s, o;
    const {
        visualElement: a
    } = C.useContext(_f), l = C.useContext(RC), u = C.useContext(ig), c = C.useContext(PC).reducedMotion, f = C.useRef(null);
    r = r || l.renderer, !f.current && r && (f.current = r(e, {
        visualState: t,
        parent: a,
        props: n,
        presenceContext: u,
        blockInitialAnimation: u ? u.initial === !1 : !1,
        reducedMotionConfig: c
    }));
    const d = f.current,
        p = C.useContext(OC);
    d && !d.projection && i && (d.type === "html" || d.type === "svg") && SM(f.current, n, i, p);
    const m = C.useRef(!1);
    C.useInsertionEffect(() => {
        d && m.current && d.update(n, u)
    });
    const h = n[jC],
        _ = C.useRef(!!h && !(!((s = window.MotionHandoffIsComplete) === null || s === void 0) && s.call(window, h)) && ((o = window.MotionHasOptimisedAnimation) === null || o === void 0 ? void 0 : o.call(window, h)));
    return aM(() => {
        d && (m.current = !0, window.MotionIsMounted = !0, d.updateFeatures(), cg.render(d.render), _.current && d.animationState && d.animationState.animateChanges())
    }), C.useEffect(() => {
        d && (!_.current && d.animationState && d.animationState.animateChanges(), _.current && (queueMicrotask(() => {
            var v;
            (v = window.MotionHandoffMarkAsComplete) === null || v === void 0 || v.call(window, h)
        }), _.current = !1))
    }), d
}

function SM(e, t, n, r) {
    const {
        layoutId: i,
        layout: s,
        drag: o,
        dragConstraints: a,
        layoutScroll: l,
        layoutRoot: u
    } = t;
    e.projection = new n(e.latestValues, t["data-framer-portal-id"] ? void 0 : LC(e.parent)), e.projection.setOptions({
        layoutId: i,
        layout: s,
        alwaysMeasureLayout: !!o || a && Ms(a),
        visualElement: e,
        animationType: typeof s == "string" ? s : "both",
        initialPromotionConfig: r,
        layoutScroll: l,
        layoutRoot: u
    })
}

function LC(e) {
    if (e) return e.options.allowProjection !== !1 ? e.projection : LC(e.parent)
}

function CM({
    preloadedFeatures: e,
    createVisualElement: t,
    useRender: n,
    useVisualState: r,
    Component: i
}) {
    var s, o;
    e && fM(e);

    function a(u, c) {
        let f;
        const d = { ...C.useContext(PC),
                ...u,
                layoutId: TM(u)
            },
            {
                isStatic: p
            } = d,
            m = yM(u),
            h = r(u, p);
        if (!p && sg) {
            EM();
            const _ = PM(d);
            f = _.MeasureLayout, m.visualElement = wM(i, h, d, t, _.ProjectionNode)
        }
        return g.jsxs(_f.Provider, {
            value: m,
            children: [f && m.visualElement ? g.jsx(f, {
                visualElement: m.visualElement,
                ...d
            }) : null, n(i, u, xM(h, m.visualElement, c), h, p, m.visualElement)]
        })
    }
    a.displayName = `motion.${typeof i=="string"?i:`create(${(o=(s=i.displayName)!==null&&s!==void 0?s:i.name)!==null&&o!==void 0?o:""})`}`;
    const l = C.forwardRef(a);
    return l[vM] = i, l
}

function TM({
    layoutId: e
}) {
    const t = C.useContext(EC).id;
    return t && e !== void 0 ? t + "-" + e : e
}

function EM(e, t) {
    C.useContext(RC).strict
}

function PM(e) {
    const {
        drag: t,
        layout: n
    } = yo;
    if (!t && !n) return {};
    const r = { ...t,
        ...n
    };
    return {
        MeasureLayout: t != null && t.isEnabled(e) || n != null && n.isEnabled(e) ? r.MeasureLayout : void 0,
        ProjectionNode: r.ProjectionNode
    }
}
const MC = e => t => typeof t == "string" && t.startsWith(e),
    fg = MC("--"),
    kM = MC("var(--"),
    dg = e => kM(e) ? bM.test(e.split("/*")[0].trim()) : !1,
    bM = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
    el = {};

function RM(e) {
    for (const t in e) el[t] = e[t], fg(t) && (el[t].isCSSVariable = !0)
}
const Eo = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
    ls = new Set(Eo);

function NC(e, {
    layout: t,
    layoutId: n
}) {
    return ls.has(e) || e.startsWith("origin") || (t || n !== void 0) && (!!el[e] || e === "opacity")
}
const Dt = e => !!(e && e.getVelocity),
    FC = (e, t) => t && typeof e == "number" ? t.transform(e) : e,
    Or = (e, t, n) => n > t ? t : n < e ? e : n,
    Po = {
        test: e => typeof e == "number",
        parse: parseFloat,
        transform: e => e
    },
    tl = { ...Po,
        transform: e => Or(0, 1, e)
    },
    nu = { ...Po,
        default: 1
    },
    xl = e => ({
        test: t => typeof t == "string" && t.endsWith(e) && t.split(" ").length === 1,
        parse: parseFloat,
        transform: t => `${t}${e}`
    }),
    Br = xl("deg"),
    lr = xl("%"),
    Q = xl("px"),
    AM = xl("vh"),
    DM = xl("vw"),
    Rv = { ...lr,
        parse: e => lr.parse(e) / 100,
        transform: e => lr.transform(e * 100)
    },
    jM = {
        borderWidth: Q,
        borderTopWidth: Q,
        borderRightWidth: Q,
        borderBottomWidth: Q,
        borderLeftWidth: Q,
        borderRadius: Q,
        radius: Q,
        borderTopLeftRadius: Q,
        borderTopRightRadius: Q,
        borderBottomRightRadius: Q,
        borderBottomLeftRadius: Q,
        width: Q,
        maxWidth: Q,
        height: Q,
        maxHeight: Q,
        top: Q,
        right: Q,
        bottom: Q,
        left: Q,
        padding: Q,
        paddingTop: Q,
        paddingRight: Q,
        paddingBottom: Q,
        paddingLeft: Q,
        margin: Q,
        marginTop: Q,
        marginRight: Q,
        marginBottom: Q,
        marginLeft: Q,
        backgroundPositionX: Q,
        backgroundPositionY: Q
    },
    OM = {
        rotate: Br,
        rotateX: Br,
        rotateY: Br,
        rotateZ: Br,
        scale: nu,
        scaleX: nu,
        scaleY: nu,
        scaleZ: nu,
        skew: Br,
        skewX: Br,
        skewY: Br,
        distance: Q,
        translateX: Q,
        translateY: Q,
        translateZ: Q,
        x: Q,
        y: Q,
        z: Q,
        perspective: Q,
        transformPerspective: Q,
        opacity: tl,
        originX: Rv,
        originY: Rv,
        originZ: Q
    },
    Av = { ...Po,
        transform: Math.round
    },
    hg = { ...jM,
        ...OM,
        zIndex: Av,
        size: Q,
        fillOpacity: tl,
        strokeOpacity: tl,
        numOctaves: Av
    },
    LM = {
        x: "translateX",
        y: "translateY",
        z: "translateZ",
        transformPerspective: "perspective"
    },
    MM = Eo.length;

function NM(e, t, n) {
    let r = "",
        i = !0;
    for (let s = 0; s < MM; s++) {
        const o = Eo[s],
            a = e[o];
        if (a === void 0) continue;
        let l = !0;
        if (typeof a == "number" ? l = a === (o.startsWith("scale") ? 1 : 0) : l = parseFloat(a) === 0, !l || n) {
            const u = FC(a, hg[o]);
            if (!l) {
                i = !1;
                const c = LM[o] || o;
                r += `${c}(${u}) `
            }
            n && (t[o] = u)
        }
    }
    return r = r.trim(), n ? r = n(t, i ? "" : r) : i && (r = "none"), r
}

function pg(e, t, n) {
    const {
        style: r,
        vars: i,
        transformOrigin: s
    } = e;
    let o = !1,
        a = !1;
    for (const l in t) {
        const u = t[l];
        if (ls.has(l)) {
            o = !0;
            continue
        } else if (fg(l)) {
            i[l] = u;
            continue
        } else {
            const c = FC(u, hg[l]);
            l.startsWith("origin") ? (a = !0, s[l] = c) : r[l] = c
        }
    }
    if (t.transform || (o || n ? r.transform = NM(t, e.transform, n) : r.transform && (r.transform = "none")), a) {
        const {
            originX: l = "50%",
            originY: u = "50%",
            originZ: c = 0
        } = s;
        r.transformOrigin = `${l} ${u} ${c}`
    }
}
const mg = () => ({
    style: {},
    transform: {},
    transformOrigin: {},
    vars: {}
});

function IC(e, t, n) {
    for (const r in t) !Dt(t[r]) && !NC(r, n) && (e[r] = t[r])
}

function FM({
    transformTemplate: e
}, t) {
    return C.useMemo(() => {
        const n = mg();
        return pg(n, t, e), Object.assign({}, n.vars, n.style)
    }, [t])
}

function IM(e, t) {
    const n = e.style || {},
        r = {};
    return IC(r, n, e), Object.assign(r, FM(e, t)), r
}

function VM(e, t) {
    const n = {},
        r = IM(e, t);
    return e.drag && e.dragListener !== !1 && (n.draggable = !1, r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none", r.touchAction = e.drag === !0 ? "none" : `pan-${e.drag==="x"?"y":"x"}`), e.tabIndex === void 0 && (e.onTap || e.onTapStart || e.whileTap) && (n.tabIndex = 0), n.style = r, n
}
const BM = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

function gg(e) {
    return typeof e != "string" || e.includes("-") ? !1 : !!(BM.indexOf(e) > -1 || /[A-Z]/u.test(e))
}
const zM = {
        offset: "stroke-dashoffset",
        array: "stroke-dasharray"
    },
    UM = {
        offset: "strokeDashoffset",
        array: "strokeDasharray"
    };

function $M(e, t, n = 1, r = 0, i = !0) {
    e.pathLength = 1;
    const s = i ? zM : UM;
    e[s.offset] = Q.transform(-r);
    const o = Q.transform(t),
        a = Q.transform(n);
    e[s.array] = `${o} ${a}`
}

function Dv(e, t, n) {
    return typeof e == "string" ? e : Q.transform(t + n * e)
}

function WM(e, t, n) {
    const r = Dv(t, e.x, e.width),
        i = Dv(n, e.y, e.height);
    return `${r} ${i}`
}

function yg(e, {
    attrX: t,
    attrY: n,
    attrScale: r,
    originX: i,
    originY: s,
    pathLength: o,
    pathSpacing: a = 1,
    pathOffset: l = 0,
    ...u
}, c, f) {
    if (pg(e, u, f), c) {
        e.style.viewBox && (e.attrs.viewBox = e.style.viewBox);
        return
    }
    e.attrs = e.style, e.style = {};
    const {
        attrs: d,
        style: p,
        dimensions: m
    } = e;
    d.transform && (m && (p.transform = d.transform), delete d.transform), m && (i !== void 0 || s !== void 0 || p.transform) && (p.transformOrigin = WM(m, i !== void 0 ? i : .5, s !== void 0 ? s : .5)), t !== void 0 && (d.x = t), n !== void 0 && (d.y = n), r !== void 0 && (d.scale = r), o !== void 0 && $M(d, o, a, l, !1)
}
const VC = () => ({ ...mg(),
        attrs: {}
    }),
    vg = e => typeof e == "string" && e.toLowerCase() === "svg";

function HM(e, t, n, r) {
    const i = C.useMemo(() => {
        const s = VC();
        return yg(s, t, vg(r), e.transformTemplate), { ...s.attrs,
            style: { ...s.style
            }
        }
    }, [t]);
    if (e.style) {
        const s = {};
        IC(s, e.style, e), i.style = { ...s,
            ...i.style
        }
    }
    return i
}

function KM(e = !1) {
    return (n, r, i, {
        latestValues: s
    }, o) => {
        const l = (gg(n) ? HM : VM)(r, s, o, n),
            u = pM(r, typeof n == "string", e),
            c = n !== C.Fragment ? { ...u,
                ...l,
                ref: i
            } : {},
            {
                children: f
            } = r,
            d = C.useMemo(() => Dt(f) ? f.get() : f, [f]);
        return C.createElement(n, { ...c,
            children: d
        })
    }
}

function jv(e) {
    const t = [{}, {}];
    return e == null || e.values.forEach((n, r) => {
        t[0][r] = n.get(), t[1][r] = n.getVelocity()
    }), t
}

function xg(e, t, n, r) {
    if (typeof t == "function") {
        const [i, s] = jv(r);
        t = t(n !== void 0 ? n : e.custom, i, s)
    }
    if (typeof t == "string" && (t = e.variants && e.variants[t]), typeof t == "function") {
        const [i, s] = jv(r);
        t = t(n !== void 0 ? n : e.custom, i, s)
    }
    return t
}
const ip = e => Array.isArray(e),
    GM = e => !!(e && typeof e == "object" && e.mix && e.toValue),
    YM = e => ip(e) ? e[e.length - 1] || 0 : e;

function bu(e) {
    const t = Dt(e) ? e.get() : e;
    return GM(t) ? t.toValue() : t
}

function XM({
    scrapeMotionValuesFromProps: e,
    createRenderState: t,
    onUpdate: n
}, r, i, s) {
    const o = {
        latestValues: qM(r, i, s, e),
        renderState: t()
    };
    return n && (o.onMount = a => n({
        props: r,
        current: a,
        ...o
    }), o.onUpdate = a => n(a)), o
}
const BC = e => (t, n) => {
    const r = C.useContext(_f),
        i = C.useContext(ig),
        s = () => XM(e, t, r, i);
    return n ? s() : sM(s)
};

function qM(e, t, n, r) {
    const i = {},
        s = r(e, {});
    for (const d in s) i[d] = bu(s[d]);
    let {
        initial: o,
        animate: a
    } = e;
    const l = Sf(e),
        u = DC(e);
    t && u && !l && e.inherit !== !1 && (o === void 0 && (o = t.initial), a === void 0 && (a = t.animate));
    let c = n ? n.initial === !1 : !1;
    c = c || o === !1;
    const f = c ? a : o;
    if (f && typeof f != "boolean" && !wf(f)) {
        const d = Array.isArray(f) ? f : [f];
        for (let p = 0; p < d.length; p++) {
            const m = xg(e, d[p]);
            if (m) {
                const {
                    transitionEnd: h,
                    transition: _,
                    ...v
                } = m;
                for (const y in v) {
                    let x = v[y];
                    if (Array.isArray(x)) {
                        const T = c ? x.length - 1 : 0;
                        x = x[T]
                    }
                    x !== null && (i[y] = x)
                }
                for (const y in h) i[y] = h[y]
            }
        }
    }
    return i
}

function _g(e, t, n) {
    var r;
    const {
        style: i
    } = e, s = {};
    for (const o in i)(Dt(i[o]) || t.style && Dt(t.style[o]) || NC(o, e) || ((r = n == null ? void 0 : n.getValue(o)) === null || r === void 0 ? void 0 : r.liveStyle) !== void 0) && (s[o] = i[o]);
    return s
}
const QM = {
    useVisualState: BC({
        scrapeMotionValuesFromProps: _g,
        createRenderState: mg
    })
};

function zC(e, t) {
    try {
        t.dimensions = typeof e.getBBox == "function" ? e.getBBox() : e.getBoundingClientRect()
    } catch {
        t.dimensions = {
            x: 0,
            y: 0,
            width: 0,
            height: 0
        }
    }
}

function UC(e, {
    style: t,
    vars: n
}, r, i) {
    Object.assign(e.style, t, i && i.getProjectionStyles(r));
    for (const s in n) e.style.setProperty(s, n[s])
}
const $C = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

function WC(e, t, n, r) {
    UC(e, t, void 0, r);
    for (const i in t.attrs) e.setAttribute($C.has(i) ? i : ug(i), t.attrs[i])
}

function HC(e, t, n) {
    const r = _g(e, t, n);
    for (const i in e)
        if (Dt(e[i]) || Dt(t[i])) {
            const s = Eo.indexOf(i) !== -1 ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i;
            r[s] = e[i]
        }
    return r
}
const Ov = ["x", "y", "width", "height", "cx", "cy", "r"],
    JM = {
        useVisualState: BC({
            scrapeMotionValuesFromProps: HC,
            createRenderState: VC,
            onUpdate: ({
                props: e,
                prevProps: t,
                current: n,
                renderState: r,
                latestValues: i
            }) => {
                if (!n) return;
                let s = !!e.drag;
                if (!s) {
                    for (const a in i)
                        if (ls.has(a)) {
                            s = !0;
                            break
                        }
                }
                if (!s) return;
                let o = !t;
                if (t)
                    for (let a = 0; a < Ov.length; a++) {
                        const l = Ov[a];
                        e[l] !== t[l] && (o = !0)
                    }
                o && Pe.read(() => {
                    zC(n, r), Pe.render(() => {
                        yg(r, i, vg(n.tagName), e.transformTemplate), WC(n, r)
                    })
                })
            }
        })
    };

function ZM(e, t) {
    return function(r, {
        forwardMotionProps: i
    } = {
        forwardMotionProps: !1
    }) {
        const o = { ...gg(r) ? JM : QM,
            preloadedFeatures: e,
            useRender: KM(i),
            createVisualElement: t,
            Component: r
        };
        return CM(o)
    }
}

function nl(e, t, n) {
    const r = e.getProps();
    return xg(r, t, n !== void 0 ? n : r.custom, e)
}
const eN = og(() => window.ScrollTimeline !== void 0);
class tN {
    constructor(t) {
        this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
    }
    get finished() {
        return Promise.all(this.animations.map(t => "finished" in t ? t.finished : t))
    }
    getAll(t) {
        return this.animations[0][t]
    }
    setAll(t, n) {
        for (let r = 0; r < this.animations.length; r++) this.animations[r][t] = n
    }
    attachTimeline(t, n) {
        const r = this.animations.map(i => {
            if (eN() && i.attachTimeline) return i.attachTimeline(t);
            if (typeof n == "function") return n(i)
        });
        return () => {
            r.forEach((i, s) => {
                i && i(), this.animations[s].stop()
            })
        }
    }
    get time() {
        return this.getAll("time")
    }
    set time(t) {
        this.setAll("time", t)
    }
    get speed() {
        return this.getAll("speed")
    }
    set speed(t) {
        this.setAll("speed", t)
    }
    get startTime() {
        return this.getAll("startTime")
    }
    get duration() {
        let t = 0;
        for (let n = 0; n < this.animations.length; n++) t = Math.max(t, this.animations[n].duration);
        return t
    }
    runAll(t) {
        this.animations.forEach(n => n[t]())
    }
    flatten() {
        this.runAll("flatten")
    }
    play() {
        this.runAll("play")
    }
    pause() {
        this.runAll("pause")
    }
    cancel() {
        this.runAll("cancel")
    }
    complete() {
        this.runAll("complete")
    }
}
class nN extends tN {
    then(t, n) {
        return Promise.all(this.animations).then(t).catch(n)
    }
}

function wg(e, t) {
    return e ? e[t] || e.default || e : void 0
}
const sp = 2e4;

function KC(e) {
    let t = 0;
    const n = 50;
    let r = e.next(t);
    for (; !r.done && t < sp;) t += n, r = e.next(t);
    return t >= sp ? 1 / 0 : t
}

function Sg(e) {
    return typeof e == "function"
}

function Lv(e, t) {
    e.timeline = t, e.onfinish = null
}
const Cg = e => Array.isArray(e) && typeof e[0] == "number",
    rN = {
        linearEasing: void 0
    };

function iN(e, t) {
    const n = og(e);
    return () => {
        var r;
        return (r = rN[t]) !== null && r !== void 0 ? r : n()
    }
}
const xc = iN(() => {
        try {
            document.createElement("div").animate({
                opacity: 0
            }, {
                easing: "linear(0, 1)"
            })
        } catch {
            return !1
        }
        return !0
    }, "linearEasing"),
    GC = (e, t, n = 10) => {
        let r = "";
        const i = Math.max(Math.round(t / n), 2);
        for (let s = 0; s < i; s++) r += e(go(0, i - 1, s)) + ", ";
        return `linear(${r.substring(0,r.length-2)})`
    };

function YC(e) {
    return !!(typeof e == "function" && xc() || !e || typeof e == "string" && (e in op || xc()) || Cg(e) || Array.isArray(e) && e.every(YC))
}
const ra = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`,
    op = {
        linear: "linear",
        ease: "ease",
        easeIn: "ease-in",
        easeOut: "ease-out",
        easeInOut: "ease-in-out",
        circIn: ra([0, .65, .55, 1]),
        circOut: ra([.55, 0, 1, .45]),
        backIn: ra([.31, .01, .66, -.59]),
        backOut: ra([.33, 1.53, .69, .99])
    };

function XC(e, t) {
    if (e) return typeof e == "function" && xc() ? GC(e, t) : Cg(e) ? ra(e) : Array.isArray(e) ? e.map(n => XC(n, t) || op.easeOut) : op[e]
}
const Nn = {
    x: !1,
    y: !1
};

function qC() {
    return Nn.x || Nn.y
}

function sN(e, t, n) {
    var r;
    if (e instanceof Element) return [e];
    if (typeof e == "string") {
        let i = document;
        const s = (r = void 0) !== null && r !== void 0 ? r : i.querySelectorAll(e);
        return s ? Array.from(s) : []
    }
    return Array.from(e)
}

function QC(e, t) {
    const n = sN(e),
        r = new AbortController,
        i = {
            passive: !0,
            ...t,
            signal: r.signal
        };
    return [n, i, () => r.abort()]
}

function Mv(e) {
    return !(e.pointerType === "touch" || qC())
}

function oN(e, t, n = {}) {
    const [r, i, s] = QC(e, n), o = a => {
        if (!Mv(a)) return;
        const {
            target: l
        } = a, u = t(l, a);
        if (typeof u != "function" || !l) return;
        const c = f => {
            Mv(f) && (u(f), l.removeEventListener("pointerleave", c))
        };
        l.addEventListener("pointerleave", c, i)
    };
    return r.forEach(a => {
        a.addEventListener("pointerenter", o, i)
    }), s
}
const JC = (e, t) => t ? e === t ? !0 : JC(e, t.parentElement) : !1,
    Tg = e => e.pointerType === "mouse" ? typeof e.button != "number" || e.button <= 0 : e.isPrimary !== !1,
    aN = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);

function lN(e) {
    return aN.has(e.tagName) || e.tabIndex !== -1
}
const ia = new WeakSet;

function Nv(e) {
    return t => {
        t.key === "Enter" && e(t)
    }
}

function _d(e, t) {
    e.dispatchEvent(new PointerEvent("pointer" + t, {
        isPrimary: !0,
        bubbles: !0
    }))
}
const uN = (e, t) => {
    const n = e.currentTarget;
    if (!n) return;
    const r = Nv(() => {
        if (ia.has(n)) return;
        _d(n, "down");
        const i = Nv(() => {
                _d(n, "up")
            }),
            s = () => _d(n, "cancel");
        n.addEventListener("keyup", i, t), n.addEventListener("blur", s, t)
    });
    n.addEventListener("keydown", r, t), n.addEventListener("blur", () => n.removeEventListener("keydown", r), t)
};

function Fv(e) {
    return Tg(e) && !qC()
}

function cN(e, t, n = {}) {
    const [r, i, s] = QC(e, n), o = a => {
        const l = a.currentTarget;
        if (!Fv(a) || ia.has(l)) return;
        ia.add(l);
        const u = t(l, a),
            c = (p, m) => {
                window.removeEventListener("pointerup", f), window.removeEventListener("pointercancel", d), !(!Fv(p) || !ia.has(l)) && (ia.delete(l), typeof u == "function" && u(p, {
                    success: m
                }))
            },
            f = p => {
                c(p, n.useGlobalTarget || JC(l, p.target))
            },
            d = p => {
                c(p, !1)
            };
        window.addEventListener("pointerup", f, i), window.addEventListener("pointercancel", d, i)
    };
    return r.forEach(a => {
        !lN(a) && a.getAttribute("tabindex") === null && (a.tabIndex = 0), (n.useGlobalTarget ? window : a).addEventListener("pointerdown", o, i), a.addEventListener("focus", u => uN(u, i), i)
    }), s
}

function fN(e) {
    return e === "x" || e === "y" ? Nn[e] ? null : (Nn[e] = !0, () => {
        Nn[e] = !1
    }) : Nn.x || Nn.y ? null : (Nn.x = Nn.y = !0, () => {
        Nn.x = Nn.y = !1
    })
}
const ZC = new Set(["width", "height", "top", "left", "right", "bottom", ...Eo]);
let Ru;

function dN() {
    Ru = void 0
}
const ur = {
    now: () => (Ru === void 0 && ur.set(yt.isProcessing || lM.useManualTiming ? yt.timestamp : performance.now()), Ru),
    set: e => {
        Ru = e, queueMicrotask(dN)
    }
};

function Eg(e, t) {
    e.indexOf(t) === -1 && e.push(t)
}

function Pg(e, t) {
    const n = e.indexOf(t);
    n > -1 && e.splice(n, 1)
}
class kg {
    constructor() {
        this.subscriptions = []
    }
    add(t) {
        return Eg(this.subscriptions, t), () => Pg(this.subscriptions, t)
    }
    notify(t, n, r) {
        const i = this.subscriptions.length;
        if (i)
            if (i === 1) this.subscriptions[0](t, n, r);
            else
                for (let s = 0; s < i; s++) {
                    const o = this.subscriptions[s];
                    o && o(t, n, r)
                }
    }
    getSize() {
        return this.subscriptions.length
    }
    clear() {
        this.subscriptions.length = 0
    }
}

function eT(e, t) {
    return t ? e * (1e3 / t) : 0
}
const Iv = 30,
    hN = e => !isNaN(parseFloat(e));
class pN {
    constructor(t, n = {}) {
        this.version = "12.4.3", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (r, i = !0) => {
            const s = ur.now();
            this.updatedAt !== s && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(r), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), i && this.events.renderRequest && this.events.renderRequest.notify(this.current)
        }, this.hasAnimated = !1, this.setCurrent(t), this.owner = n.owner
    }
    setCurrent(t) {
        this.current = t, this.updatedAt = ur.now(), this.canTrackVelocity === null && t !== void 0 && (this.canTrackVelocity = hN(this.current))
    }
    setPrevFrameValue(t = this.current) {
        this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
    }
    onChange(t) {
        return this.on("change", t)
    }
    on(t, n) {
        this.events[t] || (this.events[t] = new kg);
        const r = this.events[t].add(n);
        return t === "change" ? () => {
            r(), Pe.read(() => {
                this.events.change.getSize() || this.stop()
            })
        } : r
    }
    clearListeners() {
        for (const t in this.events) this.events[t].clear()
    }
    attach(t, n) {
        this.passiveEffect = t, this.stopPassiveEffect = n
    }
    set(t, n = !0) {
        !n || !this.passiveEffect ? this.updateAndNotify(t, n) : this.passiveEffect(t, this.updateAndNotify)
    }
    setWithVelocity(t, n, r) {
        this.set(n), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - r
    }
    jump(t, n = !0) {
        this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, n && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
    }
    get() {
        return this.current
    }
    getPrevious() {
        return this.prev
    }
    getVelocity() {
        const t = ur.now();
        if (!this.canTrackVelocity || this.prevFrameValue === void 0 || t - this.updatedAt > Iv) return 0;
        const n = Math.min(this.updatedAt - this.prevUpdatedAt, Iv);
        return eT(parseFloat(this.current) - parseFloat(this.prevFrameValue), n)
    }
    start(t) {
        return this.stop(), new Promise(n => {
            this.hasAnimated = !0, this.animation = t(n), this.events.animationStart && this.events.animationStart.notify()
        }).then(() => {
            this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
        })
    }
    stop() {
        this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
    }
    isAnimating() {
        return !!this.animation
    }
    clearAnimation() {
        delete this.animation
    }
    destroy() {
        this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
    }
}

function rl(e, t) {
    return new pN(e, t)
}

function mN(e, t, n) {
    e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, rl(n))
}

function gN(e, t) {
    const n = nl(e, t);
    let {
        transitionEnd: r = {},
        transition: i = {},
        ...s
    } = n || {};
    s = { ...s,
        ...r
    };
    for (const o in s) {
        const a = YM(s[o]);
        mN(e, o, a)
    }
}

function yN(e) {
    return !!(Dt(e) && e.add)
}

function ap(e, t) {
    const n = e.getValue("willChange");
    if (yN(n)) return n.add(t)
}

function tT(e) {
    return e.props[jC]
}
const nT = (e, t, n) => (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e,
    vN = 1e-7,
    xN = 12;

function _N(e, t, n, r, i) {
    let s, o, a = 0;
    do o = t + (n - t) / 2, s = nT(o, r, i) - e, s > 0 ? n = o : t = o; while (Math.abs(s) > vN && ++a < xN);
    return o
}

function _l(e, t, n, r) {
    if (e === t && n === r) return pn;
    const i = s => _N(s, 0, 1, e, n);
    return s => s === 0 || s === 1 ? s : nT(i(s), t, r)
}
const rT = e => t => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2,
    iT = e => t => 1 - e(1 - t),
    sT = _l(.33, 1.53, .69, .99),
    bg = iT(sT),
    oT = rT(bg),
    aT = e => (e *= 2) < 1 ? .5 * bg(e) : .5 * (2 - Math.pow(2, -10 * (e - 1))),
    Rg = e => 1 - Math.sin(Math.acos(e)),
    lT = iT(Rg),
    uT = rT(Rg),
    cT = e => /^0[^.\s]+$/u.test(e);

function wN(e) {
    return typeof e == "number" ? e === 0 : e !== null ? e === "none" || e === "0" || cT(e) : !0
}
const va = e => Math.round(e * 1e5) / 1e5,
    Ag = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;

function SN(e) {
    return e == null
}
const CN = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
    Dg = (e, t) => n => !!(typeof n == "string" && CN.test(n) && n.startsWith(e) || t && !SN(n) && Object.prototype.hasOwnProperty.call(n, t)),
    fT = (e, t, n) => r => {
        if (typeof r != "string") return r;
        const [i, s, o, a] = r.match(Ag);
        return {
            [e]: parseFloat(i),
            [t]: parseFloat(s),
            [n]: parseFloat(o),
            alpha: a !== void 0 ? parseFloat(a) : 1
        }
    },
    TN = e => Or(0, 255, e),
    wd = { ...Po,
        transform: e => Math.round(TN(e))
    },
    Bi = {
        test: Dg("rgb", "red"),
        parse: fT("red", "green", "blue"),
        transform: ({
            red: e,
            green: t,
            blue: n,
            alpha: r = 1
        }) => "rgba(" + wd.transform(e) + ", " + wd.transform(t) + ", " + wd.transform(n) + ", " + va(tl.transform(r)) + ")"
    };

function EN(e) {
    let t = "",
        n = "",
        r = "",
        i = "";
    return e.length > 5 ? (t = e.substring(1, 3), n = e.substring(3, 5), r = e.substring(5, 7), i = e.substring(7, 9)) : (t = e.substring(1, 2), n = e.substring(2, 3), r = e.substring(3, 4), i = e.substring(4, 5), t += t, n += n, r += r, i += i), {
        red: parseInt(t, 16),
        green: parseInt(n, 16),
        blue: parseInt(r, 16),
        alpha: i ? parseInt(i, 16) / 255 : 1
    }
}
const lp = {
        test: Dg("#"),
        parse: EN,
        transform: Bi.transform
    },
    Ns = {
        test: Dg("hsl", "hue"),
        parse: fT("hue", "saturation", "lightness"),
        transform: ({
            hue: e,
            saturation: t,
            lightness: n,
            alpha: r = 1
        }) => "hsla(" + Math.round(e) + ", " + lr.transform(va(t)) + ", " + lr.transform(va(n)) + ", " + va(tl.transform(r)) + ")"
    },
    Pt = {
        test: e => Bi.test(e) || lp.test(e) || Ns.test(e),
        parse: e => Bi.test(e) ? Bi.parse(e) : Ns.test(e) ? Ns.parse(e) : lp.parse(e),
        transform: e => typeof e == "string" ? e : e.hasOwnProperty("red") ? Bi.transform(e) : Ns.transform(e)
    },
    PN = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;

function kN(e) {
    var t, n;
    return isNaN(e) && typeof e == "string" && (((t = e.match(Ag)) === null || t === void 0 ? void 0 : t.length) || 0) + (((n = e.match(PN)) === null || n === void 0 ? void 0 : n.length) || 0) > 0
}
const dT = "number",
    hT = "color",
    bN = "var",
    RN = "var(",
    Vv = "${}",
    AN = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

function il(e) {
    const t = e.toString(),
        n = [],
        r = {
            color: [],
            number: [],
            var: []
        },
        i = [];
    let s = 0;
    const a = t.replace(AN, l => (Pt.test(l) ? (r.color.push(s), i.push(hT), n.push(Pt.parse(l))) : l.startsWith(RN) ? (r.var.push(s), i.push(bN), n.push(l)) : (r.number.push(s), i.push(dT), n.push(parseFloat(l))), ++s, Vv)).split(Vv);
    return {
        values: n,
        split: a,
        indexes: r,
        types: i
    }
}

function pT(e) {
    return il(e).values
}

function mT(e) {
    const {
        split: t,
        types: n
    } = il(e), r = t.length;
    return i => {
        let s = "";
        for (let o = 0; o < r; o++)
            if (s += t[o], i[o] !== void 0) {
                const a = n[o];
                a === dT ? s += va(i[o]) : a === hT ? s += Pt.transform(i[o]) : s += i[o]
            }
        return s
    }
}
const DN = e => typeof e == "number" ? 0 : e;

function jN(e) {
    const t = pT(e);
    return mT(e)(t.map(DN))
}
const hi = {
        test: kN,
        parse: pT,
        createTransformer: mT,
        getAnimatableNone: jN
    },
    ON = new Set(["brightness", "contrast", "saturate", "opacity"]);

function LN(e) {
    const [t, n] = e.slice(0, -1).split("(");
    if (t === "drop-shadow") return e;
    const [r] = n.match(Ag) || [];
    if (!r) return e;
    const i = n.replace(r, "");
    let s = ON.has(t) ? 1 : 0;
    return r !== n && (s *= 100), t + "(" + s + i + ")"
}
const MN = /\b([a-z-]*)\(.*?\)/gu,
    up = { ...hi,
        getAnimatableNone: e => {
            const t = e.match(MN);
            return t ? t.map(LN).join(" ") : e
        }
    },
    NN = { ...hg,
        color: Pt,
        backgroundColor: Pt,
        outlineColor: Pt,
        fill: Pt,
        stroke: Pt,
        borderColor: Pt,
        borderTopColor: Pt,
        borderRightColor: Pt,
        borderBottomColor: Pt,
        borderLeftColor: Pt,
        filter: up,
        WebkitFilter: up
    },
    jg = e => NN[e];

function gT(e, t) {
    let n = jg(e);
    return n !== up && (n = hi), n.getAnimatableNone ? n.getAnimatableNone(t) : void 0
}
const FN = new Set(["auto", "none", "0"]);

function IN(e, t, n) {
    let r = 0,
        i;
    for (; r < e.length && !i;) {
        const s = e[r];
        typeof s == "string" && !FN.has(s) && il(s).values.length && (i = e[r]), r++
    }
    if (i && n)
        for (const s of t) e[s] = gT(n, i)
}
const Bv = e => e === Po || e === Q,
    zv = (e, t) => parseFloat(e.split(", ")[t]),
    Uv = (e, t) => (n, {
        transform: r
    }) => {
        if (r === "none" || !r) return 0;
        const i = r.match(/^matrix3d\((.+)\)$/u);
        if (i) return zv(i[1], t); {
            const s = r.match(/^matrix\((.+)\)$/u);
            return s ? zv(s[1], e) : 0
        }
    },
    VN = new Set(["x", "y", "z"]),
    BN = Eo.filter(e => !VN.has(e));

function zN(e) {
    const t = [];
    return BN.forEach(n => {
        const r = e.getValue(n);
        r !== void 0 && (t.push([n, r.get()]), r.set(n.startsWith("scale") ? 1 : 0))
    }), t
}
const vo = {
    width: ({
        x: e
    }, {
        paddingLeft: t = "0",
        paddingRight: n = "0"
    }) => e.max - e.min - parseFloat(t) - parseFloat(n),
    height: ({
        y: e
    }, {
        paddingTop: t = "0",
        paddingBottom: n = "0"
    }) => e.max - e.min - parseFloat(t) - parseFloat(n),
    top: (e, {
        top: t
    }) => parseFloat(t),
    left: (e, {
        left: t
    }) => parseFloat(t),
    bottom: ({
        y: e
    }, {
        top: t
    }) => parseFloat(t) + (e.max - e.min),
    right: ({
        x: e
    }, {
        left: t
    }) => parseFloat(t) + (e.max - e.min),
    x: Uv(4, 13),
    y: Uv(5, 14)
};
vo.translateX = vo.x;
vo.translateY = vo.y;
const Yi = new Set;
let cp = !1,
    fp = !1;

function yT() {
    if (fp) {
        const e = Array.from(Yi).filter(r => r.needsMeasurement),
            t = new Set(e.map(r => r.element)),
            n = new Map;
        t.forEach(r => {
            const i = zN(r);
            i.length && (n.set(r, i), r.render())
        }), e.forEach(r => r.measureInitialState()), t.forEach(r => {
            r.render();
            const i = n.get(r);
            i && i.forEach(([s, o]) => {
                var a;
                (a = r.getValue(s)) === null || a === void 0 || a.set(o)
            })
        }), e.forEach(r => r.measureEndState()), e.forEach(r => {
            r.suspendedScrollY !== void 0 && window.scrollTo(0, r.suspendedScrollY)
        })
    }
    fp = !1, cp = !1, Yi.forEach(e => e.complete()), Yi.clear()
}

function vT() {
    Yi.forEach(e => {
        e.readKeyframes(), e.needsMeasurement && (fp = !0)
    })
}

function UN() {
    vT(), yT()
}
class Og {
    constructor(t, n, r, i, s, o = !1) {
        this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = n, this.name = r, this.motionValue = i, this.element = s, this.isAsync = o
    }
    scheduleResolve() {
        this.isScheduled = !0, this.isAsync ? (Yi.add(this), cp || (cp = !0, Pe.read(vT), Pe.resolveKeyframes(yT))) : (this.readKeyframes(), this.complete())
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: t,
            name: n,
            element: r,
            motionValue: i
        } = this;
        for (let s = 0; s < t.length; s++)
            if (t[s] === null)
                if (s === 0) {
                    const o = i == null ? void 0 : i.get(),
                        a = t[t.length - 1];
                    if (o !== void 0) t[0] = o;
                    else if (r && n) {
                        const l = r.readValue(n, a);
                        l != null && (t[0] = l)
                    }
                    t[0] === void 0 && (t[0] = a), i && o === void 0 && i.set(t[0])
                } else t[s] = t[s - 1]
    }
    setFinalKeyframe() {}
    measureInitialState() {}
    renderEndStyles() {}
    measureEndState() {}
    complete() {
        this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), Yi.delete(this)
    }
    cancel() {
        this.isComplete || (this.isScheduled = !1, Yi.delete(this))
    }
    resume() {
        this.isComplete || this.scheduleResolve()
    }
}
const xT = e => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e),
    $N = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;

function WN(e) {
    const t = $N.exec(e);
    if (!t) return [, ];
    const [, n, r, i] = t;
    return [`--${n??r}`, i]
}

function _T(e, t, n = 1) {
    const [r, i] = WN(e);
    if (!r) return;
    const s = window.getComputedStyle(t).getPropertyValue(r);
    if (s) {
        const o = s.trim();
        return xT(o) ? parseFloat(o) : o
    }
    return dg(i) ? _T(i, t, n + 1) : i
}
const wT = e => t => t.test(e),
    HN = {
        test: e => e === "auto",
        parse: e => e
    },
    ST = [Po, Q, lr, Br, DM, AM, HN],
    $v = e => ST.find(wT(e));
class CT extends Og {
    constructor(t, n, r, i, s) {
        super(t, n, r, i, s, !0)
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: t,
            element: n,
            name: r
        } = this;
        if (!n || !n.current) return;
        super.readKeyframes();
        for (let l = 0; l < t.length; l++) {
            let u = t[l];
            if (typeof u == "string" && (u = u.trim(), dg(u))) {
                const c = _T(u, n.current);
                c !== void 0 && (t[l] = c), l === t.length - 1 && (this.finalKeyframe = u)
            }
        }
        if (this.resolveNoneKeyframes(), !ZC.has(r) || t.length !== 2) return;
        const [i, s] = t, o = $v(i), a = $v(s);
        if (o !== a)
            if (Bv(o) && Bv(a))
                for (let l = 0; l < t.length; l++) {
                    const u = t[l];
                    typeof u == "string" && (t[l] = parseFloat(u))
                } else this.needsMeasurement = !0
    }
    resolveNoneKeyframes() {
        const {
            unresolvedKeyframes: t,
            name: n
        } = this, r = [];
        for (let i = 0; i < t.length; i++) wN(t[i]) && r.push(i);
        r.length && IN(t, r, n)
    }
    measureInitialState() {
        const {
            element: t,
            unresolvedKeyframes: n,
            name: r
        } = this;
        if (!t || !t.current) return;
        r === "height" && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = vo[r](t.measureViewportBox(), window.getComputedStyle(t.current)), n[0] = this.measuredOrigin;
        const i = n[n.length - 1];
        i !== void 0 && t.getValue(r, i).jump(i, !1)
    }
    measureEndState() {
        var t;
        const {
            element: n,
            name: r,
            unresolvedKeyframes: i
        } = this;
        if (!n || !n.current) return;
        const s = n.getValue(r);
        s && s.jump(this.measuredOrigin, !1);
        const o = i.length - 1,
            a = i[o];
        i[o] = vo[r](n.measureViewportBox(), window.getComputedStyle(n.current)), a !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = a), !((t = this.removedTransforms) === null || t === void 0) && t.length && this.removedTransforms.forEach(([l, u]) => {
            n.getValue(l).set(u)
        }), this.resolveNoneKeyframes()
    }
}
const Wv = (e, t) => t === "zIndex" ? !1 : !!(typeof e == "number" || Array.isArray(e) || typeof e == "string" && (hi.test(e) || e === "0") && !e.startsWith("url("));

function KN(e) {
    const t = e[0];
    if (e.length === 1) return !0;
    for (let n = 0; n < e.length; n++)
        if (e[n] !== t) return !0
}

function GN(e, t, n, r) {
    const i = e[0];
    if (i === null) return !1;
    if (t === "display" || t === "visibility") return !0;
    const s = e[e.length - 1],
        o = Wv(i, t),
        a = Wv(s, t);
    return !o || !a ? !1 : KN(e) || (n === "spring" || Sg(n)) && r
}
const YN = e => e !== null;

function Cf(e, {
    repeat: t,
    repeatType: n = "loop"
}, r) {
    const i = e.filter(YN),
        s = t && n !== "loop" && t % 2 === 1 ? 0 : i.length - 1;
    return !s || r === void 0 ? i[s] : r
}
const XN = 40;
class TT {
    constructor({
        autoplay: t = !0,
        delay: n = 0,
        type: r = "keyframes",
        repeat: i = 0,
        repeatDelay: s = 0,
        repeatType: o = "loop",
        ...a
    }) {
        this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = ur.now(), this.options = {
            autoplay: t,
            delay: n,
            type: r,
            repeat: i,
            repeatDelay: s,
            repeatType: o,
            ...a
        }, this.updateFinishedPromise()
    }
    calcStartTime() {
        return this.resolvedAt ? this.resolvedAt - this.createdAt > XN ? this.resolvedAt : this.createdAt : this.createdAt
    }
    get resolved() {
        return !this._resolved && !this.hasAttemptedResolve && UN(), this._resolved
    }
    onKeyframesResolved(t, n) {
        this.resolvedAt = ur.now(), this.hasAttemptedResolve = !0;
        const {
            name: r,
            type: i,
            velocity: s,
            delay: o,
            onComplete: a,
            onUpdate: l,
            isGenerator: u
        } = this.options;
        if (!u && !GN(t, r, i, s))
            if (o) this.options.duration = 0;
            else {
                l && l(Cf(t, this.options, n)), a && a(), this.resolveFinishedPromise();
                return
            }
        const c = this.initPlayback(t, n);
        c !== !1 && (this._resolved = {
            keyframes: t,
            finalKeyframe: n,
            ...c
        }, this.onPostResolved())
    }
    onPostResolved() {}
    then(t, n) {
        return this.currentFinishedPromise.then(t, n)
    }
    flatten() {
        this.options.type = "keyframes", this.options.ease = "linear"
    }
    updateFinishedPromise() {
        this.currentFinishedPromise = new Promise(t => {
            this.resolveFinishedPromise = t
        })
    }
}
const Be = (e, t, n) => e + (t - e) * n;

function Sd(e, t, n) {
    return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e
}

function qN({
    hue: e,
    saturation: t,
    lightness: n,
    alpha: r
}) {
    e /= 360, t /= 100, n /= 100;
    let i = 0,
        s = 0,
        o = 0;
    if (!t) i = s = o = n;
    else {
        const a = n < .5 ? n * (1 + t) : n + t - n * t,
            l = 2 * n - a;
        i = Sd(l, a, e + 1 / 3), s = Sd(l, a, e), o = Sd(l, a, e - 1 / 3)
    }
    return {
        red: Math.round(i * 255),
        green: Math.round(s * 255),
        blue: Math.round(o * 255),
        alpha: r
    }
}

function _c(e, t) {
    return n => n > 0 ? t : e
}
const Cd = (e, t, n) => {
        const r = e * e,
            i = n * (t * t - r) + r;
        return i < 0 ? 0 : Math.sqrt(i)
    },
    QN = [lp, Bi, Ns],
    JN = e => QN.find(t => t.test(e));

function Hv(e) {
    const t = JN(e);
    if (!t) return !1;
    let n = t.parse(e);
    return t === Ns && (n = qN(n)), n
}
const Kv = (e, t) => {
        const n = Hv(e),
            r = Hv(t);
        if (!n || !r) return _c(e, t);
        const i = { ...n
        };
        return s => (i.red = Cd(n.red, r.red, s), i.green = Cd(n.green, r.green, s), i.blue = Cd(n.blue, r.blue, s), i.alpha = Be(n.alpha, r.alpha, s), Bi.transform(i))
    },
    ZN = (e, t) => n => t(e(n)),
    wl = (...e) => e.reduce(ZN),
    dp = new Set(["none", "hidden"]);

function e5(e, t) {
    return dp.has(e) ? n => n <= 0 ? e : t : n => n >= 1 ? t : e
}

function t5(e, t) {
    return n => Be(e, t, n)
}

function Lg(e) {
    return typeof e == "number" ? t5 : typeof e == "string" ? dg(e) ? _c : Pt.test(e) ? Kv : i5 : Array.isArray(e) ? ET : typeof e == "object" ? Pt.test(e) ? Kv : n5 : _c
}

function ET(e, t) {
    const n = [...e],
        r = n.length,
        i = e.map((s, o) => Lg(s)(s, t[o]));
    return s => {
        for (let o = 0; o < r; o++) n[o] = i[o](s);
        return n
    }
}

function n5(e, t) {
    const n = { ...e,
            ...t
        },
        r = {};
    for (const i in n) e[i] !== void 0 && t[i] !== void 0 && (r[i] = Lg(e[i])(e[i], t[i]));
    return i => {
        for (const s in r) n[s] = r[s](i);
        return n
    }
}

function r5(e, t) {
    var n;
    const r = [],
        i = {
            color: 0,
            var: 0,
            number: 0
        };
    for (let s = 0; s < t.values.length; s++) {
        const o = t.types[s],
            a = e.indexes[o][i[o]],
            l = (n = e.values[a]) !== null && n !== void 0 ? n : 0;
        r[s] = l, i[o]++
    }
    return r
}
const i5 = (e, t) => {
    const n = hi.createTransformer(t),
        r = il(e),
        i = il(t);
    return r.indexes.var.length === i.indexes.var.length && r.indexes.color.length === i.indexes.color.length && r.indexes.number.length >= i.indexes.number.length ? dp.has(e) && !i.values.length || dp.has(t) && !r.values.length ? e5(e, t) : wl(ET(r5(r, i), i.values), n) : _c(e, t)
};

function PT(e, t, n) {
    return typeof e == "number" && typeof t == "number" && typeof n == "number" ? Be(e, t, n) : Lg(e)(e, t)
}
const s5 = 5;

function kT(e, t, n) {
    const r = Math.max(t - s5, 0);
    return eT(n - e(r), t - r)
}
const Ge = {
        stiffness: 100,
        damping: 10,
        mass: 1,
        velocity: 0,
        duration: 800,
        bounce: .3,
        visualDuration: .3,
        restSpeed: {
            granular: .01,
            default: 2
        },
        restDelta: {
            granular: .005,
            default: .5
        },
        minDuration: .01,
        maxDuration: 10,
        minDamping: .05,
        maxDamping: 1
    },
    Gv = .001;

function o5({
    duration: e = Ge.duration,
    bounce: t = Ge.bounce,
    velocity: n = Ge.velocity,
    mass: r = Ge.mass
}) {
    let i, s, o = 1 - t;
    o = Or(Ge.minDamping, Ge.maxDamping, o), e = Or(Ge.minDuration, Ge.maxDuration, Tr(e)), o < 1 ? (i = u => {
        const c = u * o,
            f = c * e,
            d = c - n,
            p = hp(u, o),
            m = Math.exp(-f);
        return Gv - d / p * m
    }, s = u => {
        const f = u * o * e,
            d = f * n + n,
            p = Math.pow(o, 2) * Math.pow(u, 2) * e,
            m = Math.exp(-f),
            h = hp(Math.pow(u, 2), o);
        return (-i(u) + Gv > 0 ? -1 : 1) * ((d - p) * m) / h
    }) : (i = u => {
        const c = Math.exp(-u * e),
            f = (u - n) * e + 1;
        return -.001 + c * f
    }, s = u => {
        const c = Math.exp(-u * e),
            f = (n - u) * (e * e);
        return c * f
    });
    const a = 5 / e,
        l = l5(i, s, a);
    if (e = Cr(e), isNaN(l)) return {
        stiffness: Ge.stiffness,
        damping: Ge.damping,
        duration: e
    }; {
        const u = Math.pow(l, 2) * r;
        return {
            stiffness: u,
            damping: o * 2 * Math.sqrt(r * u),
            duration: e
        }
    }
}
const a5 = 12;

function l5(e, t, n) {
    let r = n;
    for (let i = 1; i < a5; i++) r = r - e(r) / t(r);
    return r
}

function hp(e, t) {
    return e * Math.sqrt(1 - t * t)
}
const u5 = ["duration", "bounce"],
    c5 = ["stiffness", "damping", "mass"];

function Yv(e, t) {
    return t.some(n => e[n] !== void 0)
}

function f5(e) {
    let t = {
        velocity: Ge.velocity,
        stiffness: Ge.stiffness,
        damping: Ge.damping,
        mass: Ge.mass,
        isResolvedFromDuration: !1,
        ...e
    };
    if (!Yv(e, c5) && Yv(e, u5))
        if (e.visualDuration) {
            const n = e.visualDuration,
                r = 2 * Math.PI / (n * 1.2),
                i = r * r,
                s = 2 * Or(.05, 1, 1 - (e.bounce || 0)) * Math.sqrt(i);
            t = { ...t,
                mass: Ge.mass,
                stiffness: i,
                damping: s
            }
        } else {
            const n = o5(e);
            t = { ...t,
                ...n,
                mass: Ge.mass
            }, t.isResolvedFromDuration = !0
        }
    return t
}

function bT(e = Ge.visualDuration, t = Ge.bounce) {
    const n = typeof e != "object" ? {
        visualDuration: e,
        keyframes: [0, 1],
        bounce: t
    } : e;
    let {
        restSpeed: r,
        restDelta: i
    } = n;
    const s = n.keyframes[0],
        o = n.keyframes[n.keyframes.length - 1],
        a = {
            done: !1,
            value: s
        },
        {
            stiffness: l,
            damping: u,
            mass: c,
            duration: f,
            velocity: d,
            isResolvedFromDuration: p
        } = f5({ ...n,
            velocity: -Tr(n.velocity || 0)
        }),
        m = d || 0,
        h = u / (2 * Math.sqrt(l * c)),
        _ = o - s,
        v = Tr(Math.sqrt(l / c)),
        y = Math.abs(_) < 5;
    r || (r = y ? Ge.restSpeed.granular : Ge.restSpeed.default), i || (i = y ? Ge.restDelta.granular : Ge.restDelta.default);
    let x;
    if (h < 1) {
        const E = hp(v, h);
        x = k => {
            const S = Math.exp(-h * v * k);
            return o - S * ((m + h * v * _) / E * Math.sin(E * k) + _ * Math.cos(E * k))
        }
    } else if (h === 1) x = E => o - Math.exp(-v * E) * (_ + (m + v * _) * E);
    else {
        const E = v * Math.sqrt(h * h - 1);
        x = k => {
            const S = Math.exp(-h * v * k),
                P = Math.min(E * k, 300);
            return o - S * ((m + h * v * _) * Math.sinh(P) + E * _ * Math.cosh(P)) / E
        }
    }
    const T = {
        calculatedDuration: p && f || null,
        next: E => {
            const k = x(E);
            if (p) a.done = E >= f;
            else {
                let S = 0;
                h < 1 && (S = E === 0 ? Cr(m) : kT(x, E, k));
                const P = Math.abs(S) <= r,
                    A = Math.abs(o - k) <= i;
                a.done = P && A
            }
            return a.value = a.done ? o : k, a
        },
        toString: () => {
            const E = Math.min(KC(T), sp),
                k = GC(S => T.next(E * S).value, E, 30);
            return E + "ms " + k
        }
    };
    return T
}

function Xv({
    keyframes: e,
    velocity: t = 0,
    power: n = .8,
    timeConstant: r = 325,
    bounceDamping: i = 10,
    bounceStiffness: s = 500,
    modifyTarget: o,
    min: a,
    max: l,
    restDelta: u = .5,
    restSpeed: c
}) {
    const f = e[0],
        d = {
            done: !1,
            value: f
        },
        p = P => a !== void 0 && P < a || l !== void 0 && P > l,
        m = P => a === void 0 ? l : l === void 0 || Math.abs(a - P) < Math.abs(l - P) ? a : l;
    let h = n * t;
    const _ = f + h,
        v = o === void 0 ? _ : o(_);
    v !== _ && (h = v - f);
    const y = P => -h * Math.exp(-P / r),
        x = P => v + y(P),
        T = P => {
            const A = y(P),
                w = x(P);
            d.done = Math.abs(A) <= u, d.value = d.done ? v : w
        };
    let E, k;
    const S = P => {
        p(d.value) && (E = P, k = bT({
            keyframes: [d.value, m(d.value)],
            velocity: kT(x, P, d.value),
            damping: i,
            stiffness: s,
            restDelta: u,
            restSpeed: c
        }))
    };
    return S(0), {
        calculatedDuration: null,
        next: P => {
            let A = !1;
            return !k && E === void 0 && (A = !0, T(P), S(P)), E !== void 0 && P >= E ? k.next(P - E) : (!A && T(P), d)
        }
    }
}
const d5 = _l(.42, 0, 1, 1),
    h5 = _l(0, 0, .58, 1),
    RT = _l(.42, 0, .58, 1),
    p5 = e => Array.isArray(e) && typeof e[0] != "number",
    m5 = {
        linear: pn,
        easeIn: d5,
        easeInOut: RT,
        easeOut: h5,
        circIn: Rg,
        circInOut: uT,
        circOut: lT,
        backIn: bg,
        backInOut: oT,
        backOut: sT,
        anticipate: aT
    },
    qv = e => {
        if (Cg(e)) {
            kC(e.length === 4);
            const [t, n, r, i] = e;
            return _l(t, n, r, i)
        } else if (typeof e == "string") return m5[e];
        return e
    };

function g5(e, t, n) {
    const r = [],
        i = n || PT,
        s = e.length - 1;
    for (let o = 0; o < s; o++) {
        let a = i(e[o], e[o + 1]);
        if (t) {
            const l = Array.isArray(t) ? t[o] || pn : t;
            a = wl(l, a)
        }
        r.push(a)
    }
    return r
}

function y5(e, t, {
    clamp: n = !0,
    ease: r,
    mixer: i
} = {}) {
    const s = e.length;
    if (kC(s === t.length), s === 1) return () => t[0];
    if (s === 2 && t[0] === t[1]) return () => t[1];
    const o = e[0] === e[1];
    e[0] > e[s - 1] && (e = [...e].reverse(), t = [...t].reverse());
    const a = g5(t, r, i),
        l = a.length,
        u = c => {
            if (o && c < e[0]) return t[0];
            let f = 0;
            if (l > 1)
                for (; f < e.length - 2 && !(c < e[f + 1]); f++);
            const d = go(e[f], e[f + 1], c);
            return a[f](d)
        };
    return n ? c => u(Or(e[0], e[s - 1], c)) : u
}

function v5(e, t) {
    const n = e[e.length - 1];
    for (let r = 1; r <= t; r++) {
        const i = go(0, t, r);
        e.push(Be(n, 1, i))
    }
}

function x5(e) {
    const t = [0];
    return v5(t, e.length - 1), t
}

function _5(e, t) {
    return e.map(n => n * t)
}

function w5(e, t) {
    return e.map(() => t || RT).splice(0, e.length - 1)
}

function wc({
    duration: e = 300,
    keyframes: t,
    times: n,
    ease: r = "easeInOut"
}) {
    const i = p5(r) ? r.map(qv) : qv(r),
        s = {
            done: !1,
            value: t[0]
        },
        o = _5(n && n.length === t.length ? n : x5(t), e),
        a = y5(o, t, {
            ease: Array.isArray(i) ? i : w5(t, i)
        });
    return {
        calculatedDuration: e,
        next: l => (s.value = a(l), s.done = l >= e, s)
    }
}
const S5 = e => {
        const t = ({
            timestamp: n
        }) => e(n);
        return {
            start: () => Pe.update(t, !0),
            stop: () => di(t),
            now: () => yt.isProcessing ? yt.timestamp : ur.now()
        }
    },
    C5 = {
        decay: Xv,
        inertia: Xv,
        tween: wc,
        keyframes: wc,
        spring: bT
    },
    T5 = e => e / 100;
class Mg extends TT {
    constructor(t) {
        super(t), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
            if (this.resolver.cancel(), this.isStopped = !0, this.state === "idle") return;
            this.teardown();
            const {
                onStop: l
            } = this.options;
            l && l()
        };
        const {
            name: n,
            motionValue: r,
            element: i,
            keyframes: s
        } = this.options, o = (i == null ? void 0 : i.KeyframeResolver) || Og, a = (l, u) => this.onKeyframesResolved(l, u);
        this.resolver = new o(s, a, n, r, i), this.resolver.scheduleResolve()
    }
    flatten() {
        super.flatten(), this._resolved && Object.assign(this._resolved, this.initPlayback(this._resolved.keyframes))
    }
    initPlayback(t) {
        const {
            type: n = "keyframes",
            repeat: r = 0,
            repeatDelay: i = 0,
            repeatType: s,
            velocity: o = 0
        } = this.options, a = Sg(n) ? n : C5[n] || wc;
        let l, u;
        a !== wc && typeof t[0] != "number" && (l = wl(T5, PT(t[0], t[1])), t = [0, 100]);
        const c = a({ ...this.options,
            keyframes: t
        });
        s === "mirror" && (u = a({ ...this.options,
            keyframes: [...t].reverse(),
            velocity: -o
        })), c.calculatedDuration === null && (c.calculatedDuration = KC(c));
        const {
            calculatedDuration: f
        } = c, d = f + i, p = d * (r + 1) - i;
        return {
            generator: c,
            mirroredGenerator: u,
            mapPercentToKeyframes: l,
            calculatedDuration: f,
            resolvedDuration: d,
            totalDuration: p
        }
    }
    onPostResolved() {
        const {
            autoplay: t = !0
        } = this.options;
        this.play(), this.pendingPlayState === "paused" || !t ? this.pause() : this.state = this.pendingPlayState
    }
    tick(t, n = !1) {
        const {
            resolved: r
        } = this;
        if (!r) {
            const {
                keyframes: P
            } = this.options;
            return {
                done: !0,
                value: P[P.length - 1]
            }
        }
        const {
            finalKeyframe: i,
            generator: s,
            mirroredGenerator: o,
            mapPercentToKeyframes: a,
            keyframes: l,
            calculatedDuration: u,
            totalDuration: c,
            resolvedDuration: f
        } = r;
        if (this.startTime === null) return s.next(0);
        const {
            delay: d,
            repeat: p,
            repeatType: m,
            repeatDelay: h,
            onUpdate: _
        } = this.options;
        this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - c / this.speed, this.startTime)), n ? this.currentTime = t : this.holdTime !== null ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
        const v = this.currentTime - d * (this.speed >= 0 ? 1 : -1),
            y = this.speed >= 0 ? v < 0 : v > c;
        this.currentTime = Math.max(v, 0), this.state === "finished" && this.holdTime === null && (this.currentTime = c);
        let x = this.currentTime,
            T = s;
        if (p) {
            const P = Math.min(this.currentTime, c) / f;
            let A = Math.floor(P),
                w = P % 1;
            !w && P >= 1 && (w = 1), w === 1 && A--, A = Math.min(A, p + 1), !!(A % 2) && (m === "reverse" ? (w = 1 - w, h && (w -= h / f)) : m === "mirror" && (T = o)), x = Or(0, 1, w) * f
        }
        const E = y ? {
            done: !1,
            value: l[0]
        } : T.next(x);
        a && (E.value = a(E.value));
        let {
            done: k
        } = E;
        !y && u !== null && (k = this.speed >= 0 ? this.currentTime >= c : this.currentTime <= 0);
        const S = this.holdTime === null && (this.state === "finished" || this.state === "running" && k);
        return S && i !== void 0 && (E.value = Cf(l, this.options, i)), _ && _(E.value), S && this.finish(), E
    }
    get duration() {
        const {
            resolved: t
        } = this;
        return t ? Tr(t.calculatedDuration) : 0
    }
    get time() {
        return Tr(this.currentTime)
    }
    set time(t) {
        t = Cr(t), this.currentTime = t, this.holdTime !== null || this.speed === 0 ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
    }
    get speed() {
        return this.playbackSpeed
    }
    set speed(t) {
        const n = this.playbackSpeed !== t;
        this.playbackSpeed = t, n && (this.time = Tr(this.currentTime))
    }
    play() {
        if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
            this.pendingPlayState = "running";
            return
        }
        if (this.isStopped) return;
        const {
            driver: t = S5,
            onPlay: n,
            startTime: r
        } = this.options;
        this.driver || (this.driver = t(s => this.tick(s))), n && n();
        const i = this.driver.now();
        this.holdTime !== null ? this.startTime = i - this.holdTime : this.startTime ? this.state === "finished" && (this.startTime = i) : this.startTime = r ? ? this.calcStartTime(), this.state === "finished" && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
    }
    pause() {
        var t;
        if (!this._resolved) {
            this.pendingPlayState = "paused";
            return
        }
        this.state = "paused", this.holdTime = (t = this.currentTime) !== null && t !== void 0 ? t : 0
    }
    complete() {
        this.state !== "running" && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
    }
    finish() {
        this.teardown(), this.state = "finished";
        const {
            onComplete: t
        } = this.options;
        t && t()
    }
    cancel() {
        this.cancelTime !== null && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
    }
    teardown() {
        this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
    }
    stopDriver() {
        this.driver && (this.driver.stop(), this.driver = void 0)
    }
    sample(t) {
        return this.startTime = 0, this.tick(t, !0)
    }
}
const E5 = new Set(["opacity", "clipPath", "filter", "transform"]);

function P5(e, t, n, {
    delay: r = 0,
    duration: i = 300,
    repeat: s = 0,
    repeatType: o = "loop",
    ease: a = "easeInOut",
    times: l
} = {}) {
    const u = {
        [t]: n
    };
    l && (u.offset = l);
    const c = XC(a, i);
    return Array.isArray(c) && (u.easing = c), e.animate(u, {
        delay: r,
        duration: i,
        easing: Array.isArray(c) ? "linear" : c,
        fill: "both",
        iterations: s + 1,
        direction: o === "reverse" ? "alternate" : "normal"
    })
}
const k5 = og(() => Object.hasOwnProperty.call(Element.prototype, "animate")),
    Sc = 10,
    b5 = 2e4;

function R5(e) {
    return Sg(e.type) || e.type === "spring" || !YC(e.ease)
}

function A5(e, t) {
    const n = new Mg({ ...t,
        keyframes: e,
        repeat: 0,
        delay: 0,
        isGenerator: !0
    });
    let r = {
        done: !1,
        value: e[0]
    };
    const i = [];
    let s = 0;
    for (; !r.done && s < b5;) r = n.sample(s), i.push(r.value), s += Sc;
    return {
        times: void 0,
        keyframes: i,
        duration: s - Sc,
        ease: "linear"
    }
}
const AT = {
    anticipate: aT,
    backInOut: oT,
    circInOut: uT
};

function D5(e) {
    return e in AT
}
class Qv extends TT {
    constructor(t) {
        super(t);
        const {
            name: n,
            motionValue: r,
            element: i,
            keyframes: s
        } = this.options;
        this.resolver = new CT(s, (o, a) => this.onKeyframesResolved(o, a), n, r, i), this.resolver.scheduleResolve()
    }
    initPlayback(t, n) {
        let {
            duration: r = 300,
            times: i,
            ease: s,
            type: o,
            motionValue: a,
            name: l,
            startTime: u
        } = this.options;
        if (!a.owner || !a.owner.current) return !1;
        if (typeof s == "string" && xc() && D5(s) && (s = AT[s]), R5(this.options)) {
            const {
                onComplete: f,
                onUpdate: d,
                motionValue: p,
                element: m,
                ...h
            } = this.options, _ = A5(t, h);
            t = _.keyframes, t.length === 1 && (t[1] = t[0]), r = _.duration, i = _.times, s = _.ease, o = "keyframes"
        }
        const c = P5(a.owner.current, l, t, { ...this.options,
            duration: r,
            times: i,
            ease: s
        });
        return c.startTime = u ? ? this.calcStartTime(), this.pendingTimeline ? (Lv(c, this.pendingTimeline), this.pendingTimeline = void 0) : c.onfinish = () => {
            const {
                onComplete: f
            } = this.options;
            a.set(Cf(t, this.options, n)), f && f(), this.cancel(), this.resolveFinishedPromise()
        }, {
            animation: c,
            duration: r,
            times: i,
            type: o,
            ease: s,
            keyframes: t
        }
    }
    get duration() {
        const {
            resolved: t
        } = this;
        if (!t) return 0;
        const {
            duration: n
        } = t;
        return Tr(n)
    }
    get time() {
        const {
            resolved: t
        } = this;
        if (!t) return 0;
        const {
            animation: n
        } = t;
        return Tr(n.currentTime || 0)
    }
    set time(t) {
        const {
            resolved: n
        } = this;
        if (!n) return;
        const {
            animation: r
        } = n;
        r.currentTime = Cr(t)
    }
    get speed() {
        const {
            resolved: t
        } = this;
        if (!t) return 1;
        const {
            animation: n
        } = t;
        return n.playbackRate
    }
    set speed(t) {
        const {
            resolved: n
        } = this;
        if (!n) return;
        const {
            animation: r
        } = n;
        r.playbackRate = t
    }
    get state() {
        const {
            resolved: t
        } = this;
        if (!t) return "idle";
        const {
            animation: n
        } = t;
        return n.playState
    }
    get startTime() {
        const {
            resolved: t
        } = this;
        if (!t) return null;
        const {
            animation: n
        } = t;
        return n.startTime
    }
    attachTimeline(t) {
        if (!this._resolved) this.pendingTimeline = t;
        else {
            const {
                resolved: n
            } = this;
            if (!n) return pn;
            const {
                animation: r
            } = n;
            Lv(r, t)
        }
        return pn
    }
    play() {
        if (this.isStopped) return;
        const {
            resolved: t
        } = this;
        if (!t) return;
        const {
            animation: n
        } = t;
        n.playState === "finished" && this.updateFinishedPromise(), n.play()
    }
    pause() {
        const {
            resolved: t
        } = this;
        if (!t) return;
        const {
            animation: n
        } = t;
        n.pause()
    }
    stop() {
        if (this.resolver.cancel(), this.isStopped = !0, this.state === "idle") return;
        this.resolveFinishedPromise(), this.updateFinishedPromise();
        const {
            resolved: t
        } = this;
        if (!t) return;
        const {
            animation: n,
            keyframes: r,
            duration: i,
            type: s,
            ease: o,
            times: a
        } = t;
        if (n.playState === "idle" || n.playState === "finished") return;
        if (this.time) {
            const {
                motionValue: u,
                onUpdate: c,
                onComplete: f,
                element: d,
                ...p
            } = this.options, m = new Mg({ ...p,
                keyframes: r,
                duration: i,
                type: s,
                ease: o,
                times: a,
                isGenerator: !0
            }), h = Cr(this.time);
            u.setWithVelocity(m.sample(h - Sc).value, m.sample(h).value, Sc)
        }
        const {
            onStop: l
        } = this.options;
        l && l(), this.cancel()
    }
    complete() {
        const {
            resolved: t
        } = this;
        t && t.animation.finish()
    }
    cancel() {
        const {
            resolved: t
        } = this;
        t && t.animation.cancel()
    }
    static supports(t) {
        const {
            motionValue: n,
            name: r,
            repeatDelay: i,
            repeatType: s,
            damping: o,
            type: a
        } = t;
        if (!n || !n.owner || !(n.owner.current instanceof HTMLElement)) return !1;
        const {
            onUpdate: l,
            transformTemplate: u
        } = n.owner.getProps();
        return k5() && r && E5.has(r) && !l && !u && !i && s !== "mirror" && o !== 0 && a !== "inertia"
    }
}
const j5 = {
        type: "spring",
        stiffness: 500,
        damping: 25,
        restSpeed: 10
    },
    O5 = e => ({
        type: "spring",
        stiffness: 550,
        damping: e === 0 ? 2 * Math.sqrt(550) : 30,
        restSpeed: 10
    }),
    L5 = {
        type: "keyframes",
        duration: .8
    },
    M5 = {
        type: "keyframes",
        ease: [.25, .1, .35, 1],
        duration: .3
    },
    N5 = (e, {
        keyframes: t
    }) => t.length > 2 ? L5 : ls.has(e) ? e.startsWith("scale") ? O5(t[1]) : j5 : M5;

function F5({
    when: e,
    delay: t,
    delayChildren: n,
    staggerChildren: r,
    staggerDirection: i,
    repeat: s,
    repeatType: o,
    repeatDelay: a,
    from: l,
    elapsed: u,
    ...c
}) {
    return !!Object.keys(c).length
}
const Ng = (e, t, n, r = {}, i, s) => o => {
    const a = wg(r, e) || {},
        l = a.delay || r.delay || 0;
    let {
        elapsed: u = 0
    } = r;
    u = u - Cr(l);
    let c = {
        keyframes: Array.isArray(n) ? n : [null, n],
        ease: "easeOut",
        velocity: t.getVelocity(),
        ...a,
        delay: -u,
        onUpdate: d => {
            t.set(d), a.onUpdate && a.onUpdate(d)
        },
        onComplete: () => {
            o(), a.onComplete && a.onComplete()
        },
        name: e,
        motionValue: t,
        element: s ? void 0 : i
    };
    F5(a) || (c = { ...c,
        ...N5(e, c)
    }), c.duration && (c.duration = Cr(c.duration)), c.repeatDelay && (c.repeatDelay = Cr(c.repeatDelay)), c.from !== void 0 && (c.keyframes[0] = c.from);
    let f = !1;
    if ((c.type === !1 || c.duration === 0 && !c.repeatDelay) && (c.duration = 0, c.delay === 0 && (f = !0)), f && !s && t.get() !== void 0) {
        const d = Cf(c.keyframes, a);
        if (d !== void 0) return Pe.update(() => {
            c.onUpdate(d), c.onComplete()
        }), new nN([])
    }
    return !s && Qv.supports(c) ? new Qv(c) : new Mg(c)
};

function I5({
    protectedKeys: e,
    needsAnimating: t
}, n) {
    const r = e.hasOwnProperty(n) && t[n] !== !0;
    return t[n] = !1, r
}

function DT(e, t, {
    delay: n = 0,
    transitionOverride: r,
    type: i
} = {}) {
    var s;
    let {
        transition: o = e.getDefaultTransition(),
        transitionEnd: a,
        ...l
    } = t;
    r && (o = r);
    const u = [],
        c = i && e.animationState && e.animationState.getState()[i];
    for (const f in l) {
        const d = e.getValue(f, (s = e.latestValues[f]) !== null && s !== void 0 ? s : null),
            p = l[f];
        if (p === void 0 || c && I5(c, f)) continue;
        const m = {
            delay: n,
            ...wg(o || {}, f)
        };
        let h = !1;
        if (window.MotionHandoffAnimation) {
            const v = tT(e);
            if (v) {
                const y = window.MotionHandoffAnimation(v, f, Pe);
                y !== null && (m.startTime = y, h = !0)
            }
        }
        ap(e, f), d.start(Ng(f, d, p, e.shouldReduceMotion && ZC.has(f) ? {
            type: !1
        } : m, e, h));
        const _ = d.animation;
        _ && u.push(_)
    }
    return a && Promise.all(u).then(() => {
        Pe.update(() => {
            a && gN(e, a)
        })
    }), u
}

function pp(e, t, n = {}) {
    var r;
    const i = nl(e, t, n.type === "exit" ? (r = e.presenceContext) === null || r === void 0 ? void 0 : r.custom : void 0);
    let {
        transition: s = e.getDefaultTransition() || {}
    } = i || {};
    n.transitionOverride && (s = n.transitionOverride);
    const o = i ? () => Promise.all(DT(e, i, n)) : () => Promise.resolve(),
        a = e.variantChildren && e.variantChildren.size ? (u = 0) => {
            const {
                delayChildren: c = 0,
                staggerChildren: f,
                staggerDirection: d
            } = s;
            return V5(e, t, c + u, f, d, n)
        } : () => Promise.resolve(),
        {
            when: l
        } = s;
    if (l) {
        const [u, c] = l === "beforeChildren" ? [o, a] : [a, o];
        return u().then(() => c())
    } else return Promise.all([o(), a(n.delay)])
}

function V5(e, t, n = 0, r = 0, i = 1, s) {
    const o = [],
        a = (e.variantChildren.size - 1) * r,
        l = i === 1 ? (u = 0) => u * r : (u = 0) => a - u * r;
    return Array.from(e.variantChildren).sort(B5).forEach((u, c) => {
        u.notify("AnimationStart", t), o.push(pp(u, t, { ...s,
            delay: n + l(c)
        }).then(() => u.notify("AnimationComplete", t)))
    }), Promise.all(o)
}

function B5(e, t) {
    return e.sortNodePosition(t)
}

function z5(e, t, n = {}) {
    e.notify("AnimationStart", t);
    let r;
    if (Array.isArray(t)) {
        const i = t.map(s => pp(e, s, n));
        r = Promise.all(i)
    } else if (typeof t == "string") r = pp(e, t, n);
    else {
        const i = typeof t == "function" ? nl(e, t, n.custom) : t;
        r = Promise.all(DT(e, i, n))
    }
    return r.then(() => {
        e.notify("AnimationComplete", t)
    })
}

function jT(e, t) {
    if (!Array.isArray(t)) return !1;
    const n = t.length;
    if (n !== e.length) return !1;
    for (let r = 0; r < n; r++)
        if (t[r] !== e[r]) return !1;
    return !0
}
const U5 = lg.length;

function OT(e) {
    if (!e) return;
    if (!e.isControllingVariants) {
        const n = e.parent ? OT(e.parent) || {} : {};
        return e.props.initial !== void 0 && (n.initial = e.props.initial), n
    }
    const t = {};
    for (let n = 0; n < U5; n++) {
        const r = lg[n],
            i = e.props[r];
        (Za(i) || i === !1) && (t[r] = i)
    }
    return t
}
const $5 = [...ag].reverse(),
    W5 = ag.length;

function H5(e) {
    return t => Promise.all(t.map(({
        animation: n,
        options: r
    }) => z5(e, n, r)))
}

function K5(e) {
    let t = H5(e),
        n = Jv(),
        r = !0;
    const i = l => (u, c) => {
        var f;
        const d = nl(e, c, l === "exit" ? (f = e.presenceContext) === null || f === void 0 ? void 0 : f.custom : void 0);
        if (d) {
            const {
                transition: p,
                transitionEnd: m,
                ...h
            } = d;
            u = { ...u,
                ...h,
                ...m
            }
        }
        return u
    };

    function s(l) {
        t = l(e)
    }

    function o(l) {
        const {
            props: u
        } = e, c = OT(e.parent) || {}, f = [], d = new Set;
        let p = {},
            m = 1 / 0;
        for (let _ = 0; _ < W5; _++) {
            const v = $5[_],
                y = n[v],
                x = u[v] !== void 0 ? u[v] : c[v],
                T = Za(x),
                E = v === l ? y.isActive : null;
            E === !1 && (m = _);
            let k = x === c[v] && x !== u[v] && T;
            if (k && r && e.manuallyAnimateOnMount && (k = !1), y.protectedKeys = { ...p
                }, !y.isActive && E === null || !x && !y.prevProp || wf(x) || typeof x == "boolean") continue;
            const S = G5(y.prevProp, x);
            let P = S || v === l && y.isActive && !k && T || _ > m && T,
                A = !1;
            const w = Array.isArray(x) ? x : [x];
            let O = w.reduce(i(v), {});
            E === !1 && (O = {});
            const {
                prevResolvedValues: F = {}
            } = y, V = { ...F,
                ...O
            }, W = q => {
                P = !0, d.has(q) && (A = !0, d.delete(q)), y.needsAnimating[q] = !0;
                const M = e.getValue(q);
                M && (M.liveStyle = !1)
            };
            for (const q in V) {
                const M = O[q],
                    B = F[q];
                if (p.hasOwnProperty(q)) continue;
                let H = !1;
                ip(M) && ip(B) ? H = !jT(M, B) : H = M !== B, H ? M != null ? W(q) : d.add(q) : M !== void 0 && d.has(q) ? W(q) : y.protectedKeys[q] = !0
            }
            y.prevProp = x, y.prevResolvedValues = O, y.isActive && (p = { ...p,
                ...O
            }), r && e.blockInitialAnimation && (P = !1), P && (!(k && S) || A) && f.push(...w.map(q => ({
                animation: q,
                options: {
                    type: v
                }
            })))
        }
        if (d.size) {
            const _ = {};
            if (typeof u.initial != "boolean") {
                const v = nl(e, Array.isArray(u.initial) ? u.initial[0] : u.initial);
                v && v.transition && (_.transition = v.transition)
            }
            d.forEach(v => {
                const y = e.getBaseTarget(v),
                    x = e.getValue(v);
                x && (x.liveStyle = !0), _[v] = y ? ? null
            }), f.push({
                animation: _
            })
        }
        let h = !!f.length;
        return r && (u.initial === !1 || u.initial === u.animate) && !e.manuallyAnimateOnMount && (h = !1), r = !1, h ? t(f) : Promise.resolve()
    }

    function a(l, u) {
        var c;
        if (n[l].isActive === u) return Promise.resolve();
        (c = e.variantChildren) === null || c === void 0 || c.forEach(d => {
            var p;
            return (p = d.animationState) === null || p === void 0 ? void 0 : p.setActive(l, u)
        }), n[l].isActive = u;
        const f = o(l);
        for (const d in n) n[d].protectedKeys = {};
        return f
    }
    return {
        animateChanges: o,
        setActive: a,
        setAnimateFunction: s,
        getState: () => n,
        reset: () => {
            n = Jv(), r = !0
        }
    }
}

function G5(e, t) {
    return typeof t == "string" ? t !== e : Array.isArray(t) ? !jT(t, e) : !1
}

function Pi(e = !1) {
    return {
        isActive: e,
        protectedKeys: {},
        needsAnimating: {},
        prevResolvedValues: {}
    }
}

function Jv() {
    return {
        animate: Pi(!0),
        whileInView: Pi(),
        whileHover: Pi(),
        whileTap: Pi(),
        whileDrag: Pi(),
        whileFocus: Pi(),
        exit: Pi()
    }
}
class _i {
    constructor(t) {
        this.isMounted = !1, this.node = t
    }
    update() {}
}
class Y5 extends _i {
    constructor(t) {
        super(t), t.animationState || (t.animationState = K5(t))
    }
    updateAnimationControlsSubscription() {
        const {
            animate: t
        } = this.node.getProps();
        wf(t) && (this.unmountControls = t.subscribe(this.node))
    }
    mount() {
        this.updateAnimationControlsSubscription()
    }
    update() {
        const {
            animate: t
        } = this.node.getProps(), {
            animate: n
        } = this.node.prevProps || {};
        t !== n && this.updateAnimationControlsSubscription()
    }
    unmount() {
        var t;
        this.node.animationState.reset(), (t = this.unmountControls) === null || t === void 0 || t.call(this)
    }
}
let X5 = 0;
class q5 extends _i {
    constructor() {
        super(...arguments), this.id = X5++
    }
    update() {
        if (!this.node.presenceContext) return;
        const {
            isPresent: t,
            onExitComplete: n
        } = this.node.presenceContext, {
            isPresent: r
        } = this.node.prevPresenceContext || {};
        if (!this.node.animationState || t === r) return;
        const i = this.node.animationState.setActive("exit", !t);
        n && !t && i.then(() => {
            n(this.id)
        })
    }
    mount() {
        const {
            register: t,
            onExitComplete: n
        } = this.node.presenceContext || {};
        n && n(this.id), t && (this.unmount = t(this.id))
    }
    unmount() {}
}
const Q5 = {
    animation: {
        Feature: Y5
    },
    exit: {
        Feature: q5
    }
};

function sl(e, t, n, r = {
    passive: !0
}) {
    return e.addEventListener(t, n, r), () => e.removeEventListener(t, n)
}

function Sl(e) {
    return {
        point: {
            x: e.pageX,
            y: e.pageY
        }
    }
}
const J5 = e => t => Tg(t) && e(t, Sl(t));

function xa(e, t, n, r) {
    return sl(e, t, J5(n), r)
}
const Zv = (e, t) => Math.abs(e - t);

function Z5(e, t) {
    const n = Zv(e.x, t.x),
        r = Zv(e.y, t.y);
    return Math.sqrt(n ** 2 + r ** 2)
}
class LT {
    constructor(t, n, {
        transformPagePoint: r,
        contextWindow: i,
        dragSnapToOrigin: s = !1
    } = {}) {
        if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                const f = Ed(this.lastMoveEventInfo, this.history),
                    d = this.startEvent !== null,
                    p = Z5(f.offset, {
                        x: 0,
                        y: 0
                    }) >= 3;
                if (!d && !p) return;
                const {
                    point: m
                } = f, {
                    timestamp: h
                } = yt;
                this.history.push({ ...m,
                    timestamp: h
                });
                const {
                    onStart: _,
                    onMove: v
                } = this.handlers;
                d || (_ && _(this.lastMoveEvent, f), this.startEvent = this.lastMoveEvent), v && v(this.lastMoveEvent, f)
            }, this.handlePointerMove = (f, d) => {
                this.lastMoveEvent = f, this.lastMoveEventInfo = Td(d, this.transformPagePoint), Pe.update(this.updatePoint, !0)
            }, this.handlePointerUp = (f, d) => {
                this.end();
                const {
                    onEnd: p,
                    onSessionEnd: m,
                    resumeAnimation: h
                } = this.handlers;
                if (this.dragSnapToOrigin && h && h(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                const _ = Ed(f.type === "pointercancel" ? this.lastMoveEventInfo : Td(d, this.transformPagePoint), this.history);
                this.startEvent && p && p(f, _), m && m(f, _)
            }, !Tg(t)) return;
        this.dragSnapToOrigin = s, this.handlers = n, this.transformPagePoint = r, this.contextWindow = i || window;
        const o = Sl(t),
            a = Td(o, this.transformPagePoint),
            {
                point: l
            } = a,
            {
                timestamp: u
            } = yt;
        this.history = [{ ...l,
            timestamp: u
        }];
        const {
            onSessionStart: c
        } = n;
        c && c(t, Ed(a, this.history)), this.removeListeners = wl(xa(this.contextWindow, "pointermove", this.handlePointerMove), xa(this.contextWindow, "pointerup", this.handlePointerUp), xa(this.contextWindow, "pointercancel", this.handlePointerUp))
    }
    updateHandlers(t) {
        this.handlers = t
    }
    end() {
        this.removeListeners && this.removeListeners(), di(this.updatePoint)
    }
}

function Td(e, t) {
    return t ? {
        point: t(e.point)
    } : e
}

function e1(e, t) {
    return {
        x: e.x - t.x,
        y: e.y - t.y
    }
}

function Ed({
    point: e
}, t) {
    return {
        point: e,
        delta: e1(e, MT(t)),
        offset: e1(e, eF(t)),
        velocity: tF(t, .1)
    }
}

function eF(e) {
    return e[0]
}

function MT(e) {
    return e[e.length - 1]
}

function tF(e, t) {
    if (e.length < 2) return {
        x: 0,
        y: 0
    };
    let n = e.length - 1,
        r = null;
    const i = MT(e);
    for (; n >= 0 && (r = e[n], !(i.timestamp - r.timestamp > Cr(t)));) n--;
    if (!r) return {
        x: 0,
        y: 0
    };
    const s = Tr(i.timestamp - r.timestamp);
    if (s === 0) return {
        x: 0,
        y: 0
    };
    const o = {
        x: (i.x - r.x) / s,
        y: (i.y - r.y) / s
    };
    return o.x === 1 / 0 && (o.x = 0), o.y === 1 / 0 && (o.y = 0), o
}
const NT = 1e-4,
    nF = 1 - NT,
    rF = 1 + NT,
    FT = .01,
    iF = 0 - FT,
    sF = 0 + FT;

function Ft(e) {
    return e.max - e.min
}

function oF(e, t, n) {
    return Math.abs(e - t) <= n
}

function t1(e, t, n, r = .5) {
    e.origin = r, e.originPoint = Be(t.min, t.max, e.origin), e.scale = Ft(n) / Ft(t), e.translate = Be(n.min, n.max, e.origin) - e.originPoint, (e.scale >= nF && e.scale <= rF || isNaN(e.scale)) && (e.scale = 1), (e.translate >= iF && e.translate <= sF || isNaN(e.translate)) && (e.translate = 0)
}

function _a(e, t, n, r) {
    t1(e.x, t.x, n.x, r ? r.originX : void 0), t1(e.y, t.y, n.y, r ? r.originY : void 0)
}

function n1(e, t, n) {
    e.min = n.min + t.min, e.max = e.min + Ft(t)
}

function aF(e, t, n) {
    n1(e.x, t.x, n.x), n1(e.y, t.y, n.y)
}

function r1(e, t, n) {
    e.min = t.min - n.min, e.max = e.min + Ft(t)
}

function wa(e, t, n) {
    r1(e.x, t.x, n.x), r1(e.y, t.y, n.y)
}

function lF(e, {
    min: t,
    max: n
}, r) {
    return t !== void 0 && e < t ? e = r ? Be(t, e, r.min) : Math.max(e, t) : n !== void 0 && e > n && (e = r ? Be(n, e, r.max) : Math.min(e, n)), e
}

function i1(e, t, n) {
    return {
        min: t !== void 0 ? e.min + t : void 0,
        max: n !== void 0 ? e.max + n - (e.max - e.min) : void 0
    }
}

function uF(e, {
    top: t,
    left: n,
    bottom: r,
    right: i
}) {
    return {
        x: i1(e.x, n, i),
        y: i1(e.y, t, r)
    }
}

function s1(e, t) {
    let n = t.min - e.min,
        r = t.max - e.max;
    return t.max - t.min < e.max - e.min && ([n, r] = [r, n]), {
        min: n,
        max: r
    }
}

function cF(e, t) {
    return {
        x: s1(e.x, t.x),
        y: s1(e.y, t.y)
    }
}

function fF(e, t) {
    let n = .5;
    const r = Ft(e),
        i = Ft(t);
    return i > r ? n = go(t.min, t.max - r, e.min) : r > i && (n = go(e.min, e.max - i, t.min)), Or(0, 1, n)
}

function dF(e, t) {
    const n = {};
    return t.min !== void 0 && (n.min = t.min - e.min), t.max !== void 0 && (n.max = t.max - e.min), n
}
const mp = .35;

function hF(e = mp) {
    return e === !1 ? e = 0 : e === !0 && (e = mp), {
        x: o1(e, "left", "right"),
        y: o1(e, "top", "bottom")
    }
}

function o1(e, t, n) {
    return {
        min: a1(e, t),
        max: a1(e, n)
    }
}

function a1(e, t) {
    return typeof e == "number" ? e : e[t] || 0
}
const l1 = () => ({
        translate: 0,
        scale: 1,
        origin: 0,
        originPoint: 0
    }),
    Fs = () => ({
        x: l1(),
        y: l1()
    }),
    u1 = () => ({
        min: 0,
        max: 0
    }),
    Qe = () => ({
        x: u1(),
        y: u1()
    });

function Cn(e) {
    return [e("x"), e("y")]
}

function IT({
    top: e,
    left: t,
    right: n,
    bottom: r
}) {
    return {
        x: {
            min: t,
            max: n
        },
        y: {
            min: e,
            max: r
        }
    }
}

function pF({
    x: e,
    y: t
}) {
    return {
        top: t.min,
        right: e.max,
        bottom: t.max,
        left: e.min
    }
}

function mF(e, t) {
    if (!t) return e;
    const n = t({
            x: e.left,
            y: e.top
        }),
        r = t({
            x: e.right,
            y: e.bottom
        });
    return {
        top: n.y,
        left: n.x,
        bottom: r.y,
        right: r.x
    }
}

function Pd(e) {
    return e === void 0 || e === 1
}

function gp({
    scale: e,
    scaleX: t,
    scaleY: n
}) {
    return !Pd(e) || !Pd(t) || !Pd(n)
}

function Ai(e) {
    return gp(e) || VT(e) || e.z || e.rotate || e.rotateX || e.rotateY || e.skewX || e.skewY
}

function VT(e) {
    return c1(e.x) || c1(e.y)
}

function c1(e) {
    return e && e !== "0%"
}

function Cc(e, t, n) {
    const r = e - n,
        i = t * r;
    return n + i
}

function f1(e, t, n, r, i) {
    return i !== void 0 && (e = Cc(e, i, r)), Cc(e, n, r) + t
}

function yp(e, t = 0, n = 1, r, i) {
    e.min = f1(e.min, t, n, r, i), e.max = f1(e.max, t, n, r, i)
}

function BT(e, {
    x: t,
    y: n
}) {
    yp(e.x, t.translate, t.scale, t.originPoint), yp(e.y, n.translate, n.scale, n.originPoint)
}
const d1 = .999999999999,
    h1 = 1.0000000000001;

function gF(e, t, n, r = !1) {
    const i = n.length;
    if (!i) return;
    t.x = t.y = 1;
    let s, o;
    for (let a = 0; a < i; a++) {
        s = n[a], o = s.projectionDelta;
        const {
            visualElement: l
        } = s.options;
        l && l.props.style && l.props.style.display === "contents" || (r && s.options.layoutScroll && s.scroll && s !== s.root && Vs(e, {
            x: -s.scroll.offset.x,
            y: -s.scroll.offset.y
        }), o && (t.x *= o.x.scale, t.y *= o.y.scale, BT(e, o)), r && Ai(s.latestValues) && Vs(e, s.latestValues))
    }
    t.x < h1 && t.x > d1 && (t.x = 1), t.y < h1 && t.y > d1 && (t.y = 1)
}

function Is(e, t) {
    e.min = e.min + t, e.max = e.max + t
}

function p1(e, t, n, r, i = .5) {
    const s = Be(e.min, e.max, i);
    yp(e, t, n, s, r)
}

function Vs(e, t) {
    p1(e.x, t.x, t.scaleX, t.scale, t.originX), p1(e.y, t.y, t.scaleY, t.scale, t.originY)
}

function zT(e, t) {
    return IT(mF(e.getBoundingClientRect(), t))
}

function yF(e, t, n) {
    const r = zT(e, n),
        {
            scroll: i
        } = t;
    return i && (Is(r.x, i.offset.x), Is(r.y, i.offset.y)), r
}
const UT = ({
        current: e
    }) => e ? e.ownerDocument.defaultView : null,
    vF = new WeakMap;
class xF {
    constructor(t) {
        this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
            x: 0,
            y: 0
        }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = Qe(), this.visualElement = t
    }
    start(t, {
        snapToCursor: n = !1
    } = {}) {
        const {
            presenceContext: r
        } = this.visualElement;
        if (r && r.isPresent === !1) return;
        const i = c => {
                const {
                    dragSnapToOrigin: f
                } = this.getProps();
                f ? this.pauseAnimation() : this.stopAnimation(), n && this.snapToCursor(Sl(c).point)
            },
            s = (c, f) => {
                const {
                    drag: d,
                    dragPropagation: p,
                    onDragStart: m
                } = this.getProps();
                if (d && !p && (this.openDragLock && this.openDragLock(), this.openDragLock = fN(d), !this.openDragLock)) return;
                this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), Cn(_ => {
                    let v = this.getAxisMotionValue(_).get() || 0;
                    if (lr.test(v)) {
                        const {
                            projection: y
                        } = this.visualElement;
                        if (y && y.layout) {
                            const x = y.layout.layoutBox[_];
                            x && (v = Ft(x) * (parseFloat(v) / 100))
                        }
                    }
                    this.originPoint[_] = v
                }), m && Pe.postRender(() => m(c, f)), ap(this.visualElement, "transform");
                const {
                    animationState: h
                } = this.visualElement;
                h && h.setActive("whileDrag", !0)
            },
            o = (c, f) => {
                const {
                    dragPropagation: d,
                    dragDirectionLock: p,
                    onDirectionLock: m,
                    onDrag: h
                } = this.getProps();
                if (!d && !this.openDragLock) return;
                const {
                    offset: _
                } = f;
                if (p && this.currentDirection === null) {
                    this.currentDirection = _F(_), this.currentDirection !== null && m && m(this.currentDirection);
                    return
                }
                this.updateAxis("x", f.point, _), this.updateAxis("y", f.point, _), this.visualElement.render(), h && h(c, f)
            },
            a = (c, f) => this.stop(c, f),
            l = () => Cn(c => {
                var f;
                return this.getAnimationState(c) === "paused" && ((f = this.getAxisMotionValue(c).animation) === null || f === void 0 ? void 0 : f.play())
            }),
            {
                dragSnapToOrigin: u
            } = this.getProps();
        this.panSession = new LT(t, {
            onSessionStart: i,
            onStart: s,
            onMove: o,
            onSessionEnd: a,
            resumeAnimation: l
        }, {
            transformPagePoint: this.visualElement.getTransformPagePoint(),
            dragSnapToOrigin: u,
            contextWindow: UT(this.visualElement)
        })
    }
    stop(t, n) {
        const r = this.isDragging;
        if (this.cancel(), !r) return;
        const {
            velocity: i
        } = n;
        this.startAnimation(i);
        const {
            onDragEnd: s
        } = this.getProps();
        s && Pe.postRender(() => s(t, n))
    }
    cancel() {
        this.isDragging = !1;
        const {
            projection: t,
            animationState: n
        } = this.visualElement;
        t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
        const {
            dragPropagation: r
        } = this.getProps();
        !r && this.openDragLock && (this.openDragLock(), this.openDragLock = null), n && n.setActive("whileDrag", !1)
    }
    updateAxis(t, n, r) {
        const {
            drag: i
        } = this.getProps();
        if (!r || !ru(t, i, this.currentDirection)) return;
        const s = this.getAxisMotionValue(t);
        let o = this.originPoint[t] + r[t];
        this.constraints && this.constraints[t] && (o = lF(o, this.constraints[t], this.elastic[t])), s.set(o)
    }
    resolveConstraints() {
        var t;
        const {
            dragConstraints: n,
            dragElastic: r
        } = this.getProps(), i = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : (t = this.visualElement.projection) === null || t === void 0 ? void 0 : t.layout, s = this.constraints;
        n && Ms(n) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : n && i ? this.constraints = uF(i.layoutBox, n) : this.constraints = !1, this.elastic = hF(r), s !== this.constraints && i && this.constraints && !this.hasMutatedConstraints && Cn(o => {
            this.constraints !== !1 && this.getAxisMotionValue(o) && (this.constraints[o] = dF(i.layoutBox[o], this.constraints[o]))
        })
    }
    resolveRefConstraints() {
        const {
            dragConstraints: t,
            onMeasureDragConstraints: n
        } = this.getProps();
        if (!t || !Ms(t)) return !1;
        const r = t.current,
            {
                projection: i
            } = this.visualElement;
        if (!i || !i.layout) return !1;
        const s = yF(r, i.root, this.visualElement.getTransformPagePoint());
        let o = cF(i.layout.layoutBox, s);
        if (n) {
            const a = n(pF(o));
            this.hasMutatedConstraints = !!a, a && (o = IT(a))
        }
        return o
    }
    startAnimation(t) {
        const {
            drag: n,
            dragMomentum: r,
            dragElastic: i,
            dragTransition: s,
            dragSnapToOrigin: o,
            onDragTransitionEnd: a
        } = this.getProps(), l = this.constraints || {}, u = Cn(c => {
            if (!ru(c, n, this.currentDirection)) return;
            let f = l && l[c] || {};
            o && (f = {
                min: 0,
                max: 0
            });
            const d = i ? 200 : 1e6,
                p = i ? 40 : 1e7,
                m = {
                    type: "inertia",
                    velocity: r ? t[c] : 0,
                    bounceStiffness: d,
                    bounceDamping: p,
                    timeConstant: 750,
                    restDelta: 1,
                    restSpeed: 10,
                    ...s,
                    ...f
                };
            return this.startAxisValueAnimation(c, m)
        });
        return Promise.all(u).then(a)
    }
    startAxisValueAnimation(t, n) {
        const r = this.getAxisMotionValue(t);
        return ap(this.visualElement, t), r.start(Ng(t, r, 0, n, this.visualElement, !1))
    }
    stopAnimation() {
        Cn(t => this.getAxisMotionValue(t).stop())
    }
    pauseAnimation() {
        Cn(t => {
            var n;
            return (n = this.getAxisMotionValue(t).animation) === null || n === void 0 ? void 0 : n.pause()
        })
    }
    getAnimationState(t) {
        var n;
        return (n = this.getAxisMotionValue(t).animation) === null || n === void 0 ? void 0 : n.state
    }
    getAxisMotionValue(t) {
        const n = `_drag${t.toUpperCase()}`,
            r = this.visualElement.getProps(),
            i = r[n];
        return i || this.visualElement.getValue(t, (r.initial ? r.initial[t] : void 0) || 0)
    }
    snapToCursor(t) {
        Cn(n => {
            const {
                drag: r
            } = this.getProps();
            if (!ru(n, r, this.currentDirection)) return;
            const {
                projection: i
            } = this.visualElement, s = this.getAxisMotionValue(n);
            if (i && i.layout) {
                const {
                    min: o,
                    max: a
                } = i.layout.layoutBox[n];
                s.set(t[n] - Be(o, a, .5))
            }
        })
    }
    scalePositionWithinConstraints() {
        if (!this.visualElement.current) return;
        const {
            drag: t,
            dragConstraints: n
        } = this.getProps(), {
            projection: r
        } = this.visualElement;
        if (!Ms(n) || !r || !this.constraints) return;
        this.stopAnimation();
        const i = {
            x: 0,
            y: 0
        };
        Cn(o => {
            const a = this.getAxisMotionValue(o);
            if (a && this.constraints !== !1) {
                const l = a.get();
                i[o] = fF({
                    min: l,
                    max: l
                }, this.constraints[o])
            }
        });
        const {
            transformTemplate: s
        } = this.visualElement.getProps();
        this.visualElement.current.style.transform = s ? s({}, "") : "none", r.root && r.root.updateScroll(), r.updateLayout(), this.resolveConstraints(), Cn(o => {
            if (!ru(o, t, null)) return;
            const a = this.getAxisMotionValue(o),
                {
                    min: l,
                    max: u
                } = this.constraints[o];
            a.set(Be(l, u, i[o]))
        })
    }
    addListeners() {
        if (!this.visualElement.current) return;
        vF.set(this.visualElement, this);
        const t = this.visualElement.current,
            n = xa(t, "pointerdown", l => {
                const {
                    drag: u,
                    dragListener: c = !0
                } = this.getProps();
                u && c && this.start(l)
            }),
            r = () => {
                const {
                    dragConstraints: l
                } = this.getProps();
                Ms(l) && l.current && (this.constraints = this.resolveRefConstraints())
            },
            {
                projection: i
            } = this.visualElement,
            s = i.addEventListener("measure", r);
        i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), Pe.read(r);
        const o = sl(window, "resize", () => this.scalePositionWithinConstraints()),
            a = i.addEventListener("didUpdate", ({
                delta: l,
                hasLayoutChanged: u
            }) => {
                this.isDragging && u && (Cn(c => {
                    const f = this.getAxisMotionValue(c);
                    f && (this.originPoint[c] += l[c].translate, f.set(f.get() + l[c].translate))
                }), this.visualElement.render())
            });
        return () => {
            o(), n(), s(), a && a()
        }
    }
    getProps() {
        const t = this.visualElement.getProps(),
            {
                drag: n = !1,
                dragDirectionLock: r = !1,
                dragPropagation: i = !1,
                dragConstraints: s = !1,
                dragElastic: o = mp,
                dragMomentum: a = !0
            } = t;
        return { ...t,
            drag: n,
            dragDirectionLock: r,
            dragPropagation: i,
            dragConstraints: s,
            dragElastic: o,
            dragMomentum: a
        }
    }
}

function ru(e, t, n) {
    return (t === !0 || t === e) && (n === null || n === e)
}

function _F(e, t = 10) {
    let n = null;
    return Math.abs(e.y) > t ? n = "y" : Math.abs(e.x) > t && (n = "x"), n
}
class wF extends _i {
    constructor(t) {
        super(t), this.removeGroupControls = pn, this.removeListeners = pn, this.controls = new xF(t)
    }
    mount() {
        const {
            dragControls: t
        } = this.node.getProps();
        t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || pn
    }
    unmount() {
        this.removeGroupControls(), this.removeListeners()
    }
}
const m1 = e => (t, n) => {
    e && Pe.postRender(() => e(t, n))
};
class SF extends _i {
    constructor() {
        super(...arguments), this.removePointerDownListener = pn
    }
    onPointerDown(t) {
        this.session = new LT(t, this.createPanHandlers(), {
            transformPagePoint: this.node.getTransformPagePoint(),
            contextWindow: UT(this.node)
        })
    }
    createPanHandlers() {
        const {
            onPanSessionStart: t,
            onPanStart: n,
            onPan: r,
            onPanEnd: i
        } = this.node.getProps();
        return {
            onSessionStart: m1(t),
            onStart: m1(n),
            onMove: r,
            onEnd: (s, o) => {
                delete this.session, i && Pe.postRender(() => i(s, o))
            }
        }
    }
    mount() {
        this.removePointerDownListener = xa(this.node.current, "pointerdown", t => this.onPointerDown(t))
    }
    update() {
        this.session && this.session.updateHandlers(this.createPanHandlers())
    }
    unmount() {
        this.removePointerDownListener(), this.session && this.session.end()
    }
}
const Au = {
    hasAnimatedSinceResize: !0,
    hasEverUpdated: !1
};

function g1(e, t) {
    return t.max === t.min ? 0 : e / (t.max - t.min) * 100
}
const Ko = {
        correct: (e, t) => {
            if (!t.target) return e;
            if (typeof e == "string")
                if (Q.test(e)) e = parseFloat(e);
                else return e;
            const n = g1(e, t.target.x),
                r = g1(e, t.target.y);
            return `${n}% ${r}%`
        }
    },
    CF = {
        correct: (e, {
            treeScale: t,
            projectionDelta: n
        }) => {
            const r = e,
                i = hi.parse(e);
            if (i.length > 5) return r;
            const s = hi.createTransformer(e),
                o = typeof i[0] != "number" ? 1 : 0,
                a = n.x.scale * t.x,
                l = n.y.scale * t.y;
            i[0 + o] /= a, i[1 + o] /= l;
            const u = Be(a, l, .5);
            return typeof i[2 + o] == "number" && (i[2 + o] /= u), typeof i[3 + o] == "number" && (i[3 + o] /= u), s(i)
        }
    };
class TF extends C.Component {
    componentDidMount() {
        const {
            visualElement: t,
            layoutGroup: n,
            switchLayoutGroup: r,
            layoutId: i
        } = this.props, {
            projection: s
        } = t;
        RM(EF), s && (n.group && n.group.add(s), r && r.register && i && r.register(s), s.root.didUpdate(), s.addEventListener("animationComplete", () => {
            this.safeToRemove()
        }), s.setOptions({ ...s.options,
            onExitComplete: () => this.safeToRemove()
        })), Au.hasEverUpdated = !0
    }
    getSnapshotBeforeUpdate(t) {
        const {
            layoutDependency: n,
            visualElement: r,
            drag: i,
            isPresent: s
        } = this.props, o = r.projection;
        return o && (o.isPresent = s, i || t.layoutDependency !== n || n === void 0 ? o.willUpdate() : this.safeToRemove(), t.isPresent !== s && (s ? o.promote() : o.relegate() || Pe.postRender(() => {
            const a = o.getStack();
            (!a || !a.members.length) && this.safeToRemove()
        }))), null
    }
    componentDidUpdate() {
        const {
            projection: t
        } = this.props.visualElement;
        t && (t.root.didUpdate(), cg.postRender(() => {
            !t.currentAnimation && t.isLead() && this.safeToRemove()
        }))
    }
    componentWillUnmount() {
        const {
            visualElement: t,
            layoutGroup: n,
            switchLayoutGroup: r
        } = this.props, {
            projection: i
        } = t;
        i && (i.scheduleCheckAfterUnmount(), n && n.group && n.group.remove(i), r && r.deregister && r.deregister(i))
    }
    safeToRemove() {
        const {
            safeToRemove: t
        } = this.props;
        t && t()
    }
    render() {
        return null
    }
}

function $T(e) {
    const [t, n] = oM(), r = C.useContext(EC);
    return g.jsx(TF, { ...e,
        layoutGroup: r,
        switchLayoutGroup: C.useContext(OC),
        isPresent: t,
        safeToRemove: n
    })
}
const EF = {
    borderRadius: { ...Ko,
        applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
    },
    borderTopLeftRadius: Ko,
    borderTopRightRadius: Ko,
    borderBottomLeftRadius: Ko,
    borderBottomRightRadius: Ko,
    boxShadow: CF
};

function PF(e, t, n) {
    const r = Dt(e) ? e : rl(e);
    return r.start(Ng("", r, t, n)), r.animation
}

function kF(e) {
    return e instanceof SVGElement && e.tagName !== "svg"
}
const bF = (e, t) => e.depth - t.depth;
class RF {
    constructor() {
        this.children = [], this.isDirty = !1
    }
    add(t) {
        Eg(this.children, t), this.isDirty = !0
    }
    remove(t) {
        Pg(this.children, t), this.isDirty = !0
    }
    forEach(t) {
        this.isDirty && this.children.sort(bF), this.isDirty = !1, this.children.forEach(t)
    }
}

function AF(e, t) {
    const n = ur.now(),
        r = ({
            timestamp: i
        }) => {
            const s = i - n;
            s >= t && (di(r), e(s - t))
        };
    return Pe.read(r, !0), () => di(r)
}
const WT = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
    DF = WT.length,
    y1 = e => typeof e == "string" ? parseFloat(e) : e,
    v1 = e => typeof e == "number" || Q.test(e);

function jF(e, t, n, r, i, s) {
    i ? (e.opacity = Be(0, n.opacity !== void 0 ? n.opacity : 1, OF(r)), e.opacityExit = Be(t.opacity !== void 0 ? t.opacity : 1, 0, LF(r))) : s && (e.opacity = Be(t.opacity !== void 0 ? t.opacity : 1, n.opacity !== void 0 ? n.opacity : 1, r));
    for (let o = 0; o < DF; o++) {
        const a = `border${WT[o]}Radius`;
        let l = x1(t, a),
            u = x1(n, a);
        if (l === void 0 && u === void 0) continue;
        l || (l = 0), u || (u = 0), l === 0 || u === 0 || v1(l) === v1(u) ? (e[a] = Math.max(Be(y1(l), y1(u), r), 0), (lr.test(u) || lr.test(l)) && (e[a] += "%")) : e[a] = u
    }(t.rotate || n.rotate) && (e.rotate = Be(t.rotate || 0, n.rotate || 0, r))
}

function x1(e, t) {
    return e[t] !== void 0 ? e[t] : e.borderRadius
}
const OF = HT(0, .5, lT),
    LF = HT(.5, .95, pn);

function HT(e, t, n) {
    return r => r < e ? 0 : r > t ? 1 : n(go(e, t, r))
}

function _1(e, t) {
    e.min = t.min, e.max = t.max
}

function wn(e, t) {
    _1(e.x, t.x), _1(e.y, t.y)
}

function w1(e, t) {
    e.translate = t.translate, e.scale = t.scale, e.originPoint = t.originPoint, e.origin = t.origin
}

function S1(e, t, n, r, i) {
    return e -= t, e = Cc(e, 1 / n, r), i !== void 0 && (e = Cc(e, 1 / i, r)), e
}

function MF(e, t = 0, n = 1, r = .5, i, s = e, o = e) {
    if (lr.test(t) && (t = parseFloat(t), t = Be(o.min, o.max, t / 100) - o.min), typeof t != "number") return;
    let a = Be(s.min, s.max, r);
    e === s && (a -= t), e.min = S1(e.min, t, n, a, i), e.max = S1(e.max, t, n, a, i)
}

function C1(e, t, [n, r, i], s, o) {
    MF(e, t[n], t[r], t[i], t.scale, s, o)
}
const NF = ["x", "scaleX", "originX"],
    FF = ["y", "scaleY", "originY"];

function T1(e, t, n, r) {
    C1(e.x, t, NF, n ? n.x : void 0, r ? r.x : void 0), C1(e.y, t, FF, n ? n.y : void 0, r ? r.y : void 0)
}

function E1(e) {
    return e.translate === 0 && e.scale === 1
}

function KT(e) {
    return E1(e.x) && E1(e.y)
}

function P1(e, t) {
    return e.min === t.min && e.max === t.max
}

function IF(e, t) {
    return P1(e.x, t.x) && P1(e.y, t.y)
}

function k1(e, t) {
    return Math.round(e.min) === Math.round(t.min) && Math.round(e.max) === Math.round(t.max)
}

function GT(e, t) {
    return k1(e.x, t.x) && k1(e.y, t.y)
}

function b1(e) {
    return Ft(e.x) / Ft(e.y)
}

function R1(e, t) {
    return e.translate === t.translate && e.scale === t.scale && e.originPoint === t.originPoint
}
class VF {
    constructor() {
        this.members = []
    }
    add(t) {
        Eg(this.members, t), t.scheduleRender()
    }
    remove(t) {
        if (Pg(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
            const n = this.members[this.members.length - 1];
            n && this.promote(n)
        }
    }
    relegate(t) {
        const n = this.members.findIndex(i => t === i);
        if (n === 0) return !1;
        let r;
        for (let i = n; i >= 0; i--) {
            const s = this.members[i];
            if (s.isPresent !== !1) {
                r = s;
                break
            }
        }
        return r ? (this.promote(r), !0) : !1
    }
    promote(t, n) {
        const r = this.lead;
        if (t !== r && (this.prevLead = r, this.lead = t, t.show(), r)) {
            r.instance && r.scheduleRender(), t.scheduleRender(), t.resumeFrom = r, n && (t.resumeFrom.preserveOpacity = !0), r.snapshot && (t.snapshot = r.snapshot, t.snapshot.latestValues = r.animationValues || r.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
            const {
                crossfade: i
            } = t.options;
            i === !1 && r.hide()
        }
    }
    exitAnimationComplete() {
        this.members.forEach(t => {
            const {
                options: n,
                resumingFrom: r
            } = t;
            n.onExitComplete && n.onExitComplete(), r && r.options.onExitComplete && r.options.onExitComplete()
        })
    }
    scheduleRender() {
        this.members.forEach(t => {
            t.instance && t.scheduleRender(!1)
        })
    }
    removeLeadSnapshot() {
        this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
    }
}

function BF(e, t, n) {
    let r = "";
    const i = e.x.translate / t.x,
        s = e.y.translate / t.y,
        o = (n == null ? void 0 : n.z) || 0;
    if ((i || s || o) && (r = `translate3d(${i}px, ${s}px, ${o}px) `), (t.x !== 1 || t.y !== 1) && (r += `scale(${1/t.x}, ${1/t.y}) `), n) {
        const {
            transformPerspective: u,
            rotate: c,
            rotateX: f,
            rotateY: d,
            skewX: p,
            skewY: m
        } = n;
        u && (r = `perspective(${u}px) ${r}`), c && (r += `rotate(${c}deg) `), f && (r += `rotateX(${f}deg) `), d && (r += `rotateY(${d}deg) `), p && (r += `skewX(${p}deg) `), m && (r += `skewY(${m}deg) `)
    }
    const a = e.x.scale * t.x,
        l = e.y.scale * t.y;
    return (a !== 1 || l !== 1) && (r += `scale(${a}, ${l})`), r || "none"
}
const kd = ["", "X", "Y", "Z"],
    zF = {
        visibility: "hidden"
    },
    A1 = 1e3;
let UF = 0;

function bd(e, t, n, r) {
    const {
        latestValues: i
    } = t;
    i[e] && (n[e] = i[e], t.setStaticValue(e, 0), r && (r[e] = 0))
}

function YT(e) {
    if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
    const {
        visualElement: t
    } = e.options;
    if (!t) return;
    const n = tT(t);
    if (window.MotionHasOptimisedAnimation(n, "transform")) {
        const {
            layout: i,
            layoutId: s
        } = e.options;
        window.MotionCancelOptimisedAnimation(n, "transform", Pe, !(i || s))
    }
    const {
        parent: r
    } = e;
    r && !r.hasCheckedOptimisedAppear && YT(r)
}

function XT({
    attachResizeListener: e,
    defaultParent: t,
    measureScroll: n,
    checkIsScrollRoot: r,
    resetTransform: i
}) {
    return class {
        constructor(o = {}, a = t == null ? void 0 : t()) {
            this.id = UF++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                x: 1,
                y: 1
            }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
            }, this.updateProjection = () => {
                this.projectionUpdateScheduled = !1, this.nodes.forEach(HF), this.nodes.forEach(qF), this.nodes.forEach(QF), this.nodes.forEach(KF)
            }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = o, this.root = a ? a.root || a : this, this.path = a ? [...a.path, a] : [], this.parent = a, this.depth = a ? a.depth + 1 : 0;
            for (let l = 0; l < this.path.length; l++) this.path[l].shouldResetTransform = !0;
            this.root === this && (this.nodes = new RF)
        }
        addEventListener(o, a) {
            return this.eventHandlers.has(o) || this.eventHandlers.set(o, new kg), this.eventHandlers.get(o).add(a)
        }
        notifyListeners(o, ...a) {
            const l = this.eventHandlers.get(o);
            l && l.notify(...a)
        }
        hasListeners(o) {
            return this.eventHandlers.has(o)
        }
        mount(o, a = this.root.hasTreeAnimated) {
            if (this.instance) return;
            this.isSVG = kF(o), this.instance = o;
            const {
                layoutId: l,
                layout: u,
                visualElement: c
            } = this.options;
            if (c && !c.current && c.mount(o), this.root.nodes.add(this), this.parent && this.parent.children.add(this), a && (u || l) && (this.isLayoutDirty = !0), e) {
                let f;
                const d = () => this.root.updateBlockedByResize = !1;
                e(o, () => {
                    this.root.updateBlockedByResize = !0, f && f(), f = AF(d, 250), Au.hasAnimatedSinceResize && (Au.hasAnimatedSinceResize = !1, this.nodes.forEach(j1))
                })
            }
            l && this.root.registerSharedNode(l, this), this.options.animate !== !1 && c && (l || u) && this.addEventListener("didUpdate", ({
                delta: f,
                hasLayoutChanged: d,
                hasRelativeLayoutChanged: p,
                layout: m
            }) => {
                if (this.isTreeAnimationBlocked()) {
                    this.target = void 0, this.relativeTarget = void 0;
                    return
                }
                const h = this.options.transition || c.getDefaultTransition() || nI,
                    {
                        onLayoutAnimationStart: _,
                        onLayoutAnimationComplete: v
                    } = c.getProps(),
                    y = !this.targetLayout || !GT(this.targetLayout, m),
                    x = !d && p;
                if (this.options.layoutRoot || this.resumeFrom || x || d && (y || !this.currentAnimation)) {
                    this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(f, x);
                    const T = { ...wg(h, "layout"),
                        onPlay: _,
                        onComplete: v
                    };
                    (c.shouldReduceMotion || this.options.layoutRoot) && (T.delay = 0, T.type = !1), this.startAnimation(T)
                } else d || j1(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                this.targetLayout = m
            })
        }
        unmount() {
            this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
            const o = this.getStack();
            o && o.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, di(this.updateProjection)
        }
        blockUpdate() {
            this.updateManuallyBlocked = !0
        }
        unblockUpdate() {
            this.updateManuallyBlocked = !1
        }
        isUpdateBlocked() {
            return this.updateManuallyBlocked || this.updateBlockedByResize
        }
        isTreeAnimationBlocked() {
            return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
        }
        startUpdate() {
            this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(JF), this.animationId++)
        }
        getTransformTemplate() {
            const {
                visualElement: o
            } = this.options;
            return o && o.getProps().transformTemplate
        }
        willUpdate(o = !0) {
            if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                this.options.onExitComplete && this.options.onExitComplete();
                return
            }
            if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && YT(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
            this.isLayoutDirty = !0;
            for (let c = 0; c < this.path.length; c++) {
                const f = this.path[c];
                f.shouldResetTransform = !0, f.updateScroll("snapshot"), f.options.layoutRoot && f.willUpdate(!1)
            }
            const {
                layoutId: a,
                layout: l
            } = this.options;
            if (a === void 0 && !l) return;
            const u = this.getTransformTemplate();
            this.prevTransformTemplateValue = u ? u(this.latestValues, "") : void 0, this.updateSnapshot(), o && this.notifyListeners("willUpdate")
        }
        update() {
            if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(D1);
                return
            }
            this.isUpdating || this.nodes.forEach(YF), this.isUpdating = !1, this.nodes.forEach(XF), this.nodes.forEach($F), this.nodes.forEach(WF), this.clearAllSnapshots();
            const a = ur.now();
            yt.delta = Or(0, 1e3 / 60, a - yt.timestamp), yt.timestamp = a, yt.isProcessing = !0, xd.update.process(yt), xd.preRender.process(yt), xd.render.process(yt), yt.isProcessing = !1
        }
        didUpdate() {
            this.updateScheduled || (this.updateScheduled = !0, cg.read(this.scheduleUpdate))
        }
        clearAllSnapshots() {
            this.nodes.forEach(GF), this.sharedNodes.forEach(ZF)
        }
        scheduleUpdateProjection() {
            this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, Pe.preRender(this.updateProjection, !1, !0))
        }
        scheduleCheckAfterUnmount() {
            Pe.postRender(() => {
                this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
            })
        }
        updateSnapshot() {
            this.snapshot || !this.instance || (this.snapshot = this.measure(), this.snapshot && !Ft(this.snapshot.measuredBox.x) && !Ft(this.snapshot.measuredBox.y) && (this.snapshot = void 0))
        }
        updateLayout() {
            if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
            if (this.resumeFrom && !this.resumeFrom.instance)
                for (let l = 0; l < this.path.length; l++) this.path[l].updateScroll();
            const o = this.layout;
            this.layout = this.measure(!1), this.layoutCorrected = Qe(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
            const {
                visualElement: a
            } = this.options;
            a && a.notify("LayoutMeasure", this.layout.layoutBox, o ? o.layoutBox : void 0)
        }
        updateScroll(o = "measure") {
            let a = !!(this.options.layoutScroll && this.instance);
            if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === o && (a = !1), a) {
                const l = r(this.instance);
                this.scroll = {
                    animationId: this.root.animationId,
                    phase: o,
                    isRoot: l,
                    offset: n(this.instance),
                    wasRoot: this.scroll ? this.scroll.isRoot : l
                }
            }
        }
        resetTransform() {
            if (!i) return;
            const o = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                a = this.projectionDelta && !KT(this.projectionDelta),
                l = this.getTransformTemplate(),
                u = l ? l(this.latestValues, "") : void 0,
                c = u !== this.prevTransformTemplateValue;
            o && (a || Ai(this.latestValues) || c) && (i(this.instance, u), this.shouldResetTransform = !1, this.scheduleRender())
        }
        measure(o = !0) {
            const a = this.measurePageBox();
            let l = this.removeElementScroll(a);
            return o && (l = this.removeTransform(l)), rI(l), {
                animationId: this.root.animationId,
                measuredBox: a,
                layoutBox: l,
                latestValues: {},
                source: this.id
            }
        }
        measurePageBox() {
            var o;
            const {
                visualElement: a
            } = this.options;
            if (!a) return Qe();
            const l = a.measureViewportBox();
            if (!(((o = this.scroll) === null || o === void 0 ? void 0 : o.wasRoot) || this.path.some(iI))) {
                const {
                    scroll: c
                } = this.root;
                c && (Is(l.x, c.offset.x), Is(l.y, c.offset.y))
            }
            return l
        }
        removeElementScroll(o) {
            var a;
            const l = Qe();
            if (wn(l, o), !((a = this.scroll) === null || a === void 0) && a.wasRoot) return l;
            for (let u = 0; u < this.path.length; u++) {
                const c = this.path[u],
                    {
                        scroll: f,
                        options: d
                    } = c;
                c !== this.root && f && d.layoutScroll && (f.wasRoot && wn(l, o), Is(l.x, f.offset.x), Is(l.y, f.offset.y))
            }
            return l
        }
        applyTransform(o, a = !1) {
            const l = Qe();
            wn(l, o);
            for (let u = 0; u < this.path.length; u++) {
                const c = this.path[u];
                !a && c.options.layoutScroll && c.scroll && c !== c.root && Vs(l, {
                    x: -c.scroll.offset.x,
                    y: -c.scroll.offset.y
                }), Ai(c.latestValues) && Vs(l, c.latestValues)
            }
            return Ai(this.latestValues) && Vs(l, this.latestValues), l
        }
        removeTransform(o) {
            const a = Qe();
            wn(a, o);
            for (let l = 0; l < this.path.length; l++) {
                const u = this.path[l];
                if (!u.instance || !Ai(u.latestValues)) continue;
                gp(u.latestValues) && u.updateSnapshot();
                const c = Qe(),
                    f = u.measurePageBox();
                wn(c, f), T1(a, u.latestValues, u.snapshot ? u.snapshot.layoutBox : void 0, c)
            }
            return Ai(this.latestValues) && T1(a, this.latestValues), a
        }
        setTargetDelta(o) {
            this.targetDelta = o, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
        }
        setOptions(o) {
            this.options = { ...this.options,
                ...o,
                crossfade: o.crossfade !== void 0 ? o.crossfade : !0
            }
        }
        clearMeasurements() {
            this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
        }
        forceRelativeParentToResolveTarget() {
            this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== yt.timestamp && this.relativeParent.resolveTargetDelta(!0)
        }
        resolveTargetDelta(o = !1) {
            var a;
            const l = this.getLead();
            this.isProjectionDirty || (this.isProjectionDirty = l.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = l.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = l.isSharedProjectionDirty);
            const u = !!this.resumingFrom || this !== l;
            if (!(o || u && this.isSharedProjectionDirty || this.isProjectionDirty || !((a = this.parent) === null || a === void 0) && a.isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
            const {
                layout: f,
                layoutId: d
            } = this.options;
            if (!(!this.layout || !(f || d))) {
                if (this.resolvedRelativeTargetAt = yt.timestamp, !this.targetDelta && !this.relativeTarget) {
                    const p = this.getClosestProjectingParent();
                    p && p.layout && this.animationProgress !== 1 ? (this.relativeParent = p, this.forceRelativeParentToResolveTarget(), this.relativeTarget = Qe(), this.relativeTargetOrigin = Qe(), wa(this.relativeTargetOrigin, this.layout.layoutBox, p.layout.layoutBox), wn(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                }
                if (!(!this.relativeTarget && !this.targetDelta) && (this.target || (this.target = Qe(), this.targetWithTransforms = Qe()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), aF(this.target, this.relativeTarget, this.relativeParent.target)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : wn(this.target, this.layout.layoutBox), BT(this.target, this.targetDelta)) : wn(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget)) {
                    this.attemptToResolveRelativeTarget = !1;
                    const p = this.getClosestProjectingParent();
                    p && !!p.resumingFrom == !!this.resumingFrom && !p.options.layoutScroll && p.target && this.animationProgress !== 1 ? (this.relativeParent = p, this.forceRelativeParentToResolveTarget(), this.relativeTarget = Qe(), this.relativeTargetOrigin = Qe(), wa(this.relativeTargetOrigin, this.target, p.target), wn(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                }
            }
        }
        getClosestProjectingParent() {
            if (!(!this.parent || gp(this.parent.latestValues) || VT(this.parent.latestValues))) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
        }
        isProjecting() {
            return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
        }
        calcProjection() {
            var o;
            const a = this.getLead(),
                l = !!this.resumingFrom || this !== a;
            let u = !0;
            if ((this.isProjectionDirty || !((o = this.parent) === null || o === void 0) && o.isProjectionDirty) && (u = !1), l && (this.isSharedProjectionDirty || this.isTransformDirty) && (u = !1), this.resolvedRelativeTargetAt === yt.timestamp && (u = !1), u) return;
            const {
                layout: c,
                layoutId: f
            } = this.options;
            if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(c || f)) return;
            wn(this.layoutCorrected, this.layout.layoutBox);
            const d = this.treeScale.x,
                p = this.treeScale.y;
            gF(this.layoutCorrected, this.treeScale, this.path, l), a.layout && !a.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1) && (a.target = a.layout.layoutBox, a.targetWithTransforms = Qe());
            const {
                target: m
            } = a;
            if (!m) {
                this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                return
            }!this.projectionDelta || !this.prevProjectionDelta ? this.createProjectionDeltas() : (w1(this.prevProjectionDelta.x, this.projectionDelta.x), w1(this.prevProjectionDelta.y, this.projectionDelta.y)), _a(this.projectionDelta, this.layoutCorrected, m, this.latestValues), (this.treeScale.x !== d || this.treeScale.y !== p || !R1(this.projectionDelta.x, this.prevProjectionDelta.x) || !R1(this.projectionDelta.y, this.prevProjectionDelta.y)) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", m))
        }
        hide() {
            this.isVisible = !1
        }
        show() {
            this.isVisible = !0
        }
        scheduleRender(o = !0) {
            var a;
            if ((a = this.options.visualElement) === null || a === void 0 || a.scheduleRender(), o) {
                const l = this.getStack();
                l && l.scheduleRender()
            }
            this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
        }
        createProjectionDeltas() {
            this.prevProjectionDelta = Fs(), this.projectionDelta = Fs(), this.projectionDeltaWithTransform = Fs()
        }
        setAnimationOrigin(o, a = !1) {
            const l = this.snapshot,
                u = l ? l.latestValues : {},
                c = { ...this.latestValues
                },
                f = Fs();
            (!this.relativeParent || !this.relativeParent.options.layoutRoot) && (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !a;
            const d = Qe(),
                p = l ? l.source : void 0,
                m = this.layout ? this.layout.source : void 0,
                h = p !== m,
                _ = this.getStack(),
                v = !_ || _.members.length <= 1,
                y = !!(h && !v && this.options.crossfade === !0 && !this.path.some(tI));
            this.animationProgress = 0;
            let x;
            this.mixTargetDelta = T => {
                const E = T / 1e3;
                O1(f.x, o.x, E), O1(f.y, o.y, E), this.setTargetDelta(f), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (wa(d, this.layout.layoutBox, this.relativeParent.layout.layoutBox), eI(this.relativeTarget, this.relativeTargetOrigin, d, E), x && IF(this.relativeTarget, x) && (this.isProjectionDirty = !1), x || (x = Qe()), wn(x, this.relativeTarget)), h && (this.animationValues = c, jF(c, u, this.latestValues, E, y, v)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = E
            }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
        }
        startAnimation(o) {
            this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && (di(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = Pe.update(() => {
                Au.hasAnimatedSinceResize = !0, this.currentAnimation = PF(0, A1, { ...o,
                    onUpdate: a => {
                        this.mixTargetDelta(a), o.onUpdate && o.onUpdate(a)
                    },
                    onStop: () => {},
                    onComplete: () => {
                        o.onComplete && o.onComplete(), this.completeAnimation()
                    }
                }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
            })
        }
        completeAnimation() {
            this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
            const o = this.getStack();
            o && o.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
        }
        finishAnimation() {
            this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(A1), this.currentAnimation.stop()), this.completeAnimation()
        }
        applyTransformsToTarget() {
            const o = this.getLead();
            let {
                targetWithTransforms: a,
                target: l,
                layout: u,
                latestValues: c
            } = o;
            if (!(!a || !l || !u)) {
                if (this !== o && this.layout && u && qT(this.options.animationType, this.layout.layoutBox, u.layoutBox)) {
                    l = this.target || Qe();
                    const f = Ft(this.layout.layoutBox.x);
                    l.x.min = o.target.x.min, l.x.max = l.x.min + f;
                    const d = Ft(this.layout.layoutBox.y);
                    l.y.min = o.target.y.min, l.y.max = l.y.min + d
                }
                wn(a, l), Vs(a, c), _a(this.projectionDeltaWithTransform, this.layoutCorrected, a, c)
            }
        }
        registerSharedNode(o, a) {
            this.sharedNodes.has(o) || this.sharedNodes.set(o, new VF), this.sharedNodes.get(o).add(a);
            const u = a.options.initialPromotionConfig;
            a.promote({
                transition: u ? u.transition : void 0,
                preserveFollowOpacity: u && u.shouldPreserveFollowOpacity ? u.shouldPreserveFollowOpacity(a) : void 0
            })
        }
        isLead() {
            const o = this.getStack();
            return o ? o.lead === this : !0
        }
        getLead() {
            var o;
            const {
                layoutId: a
            } = this.options;
            return a ? ((o = this.getStack()) === null || o === void 0 ? void 0 : o.lead) || this : this
        }
        getPrevLead() {
            var o;
            const {
                layoutId: a
            } = this.options;
            return a ? (o = this.getStack()) === null || o === void 0 ? void 0 : o.prevLead : void 0
        }
        getStack() {
            const {
                layoutId: o
            } = this.options;
            if (o) return this.root.sharedNodes.get(o)
        }
        promote({
            needsReset: o,
            transition: a,
            preserveFollowOpacity: l
        } = {}) {
            const u = this.getStack();
            u && u.promote(this, l), o && (this.projectionDelta = void 0, this.needsReset = !0), a && this.setOptions({
                transition: a
            })
        }
        relegate() {
            const o = this.getStack();
            return o ? o.relegate(this) : !1
        }
        resetSkewAndRotation() {
            const {
                visualElement: o
            } = this.options;
            if (!o) return;
            let a = !1;
            const {
                latestValues: l
            } = o;
            if ((l.z || l.rotate || l.rotateX || l.rotateY || l.rotateZ || l.skewX || l.skewY) && (a = !0), !a) return;
            const u = {};
            l.z && bd("z", o, u, this.animationValues);
            for (let c = 0; c < kd.length; c++) bd(`rotate${kd[c]}`, o, u, this.animationValues), bd(`skew${kd[c]}`, o, u, this.animationValues);
            o.render();
            for (const c in u) o.setStaticValue(c, u[c]), this.animationValues && (this.animationValues[c] = u[c]);
            o.scheduleRender()
        }
        getProjectionStyles(o) {
            var a, l;
            if (!this.instance || this.isSVG) return;
            if (!this.isVisible) return zF;
            const u = {
                    visibility: ""
                },
                c = this.getTransformTemplate();
            if (this.needsReset) return this.needsReset = !1, u.opacity = "", u.pointerEvents = bu(o == null ? void 0 : o.pointerEvents) || "", u.transform = c ? c(this.latestValues, "") : "none", u;
            const f = this.getLead();
            if (!this.projectionDelta || !this.layout || !f.target) {
                const h = {};
                return this.options.layoutId && (h.opacity = this.latestValues.opacity !== void 0 ? this.latestValues.opacity : 1, h.pointerEvents = bu(o == null ? void 0 : o.pointerEvents) || ""), this.hasProjected && !Ai(this.latestValues) && (h.transform = c ? c({}, "") : "none", this.hasProjected = !1), h
            }
            const d = f.animationValues || f.latestValues;
            this.applyTransformsToTarget(), u.transform = BF(this.projectionDeltaWithTransform, this.treeScale, d), c && (u.transform = c(d, u.transform));
            const {
                x: p,
                y: m
            } = this.projectionDelta;
            u.transformOrigin = `${p.origin*100}% ${m.origin*100}% 0`, f.animationValues ? u.opacity = f === this ? (l = (a = d.opacity) !== null && a !== void 0 ? a : this.latestValues.opacity) !== null && l !== void 0 ? l : 1 : this.preserveOpacity ? this.latestValues.opacity : d.opacityExit : u.opacity = f === this ? d.opacity !== void 0 ? d.opacity : "" : d.opacityExit !== void 0 ? d.opacityExit : 0;
            for (const h in el) {
                if (d[h] === void 0) continue;
                const {
                    correct: _,
                    applyTo: v,
                    isCSSVariable: y
                } = el[h], x = u.transform === "none" ? d[h] : _(d[h], f);
                if (v) {
                    const T = v.length;
                    for (let E = 0; E < T; E++) u[v[E]] = x
                } else y ? this.options.visualElement.renderState.vars[h] = x : u[h] = x
            }
            return this.options.layoutId && (u.pointerEvents = f === this ? bu(o == null ? void 0 : o.pointerEvents) || "" : "none"), u
        }
        clearSnapshot() {
            this.resumeFrom = this.snapshot = void 0
        }
        resetTree() {
            this.root.nodes.forEach(o => {
                var a;
                return (a = o.currentAnimation) === null || a === void 0 ? void 0 : a.stop()
            }), this.root.nodes.forEach(D1), this.root.sharedNodes.clear()
        }
    }
}

function $F(e) {
    e.updateLayout()
}

function WF(e) {
    var t;
    const n = ((t = e.resumeFrom) === null || t === void 0 ? void 0 : t.snapshot) || e.snapshot;
    if (e.isLead() && e.layout && n && e.hasListeners("didUpdate")) {
        const {
            layoutBox: r,
            measuredBox: i
        } = e.layout, {
            animationType: s
        } = e.options, o = n.source !== e.layout.source;
        s === "size" ? Cn(f => {
            const d = o ? n.measuredBox[f] : n.layoutBox[f],
                p = Ft(d);
            d.min = r[f].min, d.max = d.min + p
        }) : qT(s, n.layoutBox, r) && Cn(f => {
            const d = o ? n.measuredBox[f] : n.layoutBox[f],
                p = Ft(r[f]);
            d.max = d.min + p, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[f].max = e.relativeTarget[f].min + p)
        });
        const a = Fs();
        _a(a, r, n.layoutBox);
        const l = Fs();
        o ? _a(l, e.applyTransform(i, !0), n.measuredBox) : _a(l, r, n.layoutBox);
        const u = !KT(a);
        let c = !1;
        if (!e.resumeFrom) {
            const f = e.getClosestProjectingParent();
            if (f && !f.resumeFrom) {
                const {
                    snapshot: d,
                    layout: p
                } = f;
                if (d && p) {
                    const m = Qe();
                    wa(m, n.layoutBox, d.layoutBox);
                    const h = Qe();
                    wa(h, r, p.layoutBox), GT(m, h) || (c = !0), f.options.layoutRoot && (e.relativeTarget = h, e.relativeTargetOrigin = m, e.relativeParent = f)
                }
            }
        }
        e.notifyListeners("didUpdate", {
            layout: r,
            snapshot: n,
            delta: l,
            layoutDelta: a,
            hasLayoutChanged: u,
            hasRelativeLayoutChanged: c
        })
    } else if (e.isLead()) {
        const {
            onExitComplete: r
        } = e.options;
        r && r()
    }
    e.options.transition = void 0
}

function HF(e) {
    e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty || (e.isSharedProjectionDirty = !!(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty)), e.isTransformDirty || (e.isTransformDirty = e.parent.isTransformDirty))
}

function KF(e) {
    e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1
}

function GF(e) {
    e.clearSnapshot()
}

function D1(e) {
    e.clearMeasurements()
}

function YF(e) {
    e.isLayoutDirty = !1
}

function XF(e) {
    const {
        visualElement: t
    } = e.options;
    t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform()
}

function j1(e) {
    e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0
}

function qF(e) {
    e.resolveTargetDelta()
}

function QF(e) {
    e.calcProjection()
}

function JF(e) {
    e.resetSkewAndRotation()
}

function ZF(e) {
    e.removeLeadSnapshot()
}

function O1(e, t, n) {
    e.translate = Be(t.translate, 0, n), e.scale = Be(t.scale, 1, n), e.origin = t.origin, e.originPoint = t.originPoint
}

function L1(e, t, n, r) {
    e.min = Be(t.min, n.min, r), e.max = Be(t.max, n.max, r)
}

function eI(e, t, n, r) {
    L1(e.x, t.x, n.x, r), L1(e.y, t.y, n.y, r)
}

function tI(e) {
    return e.animationValues && e.animationValues.opacityExit !== void 0
}
const nI = {
        duration: .45,
        ease: [.4, 0, .1, 1]
    },
    M1 = e => typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(e),
    N1 = M1("applewebkit/") && !M1("chrome/") ? Math.round : pn;

function F1(e) {
    e.min = N1(e.min), e.max = N1(e.max)
}

function rI(e) {
    F1(e.x), F1(e.y)
}

function qT(e, t, n) {
    return e === "position" || e === "preserve-aspect" && !oF(b1(t), b1(n), .2)
}

function iI(e) {
    var t;
    return e !== e.root && ((t = e.scroll) === null || t === void 0 ? void 0 : t.wasRoot)
}
const sI = XT({
        attachResizeListener: (e, t) => sl(e, "resize", t),
        measureScroll: () => ({
            x: document.documentElement.scrollLeft || document.body.scrollLeft,
            y: document.documentElement.scrollTop || document.body.scrollTop
        }),
        checkIsScrollRoot: () => !0
    }),
    Rd = {
        current: void 0
    },
    QT = XT({
        measureScroll: e => ({
            x: e.scrollLeft,
            y: e.scrollTop
        }),
        defaultParent: () => {
            if (!Rd.current) {
                const e = new sI({});
                e.mount(window), e.setOptions({
                    layoutScroll: !0
                }), Rd.current = e
            }
            return Rd.current
        },
        resetTransform: (e, t) => {
            e.style.transform = t !== void 0 ? t : "none"
        },
        checkIsScrollRoot: e => window.getComputedStyle(e).position === "fixed"
    }),
    oI = {
        pan: {
            Feature: SF
        },
        drag: {
            Feature: wF,
            ProjectionNode: QT,
            MeasureLayout: $T
        }
    };

function I1(e, t, n) {
    const {
        props: r
    } = e;
    e.animationState && r.whileHover && e.animationState.setActive("whileHover", n === "Start");
    const i = "onHover" + n,
        s = r[i];
    s && Pe.postRender(() => s(t, Sl(t)))
}
class aI extends _i {
    mount() {
        const {
            current: t
        } = this.node;
        t && (this.unmount = oN(t, (n, r) => (I1(this.node, r, "Start"), i => I1(this.node, i, "End"))))
    }
    unmount() {}
}
class lI extends _i {
    constructor() {
        super(...arguments), this.isActive = !1
    }
    onFocus() {
        let t = !1;
        try {
            t = this.node.current.matches(":focus-visible")
        } catch {
            t = !0
        }!t || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
    }
    onBlur() {
        !this.isActive || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
    }
    mount() {
        this.unmount = wl(sl(this.node.current, "focus", () => this.onFocus()), sl(this.node.current, "blur", () => this.onBlur()))
    }
    unmount() {}
}

function V1(e, t, n) {
    const {
        props: r
    } = e;
    if (e.current instanceof HTMLButtonElement && e.current.disabled) return;
    e.animationState && r.whileTap && e.animationState.setActive("whileTap", n === "Start");
    const i = "onTap" + (n === "End" ? "" : n),
        s = r[i];
    s && Pe.postRender(() => s(t, Sl(t)))
}
class uI extends _i {
    mount() {
        const {
            current: t
        } = this.node;
        t && (this.unmount = cN(t, (n, r) => (V1(this.node, r, "Start"), (i, {
            success: s
        }) => V1(this.node, i, s ? "End" : "Cancel")), {
            useGlobalTarget: this.node.props.globalTapTarget
        }))
    }
    unmount() {}
}
const vp = new WeakMap,
    Ad = new WeakMap,
    cI = e => {
        const t = vp.get(e.target);
        t && t(e)
    },
    fI = e => {
        e.forEach(cI)
    };

function dI({
    root: e,
    ...t
}) {
    const n = e || document;
    Ad.has(n) || Ad.set(n, {});
    const r = Ad.get(n),
        i = JSON.stringify(t);
    return r[i] || (r[i] = new IntersectionObserver(fI, {
        root: e,
        ...t
    })), r[i]
}

function hI(e, t, n) {
    const r = dI(t);
    return vp.set(e, n), r.observe(e), () => {
        vp.delete(e), r.unobserve(e)
    }
}
const pI = {
    some: 0,
    all: 1
};
class mI extends _i {
    constructor() {
        super(...arguments), this.hasEnteredView = !1, this.isInView = !1
    }
    startObserver() {
        this.unmount();
        const {
            viewport: t = {}
        } = this.node.getProps(), {
            root: n,
            margin: r,
            amount: i = "some",
            once: s
        } = t, o = {
            root: n ? n.current : void 0,
            rootMargin: r,
            threshold: typeof i == "number" ? i : pI[i]
        }, a = l => {
            const {
                isIntersecting: u
            } = l;
            if (this.isInView === u || (this.isInView = u, s && !u && this.hasEnteredView)) return;
            u && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", u);
            const {
                onViewportEnter: c,
                onViewportLeave: f
            } = this.node.getProps(), d = u ? c : f;
            d && d(l)
        };
        return hI(this.node.current, o, a)
    }
    mount() {
        this.startObserver()
    }
    update() {
        if (typeof IntersectionObserver > "u") return;
        const {
            props: t,
            prevProps: n
        } = this.node;
        ["amount", "margin", "root"].some(gI(t, n)) && this.startObserver()
    }
    unmount() {}
}

function gI({
    viewport: e = {}
}, {
    viewport: t = {}
} = {}) {
    return n => e[n] !== t[n]
}
const yI = {
        inView: {
            Feature: mI
        },
        tap: {
            Feature: uI
        },
        focus: {
            Feature: lI
        },
        hover: {
            Feature: aI
        }
    },
    vI = {
        layout: {
            ProjectionNode: QT,
            MeasureLayout: $T
        }
    },
    xp = {
        current: null
    },
    JT = {
        current: !1
    };

function xI() {
    if (JT.current = !0, !!sg)
        if (window.matchMedia) {
            const e = window.matchMedia("(prefers-reduced-motion)"),
                t = () => xp.current = e.matches;
            e.addListener(t), t()
        } else xp.current = !1
}
const _I = [...ST, Pt, hi],
    wI = e => _I.find(wT(e)),
    SI = new WeakMap;

function CI(e, t, n) {
    for (const r in t) {
        const i = t[r],
            s = n[r];
        if (Dt(i)) e.addValue(r, i);
        else if (Dt(s)) e.addValue(r, rl(i, {
            owner: e
        }));
        else if (s !== i)
            if (e.hasValue(r)) {
                const o = e.getValue(r);
                o.liveStyle === !0 ? o.jump(i) : o.hasAnimated || o.set(i)
            } else {
                const o = e.getStaticValue(r);
                e.addValue(r, rl(o !== void 0 ? o : i, {
                    owner: e
                }))
            }
    }
    for (const r in n) t[r] === void 0 && e.removeValue(r);
    return t
}
const B1 = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
class TI {
    scrapeMotionValuesFromProps(t, n, r) {
        return {}
    }
    constructor({
        parent: t,
        props: n,
        presenceContext: r,
        reducedMotionConfig: i,
        blockInitialAnimation: s,
        visualState: o
    }, a = {}) {
        this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = Og, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
            this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
        }, this.renderScheduledAt = 0, this.scheduleRender = () => {
            const p = ur.now();
            this.renderScheduledAt < p && (this.renderScheduledAt = p, Pe.render(this.render, !1, !0))
        };
        const {
            latestValues: l,
            renderState: u,
            onUpdate: c
        } = o;
        this.onUpdate = c, this.latestValues = l, this.baseTarget = { ...l
        }, this.initialValues = n.initial ? { ...l
        } : {}, this.renderState = u, this.parent = t, this.props = n, this.presenceContext = r, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = i, this.options = a, this.blockInitialAnimation = !!s, this.isControllingVariants = Sf(n), this.isVariantNode = DC(n), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
        const {
            willChange: f,
            ...d
        } = this.scrapeMotionValuesFromProps(n, {}, this);
        for (const p in d) {
            const m = d[p];
            l[p] !== void 0 && Dt(m) && m.set(l[p], !1)
        }
    }
    mount(t) {
        this.current = t, SI.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((n, r) => this.bindToMotionValue(r, n)), JT.current || xI(), this.shouldReduceMotion = this.reducedMotionConfig === "never" ? !1 : this.reducedMotionConfig === "always" ? !0 : xp.current, this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
    }
    unmount() {
        this.projection && this.projection.unmount(), di(this.notifyUpdate), di(this.render), this.valueSubscriptions.forEach(t => t()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this);
        for (const t in this.events) this.events[t].clear();
        for (const t in this.features) {
            const n = this.features[t];
            n && (n.unmount(), n.isMounted = !1)
        }
        this.current = null
    }
    bindToMotionValue(t, n) {
        this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)();
        const r = ls.has(t);
        r && this.onBindTransform && this.onBindTransform();
        const i = n.on("change", a => {
                this.latestValues[t] = a, this.props.onUpdate && Pe.preRender(this.notifyUpdate), r && this.projection && (this.projection.isTransformDirty = !0)
            }),
            s = n.on("renderRequest", this.scheduleRender);
        let o;
        window.MotionCheckAppearSync && (o = window.MotionCheckAppearSync(this, t, n)), this.valueSubscriptions.set(t, () => {
            i(), s(), o && o(), n.owner && n.stop()
        })
    }
    sortNodePosition(t) {
        return !this.current || !this.sortInstanceNodePosition || this.type !== t.type ? 0 : this.sortInstanceNodePosition(this.current, t.current)
    }
    updateFeatures() {
        let t = "animation";
        for (t in yo) {
            const n = yo[t];
            if (!n) continue;
            const {
                isEnabled: r,
                Feature: i
            } = n;
            if (!this.features[t] && i && r(this.props) && (this.features[t] = new i(this)), this.features[t]) {
                const s = this.features[t];
                s.isMounted ? s.update() : (s.mount(), s.isMounted = !0)
            }
        }
    }
    triggerBuild() {
        this.build(this.renderState, this.latestValues, this.props)
    }
    measureViewportBox() {
        return this.current ? this.measureInstanceViewportBox(this.current, this.props) : Qe()
    }
    getStaticValue(t) {
        return this.latestValues[t]
    }
    setStaticValue(t, n) {
        this.latestValues[t] = n
    }
    update(t, n) {
        (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = n;
        for (let r = 0; r < B1.length; r++) {
            const i = B1[r];
            this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
            const s = "on" + i,
                o = t[s];
            o && (this.propEventSubscriptions[i] = this.on(i, o))
        }
        this.prevMotionValues = CI(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue(), this.onUpdate && this.onUpdate(this)
    }
    getProps() {
        return this.props
    }
    getVariant(t) {
        return this.props.variants ? this.props.variants[t] : void 0
    }
    getDefaultTransition() {
        return this.props.transition
    }
    getTransformPagePoint() {
        return this.props.transformPagePoint
    }
    getClosestVariantNode() {
        return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
    }
    addVariantChild(t) {
        const n = this.getClosestVariantNode();
        if (n) return n.variantChildren && n.variantChildren.add(t), () => n.variantChildren.delete(t)
    }
    addValue(t, n) {
        const r = this.values.get(t);
        n !== r && (r && this.removeValue(t), this.bindToMotionValue(t, n), this.values.set(t, n), this.latestValues[t] = n.get())
    }
    removeValue(t) {
        this.values.delete(t);
        const n = this.valueSubscriptions.get(t);
        n && (n(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
    }
    hasValue(t) {
        return this.values.has(t)
    }
    getValue(t, n) {
        if (this.props.values && this.props.values[t]) return this.props.values[t];
        let r = this.values.get(t);
        return r === void 0 && n !== void 0 && (r = rl(n === null ? void 0 : n, {
            owner: this
        }), this.addValue(t, r)), r
    }
    readValue(t, n) {
        var r;
        let i = this.latestValues[t] !== void 0 || !this.current ? this.latestValues[t] : (r = this.getBaseTargetFromProps(this.props, t)) !== null && r !== void 0 ? r : this.readValueFromInstance(this.current, t, this.options);
        return i != null && (typeof i == "string" && (xT(i) || cT(i)) ? i = parseFloat(i) : !wI(i) && hi.test(n) && (i = gT(t, n)), this.setBaseTarget(t, Dt(i) ? i.get() : i)), Dt(i) ? i.get() : i
    }
    setBaseTarget(t, n) {
        this.baseTarget[t] = n
    }
    getBaseTarget(t) {
        var n;
        const {
            initial: r
        } = this.props;
        let i;
        if (typeof r == "string" || typeof r == "object") {
            const o = xg(this.props, r, (n = this.presenceContext) === null || n === void 0 ? void 0 : n.custom);
            o && (i = o[t])
        }
        if (r && i !== void 0) return i;
        const s = this.getBaseTargetFromProps(this.props, t);
        return s !== void 0 && !Dt(s) ? s : this.initialValues[t] !== void 0 && i === void 0 ? void 0 : this.baseTarget[t]
    }
    on(t, n) {
        return this.events[t] || (this.events[t] = new kg), this.events[t].add(n)
    }
    notify(t, ...n) {
        this.events[t] && this.events[t].notify(...n)
    }
}
class ZT extends TI {
    constructor() {
        super(...arguments), this.KeyframeResolver = CT
    }
    sortInstanceNodePosition(t, n) {
        return t.compareDocumentPosition(n) & 2 ? 1 : -1
    }
    getBaseTargetFromProps(t, n) {
        return t.style ? t.style[n] : void 0
    }
    removeValueFromRenderState(t, {
        vars: n,
        style: r
    }) {
        delete n[t], delete r[t]
    }
    handleChildMotionValue() {
        this.childSubscription && (this.childSubscription(), delete this.childSubscription);
        const {
            children: t
        } = this.props;
        Dt(t) && (this.childSubscription = t.on("change", n => {
            this.current && (this.current.textContent = `${n}`)
        }))
    }
}

function EI(e) {
    return window.getComputedStyle(e)
}
class PI extends ZT {
    constructor() {
        super(...arguments), this.type = "html", this.renderInstance = UC
    }
    readValueFromInstance(t, n) {
        if (ls.has(n)) {
            const r = jg(n);
            return r && r.default || 0
        } else {
            const r = EI(t),
                i = (fg(n) ? r.getPropertyValue(n) : r[n]) || 0;
            return typeof i == "string" ? i.trim() : i
        }
    }
    measureInstanceViewportBox(t, {
        transformPagePoint: n
    }) {
        return zT(t, n)
    }
    build(t, n, r) {
        pg(t, n, r.transformTemplate)
    }
    scrapeMotionValuesFromProps(t, n, r) {
        return _g(t, n, r)
    }
}
class kI extends ZT {
    constructor() {
        super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = Qe, this.updateDimensions = () => {
            this.current && !this.renderState.dimensions && zC(this.current, this.renderState)
        }
    }
    getBaseTargetFromProps(t, n) {
        return t[n]
    }
    readValueFromInstance(t, n) {
        if (ls.has(n)) {
            const r = jg(n);
            return r && r.default || 0
        }
        return n = $C.has(n) ? n : ug(n), t.getAttribute(n)
    }
    scrapeMotionValuesFromProps(t, n, r) {
        return HC(t, n, r)
    }
    onBindTransform() {
        this.current && !this.renderState.dimensions && Pe.postRender(this.updateDimensions)
    }
    build(t, n, r) {
        yg(t, n, this.isSVGTag, r.transformTemplate)
    }
    renderInstance(t, n, r, i) {
        WC(t, n, r, i)
    }
    mount(t) {
        this.isSVGTag = vg(t.tagName), super.mount(t)
    }
}
const bI = (e, t) => gg(e) ? new kI(t) : new PI(t, {
        allowProjection: e !== C.Fragment
    }),
    RI = ZM({ ...Q5,
        ...yI,
        ...oI,
        ...vI
    }, bI),
    iu = mM(RI),
    qe = () => {
        const e = "StudyVault".split(""),
            t = Array.from({
                length: 5
            }, (n, r) => g.jsx(iu.div, {
                className: "circle",
                animate: {
                    x: [0, Math.random() * 200 - 100, Math.random() * -200 + 100, 0],
                    y: [0, Math.random() * 200 - 100, Math.random() * -200 + 100, 0],
                    scale: [1, 1.5, 1],
                    rotate: [0, 360]
                },
                transition: {
                    duration: 4 + Math.random() * 2,
                    repeat: 1 / 0,
                    ease: "easeInOut"
                }
            }, r));
        return g.jsxs("div", {
            id: "introloader",
            children: [t, g.jsx(iu.h1, {
                children: e.map((n, r) => g.jsx(iu.span, {
                    initial: {
                        y: -40,
                        opacity: .4
                    },
                    animate: {
                        y: [0, -10, 0],
                        opacity: 1
                    },
                    transition: {
                        delay: r * .2,
                        repeat: 1 / 0,
                        repeatType: "reverse",
                        duration: 1
                    },
                    children: n
                }, r))
            }), g.jsx(iu.h2, {
                className: "loading-text",
                initial: {
                    opacity: .4
                },
                animate: {
                    opacity: .9
                },
                transition: {
                    duration: .4,
                    repeat: 1 / 0,
                    repeatType: "reverse",
                    ease: "easeInOut"
                },
                children: "Loading..."
            })]
        })
    },
    AI = C.lazy(() => ce(() =>
        import ("./Filter-B1QLf4MC.js"), __vite__mapDeps([0, 1, 2, 3, 4, 5]))),
    DI = C.lazy(() => ce(() =>
        import ("./Departmentlist-DKe7pzPz.js"), __vite__mapDeps([6, 2, 7, 1]))),
    jI = C.lazy(() => ce(() =>
        import ("./Login-0lBrvo7V.js"), __vite__mapDeps([8, 9, 10, 11, 12, 13, 14, 15, 1, 16]))),
    OI = C.lazy(() => ce(() =>
        import ("./ForgatePw-BQYawr9P.js"), __vite__mapDeps([17, 9, 10, 1, 18]))),
    LI = C.lazy(() => ce(() =>
        import ("./Allpages-DxZ3r7d1.js"), __vite__mapDeps([19, 1]))),
    MI = C.lazy(() => ce(() =>
        import ("./Admine-DvPiGv4C.js"), __vite__mapDeps([20, 1, 21]))),
    NI = C.lazy(() => ce(() =>
        import ("./Dashboard-B7wnVV2s.js"), __vite__mapDeps([22, 1, 23]))),
    FI = C.lazy(() => ce(() =>
        import ("./Question-CYwK6Uop.js"), __vite__mapDeps([24, 25, 1, 26, 27]))),
    II = C.lazy(() => ce(() =>
        import ("./UserSend-DKTd8B8R.js"), __vite__mapDeps([28, 1]))),
    VI = C.lazy(() => ce(() =>
        import ("./CsUpload-Dp9MPJeR.js"), __vite__mapDeps([29, 1]))),
    BI = C.lazy(() => ce(() =>
        import ("./ArticleContainerRouter-QlcUYETH.js"), __vite__mapDeps([30, 1, 31]))),
    zI = C.lazy(() => ce(() =>
        import ("./CollegeArticleRouter-BIPPSNmS.js"), __vite__mapDeps([32, 1]))),
    UI = C.lazy(() => ce(() =>
        import ("./NoteUpload-DT81vbA0.js"), __vite__mapDeps([33, 1, 34]))),
    $I = C.lazy(() => ce(() =>
        import ("./Alart-feY4T56g.js"), __vite__mapDeps([35, 1, 36]))),
    WI = C.lazy(() => ce(() =>
        import ("./MaterialRouting-DARt4UAj.js"), __vite__mapDeps([37, 26, 1, 38]))),
    HI = C.lazy(() => ce(() =>
        import ("./PaymentStatus-BSOVYheG.js"), __vite__mapDeps([39, 13, 1, 40]))),
    KI = C.lazy(() => ce(() =>
        import ("./PaymentRouter-CiTrG1nx.js"), __vite__mapDeps([41, 1]))),
    GI = C.lazy(() => ce(() =>
        import ("./Notes-s3JWzZ7O.js"), __vite__mapDeps([42, 1, 7, 11, 12, 26, 43]))),
    YI = C.lazy(() => ce(() =>
        import ("./Cashfree-Dp3rS-Xt.js"), __vite__mapDeps([44, 13, 1, 45]))),
    XI = C.lazy(() => ce(() =>
        import ("./SyllabusUpload-CudDbegm.js"), __vite__mapDeps([46, 1, 47]))),
    qI = C.lazy(() => ce(() =>
        import ("./NotFound-BeZrGTw4.js"), __vite__mapDeps([48, 1]))),
    QI = C.lazy(() => ce(() =>
        import ("./Syllabus-CAXcPY9_.js"), __vite__mapDeps([49, 3, 4, 1, 50]))),
    JI = C.lazy(() => ce(() =>
        import ("./MpcArticle-911HG-l4.js"), __vite__mapDeps([51, 52, 1, 53]))),
    ZI = C.lazy(() => ce(() =>
        import ("./CollegeAritcle-CCLiyiXn.js"), __vite__mapDeps([54, 52, 1, 55]))),
    e3 = C.lazy(() => ce(() =>
        import ("./ArticleHome-BnrnIdKg.js"), __vite__mapDeps([56, 54, 52, 1, 55, 57]))),
    t3 = C.lazy(() => ce(() =>
        import ("./TermsConditions-DIRjCuc8.js"), __vite__mapDeps([58, 1, 59]))),
    n3 = C.lazy(() => ce(() =>
        import ("./PrivecyandPolicy-DBMzI0uj.js"), __vite__mapDeps([60, 1, 61]))),
    r3 = C.lazy(() => ce(() =>
        import ("./AdmineLogIn-D07-9XcW.js"), __vite__mapDeps([62, 9, 10, 14, 15, 1, 63]))),
    i3 = C.lazy(() => ce(() =>
        import ("./AboutUs-D244UCIW.js"), __vite__mapDeps([64, 1, 65]))),
    s3 = C.lazy(() => ce(() =>
        import ("./Home-IZ44vQDY.js"), __vite__mapDeps([66, 1, 52, 2, 25, 13, 67, 4]))),
    o3 = C.lazy(() => ce(() =>
        import ("./Profile-Baf-4-l7.js"), __vite__mapDeps([68, 1, 69]))),
    a3 = C.lazy(() => ce(() =>
        import ("./Contact-BdWc4PFa.js"), __vite__mapDeps([70, 1, 71]))),
    l3 = C.lazy(() => ce(() =>
        import ("./Signup-DeeDnQZN.js"), __vite__mapDeps([72, 9, 10, 11, 12, 1, 73]))),
    u3 = C.lazy(() => ce(() =>
        import ("./Loginsignup-C0I2rfSl.js"), __vite__mapDeps([74, 1])));

function c3() {
    const [e, t] = C.useState(""), n = a => {
        t({
            type: a
        })
    }, [r, i] = C.useState(), s = a => {
        i({
            value: a
        })
    }, o = lR([{
        path: "*",
        element: g.jsx(ge, {
            children: g.jsx(C.Suspense, {
                fallback: g.jsx(qe, {}),
                children: g.jsx(qI, {})
            })
        })
    }, {
        path: "/",
        element: g.jsx(g.Fragment, {
            children: g.jsxs(ge, {
                children: ["    ", g.jsxs(C.Suspense, {
                    fallback: g.jsx(qe, {}),
                    children: [" ", g.jsxs(DD, {
                        children: [g.jsx(rM, {
                            children: g.jsx(hA, {
                                children: g.jsx(AR, {
                                    children: g.jsx(cA, {
                                        children: g.jsx(DR, {
                                            children: g.jsx(RR, {
                                                children: g.jsx(LI, {})
                                            })
                                        })
                                    })
                                })
                            })
                        }), g.jsx($I, {})]
                    })]
                })]
            })
        }),
        children: [{
            path: "",
            element: g.jsx(g.Fragment, {
                children: g.jsxs(ge, {
                    children: [" ", g.jsx(tM, {
                        navrefvalue: s
                    }), g.jsx(iM, {})]
                })
            }),
            children: [{
                path: "",
                element: g.jsx(g.Fragment, {
                    children: g.jsxs(C.Suspense, {
                        fallback: g.jsx(qe, {}),
                        children: [" ", g.jsx(s3, {
                            navRefvalue: r
                        })]
                    })
                }),
                children: [{
                    path: "",
                    element: g.jsx(g.Fragment, {
                        children: g.jsx(ge, {
                            children: g.jsx(DI, {})
                        })
                    })
                }]
            }, {
                path: "Contact-Us",
                element: g.jsxs(g.Fragment, {
                    children: [g.jsx(ge, {
                        children: g.jsx(C.Suspense, {
                            fallback: g.jsx(qe, {}),
                            children: g.jsx(OR, {
                                children: g.jsx(a3, {})
                            })
                        })
                    }), " "]
                })
            }, {
                path: "Profile",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(qe, {}),
                            children: [" ", g.jsx(o3, {})]
                        })
                    })
                })
            }, {
                path: "About-us",
                element: g.jsx(g.Fragment, {
                    children: g.jsxs(ge, {
                        children: [" ", g.jsxs(C.Suspense, {
                            fallback: g.jsx(qe, {}),
                            children: [" ", g.jsx(i3, {})]
                        })]
                    })
                })
            }, {
                path: "Privacy-Policy",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(qe, {}),
                            children: [" ", g.jsx(n3, {})]
                        })
                    })
                })
            }, {
                path: "Terms-Conditions",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(qe, {}),
                            children: [" ", g.jsx(t3, {})]
                        })
                    })
                })
            }]
        }, {
            path: "Filter",
            element: g.jsx(g.Fragment, {
                children: g.jsx(C.Suspense, {
                    fallback: g.jsx(qe, {}),
                    children: g.jsx(WI, {
                        subheadingtypedata: e
                    })
                })
            }),
            children: [{
                path: "",
                element: g.jsx(g.Fragment, {
                    children: g.jsxs(C.Suspense, {
                        fallback: g.jsx(en, {}),
                        children: [g.jsx(AI, {
                            subheadingtypedata: n
                        }), " "]
                    })
                })
            }, {
                path: "syllabus",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: [" ", g.jsx(QI, {
                                subheadingtypedata: n
                            }), " "]
                        })
                    })
                })
            }, {
                path: "Notes",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: [" ", g.jsx(GI, {
                                subheadingtypedata: n
                            }), " "]
                        })
                    })
                })
            }]
        }, {
            path: "/Downloadpdf/:fName",
            element: g.jsx(g.Fragment, {
                children: g.jsx(ge, {
                    children: g.jsx(C.Suspense, {
                        fallback: g.jsx(qe, {}),
                        children: g.jsx(bR, {})
                    })
                })
            })
        }, {
            path: "LogIn",
            element: g.jsx(g.Fragment, {
                children: g.jsx(C.Suspense, {
                    fallback: g.jsx(qe, {}),
                    children: g.jsx(u3, {})
                })
            }),
            children: [{
                path: "",
                element: g.jsx(ge, {
                    children: g.jsxs(C.Suspense, {
                        fallback: g.jsx(qe, {}),
                        children: [" ", g.jsx(jI, {})]
                    })
                })
            }, {
                path: "Signup",
                element: g.jsxs(g.Fragment, {
                    children: [" ", g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(qe, {}),
                            children: [" ", g.jsx(l3, {})]
                        })
                    })]
                })
            }, {
                path: "ForgatePw",
                element: g.jsx(ge, {
                    children: g.jsxs(C.Suspense, {
                        fallback: g.jsx(qe, {}),
                        children: ["  ", g.jsx(OI, {})]
                    })
                })
            }]
        }, {
            path: "payment-donate-us",
            element: g.jsx(g.Fragment, {
                children: g.jsxs(ge, {
                    children: [" ", g.jsxs(C.Suspense, {
                        fallback: g.jsx(qe, {}),
                        children: [" ", g.jsx(KI, {})]
                    }), " "]
                })
            }),
            children: [{
                index: !0,
                path: "",
                element: g.jsx(g.Fragment, {
                    children: g.jsxs(ge, {
                        children: [g.jsxs(C.Suspense, {
                            fallback: g.jsx(qe, {}),
                            children: [" ", g.jsx(YI, {})]
                        }), " "]
                    })
                })
            }, {
                path: "payment-response",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(qe, {}),
                            children: [" ", g.jsx(HI, {})]
                        })
                    })
                })
            }]
        }, {
            path: "Admin",
            element: g.jsx(g.Fragment, {
                children: g.jsx(C.Suspense, {
                    fallback: g.jsx(qe, {}),
                    children: g.jsx(dA, {
                        children: g.jsx(MI, {})
                    })
                })
            }),
            children: [{
                path: "",
                element: g.jsx(g.Fragment, {
                    children: g.jsxs(ge, {
                        children: [g.jsx(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: g.jsx(NI, {})
                        }), "  "]
                    })
                })
            }, {
                path: "Question",
                element: g.jsx(g.Fragment, {
                    children: g.jsxs(ge, {
                        children: [g.jsx(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: g.jsx(FI, {})
                        }), " "]
                    })
                })
            }, {
                path: "syllabusupload",
                element: g.jsx(g.Fragment, {
                    children: g.jsxs(ge, {
                        children: [g.jsx(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: g.jsx(XI, {})
                        }), " "]
                    })
                })
            }, {
                path: "Usersend",
                element: g.jsxs(g.Fragment, {
                    children: [g.jsx(ge, {
                        children: g.jsx(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: g.jsx(II, {})
                        })
                    }), " "]
                })
            }, {
                path: "CsUpload",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: [" ", g.jsx(VI, {})]
                        })
                    })
                })
            }, {
                path: "Notes",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: [" ", g.jsx(UI, {})]
                        })
                    })
                })
            }]
        }, {
            path: "Admin/AdminLogIn",
            element: g.jsx(g.Fragment, {
                children: g.jsx(ge, {
                    children: g.jsx(C.Suspense, {
                        fallback: g.jsx(qe, {}),
                        children: g.jsx(r3, {})
                    })
                })
            })
        }, {
            path: "article-section",
            element: g.jsxs(g.Fragment, {
                children: [g.jsxs(C.Suspense, {
                    fallback: g.jsx(qe, {}),
                    children: [" ", g.jsx(mA, {
                        children: g.jsx(BI, {})
                    })]
                }), " "]
            }),
            children: [{
                path: "",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: [" ", g.jsx(e3, {})]
                        })
                    })
                })
            }, {
                path: "colleges-article",
                element: g.jsx(g.Fragment, {
                    children: g.jsx(ge, {
                        children: g.jsxs(C.Suspense, {
                            fallback: g.jsx(en, {}),
                            children: ["  ", g.jsx(zI, {})]
                        })
                    })
                }),
                children: [{
                    path: "",
                    element: g.jsx(g.Fragment, {
                        children: g.jsx(ge, {
                            children: g.jsxs(C.Suspense, {
                                fallback: g.jsx(en, {}),
                                children: [" ", g.jsx(ZI, {})]
                            })
                        })
                    })
                }, {
                    path: "mpc-article",
                    element: g.jsx(g.Fragment, {
                        children: g.jsx(ge, {
                            children: g.jsxs(C.Suspense, {
                                fallback: g.jsx(en, {}),
                                children: [" ", g.jsx(JI, {})]
                            })
                        })
                    })
                }]
            }]
        }]
    }]);
    return g.jsx(g.Fragment, {
        children: g.jsx(gR, {
            router: o
        })
    })
}
const f3 = () => {
    const e = document.getElementById("static-loader");
    e && (e.style.transition = "opacity 0.5s", e.style.opacity = "0", setTimeout(() => {
        e.remove()
    }, 500))
};
jd.createRoot(document.getElementById("root")).render(g.jsx(ge, {
    children: g.jsx(C.Suspense, {
        fallback: g.jsx(qe, {}),
        children: g.jsx(c3, {})
    })
}));
f3();
export {
    GS as A, vw as D, ge as E, fA as F, ER as H, Jo as L, je as N, eR as O, jR as P, Z1 as R, xw as S, Cm as U, os as a, et as b, Kw as c, pA as d, Hw as e, Tv as f, g as j, Ev as l, iu as m, C as r, Sm as u
};