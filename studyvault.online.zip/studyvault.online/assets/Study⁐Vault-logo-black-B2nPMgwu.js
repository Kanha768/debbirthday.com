const s = "/assets/Study%E2%81%90Vault-logo-black-CeAWSa-k.png";
export {
    s
};