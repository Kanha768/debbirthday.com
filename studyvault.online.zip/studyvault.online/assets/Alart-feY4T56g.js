import {
    r,
    A as o,
    j as t
} from "./index-CoOseuI4.js";
import "./lottie-pWNopbfh.js";
const n = "/assets/check2-CVSN_3Ir.png",
    c = "/assets/mark-DfLkA9ec.png",
    a = "/assets/close-B2Fsw5Ms.png",
    d = () => {
        const {
            alart: s
        } = r.useContext(o), e = {
            check: n,
            mark: c,
            cancel: a
        };
        return t.jsx("div", {
            id: "alart",
            children: s && t.jsx("div", {
                id: "alart-box",
                style: {
                    padding: "0.8rem 1.5rem 0.8rem 1rem",
                    position: "fixed",
                    top: "10%",
                    right: "2%",
                    zIndex: "200000000000000000",
                    borderRadius: "0.7rem"
                },
                children: t.jsxs("p", {
                    style: {
                        fontSize: "1rem",
                        color: "#fff",
                        fontWeight: "600"
                    },
                    children: [" ", t.jsx("img", {
                        src: e[s.state],
                        alt: "succes button"
                    }), t.jsxs("strong", {
                        style: {
                            color: "#000",
                            fontSize: "1rem",
                            fontWeight: "600"
                        },
                        children: [s.type, " "]
                    }), " "]
                })
            })
        })
    };
export {
    d as
    default
};