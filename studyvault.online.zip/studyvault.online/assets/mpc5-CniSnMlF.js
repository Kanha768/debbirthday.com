const s = "/assets/mpc5-BtKQRlaT.jpg";
export {
    s as l
};