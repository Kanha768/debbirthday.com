import {
    a as o,
    r as l,
    j as e,
    O as u
} from "./index-CoOseuI4.js";
import "./lottie-pWNopbfh.js";
const c = () => {
        let t;
        try {
            t = o()
        } catch {
            console.warn("useLocation() called outside a <Router>"), t = {
                pathname: "/"
            }
        }
        const a = "StudyVault - Access all previous years question papers and free notes from M.P.C Autonomous College.";
        return l.useEffect(() => {
            switch (t.pathname) {
                case "/Profile":
                    document.title = "Profile- StudyVault";
                    break;
                case "/Contact-Us":
                    document.title = "Contact Us -StudyVault";
                    break;
                case "/About-us":
                    document.title = "About Us - StudyVault";
                    break;
                case "/Filter":
                    document.title = "Find Material- StudyVault";
                    break;
                case "/Downloadpdf":
                    document.title = "Download File- StudyVault";
                    break;
                case "/LogIn":
                    document.title = "Student Login- StudyVault";
                    break;
                case "/LogIn/ForgatePw":
                    document.title = "Reset Your Password- StudyVault";
                    break;
                case "/Admin/AdminLogIn":
                    document.title = "Admin Login- StudyVault";
                    break;
                case "/Admin":
                    document.title = "Admin Dashboard- StudyVault";
                    break;
                case "/article-section":
                    document.title = "Article Section- StudyVault";
                    break;
                case "/article-section/colleges-article":
                    document.title = "Article Section - Colleges - StudyVault";
                    break;
                case "/Privacy-Policy":
                    document.title = "Privacy Policy  - StudyVault";
                    break;
                case "/Terms-Conditions":
                    document.title = "Terms & Conditions  - StudyVault";
                    break;
                default:
                    document.title = a;
                    break
            }
        }, [t]), null
    },
    i = ({
        alart: t
    }) => e.jsxs(e.Fragment, {
        children: [e.jsx(c, {}), e.jsx(u, {})]
    });
export {
    i as
    default
};