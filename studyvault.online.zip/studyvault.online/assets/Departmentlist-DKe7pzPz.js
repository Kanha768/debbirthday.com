import {
    r as t,
    D as h,
    U as u,
    u as x,
    S as f,
    j as e
} from "./index-CoOseuI4.js";
import {
    A as j
} from "./AritcleAds-C6Frj4LM.js";
import {
    M as v
} from "./Morenoteabove-D1egt4Ok.js";
import "./lottie-pWNopbfh.js";
const F = g => {
    const i = t.useContext(h),
        {
            usernav: C
        } = t.useContext(u),
        o = x(),
        [n, c] = t.useState(!1),
        r = t.useRef(),
        l = t.useRef(),
        {
            setFiltersection: N
        } = t.useContext(f),
        d = s => {
            o("/Filter", {
                state: {
                    departmentName: s
                }
            })
        },
        [m, a] = t.useState(!1);
    return t.useEffect(() => {
        r.current && ((r.current.style.height = n) ? r.current.style.height = "100%" : r.current.style.height = "94vh", a(!!n))
    }, [n]), e.jsx(e.Fragment, {
        children: e.jsx("div", {
            className: "main-container",
            style: {
                paddingTop: "1rem"
            },
            children: e.jsxs("div", {
                className: "inner-main-container",
                children: [e.jsx("div", {
                    className: "ads-center-perfect",
                    style: {
                        overflow: "hidden"
                    },
                    children: e.jsx(v, {})
                }), e.jsxs("div", {
                    ref: l,
                    className: "content-container",
                    children: [e.jsxs("div", {
                        className: "department-title-box",
                        children: [e.jsx("h2", {
                            children: "Departments :"
                        }), e.jsxs("button", {
                            children: ["Question Papers", e.jsx("i", {
                                className: "fa-solid fa-not-equal"
                            })]
                        })]
                    }), e.jsx("div", {
                        ref: r,
                        className: "department-list",
                        children: i.map((s, p) => e.jsx("div", {
                            className: "department",
                            children: e.jsxs("p", {
                                onClick: () => d(s),
                                children: [" ", s]
                            })
                        }, p))
                    }), e.jsx("button", {
                        style: {
                            cursor: "pointer",
                            padding: "0.7rem 1rem",
                            border: "none",
                            background: "#4B97D5",
                            borderRadius: "0.1rem",
                            margin: "0.9rem 0 0 0 "
                        },
                        onClick: () => {
                            c(s => !s)
                        },
                        children: e.jsx("p", {
                            style: {
                                color: "#fff",
                                fontSize: "1.1rem",
                                whiteSpace: "nowrap"
                            },
                            children: m ? "See less" : "More Departments"
                        })
                    })]
                }), e.jsx("div", {
                    className: "ads-center ",
                    style: {
                        overflow: "hidden"
                    },
                    children: e.jsx(j, {
                        background: "#F2F2FB"
                    })
                })]
            })
        })
    })
};
export {
    F as
    default
};