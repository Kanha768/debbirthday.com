import {
    r as s,
    j as o
} from "./index-CoOseuI4.js";
const r = a => (s.useEffect(() => {
    {
        if (window.adsbygoogle = window.adsbygoogle || [], !document.querySelector('script[src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"]')) {
            const e = document.createElement("script");
            e.async = !0, e.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-9796833231647897", e.crossOrigin = "anonymous", document.head.appendChild(e)
        }
        const t = setTimeout(() => {
            try {
                window.adsbygoogle && window.adsbygoogle.push({})
            } catch (e) {
                console.error("AdSense error:", e)
            }
        }, 500);
        return () => clearTimeout(t)
    }
}, []), o.jsx("div", {
    style: {
        width: "100%",
        overflow: "hidden"
    },
    children: o.jsx("ins", {
        className: "adsbygoogle",
        style: {
            display: "block",
            textAlign: "center",
            width: "100%",
            minWidth: "250px ",
            backgroundColor: "#F2F2FB"
        },
        "data-ad-layout": "in-article",
        "data-ad-format": "fluid",
        "data-ad-client": "ca-pub-9796833231647897",
        "data-ad-slot": "9011527763"
    })
}));
export {
    r as A
};