import {
    r as s,
    j as e,
    u as P,
    U,
    e as H,
    l as T,
    L as B,
    A as F,
    a as I,
    b as R,
    S as M,
    N as f,
    E as x,
    O as Y,
    H as Q
} from "./index-CoOseuI4.js";
import "./lottie-pWNopbfh.js"; /* empty css               */
import {
    l as $
} from "./mpc5-CniSnMlF.js";
import {
    A as z
} from "./AritcleAds-C6Frj4LM.js";
import "./PDFButton-CZYBgW8y.js";
import {
    s as A
} from "./Study⁐Vault-logo-black-B2nPMgwu.js";
const W = c => {
        const [t, o] = s.useState(!1), n = s.useRef();
        s.useEffect(() => {
            const i = () => {
                window.scrollTo({
                    top: 0,
                    behavior: "smooth"
                })
            };
            n.current.addEventListener("click", i, {
                passive: !0
            });
            const d = () => {
                window.scrollY > 50 ? o(!0) : o(!1)
            };
            window.addEventListener("scroll", d, {
                passive: !0
            });
            const g = () => {
                c.navRefvalue.value.style.transform = "translateX(0)"
            };
            return n.current.addEventListener("click", g, {
                passive: !0
            }), () => {
                window.removeEventListener("scroll", d), window.removeEventListener("click", i), n.current && n.current.removeEventListener("click", g)
            }
        }, []);
        const a = "https://whatsapp.com/channel/0029Vaz0nHC2ER6d7N0Ipa3O",
            l = () => {
                console.log("Worked"), window.open(a, "_blank")
            };
        return e.jsxs(e.Fragment, {
            children: [e.jsx("div", {
                id: "scrollbtn",
                className: `${t?"":"hide-btn"}`,
                ref: n,
                children: e.jsx("i", {
                    className: "fa-solid fa-arrow-up"
                })
            }), e.jsx("div", {
                className: `whatsappopen ${t?"bottomp":"originalp"}`,
                onClick: l,
                children: e.jsx("i", {
                    className: "fa-brands fa-whatsapp"
                })
            })]
        })
    },
    q = "/assets/homelogo3-CQYntxwC.png",
    O = "/assets/homelogo3-DFAvtF_s.webp",
    K = "/assets/homelogo3-BpVKc5ND.avif",
    G = "/assets/weblogo-C28fg30Z.webp",
    V = "/assets/weblogo-Bi2HZDu-.avif",
    Z = c => {
        const t = P(),
            {
                usernav: o
            } = s.useContext(U),
            [n, a] = s.useState();
        s.useContext(H);
        const l = sessionStorage.getItem("isLoggedIn");
        return s.useEffect(() => {
            a(!!l)
        }, [l]), e.jsx(e.Fragment, {
            children: e.jsx("div", {
                className: "main-container",
                children: e.jsx("div", {
                    className: "landing-section",
                    children: e.jsxs("div", {
                        className: "inner-landing",
                        children: [e.jsxs("div", {
                            className: "home-info",
                            children: [e.jsxs("div", {
                                className: "home-info-h1-logo",
                                children: [e.jsx("h1", {
                                    style: {
                                        position: "absolute",
                                        top: "-100%",
                                        left: "-100%",
                                        opacity: "0"
                                    },
                                    children: "All Previous Year Question Papers of M.P.C Auto."
                                }), e.jsx("h1", {
                                    children: "Hi! I Am"
                                }), e.jsx("div", {
                                    className: "h1-box",
                                    children: e.jsxs("picture", {
                                        children: [e.jsx("source", {
                                            srcSet: V,
                                            type: "image/avif"
                                        }), e.jsx("source", {
                                            srcSet: G,
                                            type: "image/webp"
                                        }), e.jsx("img", {
                                            src: T,
                                            alt: "web logo",
                                            loading: "lazy"
                                        })]
                                    })
                                })]
                            }), e.jsx("h1", {
                                className: "header-sub-head",
                                children: c.title
                            }), e.jsx("p", {
                                children: c.titlepara
                            }), e.jsxs("div", {
                                className: "live-count",
                                children: [e.jsxs("div", {
                                    className: "counts",
                                    children: [e.jsx("h3", {
                                        children: "100K+"
                                    }), e.jsx("p", {
                                        children: "Users visite this app"
                                    })]
                                }), e.jsxs("div", {
                                    className: "counts",
                                    children: [e.jsx("h3", {
                                        children: "8K+"
                                    }), e.jsx("p", {
                                        children: "Users use this app"
                                    })]
                                }), e.jsxs("div", {
                                    className: "counts",
                                    children: [e.jsx("h3", {
                                        children: "1K+"
                                    }), e.jsx("p", {
                                        children: "Total Resources downloaded "
                                    })]
                                })]
                            }), e.jsxs("div", {
                                className: "buttons-home",
                                children: [e.jsx("button", {
                                    onClick: () => {
                                        t("About-us")
                                    },
                                    children: "Read me"
                                }), !n && e.jsxs(B, {
                                    to: "/LogIn/Signup",
                                    children: ["Sign Up ", e.jsx("i", {
                                        className: "fa-solid fa-arrow-right"
                                    })]
                                })]
                            })]
                        }), e.jsxs("div", {
                            className: "home-image-section",
                            children: [e.jsx("div", {
                                className: "background-image",
                                children: e.jsxs("picture", {
                                    children: [e.jsx("source", {
                                        srcSet: K,
                                        type: "image/avif"
                                    }), e.jsx("source", {
                                        srcSet: O,
                                        type: "image/webp"
                                    }), e.jsx("img", {
                                        src: q,
                                        alt: "not found",
                                        loading: "lazy"
                                    })]
                                })
                            }), e.jsxs("div", {
                                className: "overfolw-box box-one",
                                children: [e.jsx("i", {
                                    className: "fa-solid fa-cloud"
                                }), e.jsxs("div", {
                                    children: [e.jsx("h2", {
                                        children: "Questions Papers"
                                    }), e.jsx("p", {
                                        children: "I am always for you Here"
                                    })]
                                })]
                            }), e.jsxs("div", {
                                className: "overfolw-box box-two",
                                children: [e.jsx("i", {
                                    className: "fa-solid fa-file-pdf"
                                }), e.jsxs("div", {
                                    children: [e.jsx("h2", {
                                        children: "Notes"
                                    }), e.jsx("p", {
                                        children: "I also provide you Notes"
                                    })]
                                })]
                            }), e.jsxs("div", {
                                className: "overfolw-box box-three",
                                children: [e.jsx("i", {
                                    className: "fa-solid fa-id-card-clip"
                                }), e.jsxs("div", {
                                    children: [e.jsx("h2", {
                                        children: "Documnets"
                                    }), e.jsx("p", {
                                        children: "You can save you college document Securly"
                                    })]
                                })]
                            })]
                        })]
                    })
                })
            })
        })
    },
    _ = c => {
        const {
            showAlart: t
        } = s.useContext(F), o = s.useRef(), [n, a] = s.useState(null), l = s.useRef(), [i, d] = s.useState(!1), [g, j] = s.useState([]), [w, u] = s.useState(!1), [k, r] = s.useState(""), [v, y] = s.useState(0), h = s.useRef();
        I();
        const C = b => {
            const p = Array.from(b.target.files),
                m = ["application/pdf", "image/jpeg", "image/png"],
                N = p.filter(S => m.includes(S.type));
            if (N.length > 0) {
                const S = N.map(E => {
                    const L = E.type.startsWith("image/") ? URL.createObjectURL(E) : null;
                    return {
                        file: E,
                        preview: L
                    }
                });
                j(S), a(N), d(!0)
            } else r("Failed: Please select valid files (PDF, JPEG, PNG)"), j([]), a(null), d(!1), o.current && (o.current.value = "")
        };
        s.useEffect(() => {
            i ? (document.body.style.overflowY = "hidden", h.current.style.bottom = "0%") : (document.body.style.overflowY = "scroll", h.current.style.bottom = "-100%")
        }, [i]), s.useEffect(() => {
            n && (l.current.style.bottom = "0%")
        }, [n]);
        const D = async b => {
            if (b.preventDefault(), u(!0), n && n.length > 0) {
                const p = new FormData;
                n.forEach(m => {
                    p.append("files", m)
                });
                try {
                    (await R.post("/api/Profile/upload/non-user", p, {
                        headers: {
                            "Content-Type": "multipart/form-data"
                        },
                        onUploadProgress: N => {
                            const S = Math.round(N.loaded * 100 / N.total);
                            y(S)
                        }
                    })).status === 200 ? (y(0), r(e.jsx("p", {
                        style: {
                            color: "green"
                        },
                        children: "Files uploaded successfully"
                    })), j([]), a(null), u(!1), o.current && (o.current.value = ""), t("Successfully send", "", "check"), l.current.style.bottom = "-100%", r(""), d(!1)) : (r(e.jsx("p", {
                        style: {
                            color: "red"
                        },
                        children: "Error: Failed to upload files"
                    })), t("Error: Failed to upload files", "", "cancel"), r(""), u(!1))
                } catch (m) {
                    console.error("Error uploading files:", m), t("Error uploading files:", "", "cancel"), r(""), r(e.jsx("p", {
                        style: {
                            color: "red"
                        },
                        children: "Error: Failed to upload files"
                    })), u(!1)
                }
            } else r(e.jsx("p", {
                style: {
                    color: "red"
                },
                children: "No files selected for upload"
            })), u(!1), r("")
        };
        return e.jsxs("aside", {
            id: "upload-section",
            children: [e.jsx("div", {
                className: "left-upload-section",
                children: e.jsxs("h3", {
                    children: ["Have you any Questions Papers? ", e.jsx("br", {}), " Share it with us—it only takes a moment!"]
                })
            }), e.jsxs("div", {
                className: "right-upload-section",
                children: [e.jsx("h4", {
                    children: "Send Us!"
                }), e.jsx("input", {
                    type: "file",
                    name: "Qupload",
                    accept: "application/pdf,image/jpeg,image/png",
                    className: "active",
                    multiple: !0,
                    onChange: C,
                    ref: o,
                    disabled: i
                }), w && e.jsxs("div", {
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        width: "80%",
                        gap: "2rem",
                        margin: "2rem 0 1rem 0"
                    },
                    children: [e.jsxs("span", {
                        style: {
                            marginTop: "1rem",
                            fontSize: "1.2rem",
                            color: "#333"
                        },
                        children: [v, "%"]
                    }), e.jsx("meter", {
                        value: v,
                        min: "0",
                        max: "100",
                        style: {
                            width: "100%"
                        }
                    })]
                }), e.jsx("article", {
                    children: "Click the button  to send Question papers. Every bit counts."
                })]
            }), e.jsxs("form", {
                onSubmit: D,
                children: [e.jsxs("aside", {
                    className: "papers-submit",
                    ref: l,
                    children: [e.jsxs("div", {
                        className: "papers-head-submit",
                        children: [e.jsx("h1", {
                            children: "Final Step"
                        }), " ", e.jsx("i", {
                            className: "fa-solid fa-xmark",
                            style: {
                                cursor: "pointer"
                            },
                            onClick: () => {
                                l.current.style.bottom = "-100%", a(null), d(!1)
                            }
                        })]
                    }), e.jsx("div", {
                        className: "file-item-box",
                        children: g.map(({
                            file: b,
                            preview: p
                        }, m) => e.jsxs("div", {
                            className: "file-item",
                            children: [p && e.jsx("img", {
                                src: p,
                                alt: "Preview",
                                style: {
                                    maxWidth: "100px",
                                    marginTop: "10px"
                                }
                            }), e.jsxs("p", {
                                children: [e.jsx("strong", {
                                    children: "File Name:"
                                }), " ", b.name]
                            }), e.jsxs("p", {
                                children: [e.jsx("strong", {
                                    children: "File Size:"
                                }), " ", (b.size / 1024).toFixed(2), " KB"]
                            })]
                        }, m))
                    }), e.jsxs("div", {
                        className: " final-submit-btn",
                        style: {
                            width: "100%",
                            display: "flex",
                            flexDirection: "column",
                            gap: "0.9rem",
                            justifyContent: "center",
                            alignItems: "center"
                        },
                        children: [k, w ? e.jsxs("div", {
                            style: {
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "center",
                                width: "90%"
                            },
                            children: [e.jsxs("span", {
                                style: {
                                    marginBottom: "0.3rem",
                                    fontSize: "1.2rem",
                                    color: "#333"
                                },
                                children: [v, "%"]
                            }), e.jsx("meter", {
                                value: v,
                                min: "0",
                                max: "100"
                            })]
                        }) : e.jsx("button", {
                            type: "submit",
                            style: w ? {
                                opacity: .5
                            } : {},
                            disabled: w,
                            children: "Send"
                        })]
                    })]
                }), e.jsx("div", {
                    className: "block",
                    ref: h
                })]
            })]
        })
    },
    J = c => {
        const t = I(),
            o = s.useRef(),
            {
                filtersection: n
            } = s.useContext(M),
            {
                showAlart: a
            } = s.useContext(F),
            l = () => {
                a("Available Soon", "", "mark")
            };
        return e.jsx("aside", {
            id: "section-selector",
            ref: o,
            children: e.jsxs("div", {
                className: "section-selector-inside section-selector-common",
                children: [e.jsx(f, {
                    to: "/",
                    className: ` ${t.pathname==="/"?"section-on":"section-nutral "} active`,
                    children: "Home"
                }), e.jsx(f, {
                    to: "/Filter",
                    className: ` ${t.pathname==="/Filter"?"section-on":"section-nutral "} active`,
                    children: "Questions"
                }), e.jsx(f, {
                    to: "/Filter/syllabus",
                    className: ` ${t.pathname==="/Filter/syllabus"?"section-on":"section-nutral "} active`,
                    children: "Syllabus"
                }), e.jsx(f, {
                    to: "/Filter/Notes",
                    className: ` ${t.pathname==="/Filter/Notes"?"section-on":"section-nutral "} active`,
                    children: "Notes"
                }), e.jsx(f, {
                    to: "/article-section",
                    className: ` ${t.pathname==="/article-section"?"section-on":"section-nutral "} active`,
                    children: "Article"
                }), e.jsx(f, {
                    to: "",
                    className: "section-off active",
                    onClick: l,
                    children: "Books"
                })]
            })
        })
    },
    X = "/assets/unnamed-B1cY2tgO.jpg",
    ee = "/assets/College3-Dc2KN_Zq.jpg",
    se = "/assets/College4-p3E9H0fk.jpg",
    te = "/assets/College5-BufxQQkI.jpg",
    ae = () => {
        var [c, t] = s.useState(0);
        const o = s.useRef(null),
            n = [$, ee, te, se, X];
        return s.useEffect(() => {
            const a = o.current.querySelectorAll(".slide");
            a.forEach((i, d) => {
                i.style.left = `${d*100}%`
            });
            const l = setInterval(() => {
                t(i => i >= a.length - 1 ? 0 : i + 1)
            }, 5e3);
            return () => clearInterval(l)
        }, []), s.useEffect(() => {
            o.current.querySelectorAll(".slide").forEach(l => {
                l.style.transform = `translateX(-${c*100}%)`
            })
        }, [c]), e.jsx(e.Fragment, {
            children: e.jsxs("section", {
                id: "college-info-out-box",
                children: [e.jsx("div", {
                    className: "ads-center"
                }), e.jsxs("div", {
                    id: "college-info",
                    children: [e.jsx("aside", {
                        className: "college-photos college-info-boxes",
                        children: e.jsx("div", {
                            className: "college-photos-box",
                            ref: o,
                            children: n.map((a, l) => e.jsx("img", {
                                src: a,
                                alt: "college photo",
                                className: "slide"
                            }, l))
                        })
                    }), e.jsxs("aside", {
                        className: "college-detail college-info-boxes",
                        children: [e.jsx("h1", {
                            children: "M.P.C Autonomous College "
                        }), e.jsx("p", {
                            children: "Curious about the rich history of our college? This article unveils its rich history, remarkable milestones, and enduring impact on generations of learners."
                        }), e.jsx("br", {}), e.jsx("p", {
                            children: "Named in honor of the visionary Maharaja Purna Chandra Bhanja Deo, the progressive ruler of the former princely state of Mayurbhanj, our college has been a beacon of higher education since July 1948. For decades, it has not only served the educational aspirations of Odisha but also welcomed learners from neighboring states, fostering a vibrant and diverse academic community."
                        }), e.jsx("br", {}), e.jsx("p", {
                            children: "Over the years, the institution has flourished, reaching new heights of excellence and adding countless accolades to its ever-growing legacy of success...."
                        }), e.jsxs(f, {
                            to: "/article-section/colleges-article/mpc-article",
                            children: ["Explore ", e.jsx("span", {
                                style: {
                                    color: "#fff",
                                    fontWeight: "900"
                                },
                                children: "↗"
                            })]
                        })]
                    })]
                }), e.jsx("div", {
                    className: "ads-center",
                    children: e.jsx(z, {
                        background: "var( --notificationbackcolor )"
                    })
                })]
            })
        })
    },
    le = c => {
        const [t, o] = s.useState(!1), n = P(), [a, l] = s.useState(!1), [i, d] = s.useState(""), [g, j] = s.useState(!1), {
            showAlart: w
        } = s.useContext(F), [u, k] = s.useState({
            firstName: "",
            lastName: "",
            gmail: "",
            message: ""
        }), r = y => {
            const {
                name: h,
                value: C
            } = y.target;
            k({ ...u,
                [h]: [C]
            })
        }, v = async y => {
            y.preventDefault(), d(" "), l(!0);
            try {
                (await R.get("/api/connectusdata", {
                    params: u
                })).status === 200 && (l(!1), j(!0), k({
                    firstName: "",
                    lastName: "",
                    gmail: "",
                    message: ""
                }))
            } catch {
                l(!1), d("Message not sent!")
            }
        };
        return s.useEffect(() => {
            t ? document.body.style.overflow = "hidden" : document.body.style.overflowY = "scroll"
        }, [t]), e.jsxs("section", {
            id: "website-info",
            children: [e.jsx("div", {
                className: "studyvault-logo",
                children: e.jsx("img", {
                    src: A,
                    alt: ""
                })
            }), e.jsxs("div", {
                className: "website-info-msg",
                children: [e.jsxs("h1", {
                    children: ["The Future of Exam  ", e.jsx("br", {}), "Preparation Starts Here!"]
                }), e.jsx("h2", {
                    children: "Small step to make your exam easy."
                }), e.jsxs("h3", {
                    children: ["This  website is running in our own fund. ", e.jsx("br", {}), "Support our mission by donating to help us grow."]
                }), e.jsx("button", {
                    className: "active",
                    onClick: () => n("/payment-donate-us"),
                    children: "Donate Us"
                }), e.jsxs("h3", {
                    children: ["Connect with Us ", e.jsx("br", {}), " for advertising opportunities and reach a wider audience!"]
                }), e.jsx("button", {
                    className: "active",
                    onClick: () => o(!0),
                    children: "Connect Us"
                }), e.jsx("div", {
                    className: "connectus-popup",
                    style: t ? {
                        transform: "scale(1)"
                    } : {
                        transform: "scale(0)"
                    },
                    children: g ? e.jsxs("div", {
                        className: "connectus-popup-msg",
                        style: t ? {
                            transform: "scale(1)",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            flexDirection: "column"
                        } : {
                            transform: "scale(0)"
                        },
                        children: [e.jsx("i", {
                            className: "fa-regular fa-circle-check",
                            style: {
                                color: "green",
                                fontSize: "9rem"
                            }
                        }), e.jsx("span", {
                            style: {
                                color: "green",
                                fontSize: "1.8rem ",
                                fontWeight: "600",
                                textAlign: "center"
                            },
                            children: "Successfully Message send."
                        }), e.jsx("button", {
                            onClick: () => {
                                o(!1), j(!1)
                            },
                            children: "Done"
                        })]
                    }) : e.jsxs("div", {
                        className: "connectus-popup-msg",
                        style: t ? {
                            transform: "scale(1)"
                        } : {
                            transform: "scale(0)"
                        },
                        children: [e.jsx("div", {
                            className: "connectus-popup-close",
                            onClick: () => {
                                o(!1), d("")
                            },
                            children: "x"
                        }), e.jsxs("aside", {
                            children: [e.jsx("img", {
                                src: A,
                                alt: "studyvault-logo"
                            }), e.jsx("br", {}), e.jsx("small", {
                                children: "Partner with us to showcase your brand—connect now to explore exciting advertising opportunities on our platform!"
                            })]
                        }), e.jsx("div", {
                            children: e.jsxs("form", {
                                action: "GET",
                                onSubmit: v,
                                children: [e.jsxs("div", {
                                    className: "connectus-input-box",
                                    children: [e.jsx("input", {
                                        type: "text",
                                        name: "firstName",
                                        onChange: r,
                                        value: u.firstName,
                                        placeholder: "First Name",
                                        required: !0
                                    }), e.jsx("input", {
                                        type: "text",
                                        name: "lastName",
                                        onChange: r,
                                        value: u.lastName,
                                        placeholder: "Last Name",
                                        required: !0
                                    }), e.jsx("input", {
                                        type: "gmail",
                                        name: "gmail",
                                        onChange: r,
                                        value: u.gmail,
                                        placeholder: "Your Gmail",
                                        required: !0
                                    })]
                                }), e.jsx("textarea", {
                                    name: "message",
                                    id: "",
                                    cols: "40",
                                    rows: "5",
                                    value: u.message,
                                    onChange: r,
                                    placeholder: "Type Message Here",
                                    required: !0
                                }), e.jsxs("button", {
                                    disabled: a,
                                    style: a ? {
                                        background: "rgb(132, 173, 238)"
                                    } : {
                                        background: ""
                                    },
                                    type: "submit",
                                    className: "active",
                                    children: [a ? e.jsx("div", {
                                        className: "loader"
                                    }) : "Send", "  "]
                                })]
                            })
                        }), i && e.jsx("p", {
                            style: {
                                margin: "1rem 0",
                                color: "red"
                            },
                            children: i
                        })]
                    })
                }), e.jsx("div", {
                    style: {
                        height: "0.2rem",
                        width: "90%",
                        background: "#fff",
                        margin: "0rem auto 1rem",
                        display: "block",
                        borderRadius: "1rem"
                    }
                })]
            })]
        })
    },
    me = c => e.jsxs(e.Fragment, {
        children: [e.jsxs(x, {
            children: [" ", e.jsx(W, {
                navRefvalue: c.navRefvalue
            })]
        }), e.jsxs(x, {
            children: [" ", e.jsx(Z, {
                title: "Your StudyVault",
                titlepara: "Welcome to StudyVault, Get all Previous Year Question Papers of M.P.C Autonomous college. We shall try to provides note also. So I gonna help you in your all exams if you make me your exam Bff😊. "
            })]
        }), e.jsxs(x, {
            children: ["  ", e.jsx(J, {})]
        }), e.jsx(Y, {}), e.jsxs(x, {
            children: ["  ", e.jsx(_, {})]
        }), e.jsxs(x, {
            children: ["  ", e.jsx(ae, {})]
        }), e.jsxs(x, {
            children: ["  ", e.jsx(le, {
                showAlart: c.showAlart
            })]
        }), e.jsxs(x, {
            children: ["  ", e.jsx(Q, {})]
        })]
    });
export {
    me as
    default
};